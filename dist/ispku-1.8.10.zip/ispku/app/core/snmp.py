"""Klien SNMP v2c yang sangat kecil: `get` dan `walk` saja.

Ditulis sendiri di atas soket UDP supaya tidak menambah pustaka ke image —
yang dibutuhkan aplikasi hanya membaca beberapa OID standar (identitas
sistem dan tabel antarmuka), bukan seluruh protokolnya. Hanya membaca:
tidak ada SET, tidak ada v3.
"""

import os
import socket

INTEGER, OCTET, NULL, OID, SEQUENCE = 0x02, 0x04, 0x05, 0x06, 0x30
IPADDRESS, COUNTER32, GAUGE32, TIMETICKS, OPAQUE, COUNTER64 = 0x40, 0x41, 0x42, 0x43, 0x44, 0x46
NO_SUCH_OBJECT, NO_SUCH_INSTANCE, END_OF_MIB = 0x80, 0x81, 0x82
GET, GETNEXT, RESPONSE, GETBULK = 0xA0, 0xA1, 0xA2, 0xA5

UKURAN_MAKS = 65535


class GalatSnmp(Exception):
    """Perangkat tidak menjawab, menolak, atau jawabannya tidak bisa dibaca."""


# ── BER ─────────────────────────────────────────────────────────────────────

def _panjang(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    isi = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(isi)]) + isi


def _tlv(tag: int, isi: bytes) -> bytes:
    return bytes([tag]) + _panjang(len(isi)) + isi


def _int(nilai: int, tag: int = INTEGER) -> bytes:
    panjang = max(1, (nilai.bit_length() + 8) // 8)
    return _tlv(tag, nilai.to_bytes(panjang, "big", signed=True))


def _oid(teks: str) -> bytes:
    bagian = [int(b) for b in teks.strip(".").split(".")]
    if len(bagian) < 2:
        raise GalatSnmp(f"OID '{teks}' tidak sah.")
    isi = bytearray([bagian[0] * 40 + bagian[1]])
    for angka in bagian[2:]:
        potong = [angka & 0x7F]
        angka >>= 7
        while angka:
            potong.append(0x80 | (angka & 0x7F))
            angka >>= 7
        isi.extend(reversed(potong))
    return _tlv(OID, bytes(isi))


def _baca(data: bytes, pos: int) -> tuple[int, bytes, int]:
    """Satu TLV mulai `pos`: `(tag, isi, posisi sesudahnya)`."""
    try:
        tag = data[pos]
        panjang = data[pos + 1]
        pos += 2
        if panjang & 0x80:
            jumlah = panjang & 0x7F
            panjang = int.from_bytes(data[pos:pos + jumlah], "big")
            pos += jumlah
        isi = data[pos:pos + panjang]
        if len(isi) != panjang:
            raise IndexError
        return tag, isi, pos + panjang
    except IndexError as galat:
        raise GalatSnmp("Jawaban SNMP terpotong.") from galat


def _oid_teks(isi: bytes) -> str:
    if not isi:
        return ""
    bagian = [isi[0] // 40, isi[0] % 40]
    angka = 0
    for bait in isi[1:]:
        angka = (angka << 7) | (bait & 0x7F)
        if not bait & 0x80:
            bagian.append(angka)
            angka = 0
    return ".".join(str(b) for b in bagian)


def _nilai(tag: int, isi: bytes):
    if tag == INTEGER:
        return int.from_bytes(isi, "big", signed=True)
    if tag in (COUNTER32, GAUGE32, TIMETICKS, COUNTER64):
        return int.from_bytes(isi, "big")
    if tag == OCTET:
        return isi
    if tag == OID:
        return _oid_teks(isi)
    if tag == IPADDRESS:
        return ".".join(str(b) for b in isi)
    return None


def teks(nilai) -> str:
    """Nilai OCTET STRING sebagai teks yang aman ditampilkan."""
    if isinstance(nilai, bytes):
        hasil = nilai.decode("utf-8", errors="replace")
        return "".join(h for h in hasil if h.isprintable()).strip()
    return "" if nilai is None else str(nilai)


# ── Pesan ───────────────────────────────────────────────────────────────────

def _permintaan(jenis: int, community: str, id_permintaan: int, oid: list[str],
                non_repeaters: int = 0, max_repetitions: int = 0) -> bytes:
    ikatan = b"".join(_tlv(SEQUENCE, _oid(satu) + _tlv(NULL, b"")) for satu in oid)
    pdu = _tlv(
        jenis,
        _int(id_permintaan) + _int(non_repeaters) + _int(max_repetitions) + _tlv(SEQUENCE, ikatan),
    )
    return _tlv(SEQUENCE, _int(1) + _tlv(OCTET, community.encode()) + pdu)


def _urai_jawaban(data: bytes, id_permintaan: int) -> list[tuple[str, int, object]]:
    tag, pesan, _ = _baca(data, 0)
    if tag != SEQUENCE:
        raise GalatSnmp("Jawaban bukan pesan SNMP.")
    _, _versi, pos = _baca(pesan, 0)
    _, _community, pos = _baca(pesan, pos)
    tag, pdu, _ = _baca(pesan, pos)
    if tag != RESPONSE:
        raise GalatSnmp("Jawaban SNMP berjenis tak terduga.")
    _, id_isi, pos = _baca(pdu, 0)
    if int.from_bytes(id_isi, "big", signed=True) != id_permintaan:
        raise GalatSnmp("Jawaban SNMP tidak cocok dengan permintaannya.")
    _, status, pos = _baca(pdu, pos)
    _, _indeks, pos = _baca(pdu, pos)
    if int.from_bytes(status, "big"):
        raise GalatSnmp(f"Perangkat menjawab galat SNMP {int.from_bytes(status, 'big')}.")
    _, ikatan, _ = _baca(pdu, pos)

    hasil = []
    pos = 0
    while pos < len(ikatan):
        _, satu, pos = _baca(ikatan, pos)
        _, oid_isi, lanjut = _baca(satu, 0)
        tag_nilai, nilai_isi, _ = _baca(satu, lanjut)
        hasil.append((_oid_teks(oid_isi), tag_nilai, _nilai(tag_nilai, nilai_isi)))
    return hasil


class Klien:
    """Satu perangkat, satu soket. Pakai sebagai pengelola konteks."""

    def __init__(self, host: str, community: str, port: int = 161,
                 tenggat: float = 2.0, ulang: int = 1):
        self.alamat = (host, port)
        self.community = community
        self.tenggat = tenggat
        self.ulang = ulang
        self._id = int.from_bytes(os.urandom(3), "big")
        self._soket = None

    def __enter__(self):
        try:
            info = socket.getaddrinfo(self.alamat[0], self.alamat[1], type=socket.SOCK_DGRAM)[0]
        except OSError as galat:
            raise GalatSnmp(f"Alamat '{self.alamat[0]}' tidak bisa dikenali.") from galat
        self._soket = socket.socket(info[0], socket.SOCK_DGRAM)
        self._soket.settimeout(self.tenggat)
        self._tujuan = info[4]
        return self

    def __exit__(self, *_):
        if self._soket is not None:
            self._soket.close()

    def _kirim(self, jenis: int, oid: list[str], **pilihan) -> list:
        self._id = (self._id + 1) & 0x7FFFFFFF
        paket = _permintaan(jenis, self.community, self._id, oid, **pilihan)
        for _ in range(self.ulang + 1):
            try:
                self._soket.sendto(paket, self._tujuan)
                while True:
                    data, _ = self._soket.recvfrom(UKURAN_MAKS)
                    try:
                        return _urai_jawaban(data, self._id)
                    except GalatSnmp as galat:
                        # Jawaban telat dari permintaan sebelumnya: tunggu yang benar.
                        if "tidak cocok" not in str(galat):
                            raise
            except socket.timeout:
                continue
            except OSError as galat:
                raise GalatSnmp(f"Tidak bisa menghubungi perangkat: {galat}.") from galat
        raise GalatSnmp(
            "Perangkat tidak menjawab SNMP. Periksa alamat, community, dan apakah "
            "SNMP v2c diizinkan dari server ini."
        )

    def get(self, oid: list[str]) -> dict[str, object]:
        """Nilai beberapa OID; yang tidak ada di perangkat bernilai `None`."""
        return {
            nama: (None if tag in (NO_SUCH_OBJECT, NO_SUCH_INSTANCE, END_OF_MIB) else nilai)
            for nama, tag, nilai in self._kirim(GET, oid)
        }

    def walk(self, akar: str, batas: int = 5000) -> dict[str, object]:
        """Seluruh nilai di bawah `akar`, berkunci akhiran OID-nya."""
        akar = akar.strip(".")
        awalan = akar + "."
        hasil: dict[str, object] = {}
        kini = akar
        while len(hasil) < batas:
            baris = self._kirim(GETBULK, [kini], non_repeaters=0, max_repetitions=24)
            if not baris:
                break
            maju = False
            for nama, tag, nilai in baris:
                if tag == END_OF_MIB or not nama.startswith(awalan):
                    return hasil
                if nama == kini or nama[len(awalan):] in hasil:
                    return hasil
                hasil[nama[len(awalan):]] = nilai
                kini = nama
                maju = True
            if not maju:
                break
        return hasil
