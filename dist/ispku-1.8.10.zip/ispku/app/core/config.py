from dataclasses import dataclass, field
import zoneinfo

FORBIDDEN_SECRET_KEY = "GANTI-NILAI-INI-SEBELUM-DIPAKAI"


class ConfigError(Exception):
    """Konfigurasi tidak sah; aplikasi tidak boleh berjalan."""


# Satu-satunya tempat versi aplikasi ditulis. `tools/buat-paket.sh`
# menaikkan baris ini; jangan menyalinnya ke berkas lain.
VERSI_APLIKASI = "1.8.10"


@dataclass(frozen=True)
class Config:
    SECRET_KEY: str = field(repr=False)
    DATABASE_URL: str
    APP_TIMEZONE: str
    HTTPS_ONLY: bool
    TRUSTED_PROXIES: int
    UPLOAD_DIR: str
    BACKUP_DIR: str
    APP_VERSION: str
    LICENSE_PUBLIC_KEY: str
    LANDING_ENABLED: bool
    SMTP_HOST: str
    SMTP_PORT: int
    SMTP_USER: str
    SMTP_PASSWORD: str = field(repr=False)
    SMTP_FROM: str
    SMTP_USE_TLS: bool
    GOOGLE_OAUTH_CLIENT_ID: str
    GOOGLE_OAUTH_CLIENT_SECRET: str = field(repr=False)


def _as_bool(value: str, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _as_int(value: str, default: int) -> int:
    if value is None or value == "":
        return default
    return int(value)


def _proxy_terpercaya(value: str) -> int:
    """Jumlah reverse proxy di depan aplikasi yang header-nya dipercaya.

    Dibatasi 0–5: angka lebih besar dari jumlah proxy yang sungguh ada
    membuat alamat kiriman klien sendiri ikut dipercaya.
    """
    try:
        jumlah = _as_int(value, 0)
    except ValueError:
        jumlah = -1
    if not 0 <= jumlah <= 5:
        raise ConfigError(
            f"TRUSTED_PROXIES '{value}' tidak sah. Isi 0 bila aplikasi dibuka "
            "langsung, atau 1 bila berada di belakang satu reverse proxy "
            "(nginx)."
        )
    return jumlah


def _valid_timezone(value: str) -> str:
    name = (value or "Asia/Jakarta").strip()
    if name not in zoneinfo.available_timezones():
        raise ConfigError(
            f"APP_TIMEZONE '{name}' tidak dikenal. Contoh nilai sah: Asia/Jakarta."
        )
    return name


def load_config(env: dict) -> Config:
    secret_key = (env.get("APP_SECRET_KEY") or "").strip()
    if not secret_key:
        raise ConfigError(
            "APP_SECRET_KEY belum diisi. Isi dengan nilai acak yang panjang "
            "sebelum menjalankan aplikasi."
        )
    if secret_key == FORBIDDEN_SECRET_KEY:
        raise ConfigError(
            "APP_SECRET_KEY masih memakai nilai contoh dari .env.example. "
            "Ganti dengan nilai acak yang panjang."
        )

    database_url = (env.get("DATABASE_URL") or "").strip()
    if not database_url:
        raise ConfigError("DATABASE_URL belum diisi.")

    smtp_user = (env.get("SMTP_USER") or "").strip()
    smtp_use_tls = _as_bool(env.get("SMTP_USE_TLS"), True)
    if smtp_user and not smtp_use_tls:
        raise ConfigError(
            "SMTP_USER diisi tetapi SMTP_USE_TLS=false. Kredensial SMTP tidak "
            "boleh dikirim lewat koneksi tanpa enkripsi. Aktifkan SMTP_USE_TLS "
            "atau kosongkan SMTP_USER."
        )

    return Config(
        SECRET_KEY=secret_key,
        DATABASE_URL=database_url,
        APP_TIMEZONE=_valid_timezone(env.get("APP_TIMEZONE")),
        HTTPS_ONLY=_as_bool(env.get("HTTPS_ONLY"), False),
        TRUSTED_PROXIES=_proxy_terpercaya(env.get("TRUSTED_PROXIES")),
        UPLOAD_DIR=(env.get("UPLOAD_DIR") or "/data/uploads").strip(),
        # Volume tersendiri, bukan anak `UPLOAD_DIR`: cadangan berisi seluruh
        # basis data dan tidak boleh ikut terhapus saat volume unggahan
        # dibersihkan.
        BACKUP_DIR=(env.get("BACKUP_DIR") or "/data/backups").strip(),
        # Versi tidak dibaca dari lingkungan. Dulu `.env` boleh menimpanya,
        # dan pemasangan yang diperbarui terus mengaku versi lama di kaki
        # sidebar karena `.env`-nya tidak pernah ikut diperbarui.
        APP_VERSION=VERSI_APLIKASI,
        # Kunci publik penerbit lisensi. Kosong berarti memakai kunci
        # penerbit resmi yang tertanam di `app/core/lisensi.py`.
        LICENSE_PUBLIC_KEY=(env.get("LICENSE_PUBLIC_KEY") or "").strip(),
        # Situs jualan mati secara bawaan: pemasangan pelanggan tidak butuh
        # halaman iklan di servernya sendiri.
        LANDING_ENABLED=_as_bool(env.get("LANDING_ENABLED"), False),
        SMTP_HOST=(env.get("SMTP_HOST") or "").strip(),
        SMTP_PORT=_as_int(env.get("SMTP_PORT"), 587),
        SMTP_USER=smtp_user,
        SMTP_PASSWORD=env.get("SMTP_PASSWORD") or "",
        SMTP_FROM=(env.get("SMTP_FROM") or "").strip(),
        SMTP_USE_TLS=smtp_use_tls,
        GOOGLE_OAUTH_CLIENT_ID=(env.get("GOOGLE_OAUTH_CLIENT_ID") or "").strip(),
        GOOGLE_OAUTH_CLIENT_SECRET=(
            env.get("GOOGLE_OAUTH_CLIENT_SECRET") or ""
        ).strip(),
    )
