"""Menarik identitas perangkat dan daftar port lewat SNMP v2c.

Hanya OID standar (MIB-II dan IF-MIB), jadi berlaku untuk hampir semua merek:
nama sistem, deskripsi, uptime, lalu tabel antarmuka — nama, status link,
kecepatan, dan deskripsinya. Port yang belum terdaftar dibuat; yang sudah ada
diperbarui. Tidak ada port yang dihapus, dan alokasi ke langganan tidak
disentuh.
"""

from app.core import audit, snmp
from app.core.errors import GalatDomain
from app.modules.inventory import pantau
from app.modules.inventory import service
from app.modules.inventory.models import DevicePort

SYS_DESCR, SYS_UPTIME, SYS_NAME = "1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.3.0", "1.3.6.1.2.1.1.5.0"
IF_DESCR, IF_TYPE, IF_SPEED, IF_OPER = (
    "1.3.6.1.2.1.2.2.1.2", "1.3.6.1.2.1.2.2.1.3", "1.3.6.1.2.1.2.2.1.5", "1.3.6.1.2.1.2.2.1.8",
)
IF_NAME, IF_HIGH_SPEED, IF_ALIAS = (
    "1.3.6.1.2.1.31.1.1.1.1", "1.3.6.1.2.1.31.1.1.1.15", "1.3.6.1.2.1.31.1.1.1.18",
)
TIPE_LOOPBACK = 24
BATAS_PORT = 2000


class SnmpGagal(GalatDomain):
    """Penarikan SNMP tidak bisa dijalankan atau perangkat tidak menjawab."""


def _klien_bawaan(host: str, community: str):
    return snmp.Klien(host, community)


def _angka(nilai) -> int | None:
    return nilai if isinstance(nilai, int) else None


def baca(klien) -> dict:
    """Identitas dan antarmuka dari satu klien SNMP yang sudah terbuka."""
    sistem = klien.get([SYS_NAME, SYS_DESCR, SYS_UPTIME])
    nama = klien.walk(IF_NAME) or {}
    deskripsi = klien.walk(IF_DESCR)
    status = klien.walk(IF_OPER)
    tipe = klien.walk(IF_TYPE)
    cepat_tinggi = klien.walk(IF_HIGH_SPEED) or {}
    cepat = klien.walk(IF_SPEED) if not cepat_tinggi else {}
    alias = klien.walk(IF_ALIAS) or {}

    antarmuka = []
    for indeks in sorted(deskripsi, key=lambda teks: int(teks) if teks.isdigit() else 0):
        if not indeks.isdigit() or _angka(tipe.get(indeks)) == TIPE_LOOPBACK:
            continue
        label = snmp.teks(nama.get(indeks)) or snmp.teks(deskripsi.get(indeks))
        if not label:
            continue
        mbps = _angka(cepat_tinggi.get(indeks))
        if mbps is None and _angka(cepat.get(indeks)) is not None:
            mbps = cepat[indeks] // 1_000_000
        antarmuka.append(
            {
                "indeks": int(indeks),
                "nama": label[:60],
                "naik": _angka(status.get(indeks)) == 1,
                "mbps": mbps or None,
                "alias": snmp.teks(alias.get(indeks))[:120] or None,
            }
        )
    uptime = _angka(sistem.get(SYS_UPTIME))
    return {
        "sysname": snmp.teks(sistem.get(SYS_NAME))[:255] or None,
        "sysdescr": snmp.teks(sistem.get(SYS_DESCR)) or None,
        "uptime_detik": uptime // 100 if uptime is not None else None,
        "antarmuka": antarmuka[:BATAS_PORT],
    }


def tarik(sesi, aktor, device_id: int, sekarang, klien_pabrik=_klien_bawaan) -> dict:
    perangkat = service.ambil_perangkat(sesi, aktor, device_id)
    host = pantau.host_dari(perangkat.mgmt_address)
    if not host:
        raise SnmpGagal("mgmt_address", "Isi Alamat Manajemen perangkat lebih dulu.")
    if not perangkat.snmp_community:
        raise SnmpGagal("snmp_community", "Isi Community SNMP di formulir perangkat lebih dulu.")

    try:
        with klien_pabrik(host, perangkat.snmp_community) as klien:
            data = baca(klien)
    except snmp.GalatSnmp as galat:
        raise SnmpGagal("snmp_community", str(galat)) from galat

    perangkat.snmp_sysname = data["sysname"]
    perangkat.snmp_sysdescr = data["sysdescr"]
    perangkat.snmp_uptime_seconds = data["uptime_detik"]
    perangkat.snmp_synced_at = sekarang

    ada = service.daftar_port(sesi, aktor, device_id)
    per_indeks = {p.snmp_index: p for p in ada if p.snmp_index is not None}
    per_nama = {p.name: p for p in ada}
    dibuat = diperbarui = 0
    terlihat: set[int] = set()
    for satu in data["antarmuka"]:
        port = per_indeks.get(satu["indeks"]) or per_nama.get(satu["nama"])
        if port is None:
            port = DevicePort(
                device_id=perangkat.id, branch_id=perangkat.branch_id,
                name=satu["nama"], kind="access", status="bebas",
            )
            sesi.add(port)
            per_nama[satu["nama"]] = port
            dibuat += 1
        elif port.id in terlihat:
            # Dua antarmuka bernama sama di perangkat: yang kedua dilewati,
            # karena nama port unik per perangkat.
            continue
        else:
            diperbarui += 1
        port.snmp_index = satu["indeks"]
        port.oper_status = "naik" if satu["naik"] else "turun"
        port.alias = satu["alias"]
        if satu["mbps"]:
            port.speed_mbps = satu["mbps"]
        sesi.flush()
        terlihat.add(port.id)

    # Port lama yang tidak lagi dilaporkan perangkat: status link-nya dikosongkan
    # supaya tidak menampilkan keadaan basi. Portnya sendiri tidak dihapus.
    for port in ada:
        if port.id not in terlihat and port.snmp_index is not None:
            port.oper_status = None
    sesi.flush()

    hasil = {"dibuat": dibuat, "diperbarui": diperbarui, "antarmuka": len(data["antarmuka"])}
    audit.record(
        sesi, "update", "device", perangkat.id,
        after={"snmp_tarik": hasil, "snmp_sysname": perangkat.snmp_sysname}, aktor=aktor,
    )
    return hasil
