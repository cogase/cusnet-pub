"""SNMP dasar: identitas perangkat dan status port

Revision ID: 0033
Revises: 0032
Create Date: 2026-10-08 23:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0033"
down_revision: Union[str, None] = "0032"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("device", sa.Column("snmp_community", sa.String(80), nullable=True))
    op.add_column("device", sa.Column("snmp_sysname", sa.String(255), nullable=True))
    op.add_column("device", sa.Column("snmp_sysdescr", sa.Text(), nullable=True))
    op.add_column("device", sa.Column("snmp_uptime_seconds", sa.BigInteger(), nullable=True))
    op.add_column(
        "device", sa.Column("snmp_synced_at", sa.DateTime(timezone=True), nullable=True)
    )
    op.add_column("device_port", sa.Column("snmp_index", sa.Integer(), nullable=True))
    op.add_column("device_port", sa.Column("oper_status", sa.String(10), nullable=True))
    op.add_column("device_port", sa.Column("alias", sa.String(120), nullable=True))


def downgrade() -> None:
    for kolom in ("alias", "oper_status", "snmp_index"):
        op.drop_column("device_port", kolom)
    for kolom in ("snmp_synced_at", "snmp_uptime_seconds", "snmp_sysdescr",
                  "snmp_sysname", "snmp_community"):
        op.drop_column("device", kolom)
