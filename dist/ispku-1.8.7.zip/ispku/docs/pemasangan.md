# Pemasangan ISPKU

Dokumen ini untuk teknisi yang memasang ISPKU di server pelanggan
(on-premise). **Memasang dari server kosong untuk pertama kali?** Ikuti
[`panduan-instal-debian.md`](panduan-instal-debian.md) — langkah demi
langkah sampai HTTPS, termasuk nginx, sertifikat, firewall, dan cron. Dokumen
ini rujukan lengkapnya.

Ada dua jalur: **pemasang otomatis** (bagian 1, dianjurkan) dan **langkah
manual** (bagian 2, bila ingin mengendalikan tiap langkah sendiri). Keduanya
menghasilkan pemasangan yang sama.

Prasyarat untuk keduanya: Docker beserta plugin `docker compose`. Contoh
perintah di bawah menganggap folder pemasangan `/opt/ispku`.

---

## 1. Pemasang otomatis

```bash
./install.sh
```

Yang dikerjakannya, berurutan:

1. Memeriksa Docker dan `docker compose` ada.
2. Membuat `.env` dari `.env.example` bila belum ada, lalu **mengisi
   `APP_SECRET_KEY` dan `POSTGRES_PASSWORD` dengan nilai acak**. `.env` yang
   sudah ada tidak pernah disentuh.
3. Membuat cadangan basis data bila pemasangan lama sedang berjalan — dan
   berhenti bila cadangan itu gagal.
4. Membangun image lalu menjalankan `docker-compose.prod.yml`.
5. Menunggu `/healthz` menjawab, lalu menanyakan data superadmin pertama
   secara interaktif bila belum ada superadmin (password diminta dua kali).
6. Menanam kategori layanan bawaan (`flask seed-master`, aman diulang).

Skrip ini aman dijalankan berulang. **Menjalankannya ulang setelah berkas
sumber diperbarui (zip baru atau `git pull`) adalah cara memperbarui versi**:
cadangan dibuat lebih dulu, image dibangun ulang, dan migrasi berjalan
sendiri saat kontainer baru start.

Selesai, aplikasi ada di `http://<alamat-server>:6060` (ubah lewat `APP_PORT`
di `.env`).

### Memperbarui dari repositori paket publik

Jika paket dipublikasikan ke `https://github.com/cogase/cusnet-pub`, clone
sekali di server pelanggan:

```bash
git clone https://github.com/cogase/cusnet-pub.git /opt/cusnet-pub
```

Setiap kali ada versi baru, ambil paket dan pasang seperti berikut. Perintah
ini memilih ZIP bernomor versi tertinggi, lalu memeriksa checksum sebelum
mengekstrak:

```bash
cd /opt/cusnet-pub
git pull --ff-only
cd dist
PAKET=$(find . -maxdepth 1 -type f -name 'ispku-*.zip' -printf '%f\n' | sort -V | tail -n 1)
sha256sum -c "$PAKET.sha256"
unzip -o "$PAKET" -d /opt
cd /opt/ispku
./install.sh
```

`install.sh` membuat cadangan basis data sebelum membangun dan menjalankan
versi baru. `git pull` hanya mengunduh paket; ekstraksi dan menjalankan
installer tetap diperlukan agar aplikasi diperbarui.

Nama proyek compose dipatok `ispku` di `docker-compose.prod.yml`, jadi volume
selalu bernama `ispku_pgdata`, `ispku_uploads`, `ispku_backups` di folder
mana pun berkasnya diekstrak. Dua pemasangan di satu host: setel
`COMPOSE_PROJECT_NAME` (dan `APP_PORT`) berbeda di `.env` masing-masing.
Pemasangan yang dibuat **sebelum 1.7.0** memakai nama folder sebagai nama
proyek — tambahkan `COMPOSE_PROJECT_NAME=<nama-folder-lama>` ke `.env`-nya
sebelum memperbarui, kalau tidak ia menyala dengan basis data kosong.

### Compose pengembangan vs compose pemasangan

| | `docker-compose.yml` | `docker-compose.prod.yml` |
|---|---|---|
| Kode | di-mount dari host | ikut di dalam image |
| Sandi Postgres | `cusnet` tetap | dari `.env` |
| Nyala ulang otomatis | tidak | `unless-stopped` |
| Volume cadangan | tidak ada | `backups:/data/backups` |

Untuk pemasangan di server pelanggan, **selalu** pakai yang `.prod.yml`.

---

## 2. Langkah manual

### 2.1 Siapkan berkas konfigurasi

```bash
cp .env.example .env
```

Berkas `.env` inilah yang dibaca aplikasi saat start. Jangan mengedit
`.env.example` — berkas itu hanya templat dan ikut disimpan di repositori.

### 2.2 Ganti APP_SECRET_KEY dan POSTGRES_PASSWORD

Nilai `APP_SECRET_KEY` bawaan di `.env.example` adalah nilai contoh yang sama
di setiap instalasi, sehingga tidak boleh dipakai apa adanya — siapa pun yang
tahu nilai contoh itu bisa memalsukan sesi login di instalasi Anda. Buat nilai
acak yang panjang:

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(64))"
```

Tempelkan hasilnya ke `APP_SECRET_KEY` di `.env`. Aplikasi sengaja menolak
untuk start bila nilai ini masih sama dengan nilai contoh, jadi langkah ini
tidak bisa dilewati.

Lakukan hal yang sama untuk `POSTGRES_PASSWORD`, dan **pastikan sandi yang
sama ikut tertulis di `DATABASE_URL`** — keduanya harus cocok.

### 2.3 Tentukan HTTPS_ONLY

Setel `HTTPS_ONLY=true` bila server ini dipasang di belakang reverse proxy TLS
(HTTPS). Bila `false`, cookie sesi dikirim tanpa flag `Secure`, artinya cookie
itu bisa disadap di jaringan yang tidak terenkripsi. Jangan pasang dengan
`HTTPS_ONLY=false` di jaringan publik — nilai itu hanya aman untuk pengujian
lokal atau jaringan tertutup yang terpercaya. Halaman Pengaturan → Sistem
menampilkan peringatan selama nilainya masih `false`.

### 2.3a Di belakang reverse proxy: TRUSTED_PROXIES dan APP_BIND

Bila nginx (atau reverse proxy lain) di server yang sama meneruskan
permintaan ke aplikasi, setel ketiganya bersama:

```
HTTPS_ONLY=true
TRUSTED_PROXIES=1
APP_BIND=127.0.0.1
```

- `TRUSTED_PROXIES=1` membuat aplikasi membaca alamat klien dari
  `X-Forwarded-For` dan skema dari `X-Forwarded-Proto` yang dipasang proxy.
  Tanpa itu, semua pengguna terbaca satu alamat (alamat proxy): pembatas
  percobaan login mengunci **semua orang** begitu ada sepuluh salah ketik
  dari siapa pun, dan audit log mencatat alamat yang sama di tiap baris.
- `APP_BIND=127.0.0.1` membuat port aplikasi hanya bisa dibuka dari server
  itu sendiri. **Wajib** bersama `TRUSTED_PROXIES`: kalau port terbuka ke
  luar, siapa pun bisa mengirim `X-Forwarded-For` karangan tanpa lewat proxy.
  Docker membuka port dengan aturan iptables-nya sendiri, jadi ufw tidak
  bisa menggantikan pengaturan ini.

Proxy wajib meneruskan `X-Forwarded-For` dan `X-Forwarded-Proto` (ditambah
`Host`, supaya aplikasi melihat nama domain asli). Templat yang sudah benar: `deploy/nginx-ispku.conf` (dengan domain +
certbot) dan `deploy/nginx-ispku-ip.conf` (tanpa domain, self-signed).

Terapkan perubahan `.env` dengan `./install.sh` atau
`docker compose -f docker-compose.prod.yml up -d` — **bukan** `restart`, yang
tidak membaca ulang `.env`.

### 2.4 Isi pengaturan SMTP (opsional)

Bila invoice akan dikirim ke pelanggan lewat email, isi `SMTP_HOST`,
`SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, dan `SMTP_USE_TLS`.
Bila belum ada rencana mengirim email dari aplikasi, kolom-kolom ini boleh
dikosongkan dan diisi belakangan lewat halaman Pengaturan Billing.

### 2.5 Nyalakan aplikasi

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

Migrasi basis data berjalan otomatis setiap kali kontainer aplikasi start
(lihat `docker-entrypoint.sh`), jadi tidak ada perintah migrasi terpisah yang
perlu dijalankan manual.

### 2.6 Buat superadmin pertama

```bash
docker compose -f docker-compose.prod.yml exec app flask seed-superadmin \
  --username admin --email admin@contoh.id \
  --password "kata-sandi-anda" --nama "Super Admin"
```

**Peringatan keamanan:** nilai yang Anda ketik di `--password` terlihat oleh
pengguna lain di server yang sama lewat perintah `ps aux` selama proses
berjalan, dan tersimpan apa adanya di riwayat shell (`~/.bash_history` atau
sejenisnya) setelah selesai. Jalankan perintah ini hanya di server yang tidak
dipakai bersama pengguna lain, lalu segera masuk ke aplikasi dan ganti
password itu. Jangan memakai password sementara ini sebagai password permanen.
`install.sh` menanyakannya secara interaktif justru untuk menghindari ini.

Setelah dibuat, superadmin bisa masuk lewat
`http://<alamat-server>:6060/masuk`.

---

## 3. Cadangan dan pemulihan

### 3.1 Membuat cadangan

Lewat aplikasi: **Pengaturan → Sistem → Buat cadangan sekarang**. Berkasnya
masuk ke `BACKUP_DIR` (bawaan `/data/backups`, volume `backups`) dan bisa
diunduh dari halaman yang sama.

Lewat baris perintah:

```bash
docker compose -f docker-compose.prod.yml exec app flask backup-db
```

Berkas berformat custom `pg_dump` (`.dump`), bukan SQL polos.

**Berkas cadangan berisi seluruh basis data** — data pribadi pelanggan, NPWP,
dan hash sandi pengguna. Simpan di tempat yang keamanannya setara dengan
server ini, dan salin ke luar server supaya kerusakan disk tidak ikut
menghabiskan cadangannya.

Menjadwalkan cadangan harian lewat cron di host:

```cron
0 2 * * * cd /opt/ispku && docker compose -f docker-compose.prod.yml exec -T app flask backup-db
```

### 3.2 Memulihkan

Lewat aplikasi: **Pengaturan → Sistem → Pemulihan Basis Data**, pilih
berkasnya, ketik `PULIHKAN`, kirim.

Lewat baris perintah:

```bash
docker compose -f docker-compose.prod.yml exec app \
  flask restore-db /data/backups/cusnet-20260808-210503.dump --paksa
```

**Pemulihan membuang seluruh data yang ada sekarang.** Invoice, pembayaran,
tiket, dan pengguna yang dibuat setelah cadangan itu akan hilang, dan tidak
ada pembatalan. Karena itu `--paksa` wajib di baris perintah, dan kata
`PULIHKAN` harus diketik di aplikasi.

Versi klien Postgres di dalam image dipatok mengikuti versi server (16). Bila
kelak server dinaikkan ke versi lain, `Dockerfile` harus ikut dinaikkan —
`pg_dump` yang lebih tua menolak basis data server yang lebih baru.

### 3.3 Sebelum menaikkan versi aplikasi

Migrasi berjalan otomatis begitu kontainer baru start, dan migrasi tidak bisa
dibatalkan tanpa cadangan. Karena itu **selalu buat cadangan lebih dulu**.
`install.sh` melakukannya sendiri; kalau memperbarui secara manual, jalankan
`flask backup-db` sebelum `up -d --build`.

---

## 4. Perawatan

### 4.1 Mereset password akun yang terkunci

Bila pemilik akun lupa password atau terkunci di luar aplikasinya sendiri
(termasuk akun superadmin):

```bash
docker compose -f docker-compose.prod.yml exec app flask reset-password --username admin
```

Perintah ini menanyakan password baru secara interaktif (dua kali, untuk
konfirmasi) — bukan lewat argumen `--password`, dengan alasan keamanan yang
sama seperti pada `seed-superadmin`.

**Wajib pakai `docker compose exec`, bukan `docker compose run`.** Dengan
`run`, prompt password interaktif tidak selalu tampil dengan benar karena
kontainer baru dibuat tanpa terhubung ke sesi terminal yang sama.

Bila akun yang direset sedang berstatus nonaktif, perintah ini otomatis
mengaktifkannya kembali — operator yang mereset password jelas ingin akun itu
bisa dipakai lagi.

### 4.2 Jadwalkan pengiriman email antrean

Bila SMTP dipakai, email invoice tidak langsung terkirim saat dibuat — email
masuk antrean dan baru dikirim saat perintah `mail-flush` dijalankan.
Jadwalkan lewat cron di host, misalnya tiap lima menit:

```cron
*/5 * * * * cd /opt/ispku && docker compose -f docker-compose.prod.yml exec -T app flask mail-flush
```

Tanpa jadwal ini, email yang mengantre tidak akan pernah terkirim walaupun
SMTP sudah dikonfigurasi dengan benar.

### 4.3 Jadwalkan pekerjaan harian billing

Satu perintah mengerjakan dua hal: menyimpan status lewat tempo, dan
mengantrekan pengingat tagihan. Jadwalkan sekali sehari, sesudah tengah malam
waktu setempat:

```cron
15 1 * * * cd /opt/ispku && docker compose -f docker-compose.prod.yml exec -T app flask billing-harian
```

Aman dijalankan berkali-kali: pengingat yang sudah pernah diantre tidak
diantre lagi, dan itu dijaga batasan unik di basis data — bukan pemeriksaan
aplikasi yang bisa balapan antar-worker.

**Jam yang dipakai aplikasi adalah `APP_TIMEZONE` di `.env`, bukan jam
kontainer.** Kontainer sengaja dibiarkan UTC; seluruh tanggal yang dihitung
aplikasi — tanggal terbit, jatuh tempo, tanggal pembayaran, batas bulan
laporan — mengikuti `APP_TIMEZONE`. Karena itu cron dini hari aman: perintah
di atas yang berjalan pukul 01.15 WIB tetap memakai tanggal hari itu, bukan
tanggal kemarin.

**Pengingat tagihan mati secara bawaan.** Sampai kolom *Pengingat Tagihan* di
**Pengaturan > Billing > Pengiriman Email** diisi, perintah ini hanya
menyegarkan status. Isinya daftar hari relatif jatuh tempo yang dipisah koma —
angka negatif berarti sebelum, positif berarti sesudah:

| Isi kolom | Artinya |
|---|---|
| *(kosong)* | pengingat mati |
| `-3` | sekali, tiga hari sebelum jatuh tempo |
| `-3, 1, 7` | tiga hari sebelum, sehari sesudah, seminggu sesudah |

Pengingat hanya **mengantre**; yang mengirim tetap `mail-flush` di §4.2, jadi
keduanya harus dijadwalkan. Invoice yang sudah lunas, dibatalkan, atau masih
draft tidak pernah diingatkan, begitu pula pelanggan yang belum punya kontak
beremail — jumlahnya dilaporkan perintah ini supaya tidak lewat begitu saja.

Menjalankan pekerjaan ini juga membuat halaman Billing tidak perlu menyimpan
status sendiri. Halamannya tetap memperlihatkan status yang benar walau cron
belum sempat berjalan — yang di layar dihitung, yang disimpan pekerjaan
terjadwal ini.

### 4.4 Membersihkan berkas kerja

Berkas impor CSV yang diunggah lalu ditinggalkan setelah pratinjau menumpuk
di volume unggahan. Jadwalkan pembersihnya sekali sehari:

```cron
30 3 * * * cd /opt/ispku && docker compose -f docker-compose.prod.yml exec -T app flask bersih-sementara
```

PDF lampiran email di `invoice-pdf/` **sengaja tidak** ikut dibuang: lampiran
yang hilang sebelum `mail-flush` sempat berjalan berarti tagihan terkirim
tanpa invoice-nya.

### 4.5 Menerbitkan invoice satu periode

```bash
docker compose -f docker-compose.prod.yml exec app flask billing-run --period 2026-09
```

Idempoten: mengulang periode yang sama tidak membuat invoice kedua.

---

## 5. Lisensi

Kunci lisensi dipasang lewat **Pengaturan → Lisensi**: tempelkan seluruh isi
kunci yang dikirim penjual, lalu simpan. Bisa juga lewat baris perintah:

```bash
docker compose -f docker-compose.prod.yml exec app flask license-apply --berkas /tmp/lisensi.txt
docker compose -f docker-compose.prod.yml exec app flask license-show
```

Yang perlu diketahui:

- **Aplikasi tidak pernah dimatikan oleh lisensi.** Ini perangkat lunak
  penagihan; menutup aplikasi karena lisensi lewat berarti invoice bulan itu
  tidak bisa terbit, dan kerugiannya jatuh ke pelanggan yang membayar.
  Lisensi yang tidak ada, kedaluwarsa, atau batasnya terlampaui hanya
  memunculkan peringatan untuk superadmin. Yang mengikuti masa berlaku adalah
  pembaruan versi dan dukungan.
- **Diperiksa tanpa jaringan.** Tanda tangan Ed25519 diverifikasi dengan kunci
  publik penerbit yang tertanam di aplikasi. Server tanpa akses internet
  keluar tetap bisa memakainya.
- Kunci disimpan di basis data, jadi ikut terbawa cadangan dan tidak perlu
  menyunting `.env` saat memperpanjang.
- Kunci yang tidak sah ditolak beserta alasannya; lisensi yang sedang berlaku
  tidak terhapus karenanya.

## 6. Situs jualan (opsional)

Halaman perkenalan produk ada di `/produk` dan **mati secara bawaan** —
pemasangan pelanggan tidak butuh halaman iklan di servernya sendiri. Untuk
instalasi demo, setel `LANDING_ENABLED=true` di `.env` lalu jalankan ulang.
`/` tidak berubah: tamu tetap dibawa ke halaman masuk.

## 7. Daftar variabel `.env`

| Variabel | Bawaan | Keterangan |
|---|---|---|
| `APP_SECRET_KEY` | — | Wajib, acak dan panjang. Aplikasi menolak start bila masih nilai contoh |
| `DATABASE_URL` | — | Wajib. Sandinya harus sama dengan `POSTGRES_PASSWORD` |
| `APP_TIMEZONE` | `Asia/Jakarta` | Zona waktu tampilan. Postgres sendiri tetap UTC |
| `HTTPS_ONLY` | `false` | `true` bila di belakang TLS |
| `TRUSTED_PROXIES` | `0` | Jumlah reverse proxy di depan aplikasi (0–5). `1` di belakang nginx; lihat 2.3a |
| `UPLOAD_DIR` | `/data/uploads` | Dokumen pelanggan, lampiran tiket, logo kop |
| `BACKUP_DIR` | `/data/backups` | Cadangan basis data. Volume tersendiri, sengaja |
| `SMTP_*` | kosong | Opsional; lihat 2.4 |
| `GOOGLE_OAUTH_*` | kosong | Login Google opsional, mati secara bawaan |
| `APP_PORT` | `6060` | Port di host. Hanya dibaca `docker-compose.prod.yml` |
| `APP_BIND` | `0.0.0.0` | Alamat host tempat port dibuka. `127.0.0.1` di belakang nginx; lihat 2.3a. Hanya dibaca `docker-compose.prod.yml` |
| `COMPOSE_PROJECT_NAME` | `ispku` | Tidak tercantum di `.env.example`. Hanya untuk dua pemasangan di satu host, atau pemasangan sebelum 1.7.0 |
| `POSTGRES_USER` | `cusnet` | Hanya dibaca `docker-compose.prod.yml` |
| `POSTGRES_PASSWORD` | — | Wajib di pemasangan. Hanya dibaca `docker-compose.prod.yml` |
| `POSTGRES_DB` | `cusnet` | Hanya dibaca `docker-compose.prod.yml` |
| `LICENSE_PUBLIC_KEY` | kosong | Kosong berarti memakai kunci penerbit resmi yang tertanam di aplikasi |
| `LANDING_ENABLED` | `false` | `true` menyalakan situs jualan di `/produk` |
