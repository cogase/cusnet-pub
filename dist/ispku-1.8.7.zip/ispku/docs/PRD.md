# CUSNET — Product Requirements & Design Standards

## Tujuan dokumen

Dokumen ini menetapkan persyaratan pengalaman produk dan standar visual
bersama CUSNET. Halaman dan menu baru wajib memakai token dan pola di sini,
bukan menciptakan nilai warna, ukuran, atau interaksi sendiri. Bila produk
membutuhkan pengecualian, jelaskan alasannya di dokumen fitur terkait dan
tetap utamakan aksesibilitas serta konsistensi.

## Arah produk

CUSNET adalah aplikasi operasional ISP untuk Customer, layanan, billing,
ticketing, inventaris jaringan, dan administrasi. Antarmuka harus terasa
tenang, dapat dipercaya, padat informasi tetapi mudah dipindai, serta tetap
efisien untuk pekerjaan berulang.

Prinsip:

- Dahulukan data dan tindakan yang membantu tugas harian; dekorasi tidak boleh
  mengalahkan informasi.
- Gunakan pola yang sama untuk daftar, formulir, status, dan navigasi di semua
  modul.
- Jangan tampilkan affordance palsu. Elemen yang terlihat seperti tombol,
  pencarian, atau tautan harus mempunyai perilaku nyata dan label yang jelas.
- Perubahan keadaan harus cepat, dapat dibalik bila aman, dan tidak
  menghilangkan data formulir yang belum disimpan.

## Design tokens

Implementasi sumber kebenaran berada di `app/static/css/tokens.css`; aturan
komponen berada di `app/static/css/app.css`. Template memakai token CSS,
bukan mengulang nilai literal.

### Palet warna

| Token | Nilai bawaan | Pemakaian |
| --- | --- | --- |
| `--bg` | `#f7f9fc` | Latar utama halaman |
| `--surface` | `#ffffff` | Kartu, input, menu popover |
| `--border` | `#e5e9f0` | Batas kartu, input, pemisah |
| `--text` | `#0f172a` | Teks utama dan angka |
| `--text-muted` | `#64748b` | Label sekunder, keterangan dan heading tabel |
| `--text-subtle` | `#94a3b8` | Metadata paling sekunder; jangan untuk instruksi penting |
| `--accent` | `#2563eb` | Aksi utama, tautan, pilihan aktif |
| `--accent-hover` | `#1d4ed8` | Hover aksi utama |
| `--accent-soft` | `#eff6ff` | Pilihan aktif ringan, hover, fokus lembut |
| `--sidebar-bg` | `#0a1a33` | Sidebar |
| `--sidebar-text` | `#94a3b8` | Teks navigasi tidak aktif |
| `--sidebar-submenu-active` | `#16305a` | Submenu aktif |
| `--sukses-fg` / `--sukses-bg` | `#166534` / `#dcfce7` | Berhasil, aktif, lunas |
| `--peringatan-fg` / `--peringatan-bg` | `#92400e` / `#fef3c7` | Perlu perhatian, tetapi belum kritis |
| `--jingga-fg` / `--jingga-bg` | `#9a3412` / `#ffedd5` | Status antara/peringatan tambahan |
| `--bahaya-fg` / `--bahaya-bg` | `#b91c1c` / `#fee2e2` | Gagal, destruktif, overdue |
| `--ungu-fg` / `--ungu-bg` | `#7c3aed` / `#ede9fe` | Kategori/status sekunder |
| `--netral-fg` / `--netral-bg` | `#475569` / `#f1f5f9` | Informasi netral |

Pastel ikon bawaan: biru `#dbeafe`, hijau `#dcfce7`, ungu `#ede9fe`, jingga
`#ffedd5`, merah `#fee2e2`, dan netral `#f1f5f9`. Warna status harus selalu
disertai teks/icon; jangan menyampaikan makna hanya lewat warna.

Merek pelanggan boleh mengganti `--accent`, `--accent-hover`, dan
`--accent-soft` melalui pengaturan merek. Warna aksen hanya untuk tindakan
utama, tautan, dan indikator aktif—jangan mengganti warna semantik sukses,
peringatan, atau bahaya. Teks normal harus memiliki rasio kontras minimal
4.5:1; teks besar minimal 3:1. Pastikan warna aksen merek dapat dibaca dengan
foreground tombol yang dipilih.

### Tipografi

- Keluarga font: **Inter** lokal (`app/static/fonts/inter-400.woff2`), fallback
  `system-ui, sans-serif`. Jangan memuat font dari CDN.
- Bobot: 400 isi, 500 label/teks penekanan, 600 heading tabel/kartu, 700 judul
  halaman dan angka KPI.
- Skala acuan pada `--skala-font: 1`:

| Peran | Ukuran |
| --- | ---: |
| Metadata kecil (versi, catatan sekunder) | 11px; jangan dipakai untuk instruksi |
| Bantuan, label tabel, badge | 12px minimum |
| Teks tabel, navigasi sekunder, bantuan | 13px |
| Isi, kontrol, navigasi utama | 14px |
| Heading kartu | 15px |
| Heading bagian | 18px |
| Judul halaman | 24px |
| Angka KPI | 26px |

Ukuran di CSS menggunakan `calc(ukuran * var(--skala-font))` agar dapat
disesuaikan terpusat. Nominal, CID, nomor invoice, tanggal dan angka tabel
memakai angka tabular (`font-variant-numeric: tabular-nums`).

### Spasi, bentuk, elevasi

Gunakan skala 4px: `4, 8, 12, 16, 24, 32, 40` (`--space-1` hingga
`--space-10`). Gap kontrol rapat 8px; gap
toolbar 8–10px; padding kartu 20px (16px pada layar kecil); jarak antarkartu
20px; padding tombol 10px 16px; tinggi kontrol minimum 40px.

- `--radius-kontrol: 8px` untuk tombol, input, dan menu; badge status memakai
  bentuk pil penuh.
- `--radius-kartu: 12px` untuk kartu dan panel.
- `--bayangan`: bayangan lembut satu tingkat untuk kartu; gunakan bayangan
  popover lebih tegas hanya ketika panel mengambang di atas konten.
- Batas gunakan `--border`; jangan menambahkan garis dekoratif tanpa fungsi.

## Tata letak dan responsif

- Sidebar desktop 225px; mode ikon 68px. Topbar 64px. Konten utama harus
  mempertahankan gutter yang konsisten.
- Breakpoint: 1200px untuk mengurangi grid lebar, 900px untuk beralih dari
  sidebar ke drawer dan mengaktifkan scroll tabel mendatar, 700px untuk
  form/grid satu kolom, dan 560px untuk penyederhanaan kontrol ponsel.
- Hindari overflow halaman horizontal. Tabel lebar boleh memiliki scroll
  horizontal dalam batas tabel dengan header/kolom tetap dapat dibaca.
- KPI desktop maksimal lima kolom; layar kecil memakai dua kolom bila label
  tetap muat, bukan memaksa kartu sangat sempit atau membuat satu kolom panjang.
- Toolbar daftar menggunakan gap dan tinggi kontrol seragam; saat sempit,
  kontrol boleh membungkus secara sengaja, tidak terpotong atau bertumpuk.
- Layout detail boleh memakai kolom sekunder pada desktop, tetapi runtuh
  menjadi satu kolom pada tablet/ponsel.

## Pola komponen dan interaksi

### Navigasi dan shell

- Setiap halaman aplikasi memakai satu judul H1, navigasi utama berlabel, dan
  tautan lewati ke konten.
- Hamburger menyatakan label dan state expanded yang sesuai, mengontrol
  sidebar/drawer yang benar, dan mendukung Escape pada drawer.
- Hanya tampilkan pencarian/notifikasi/bantuan bila perilaku dan tujuannya
  benar-benar tersedia.
- Navigasi mengikuti role. Menu yang tidak boleh diakses tidak boleh menjadi
  tautan aktif; menu Billing untuk `teknis` ditampilkan nonaktif. Pada menu
  hanya-baca, sembunyikan aksi ubah/hapus dan tetap tegakkan larangan di server.
- Halaman awal setelah login: `superadmin` dan `admin_cabang` ke Dashboard
  Utama, `billing` ke Dashboard Billing, dan `teknis` ke Dashboard Utama
  yang hanya memuat tiket dan jaringan (tanpa angka uang).

### Dashboard operasional

- Dahulukan indikator yang mendukung tindakan harian: customer dan layanan
  aktif, pembayaran/outstanding, invoice overdue, dan tiket terbuka.
- KPI yang tampak sebagai kartu tautan harus membuka daftar atau laporan yang
  relevan; jangan menjadikan angka dekoratif seolah-olah dapat diklik.
- Kelompokkan pekerjaan yang perlu ditindaklanjuti dalam antrian dengan
  ringkasan, beberapa item terpenting, dan tautan ke daftar lengkap. Tampilkan
  empty state yang jelas bila tidak ada pekerjaan terbuka.
- Semua query dashboard harus mengikuti pembatasan cabang/RBAC yang sama
  seperti halaman sumbernya.
- Kartu dalam satu baris memakai tinggi dan alignment yang konsisten; urutan
  informasi adalah KPI, tindak lanjut, analitik, lalu aktivitas/rekap.
- Tindakan cepat harus mengikuti hak akses pengguna dan mengarah ke alur
  pembuatan yang sudah ada.

### Daftar

- Urutan umum: judul dan aksi utama, KPI relevan bila membantu, tab/status,
  toolbar pencarian/filter/ekspor/kolom, lalu tabel dan paginasi.
- Filter, ekspor, dan pemilih kolom diletakkan pada toolbar di luar kartu
  permukaan tabel. Gunakan satu pola posisi yang konsisten di setiap modul;
  hindari tab kategori yang menduplikasi pilihan pada filter.
- Filter yang dibuka menampilkan panel dengan judul, Reset, label untuk setiap
  input, dan aksi Terapkan yang terlihat. State aktif harus terlihat dan
  nilai filter bertahan setelah submit/pindah halaman yang relevan.
- Kolom tabel dipilih berdasarkan tugas utama; detail sekunder gunakan ukuran
  dan warna muted, bukan menghilangkan konteks penting.
- Empty state menjelaskan kondisi dan menawarkan tindakan berikutnya jika ada.

### Formulir

- Label tetap terlihat di atas input; placeholder hanya contoh, bukan label.
- Bantuan dan kesalahan dekat dengan field yang terkait; tandai field wajib.
- Form panjang dikelompokkan dengan heading, urutan alur kerja, dan aksi utama
  yang konsisten di bagian akhir.
- Validasi server tetap menjadi sumber kebenaran; error jangan hanya berupa
  warna atau notifikasi yang cepat hilang.

### Tombol, fokus, dan gerak

- Aksi utama memakai `--accent`; aksi destruktif memakai warna bahaya dan
  konfirmasi yang menjelaskan konsekuensinya.
- Semua tombol dan tautan interaktif memiliki hover (perangkat pointer),
  pressed, disabled, dan `:focus-visible` yang terlihat. Tombol aksi utama dan
  destruktif mempertahankan warna semantiknya saat hover.
- Gunakan transisi hanya untuk feedback kecil; properti spesifik `transform`
  atau `opacity`, durasi umumnya 100–200ms, easing ease-out. Jangan gunakan
  animasi untuk menunda aksi berulang.
- Hormati `prefers-reduced-motion`; perpindahan posisi/transform dekoratif
  dimatikan atau dikurangi.

## Kriteria untuk menu/halaman baru

Sebelum merge, halaman baru harus:

1. Menggunakan token warna, tipografi, radius, bayangan, dan spacing di atas.
2. Memakai shell, judul, breadcrumb, pola toolbar/form/tabel yang sudah ada.
3. Berfungsi pada 1440px, 1024px, 768px, dan 375px tanpa overflow yang tidak
   disengaja.
4. Dapat digunakan dengan keyboard; fokus terlihat dan nama kontrol dapat
   dipahami pembaca layar.
5. Memiliki state loading, empty, error, sukses, disabled, serta data panjang
   yang sesuai dengan alur fitur.
6. Tidak menambah warna/ukuran literal baru bila token yang ada dapat dipakai;
   pengecualian harus dijelaskan.
