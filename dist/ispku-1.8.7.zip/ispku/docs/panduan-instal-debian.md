# Panduan Instalasi ISPKU di Debian

Dari server kosong sampai ISPKU bisa dibuka lewat `https://` dengan
sertifikat SSL.

Panduan ini ditulis untuk pembaca yang **belum pernah** memasang aplikasi
server. Setiap langkah berisi perintah yang tinggal disalin, penjelasan apa
yang dikerjakannya, dan **hasil yang seharusnya terlihat** — kalau hasil di
layar Anda berbeda, berhenti di situ dan buka bagian
[Kalau ada masalah](#kalau-ada-masalah) sebelum lanjut.

Perkiraan waktu: 45–90 menit, sebagian besar menunggu unduhan.

---

## Daftar isi

- [Gambaran singkat](#gambaran-singkat)
- [Langkah 0 — Siapkan dulu](#langkah-0--siapkan-dulu)
- [Cara membaca panduan ini](#cara-membaca-panduan-ini)
- [Langkah 1 — Masuk ke server sebagai root](#langkah-1--masuk-ke-server-sebagai-root)
- [Langkah 2 — Perbarui sistem dan pasang alat dasar](#langkah-2--perbarui-sistem-dan-pasang-alat-dasar)
- [Langkah 3 — Pasang Docker](#langkah-3--pasang-docker)
- [Langkah 4 — Unduh ISPKU](#langkah-4--unduh-ispku)
- [Langkah 5 — Jalankan pemasang](#langkah-5--jalankan-pemasang)
- [Langkah 6 — Coba buka lewat alamat IP](#langkah-6--coba-buka-lewat-alamat-ip)
- [Langkah 7 — Arahkan domain ke server](#langkah-7--arahkan-domain-ke-server)
- [Langkah 8 — Pasang nginx](#langkah-8--pasang-nginx)
- [Langkah 9 — Pasang sertifikat SSL gratis](#langkah-9--pasang-sertifikat-ssl-gratis)
- [Langkah 10 — Kunci aplikasi di belakang nginx](#langkah-10--kunci-aplikasi-di-belakang-nginx)
- [Langkah 11 — Nyalakan firewall](#langkah-11--nyalakan-firewall)
- [Langkah 12 — Pasang jadwal otomatis](#langkah-12--pasang-jadwal-otomatis)
- [Langkah 13 — Pemeriksaan akhir](#langkah-13--pemeriksaan-akhir)
- [Memperbarui ke versi baru](#memperbarui-ke-versi-baru)
- [Kalau ada masalah](#kalau-ada-masalah)
- [Lampiran A — Tanpa domain (hanya alamat IP)](#lampiran-a--tanpa-domain-hanya-alamat-ip)
- [Lampiran B — Perintah sehari-hari](#lampiran-b--perintah-sehari-hari)
- [Lampiran C — Menghapus ISPKU](#lampiran-c--menghapus-ispku)

---

## Gambaran singkat

Yang akan terpasang di server:

```
 Peramban pengguna
        │  https://crm.contoh.id   (port 443, terenkripsi)
        ▼
 ┌─────────────────────── Server Debian ───────────────────────┐
 │  nginx  ── pintu depan, memegang sertifikat SSL             │
 │    │  diteruskan ke 127.0.0.1:6060 (hanya dari dalam server)│
 │    ▼                                                        │
 │  Docker                                                     │
 │    ├─ kontainer "app" : aplikasi ISPKU                      │
 │    └─ kontainer "db"  : basis data PostgreSQL               │
 └─────────────────────────────────────────────────────────────┘
```

- **Docker** menjalankan aplikasi dan basis datanya dalam "kontainer" — Anda
  tidak perlu memasang Python atau PostgreSQL sendiri.
- **nginx** menerima pengunjung dari internet, memegang sertifikat SSL, lalu
  meneruskannya ke aplikasi.
- **Let's Encrypt (certbot)** memberi sertifikat SSL gratis yang
  memperpanjang dirinya sendiri.

---

## Langkah 0 — Siapkan dulu

| Yang dibutuhkan | Keterangan |
|---|---|
| Server Debian 12 atau 13 | VPS atau server fisik, 64-bit. Instalasi baru lebih baik — jangan server yang sudah menjalankan situs lain di port 80/443. |
| Spesifikasi | Minimal 2 CPU, **2 GB RAM**, disk 20 GB. RAM 1 GB bisa gagal saat membangun aplikasi. |
| Alamat IP publik | Tertera di panel penyedia VPS Anda. |
| Nama domain | Contoh `crm.ispanda.id`. Wajib untuk SSL Let's Encrypt. Tanpa domain, ikuti [Lampiran A](#lampiran-a--tanpa-domain-hanya-alamat-ip). |
| Akses root | Password root, atau user biasa yang tahu password root. |
| Paket ISPKU | Alamat unduhan zip dari penjual, **atau** akses ke repositori GitHub. |
| Alamat email | Untuk pemberitahuan dari Let's Encrypt bila sertifikat bermasalah. |
| Aplikasi SSH di komputer Anda | Windows 10/11: **Windows Terminal** atau **PowerShell** (sudah ada), atau **PuTTY**. macOS/Linux: **Terminal**. |

**Isi tabel ini dulu di kertas/Notepad** — nilainya dipakai berulang kali:

| | Contoh | Punya Anda |
|---|---|---|
| Alamat IP server | `203.0.113.10` | |
| Domain | `crm.ispanda.id` | |
| Email | `admin@ispanda.id` | |

Di seluruh panduan, **ganti** `203.0.113.10`, `crm.contoh.id`, dan
`admin@contoh.id` dengan milik Anda.

---

## Cara membaca panduan ini

- Kotak abu-abu seperti di bawah berisi **perintah**. Salin, tempel ke jendela
  SSH, tekan **Enter**.

  ```bash
  echo "halo"
  ```

- Menempel di PuTTY: **klik kanan**. Di Windows Terminal/PowerShell:
  **Ctrl+Shift+V** atau klik kanan. Di Terminal macOS: **Cmd+V**.
- Baris yang diawali `#` adalah **komentar** — penjelasan, bukan perintah.
  Ikut tertempel pun tidak apa-apa.
- Jalankan perintah **satu kotak demi satu kotak**, tunggu sampai selesai
  (muncul lagi tanda `root@...:~#`) sebelum menempel kotak berikutnya.
- Kotak berjudul "Hasil yang diharapkan" **bukan** perintah — itu contoh
  tampilan layar yang benar.
- Saat mengetik password di terminal, **huruf tidak muncul sama sekali**
  (bahkan tidak berupa `*`). Itu normal. Ketik saja lalu Enter.

---

## Langkah 1 — Masuk ke server sebagai root

Di komputer Anda, buka Windows Terminal / PowerShell / Terminal, lalu
(ganti IP-nya):

```bash
ssh root@203.0.113.10
```

- Pertama kali tersambung muncul pertanyaan
  `Are you sure you want to continue connecting (yes/no)?` — ketik `yes`,
  Enter.
- Masukkan password root (tidak terlihat saat diketik).

**Kalau penyedia VPS memberi user biasa**, bukan root (misalnya `debian`):
masuk dengan user itu, lalu jadilah root:

```bash
su -
```

Masukkan password root. (Kalau yang Anda punya justru akses `sudo`, ketik
`sudo -i`.)

Pastikan Anda sudah root dan versinya Debian:

```bash
whoami
cat /etc/debian_version
```

Hasil yang diharapkan:

```
root
12.x      ← atau 13.x
```

> Semua perintah di panduan ini dijalankan sebagai **root**, jadi tidak ada
> `sudo` di depannya. Tanda prompt root diakhiri `#`, contoh
> `root@server:~#`.

---

## Langkah 2 — Perbarui sistem dan pasang alat dasar

```bash
apt update
apt upgrade -y
apt install -y ca-certificates curl wget unzip git nano ufw
```

- `apt update` mengambil daftar paket terbaru, `apt upgrade` memasang
  pembaruan keamanan, baris ketiga memasang alat yang dipakai di langkah
  berikutnya.
- Kalau di tengah `apt upgrade` muncul layar biru bertanya soal berkas
  konfigurasi, pilih jawaban bawaan (langsung **Enter**).

Setel jam server ke WIB, supaya jadwal otomatis di Langkah 12 berjalan di
jam yang Anda maksud:

```bash
timedatectl set-timezone Asia/Jakarta
date
```

Hasil yang diharapkan — jam sekarang dengan akhiran `WIB`:

```
Sat Sep 12 10:15:03 WIB 2026
```

(Untuk WITA pakai `Asia/Makassar`, WIT pakai `Asia/Jayapura`.)

---

## Langkah 3 — Pasang Docker

Docker dipasang dari repositori resmi Docker, **bukan** paket `docker.io`
bawaan Debian — versi bawaan Debian tidak membawa perintah `docker compose`
yang dibutuhkan ISPKU.

Tempel **satu per satu**:

```bash
install -m 0755 -d /etc/apt/keyrings
```

```bash
curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
```

```bash
chmod a+r /etc/apt/keyrings/docker.asc
```

Perintah berikut **satu baris panjang** — salin utuh:

```bash
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" > /etc/apt/sources.list.d/docker.list
```

```bash
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

Nyalakan Docker, dan atur supaya ikut menyala tiap server dinyalakan ulang:

```bash
systemctl enable --now docker
```

Uji:

```bash
docker run --rm hello-world
docker compose version
```

Hasil yang diharapkan (potongan):

```
Hello from Docker!
This message shows that your installation appears to be working correctly.
...
Docker Compose version v5.5.1      ← angka versinya boleh berbeda
```

---

## Langkah 4 — Unduh ISPKU

ISPKU dipasang di folder **`/opt/ispku`**. Pilih **salah satu** cara di
bawah.

| Cara | Kapan dipakai |
|---|---|
| **4A** — zip dari penjual | Anda menerima alamat unduhan (link) berkas `ispku-x.y.z.zip`. |
| **4B** — zip dari GitHub | Anda punya akses ke repositori GitHub ISPKU. |
| **4C** — `git clone` | Sama dengan 4B, tapi memperbarui versi nanti cukup `git pull`. |
| **4D** — repo paket publik | Anda ingin menarik ZIP rilis dari `cogase/cusnet-pub`; tidak perlu token. |

### 4A — Zip dari penjual

Ganti alamat di dalam tanda kutip dengan link yang Anda terima:

```bash
cd /opt
wget -O ispku.zip "https://alamat-dari-penjual/ispku-1.7.0.zip"
unzip ispku.zip
rm ispku.zip
cd /opt/ispku
ls
```

> Kalau berkas zip-nya ada di komputer Anda (bukan link), kirim ke server
> lewat PowerShell/Terminal **di komputer Anda** (bukan di jendela SSH):
> `scp ispku-1.7.0.zip root@203.0.113.10:/opt/ispku.zip` — lalu di jendela
> SSH jalankan mulai baris `cd /opt` di atas, lewati baris `wget`. Pengguna
> Windows yang lebih suka tampilan grafis bisa memakai **WinSCP**.

### 4B — Zip dari GitHub

Repositori ISPKU privat, jadi GitHub meminta **token** (semacam password
khusus yang hanya boleh membaca).

**Membuat token** (sekali saja, di peramban):

1. Masuk ke github.com → klik foto profil (kanan atas) → **Settings**.
2. Paling bawah menu kiri: **Developer settings** → **Personal access
   tokens** → **Fine-grained tokens** → **Generate new token**.
3. Isi **Token name** (misalnya `server-ispku`), **Expiration** 30 hari.
4. **Repository access** → *Only select repositories* → pilih
   `cusnet-crm`.
5. **Permissions** → *Repository permissions* → **Contents** → *Read-only*.
6. **Generate token**, lalu **salin** tokennya (diawali `github_pat_`).
   Token hanya ditampilkan sekali.

Di server:

```bash
cd /opt
read -rs TOKEN
```

Tempel token lalu tekan Enter — **tidak terlihat**, itu disengaja supaya
token tidak tercatat di riwayat perintah. Lalu:

```bash
wget --header="Authorization: Bearer $TOKEN" -O ispku.zip https://api.github.com/repos/cogase/cusnet-crm/zipball/main
unset TOKEN
unzip ispku.zip
mv cogase-cusnet-crm-* ispku
rm ispku.zip
cd /opt/ispku
ls
```

> `ERROR 404: Not Found` pada `wget` berarti token salah/kedaluwarsa atau
> belum diberi akses ke repositori `cusnet-crm` (poin 4 di atas).

### 4C — git clone

```bash
cd /opt
git clone https://github.com/cogase/cusnet-crm.git ispku
```

Git bertanya dua hal:

- `Username for 'https://github.com':` — nama akun GitHub Anda.
- `Password for 'https://...':` — **tempel token** dari cara 4B (bukan
  password akun GitHub; GitHub menolak password akun).

```bash
cd /opt/ispku
ls
```

### 4D — Repo paket publik

Repo ini berisi paket ZIP dan checksum, bukan source code aplikasi. Clone
sekali ke folder terpisah dari `/opt/ispku`:

```bash
git clone https://github.com/cogase/cusnet-pub.git /opt/cusnet-pub
cd /opt/cusnet-pub/dist
PAKET=$(find . -maxdepth 1 -type f -name 'ispku-*.zip' -printf '%f\n' | sort -V | tail -n 1)
test -n "$PAKET" || { echo "Paket ISPKU belum ditemukan"; exit 1; }
sha256sum -c "$PAKET.sha256"
unzip -o "$PAKET" -d /opt
cd /opt/ispku
ls
```

`sha256sum -c` harus menampilkan `OK`. Jika checksum gagal atau belum ada
paket, berhenti dan hubungi penjual. Setelah itu lanjutkan ke **Langkah 5**
untuk menjalankan installer.

### Hasil yang diharapkan (semua cara)

`ls` memperlihatkan isi folder, antara lain:

```
Dockerfile  README.md  app  deploy  docker-compose.prod.yml  docs  install.sh  ...
```

---

## Langkah 5 — Jalankan pemasang

```bash
cd /opt/ispku
./install.sh
```

Pemasang mengerjakan enam tahap dan menampilkannya berurutan:

| Tahap | Yang dikerjakan |
|---|---|
| `[1/6]` | Membuat berkas konfigurasi `.env` beserta password acak |
| `[2/6]` | Mencadangkan basis data bila ISPKU sudah pernah terpasang |
| `[3/6]` | Membangun aplikasi — **pertama kali 5–15 menit**, layar penuh tulisan, biarkan saja |
| `[4/6]` | Menunggu aplikasi siap |
| `[5/6]` | Menanyakan akun **superadmin** pertama |
| `[6/6]` | Menanam kategori layanan bawaan |

Di tahap `[5/6]` Anda diminta mengisi:

```
    Buat akun superadmin pertama (akun untuk masuk ke aplikasi).
    Username superadmin: admin
    Email              : admin@contoh.id
    Nama lengkap       : Nama Anda
    Password (min 8)   :            ← tidak terlihat saat diketik
    Ulangi password    :
```

**Catat username dan password ini.** Inilah akun untuk masuk ke ISPKU.

Hasil yang diharapkan di akhir:

```
ISPKU siap.  Buka dari peramban: http://203.0.113.10:6060

PERINGATAN: HTTPS_ONLY=false. Cookie sesi dikirim tanpa enkripsi.
...
```

Peringatan `HTTPS_ONLY=false` itu wajar pada tahap ini — akan diselesaikan
di Langkah 10.

> **`Permission denied` saat menjalankan `./install.sh`?** Jalankan
> `chmod +x install.sh` lalu ulangi, atau pakai `sh install.sh`.

> Password basis data dan kunci rahasia aplikasi tersimpan di
> `/opt/ispku/.env`. **Jangan hapus berkas ini** dan jangan bagikan isinya.

---

## Langkah 6 — Coba buka lewat alamat IP

Ini uji sementara, untuk memastikan aplikasinya sendiri sudah jalan sebelum
nginx dipasang.

Di peramban komputer Anda, buka (ganti IP-nya):

```
http://203.0.113.10:6060
```

Harus muncul halaman masuk ISPKU. Masuk dengan akun superadmin dari Langkah
5.

**Tidak terbuka?** Banyak penyedia VPS (misalnya yang punya menu *Firewall*
atau *Security Group* di panelnya) menutup port selain 22/80/443. Tidak
masalah — uji dari server sendiri saja:

```bash
curl -I http://127.0.0.1:6060/masuk
```

Hasil yang diharapkan: baris pertama `HTTP/1.1 200 OK`. Kalau begitu,
aplikasinya sudah jalan; lanjut ke Langkah 7.

> Port 6060 akan **ditutup dari luar** di Langkah 10. Setelah itu ISPKU
> hanya bisa dibuka lewat `https://domain-anda`.

---

## Langkah 7 — Arahkan domain ke server

Buka panel pengelola DNS domain Anda (tempat membeli domain, atau
Cloudflare bila domain dikelola di sana). Tambahkan **record** baru:

| Kolom | Isi |
|---|---|
| Type | `A` |
| Name / Host | `crm` (bagian depan domain; untuk `crm.ispanda.id` isinya `crm`) |
| Value / Points to / IPv4 | alamat IP server, contoh `203.0.113.10` |
| TTL | Auto / 300 |
| Proxy status (khusus Cloudflare) | **DNS only** (awan abu-abu), jangan awan oranye |

Simpan, lalu tunggu 5–30 menit. Periksa dari server (ganti domainnya):

```bash
getent hosts crm.contoh.id
```

Hasil yang diharapkan — alamat IP server Anda:

```
203.0.113.10    crm.contoh.id
```

Kalau tidak keluar apa-apa, DNS belum menyebar. Tunggu beberapa menit lalu
ulangi. **Jangan lanjut ke Langkah 9 sebelum ini benar** — Let's Encrypt
menolak menerbitkan sertifikat untuk domain yang belum mengarah ke server.

---

## Langkah 8 — Pasang nginx

```bash
apt install -y nginx
```

Salin konfigurasi nginx yang sudah disiapkan paket ISPKU, lalu isi nama
domain Anda. **Ganti `crm.contoh.id` di baris kedua** dengan domain Anda:

```bash
cp /opt/ispku/deploy/nginx-ispku.conf /etc/nginx/sites-available/ispku
sed -i 's/DOMAIN_ANDA/crm.contoh.id/' /etc/nginx/sites-available/ispku
```

Aktifkan konfigurasi ISPKU dan matikan halaman bawaan nginx:

```bash
ln -s /etc/nginx/sites-available/ispku /etc/nginx/sites-enabled/ispku
rm -f /etc/nginx/sites-enabled/default
```

Periksa isinya dan kebenaran tulisannya:

```bash
grep server_name /etc/nginx/sites-available/ispku
nginx -t
```

Hasil yang diharapkan:

```
    server_name crm.contoh.id;          ← domain Anda, bukan DOMAIN_ANDA
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

Terapkan:

```bash
systemctl reload nginx
```

Uji di peramban: `http://crm.contoh.id` (masih **http**, belum https) — harus
muncul halaman masuk ISPKU.

---

## Langkah 9 — Pasang sertifikat SSL gratis

```bash
apt install -y certbot python3-certbot-nginx
```

Minta sertifikat. **Ganti domain dan email** — perintahnya satu baris:

```bash
certbot --nginx -d crm.contoh.id -m admin@contoh.id --agree-tos --no-eff-email --redirect
```

- `--nginx` : certbot sendiri yang menambahkan pengaturan SSL ke konfigurasi
  nginx dari Langkah 8.
- `--redirect` : pengunjung yang membuka `http://` otomatis dipindahkan ke
  `https://`.

Hasil yang diharapkan (potongan):

```
Successfully received certificate.
...
Successfully deployed certificate for crm.contoh.id to /etc/nginx/sites-enabled/ispku
Congratulations! You have successfully enabled HTTPS on https://crm.contoh.id
```

Sertifikat berlaku 90 hari dan **diperpanjang otomatis**. Pastikan
perpanjangan otomatisnya bekerja:

```bash
certbot renew --dry-run
```

Hasil yang diharapkan di akhir: `Congratulations, all simulated renewals
succeeded`.

Buka `https://crm.contoh.id` di peramban — harus ada ikon gembok.

---

## Langkah 10 — Kunci aplikasi di belakang nginx

Sekarang ISPKU sudah bisa dibuka lewat HTTPS, tiga pengaturan di `.env`
diubah:

| Pengaturan | Nilai | Artinya |
|---|---|---|
| `HTTPS_ONLY` | `true` | Cookie login hanya dikirim lewat koneksi terenkripsi. |
| `TRUSTED_PROXIES` | `1` | Aplikasi membaca alamat IP asli pengunjung dari nginx. Tanpa ini semua orang terbaca satu alamat, dan 10 salah ketik password dari siapa pun mengunci login **semua orang** selama 15 menit. |
| `APP_BIND` | `127.0.0.1` | Port 6060 hanya bisa dibuka dari dalam server; dari luar harus lewat nginx. |

```bash
cd /opt/ispku
sed -i 's/^HTTPS_ONLY=.*/HTTPS_ONLY=true/' .env
sed -i 's/^TRUSTED_PROXIES=.*/TRUSTED_PROXIES=1/' .env
sed -i 's/^APP_BIND=.*/APP_BIND=127.0.0.1/' .env
grep -E '^(HTTPS_ONLY|TRUSTED_PROXIES|APP_BIND)=' .env
```

Hasil yang diharapkan — **tepat tiga baris** ini:

```
HTTPS_ONLY=true
TRUSTED_PROXIES=1
APP_BIND=127.0.0.1
```

> Kalau salah satu baris tidak muncul (bisa terjadi pada `.env` dari versi
> lama), tambahkan sendiri, misalnya `echo 'APP_BIND=127.0.0.1' >> .env`,
> lalu ulangi `grep` di atas.

Terapkan dengan menjalankan pemasang lagi (ia membuat cadangan dulu, lalu
menyalakan ulang aplikasi dengan pengaturan baru):

```bash
./install.sh
```

Hasil yang diharapkan di akhir:

```
ISPKU siap.  Aplikasi hanya mendengar di 127.0.0.1:6060 — buka lewat alamat HTTPS (nginx) Anda.
```

Di tahap `[2/6]` mungkin muncul satu baris `HTTPS_ONLY=false — cookie sesi
dikirim tanpa flag Secure...`. Abaikan: itu dari aplikasi lama yang sedang
dicadangkan, sebelum dinyalakan ulang dengan pengaturan baru. Yang penting
peringatan `PERINGATAN: HTTPS_ONLY=false` **tidak** muncul lagi di akhir.

> **Penting:** setelah mengubah `.env`, selalu terapkan dengan
> `./install.sh` (atau `docker compose -f docker-compose.prod.yml up -d`).
> Perintah `docker compose restart` **tidak** membaca ulang `.env`.

Periksa bahwa port 6060 kini hanya terbuka untuk server sendiri:

```bash
ss -ltn | grep 6060
```

Hasil yang diharapkan — diawali `127.0.0.1`, **bukan** `0.0.0.0`:

```
LISTEN 0      4096       127.0.0.1:6060       0.0.0.0:*
```

---

## Langkah 11 — Nyalakan firewall

> **Peringatan:** baris `ufw allow 22/tcp` wajib dijalankan **sebelum**
> `ufw enable`. Kalau terbalik, sambungan SSH Anda terputus dan server hanya
> bisa dibuka lagi lewat konsol di panel penyedia VPS. Kalau SSH server Anda
> memakai port selain 22, ganti angka 22 dengan port itu.

```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

Saat ditanya `Command may disrupt existing ssh connections. Proceed with
operation (y|n)?` ketik `y`, Enter.

```bash
ufw status
```

Hasil yang diharapkan:

```
Status: active

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW       Anywhere
80/tcp                     ALLOW       Anywhere
443/tcp                    ALLOW       Anywhere
...
```

> Kenapa Langkah 10 tetap perlu padahal sudah ada firewall? Docker membuka
> port kontainernya dengan aturannya sendiri yang **melewati ufw**. Port 6060
> yang dibuka Docker tetap bisa dijangkau dari luar walaupun ufw aktif —
> satu-satunya penutupnya adalah `APP_BIND=127.0.0.1`.

---

## Langkah 12 — Pasang jadwal otomatis

Lima pekerjaan yang harus berjalan sendiri tiap hari: cadangan basis data,
status tagihan lewat tempo, pengiriman email antrean, dan dua pembersihan.
Semuanya sudah ditulis di paket ISPKU; tinggal disalin:

```bash
cp /opt/ispku/deploy/cron-ispku /etc/cron.d/ispku
chmod 644 /etc/cron.d/ispku
grep -v '^#' /etc/cron.d/ispku | grep .
```

Hasil yang diharapkan — tujuh baris (dua pengaturan, lima jadwal):

| Jam | Pekerjaan |
|---|---|
| 01.15 | Status invoice lewat tempo + antre pengingat tagihan |
| 02.00 | Cadangan basis data |
| 03.30 | Buang berkas impor CSV yang ditinggalkan |
| 04.00 | Buang cadangan yang lebih tua dari 14 hari |
| tiap 5 menit | Kirim email yang mengantre |

Uji sekali sekarang tanpa menunggu jam 02.00:

```bash
cd /opt/ispku && docker compose -f docker-compose.prod.yml exec -T app flask backup-db
```

Hasil yang diharapkan (tanggal dan jamnya mengikuti saat Anda menjalankan):

```
Cadangan dibuat: /data/backups/cusnet-20260912-101530.dump
```

Besok, catatan jalannya jadwal bisa dilihat dengan:

```bash
tail -n 30 /var/log/ispku-cron.log
```

> **Cadangan masih berada di server yang sama.** Kalau disk server rusak,
> cadangannya ikut hilang. Secara berkala unduh cadangan terbaru lewat
> **Pengaturan → Sistem** di aplikasi, atau salin dari folder
> `/var/lib/docker/volumes/ispku_backups/_data/` ke tempat lain.

---

## Langkah 13 — Pemeriksaan akhir

Centang satu per satu:

- [ ] `https://crm.contoh.id` terbuka dengan ikon gembok.
- [ ] `http://crm.contoh.id` (tanpa s) otomatis pindah ke `https://`.
- [ ] `http://203.0.113.10:6060` dari komputer Anda **tidak** terbuka lagi.
- [ ] Bisa masuk dengan akun superadmin.
- [ ] **Pengaturan → Sistem** tidak lagi menampilkan peringatan
      `HTTPS_ONLY=false`.
- [ ] **Pengaturan → Audit Log**: kolom alamat IP pada catatan terbaru
      menunjukkan IP internet Anda (cek di https://ifconfig.me dari komputer
      Anda), **bukan** alamat yang diawali `172.`.
- [ ] Server dinyalakan ulang (`reboot`), tunggu 2 menit, lalu
      `https://crm.contoh.id` terbuka lagi dengan sendirinya.

Kalau semuanya tercentang, **ISPKU sudah terpasang dengan benar.**

Langkah pertama di dalam aplikasi (sebagai superadmin):

1. **Pengaturan → Merek Aplikasi** — nama dan warna aplikasi.
2. **Pengaturan → Billing** — kop surat invoice, rekening bank, pola nomor
   CID/invoice, dan SMTP bila invoice akan dikirim lewat email.
3. **Master Data → Cabang**, lalu **Pengaturan → User & Peran** — akun untuk
   staf.
4. **Pengaturan → Lisensi** — tempel kunci lisensi dari penjual.

Pengaturan lanjutan (semua variabel `.env`, pemulihan cadangan, perintah
perawatan) ada di `docs/pemasangan.md`.

---

## Memperbarui ke versi baru

`./install.sh` selalu membuat cadangan basis data **sebelum** memasang versi
baru, dan `.env` Anda tidak pernah disentuh.

**Kalau memasang lewat 4A (zip dari penjual):**

```bash
cd /opt
wget -O ispku-baru.zip "https://alamat-dari-penjual/ispku-1.8.0.zip"
unzip -o ispku-baru.zip
rm ispku-baru.zip
cd /opt/ispku
./install.sh
```

`unzip -o` menimpa berkas lama dengan yang baru tanpa bertanya.
Berkas lama yang tidak lagi ada di ZIP bisa tetap tertinggal di folder, tetapi
tidak akan ikut masuk ke image Docker. Ini juga menangani migrasi `0023` dari
paket lama; jangan menghapus atau mengubah tabel `alembic_version` secara manual.

**Kalau memasang lewat 4B (zip GitHub):**

```bash
cd /opt
read -rs TOKEN
```

```bash
wget --header="Authorization: Bearer $TOKEN" -O ispku-baru.zip https://api.github.com/repos/cogase/cusnet-crm/zipball/main
unset TOKEN
unzip -q ispku-baru.zip
cp -r cogase-cusnet-crm-*/. /opt/ispku/
rm -rf cogase-cusnet-crm-* ispku-baru.zip
cd /opt/ispku
./install.sh
```

**Kalau memasang lewat 4C (git clone):**

```bash
cd /opt/ispku
git pull --ff-only
./install.sh
```

**Kalau memasang lewat 4D (repo paket publik):**

```bash
cd /opt/cusnet-pub
git pull --ff-only
cd dist
PAKET=$(find . -maxdepth 1 -type f -name 'ispku-*.zip' -printf '%f\n' | sort -V | tail -n 1)
test -n "$PAKET" || { echo "Paket ISPKU belum ditemukan"; exit 1; }
sha256sum -c "$PAKET.sha256"
unzip -o "$PAKET" -d /opt
cd /opt/ispku
./install.sh
```

Repo paket publik di-clone hanya sekali. Pada pembaruan, `git pull` mengambil
paket terbaru; checksum memeriksa integritas unduhan; ZIP diekstrak ke folder
aplikasi yang sudah ada; lalu `install.sh` membuat cadangan dan menerapkan
pembaruan. Jangan menjalankan `git pull` di `/opt/ispku` untuk cara 4D.

Sesudahnya versi yang berjalan tertera di kaki menu samping aplikasi.

---

## Kalau ada masalah

| Gejala | Penyebab | Yang dilakukan |
|---|---|---|
| `Permission denied` saat `./install.sh` | Berkas kehilangan izin jalan | `chmod +x install.sh`, atau jalankan `sh install.sh` |
| `Docker tidak bisa dipakai oleh user ini` | Belum root | `su -`, lalu `cd /opt/ispku` dan ulangi |
| `Docker belum terpasang` | Langkah 3 terlewat/gagal | Ulangi Langkah 3 |
| Tahap `[3/6]` berhenti dengan `Temporary failure resolving` / `Could not resolve host` | Server tidak bisa mengakses internet atau DNS server bermasalah | `ping -c 3 deb.debian.org`. Kalau gagal, hubungi penyedia VPS |
| Tahap `[3/6]` berhenti dengan `Killed` atau `exit code: 137` | RAM habis | Tambah RAM (minimal 2 GB) atau pasang swap, lalu ulangi |
| `Aplikasi tidak siap setelah 2 menit` | Aplikasi gagal menyala | `docker compose -f docker-compose.prod.yml logs --tail 50 app` — baris terakhir menyebut sebabnya |
| `unknown flag: --status` atau `docker: 'compose' is not a docker command` | Docker versi lama dari paket Debian | Hapus `apt remove -y docker.io docker-compose`, ulangi Langkah 3 |
| Peramban: **502 Bad Gateway** | nginx jalan, aplikasi tidak | `cd /opt/ispku && docker compose -f docker-compose.prod.yml ps` — kedua layanan harus `Up`/`running`. Kalau mati: `./install.sh`. Kalau `APP_PORT` di `.env` bukan 6060, samakan angka di `/etc/nginx/sites-available/ispku` |
| Peramban: halaman **Welcome to nginx!** | Halaman bawaan nginx masih aktif | `rm -f /etc/nginx/sites-enabled/default && systemctl reload nginx` |
| `nginx -t` gagal | Salah ketik di konfigurasi | Pesan galat menyebut nomor barisnya. Paling mudah: ulangi Langkah 8 dari `cp` |
| certbot: `Timeout during connect (likely firewall problem)` | Port 80 tertutup di firewall panel VPS | Buka port 80 dan 443 di panel VPS, ulangi Langkah 9 |
| certbot: `NXDOMAIN` / `DNS problem` | Domain belum mengarah ke server | Kembali ke Langkah 7, tunggu sampai `getent hosts` benar |
| certbot: `too many certificates` | Terlalu sering meminta sertifikat untuk domain yang sama | Tunggu (batasnya mingguan); jangan mengulang certbot berkali-kali |
| Masuk berhasil tapi langsung kembali ke halaman masuk, tanpa pesan | `HTTPS_ONLY=true` tetapi aplikasi dibuka lewat `http://` | Buka lewat `https://domain-anda` |
| **413 Request Entity Too Large** saat mengunggah | `client_max_body_size` hilang dari konfigurasi nginx | Ulangi Langkah 8 dari `cp`, lalu Langkah 9 |
| Semua orang kena `Terlalu banyak percobaan masuk` bersamaan | `TRUSTED_PROXIES` belum `1` | Ulangi Langkah 10 |
| Lupa password superadmin | — | `cd /opt/ispku && docker compose -f docker-compose.prod.yml exec app flask reset-password --username admin` (ganti `admin` dengan username Anda) |
| Terkunci dari SSH setelah `ufw enable` | `ufw allow 22/tcp` terlewat | Buka konsol dari panel penyedia VPS, jalankan `ufw allow 22/tcp` |

Masih buntu? Kumpulkan keluaran tiga perintah ini dan kirim ke penjual:

```bash
cd /opt/ispku
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs --tail 80 app
nginx -t
```

(Keluaran ini tidak memuat password. **Jangan** mengirim isi berkas `.env`.)

---

## Lampiran A — Tanpa domain (hanya alamat IP)

Untuk pemakaian di jaringan kantor atau uji coba tanpa domain. Let's Encrypt
tidak menerbitkan sertifikat untuk alamat IP, jadi dipakai sertifikat buatan
sendiri (*self-signed*): koneksinya tetap terenkripsi, tetapi peramban
menampilkan peringatan **"Koneksi Anda tidak pribadi"** yang perlu dilewati
sekali di tiap perangkat (**Lanjutan → Lanjutkan ke ...**).

Kerjakan Langkah 1–6 seperti biasa, **lewati Langkah 7–9**, lalu:

```bash
apt install -y nginx openssl
mkdir -p /etc/ssl/ispku
```

Buat sertifikat. **Ganti `203.0.113.10`** dengan IP server — satu baris:

```bash
openssl req -x509 -nodes -newkey rsa:2048 -days 825 -keyout /etc/ssl/ispku/ispku.key -out /etc/ssl/ispku/ispku.crt -subj "/CN=ISPKU" -addext "subjectAltName=IP:203.0.113.10"
```

```bash
chmod 600 /etc/ssl/ispku/ispku.key
cp /opt/ispku/deploy/nginx-ispku-ip.conf /etc/nginx/sites-available/ispku
ln -s /etc/nginx/sites-available/ispku /etc/nginx/sites-enabled/ispku
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

Buka `https://203.0.113.10` di peramban, lewati peringatannya, dan halaman
masuk ISPKU harus muncul. Setelah itu lanjutkan **Langkah 10, 11, dan 12**
seperti biasa (di Langkah 13, lewati butir gembok dan domain).

Sertifikat ini berlaku 825 hari. Menjelang habis, ulangi perintah
`openssl` di atas lalu `systemctl reload nginx`.

---

## Lampiran B — Perintah sehari-hari

Semua dijalankan dari folder `/opt/ispku`:

```bash
cd /opt/ispku
```

| Keperluan | Perintah |
|---|---|
| Lihat status | `docker compose -f docker-compose.prod.yml ps` |
| Lihat log aplikasi (keluar: Ctrl+C) | `docker compose -f docker-compose.prod.yml logs -f app` |
| Buat cadangan sekarang | `docker compose -f docker-compose.prod.yml exec app flask backup-db` |
| Reset password akun | `docker compose -f docker-compose.prod.yml exec app flask reset-password --username admin` |
| Matikan aplikasi | `docker compose -f docker-compose.prod.yml down` |
| Nyalakan lagi | `docker compose -f docker-compose.prod.yml up -d` |
| Terapkan perubahan `.env` | `./install.sh` |

Pemulihan dari cadangan, pengiriman email, dan penerbitan invoice lewat
baris perintah dijelaskan di `docs/pemasangan.md`.

---

## Lampiran C — Menghapus ISPKU

> **Peringatan:** perintah di bawah **menghapus seluruh data secara
> permanen** — pelanggan, invoice, pembayaran, tiket, dokumen unggahan, dan
> semua cadangan di server. Tidak ada cara membatalkannya. Unduh cadangan
> terbaru lebih dulu lewat **Pengaturan → Sistem**.

```bash
cd /opt/ispku
docker compose -f docker-compose.prod.yml down -v
rm -rf /opt/ispku /etc/cron.d/ispku /etc/nginx/sites-enabled/ispku /etc/nginx/sites-available/ispku
systemctl reload nginx
```

`down -v` — huruf `-v` itulah yang membuang data. Tanpa `-v`, aplikasi hanya
dimatikan dan datanya tetap tersimpan.
