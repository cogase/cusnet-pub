import os

from alembic import context

from app.core.config import load_config
from app.core.db import Base, create_db_engine, index_ekspresi

import app.models_all  # noqa: F401  daftarkan seluruh model

config = context.config
target_metadata = Base.metadata
app_config = load_config(os.environ)


def _sertakan_objek(objek, _nama, tipe_, _reflected, _compare_to) -> bool:
    """Menyaring objek yang tidak bisa dibandingkan Alembic secara andal."""
    if tipe_ == "index" and index_ekspresi(objek):
        return False
    return True


def run_migrations_online() -> None:
    engine = create_db_engine(app_config.DATABASE_URL, app_config.APP_TIMEZONE)
    with engine.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_object=_sertakan_objek,
        )
        with context.begin_transaction():
            context.run_migrations()


run_migrations_online()
