"""CHECK constraint untuk kolom berdaftar nilai

Revision ID: 0020
Revises: 0019
Create Date: 2026-08-22 11:00:00.000000

Daftar nilai enum selama ini hanya hidup sebagai tuple Python dan diperiksa di
lapisan service. Yang tidak lewat service — impor yang salah kolom, perbaikan
darurat lewat `psql`, skrip migrasi data milik ISP sendiri — bisa menulis
nilai yang tidak dikenal siapa pun.

Nilai enum yang salah tidak pernah gagal dengan keras, ia gagal DIAM-DIAM:
`invoice_mode` di luar daftar membuat batch menerbitkan invoice dengan cara
yang tidak diminta, `subscription.status` di luar daftar membuat langganan
hilang dari daftar yang ditagih sehingga pelanggannya berhenti ditagih tanpa
ada layar yang memperlihatkannya, dan `role` yang salah ketik mengunci orang
dari aplikasinya sendiri.

Constraint dipasang dengan `NOT VALID` lalu langsung divalidasi terpisah.
Alasannya operasional: kalau pemasangan yang sudah berjalan ternyata memuat
baris bernilai asing, yang gagal adalah langkah VALIDATE — dan pesannya
menyebut tabel serta constraint yang bersangkutan, sehingga operator tahu
persis baris mana yang harus dibereskan. Tanpa pemisahan itu, kegagalannya
muncul sebagai satu galat panjang di tengah `alembic upgrade head` yang
menghentikan kontainer tanpa petunjuk.
"""
from typing import Sequence, Union

from alembic import op


revision: str = '0020'
down_revision: Union[str, None] = '0019'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# (nama, tabel, ekspresi) — sama persis dengan yang dirakit `enum_check`
# di `app/core/models.py`. Dua daftar yang berbeda adalah nilai yang diterima
# basis data tetapi ditolak aplikasi, jadi `tests/test_migrasi.py` dan
# `tests/test_enum_constraint.py` sama-sama menjaganya.
CONSTRAINT = [
    ("ck_customer_status", "customer",
     "status IN ('pending', 'active', 'suspend', 'terminasi')"),
    ("ck_customer_mode_invoice", "customer",
     "invoice_mode IN ('gabungan', 'terpisah')"),
    ("ck_customer_tipe", "customer",
     "customer_type IN ('corporate', 'sme', 'personal')"),
    ("ck_customer_tipe_bayar", "customer",
     "payment_type IN ('postpaid', 'prepaid')"),
    ("ck_subscription_status", "subscription",
     "status IN ('pending', 'active', 'suspend', 'terminasi')"),
    ("ck_subscription_jenis_diskon", "subscription",
     "discount_kind IS NULL OR discount_kind IN ('persen', 'nominal')"),
    ("ck_invoice_status", "invoice",
     "status IN ('draft', 'issued', 'partial', 'paid', 'overdue', 'void')"),
    ("ck_invoice_item_sumber", "invoice_item",
     "source IN ('langganan', 'addon', 'cicilan', 'manual')"),
    ("ck_payment_metode", "payment", "method IN ('transfer', 'tunai')"),
    ("ck_ticket_status", "ticket",
     "status IN ('baru', 'proses', 'pending', 'selesai', 'ditutup')"),
    ("ck_ticket_prioritas", "ticket",
     "priority IN ('rendah', 'sedang', 'tinggi', 'kritis')"),
    ("ck_app_user_role", "app_user",
     "role IN ('superadmin', 'admin_cabang', 'billing', 'teknis', 'viewer')"),
    ("ck_device_port_status", "device_port",
     "status IN ('bebas', 'terpakai', 'rusak', 'dicadangkan')"),
]


def upgrade() -> None:
    for nama, tabel, ekspresi in CONSTRAINT:
        op.execute(
            f'ALTER TABLE "{tabel}" ADD CONSTRAINT "{nama}" '
            f"CHECK ({ekspresi}) NOT VALID"
        )
    for nama, tabel, _ in CONSTRAINT:
        op.execute(f'ALTER TABLE "{tabel}" VALIDATE CONSTRAINT "{nama}"')


def downgrade() -> None:
    for nama, tabel, _ in reversed(CONSTRAINT):
        op.execute(f'ALTER TABLE "{tabel}" DROP CONSTRAINT "{nama}"')
