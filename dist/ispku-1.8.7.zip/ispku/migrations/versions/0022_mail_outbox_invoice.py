"""tautkan email antrean dengan invoice

Revision ID: 0022
Revises: 0021
Create Date: 2026-10-05 19:40:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0022"
down_revision: Union[str, None] = "0021"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "mail_outbox",
        sa.Column("invoice_id", sa.Integer(), nullable=True),
    )
    op.create_foreign_key(
        "fk_mail_outbox_invoice_id_invoice",
        "mail_outbox",
        "invoice",
        ["invoice_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index("ix_mail_outbox_invoice_id", "mail_outbox", ["invoice_id"])


def downgrade() -> None:
    op.drop_index("ix_mail_outbox_invoice_id", table_name="mail_outbox")
    op.drop_constraint(
        "fk_mail_outbox_invoice_id_invoice", "mail_outbox", type_="foreignkey"
    )
    op.drop_column("mail_outbox", "invoice_id")
