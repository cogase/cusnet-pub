"""merek aplikasi per ISP

Revision ID: 0014
Revises: 0013
Create Date: 2026-08-08 20:00:00.000000

Produk ini dijual ke banyak ISP, tetapi "CUSNET CRM" tertulis keras di
delapan templat. Tabel ini menampung merek yang bisa diganti pemasangnya.

Sengaja terpisah dari `billing_setting`: kolom merek di sana adalah kop surat
invoice, dan invoice memang boleh memakai nama badan hukum yang berbeda dari
nama dagang di aplikasi.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0014'
down_revision: Union[str, None] = '0013'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "app_branding",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("app_name", sa.String(length=60), nullable=False),
        sa.Column("app_name_suffix", sa.String(length=30), nullable=True),
        sa.Column("tagline", sa.String(length=120), nullable=True),
        sa.Column("logo_path", sa.String(length=500), nullable=True),
        sa.Column("accent_color", sa.String(length=7), nullable=False),
        sa.Column("login_headline", sa.String(length=160), nullable=True),
        sa.Column("login_body", sa.Text(), nullable=True),
        sa.Column("footer_text", sa.String(length=160), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint("id = 1", name="ck_app_branding_satu_baris"),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("app_branding")
