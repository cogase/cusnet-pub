"""network inventory

Revision ID: 0012
Revises: 0011
Create Date: 2026-08-07 22:00:00.000000

Site/POP, perangkat, port, VLAN, dan blok IP (M4).

Tidak ada data bawaan: site dan perangkat adalah data milik ISP-nya sendiri.
Menebaknya berarti mengarang isi inventaris orang.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0012'
down_revision: Union[str, None] = '0011'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _waktu():
    return (
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
    )


def upgrade() -> None:
    op.create_table(
        "site",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(length=20), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="pop"),
        sa.Column("address", sa.Text(), nullable=True),
        sa.Column("lat", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("lng", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("code"),
    )
    op.create_index("ix_site_branch", "site", ["branch_id"])

    op.create_table(
        "device",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("site_id", sa.Integer(), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="switch"),
        sa.Column("brand", sa.String(length=80), nullable=True),
        sa.Column("model", sa.String(length=80), nullable=True),
        sa.Column("mgmt_address", sa.String(length=120), nullable=True),
        sa.Column("serial_number", sa.String(length=80), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="aktif"),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["site_id"], ["site.id"]),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_device_site", "device", ["site_id"])
    op.create_index("ix_device_branch", "device", ["branch_id"])

    op.create_table(
        "device_port",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("device_id", sa.Integer(), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=60), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="access"),
        sa.Column("speed_mbps", sa.Integer(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="bebas"),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["device_id"], ["device.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="SET NULL"
        ),
        sa.PrimaryKeyConstraint("id"),
        # Satu port satu langganan, ditegakkan basis data — pemeriksaan
        # aplikasi saja bisa dilewati dua worker yang berbarengan.
        sa.UniqueConstraint("subscription_id", name="uq_port_langganan"),
        sa.UniqueConstraint("device_id", "name", name="uq_port_per_perangkat"),
    )
    op.create_index("ix_port_device", "device_port", ["device_id"])
    op.create_index("ix_port_branch_status", "device_port", ["branch_id", "status"])

    op.create_table(
        "vlan",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("vlan_id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("site_id", sa.Integer(), nullable=True),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="pelanggan"),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["site_id"], ["site.id"]),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="SET NULL"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("site_id", "vlan_id", name="uq_vlan_per_site"),
    )
    op.create_index("ix_vlan_branch", "vlan", ["branch_id"])

    op.create_table(
        "ip_block",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("cidr", sa.String(length=60), nullable=False),
        sa.Column("kind", sa.String(length=20), nullable=False, server_default="publik"),
        sa.Column("site_id", sa.Integer(), nullable=True),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("gateway", sa.String(length=60), nullable=True),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["site_id"], ["site.id"]),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="SET NULL"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("cidr", name="uq_blok_ip"),
    )
    op.create_index("ix_ip_block_branch", "ip_block", ["branch_id"])


def downgrade() -> None:
    op.drop_index("ix_ip_block_branch", table_name="ip_block")
    op.drop_table("ip_block")
    op.drop_index("ix_vlan_branch", table_name="vlan")
    op.drop_table("vlan")
    op.drop_index("ix_port_branch_status", table_name="device_port")
    op.drop_index("ix_port_device", table_name="device_port")
    op.drop_table("device_port")
    op.drop_index("ix_device_branch", table_name="device")
    op.drop_index("ix_device_site", table_name="device")
    op.drop_table("device")
    op.drop_index("ix_site_branch", table_name="site")
    op.drop_table("site")
