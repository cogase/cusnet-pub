"""billing

Revision ID: 0010
Revises: 0009
Create Date: 2026-08-07 09:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = '0010'
down_revision: Union[str, None] = '0009'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

KOLOM_SETTING_BARU = (
    ("invoice_day", sa.Integer(), False, "1"),
    ("company_name", sa.String(length=160), True, None),
    ("company_address", sa.Text(), True, None),
    ("company_phone", sa.String(length=40), True, None),
    ("company_email", sa.String(length=160), True, None),
    ("company_website", sa.String(length=160), True, None),
    ("company_npwp", sa.String(length=32), True, None),
    ("logo_path", sa.String(length=500), True, None),
    ("signature_path", sa.String(length=500), True, None),
    ("signer_name", sa.String(length=120), True, None),
    ("signer_title", sa.String(length=120), True, None),
    ("payment_terms_text", sa.Text(), True, None),
    ("footer_text", sa.Text(), True, None),
    ("accent_color", sa.String(length=7), False, "'#2563EB'"),
    ("smtp_host", sa.String(length=160), True, None),
    ("smtp_port", sa.Integer(), True, None),
    ("smtp_user", sa.String(length=160), True, None),
    ("smtp_password", sa.String(length=255), True, None),
    ("smtp_from", sa.String(length=160), True, None),
    ("email_subject_template", sa.String(length=255), True, None),
    ("email_body_template", sa.Text(), True, None),
)


def _waktu():
    return (
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )


def upgrade() -> None:
    for nama, tipe, nullable, bawaan in KOLOM_SETTING_BARU:
        op.add_column(
            "billing_setting",
            sa.Column(
                nama,
                tipe,
                nullable=nullable,
                server_default=sa.text(bawaan) if bawaan else None,
            ),
        )
    # server_default hanya dibutuhkan untuk mengisi baris yang sudah ada;
    # setelah itu dilepas supaya nilai bawaannya tetap milik model.
    for nama, _tipe, nullable, bawaan in KOLOM_SETTING_BARU:
        if bawaan and not nullable:
            op.alter_column("billing_setting", nama, server_default=None)

    op.create_table(
        "bank_account",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("bank_name", sa.String(length=80), nullable=False),
        sa.Column("account_number", sa.String(length=40), nullable=False),
        sa.Column("account_holder", sa.String(length=120), nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        *_waktu(),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "invoice",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("number", sa.String(length=60), nullable=True),
        sa.Column("seq_no", sa.Integer(), nullable=True),
        sa.Column("customer_id", sa.Integer(), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("period_start", sa.Date(), nullable=False),
        sa.Column("period_end", sa.Date(), nullable=False),
        sa.Column("issued_at", sa.Date(), nullable=True),
        sa.Column("due_at", sa.Date(), nullable=True),
        sa.Column("subtotal", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("discount_total", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("ppn_rate", sa.Numeric(precision=5, scale=2), nullable=False),
        sa.Column("ppn_amount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("total", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("void_reason", sa.Text(), nullable=True),
        sa.Column("corrects_invoice_id", sa.Integer(), nullable=True),
        sa.Column("created_by_user_id", sa.Integer(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(["corrects_invoice_id"], ["invoice.id"]),
        sa.ForeignKeyConstraint(["created_by_user_id"], ["app_user.id"]),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"]),
        sa.ForeignKeyConstraint(["subscription_id"], ["subscription.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("number"),
    )
    op.create_index("ix_invoice_customer_id", "invoice", ["customer_id"])
    op.create_index("ix_invoice_branch_id", "invoice", ["branch_id"])
    op.create_index("ix_invoice_status", "invoice", ["status"])
    op.execute(
        "CREATE UNIQUE INDEX uq_invoice_pelanggan_periode ON invoice "
        "(customer_id, period_start, coalesce(subscription_id, 0)) "
        "WHERE corrects_invoice_id IS NULL AND status <> 'void'"
    )

    op.create_table(
        "invoice_item",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("invoice_id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("source", sa.String(length=20), nullable=False),
        sa.Column("description", sa.String(length=255), nullable=False),
        sa.Column("subdescription", sa.String(length=255), nullable=True),
        sa.Column("period_start", sa.Date(), nullable=True),
        sa.Column("period_end", sa.Date(), nullable=True),
        sa.Column("qty", sa.Integer(), nullable=False),
        sa.Column("unit_price", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("discount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("amount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("is_prorated", sa.Boolean(), nullable=False),
        *_waktu(),
        sa.ForeignKeyConstraint(["invoice_id"], ["invoice.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["subscription_id"], ["subscription.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_invoice_item_invoice_id", "invoice_item", ["invoice_id"])

    op.create_table(
        "payment",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("invoice_id", sa.Integer(), nullable=False),
        sa.Column("paid_at", sa.Date(), nullable=False),
        sa.Column("amount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("method", sa.String(length=20), nullable=False),
        sa.Column("bank_account_id", sa.Integer(), nullable=True),
        sa.Column("reference", sa.String(length=120), nullable=True),
        sa.Column("proof_path", sa.String(length=500), nullable=True),
        sa.Column("recorded_by_user_id", sa.Integer(), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["bank_account_id"], ["bank_account.id"]),
        sa.ForeignKeyConstraint(["invoice_id"], ["invoice.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["recorded_by_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_payment_invoice_id", "payment", ["invoice_id"])

    op.create_table(
        "invoice_run",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("period_start", sa.Date(), nullable=False),
        sa.Column("period_end", sa.Date(), nullable=False),
        sa.Column("actor_user_id", sa.Integer(), nullable=True),
        sa.Column("created_count", sa.Integer(), nullable=False),
        sa.Column("failed_count", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("error_summary", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["actor_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("invoice_run")
    op.drop_index("ix_payment_invoice_id", table_name="payment")
    op.drop_table("payment")
    op.drop_index("ix_invoice_item_invoice_id", table_name="invoice_item")
    op.drop_table("invoice_item")
    op.drop_index("uq_invoice_pelanggan_periode", table_name="invoice")
    op.drop_index("ix_invoice_status", table_name="invoice")
    op.drop_index("ix_invoice_branch_id", table_name="invoice")
    op.drop_index("ix_invoice_customer_id", table_name="invoice")
    op.drop_table("invoice")
    op.drop_table("bank_account")
    for nama, _tipe, _nullable, _bawaan in reversed(KOLOM_SETTING_BARU):
        op.drop_column("billing_setting", nama)
