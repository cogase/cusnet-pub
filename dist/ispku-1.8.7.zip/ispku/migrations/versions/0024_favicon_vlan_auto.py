"""favicon aplikasi dan VLAN turunan layanan

Revision ID: 0024
Revises: 0023
Create Date: 2026-10-06 01:20:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql


revision: str = "0024"
down_revision: Union[str, None] = "0023"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Revisi 0023 pernah dipakai untuk favicon/VLAN pada paket lama. Saat
    # memperbarui instalasi itu, 0023 sudah tercatat meski preferensi belum ada.
    kolom = {
        nama_tabel: {c["name"] for c in sa.inspect(op.get_bind()).get_columns(nama_tabel)}
        for nama_tabel in ("app_user", "app_branding", "vlan")
    }
    if "preferences" not in kolom["app_user"]:
        op.add_column(
            "app_user",
            sa.Column(
                "preferences",
                postgresql.JSONB(astext_type=sa.Text()),
                server_default=sa.text("'{}'::jsonb"),
                nullable=False,
            ),
        )
    if "favicon_path" not in kolom["app_branding"]:
        op.add_column("app_branding", sa.Column("favicon_path", sa.String(500), nullable=True))
    if "is_auto" not in kolom["vlan"]:
        op.add_column(
            "vlan",
            sa.Column("is_auto", sa.Boolean(), server_default=sa.false(), nullable=False),
        )
        op.alter_column("vlan", "is_auto", server_default=None)


def downgrade() -> None:
    op.drop_column("vlan", "is_auto")
    op.drop_column("app_branding", "favicon_path")
