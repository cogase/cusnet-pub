"""data vendor pada hop transit

Revision ID: 0013
Revises: 0012
Create Date: 2026-08-08 10:00:00.000000

Hop transit dulu hanya menyimpan vendor dan label. Saat gangguan, yang
ditanyakan NOC vendor lebih dulu justru circuit ID dan nomor telepon —
tanpa kolom ini teknisi mencarinya di email lama.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0013'
down_revision: Union[str, None] = '0012'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

KOLOM_BARU = (
    ("circuit_id", sa.String(length=80)),
    ("vendor_phone", sa.String(length=40)),
    ("vlan", sa.String(length=20)),
    ("physical_note", sa.Text()),
)


def upgrade() -> None:
    for nama, tipe in KOLOM_BARU:
        op.add_column("p2p_transit_hop", sa.Column(nama, tipe, nullable=True))


def downgrade() -> None:
    for nama, _tipe in reversed(KOLOM_BARU):
        op.drop_column("p2p_transit_hop", nama)
