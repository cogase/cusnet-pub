"""vendor nama unik

Revision ID: 0007
Revises: 0006
Create Date: 2026-08-06 20:10:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0007'
down_revision: Union[str, None] = '0006'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Duplikat yang sudah telanjur ada tidak dirapikan diam-diam: nama vendor
    # dipakai di kontrak dan tagihan, jadi menggabungkan atau mengganti nama
    # adalah keputusan operator, bukan efek samping pembaruan versi. Migrasi
    # berhenti dengan pesan yang bisa dibaca, bukan IntegrityError mentah.
    duplikat = op.get_bind().execute(
        sa.text(
            """
            SELECT lower(trim(name)) AS kunci, count(*) AS jumlah
            FROM vendor
            GROUP BY lower(trim(name))
            HAVING count(*) > 1
            ORDER BY kunci
            """
        )
    ).all()

    if duplikat:
        rincian = ", ".join(f"'{kunci}' ({jumlah} baris)" for kunci, jumlah in duplikat)
        raise RuntimeError(
            "Ada nama vendor kembar yang hanya berbeda huruf besar-kecil atau "
            f"spasi: {rincian}. Gabungkan atau ganti namanya lebih dulu lewat "
            "halaman Vendor, lalu jalankan pembaruan ini lagi."
        )

    op.execute(
        "CREATE UNIQUE INDEX uq_vendor_nama_lower ON vendor (lower(trim(name)))"
    )


def downgrade() -> None:
    op.execute("DROP INDEX uq_vendor_nama_lower")
