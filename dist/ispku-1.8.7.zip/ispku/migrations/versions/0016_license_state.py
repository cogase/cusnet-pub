"""kunci lisensi yang sedang berlaku

Revision ID: 0016
Revises: 0015
Create Date: 2026-08-08 23:30:00.000000

Disimpan di basis data, bukan di `.env`: lisensi diperpanjang oleh orang yang
memegang aplikasinya, bukan oleh yang memegang shell server.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0016'
down_revision: Union[str, None] = '0015'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "license_state",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("key_text", sa.Text(), nullable=True),
        sa.Column("applied_by_user_id", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint("id = 1", name="ck_license_state_satu_baris"),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("license_state")
