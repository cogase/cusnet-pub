"""zona waktu aplikasi dipilih dari Pengaturan

Revision ID: 0027
Revises: 0026
Create Date: 2026-10-08 16:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0027"
down_revision: Union[str, None] = "0026"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Kosong berarti mengikuti APP_TIMEZONE di .env seperti sebelumnya.
    op.add_column("app_branding", sa.Column("timezone", sa.String(64), nullable=True))


def downgrade() -> None:
    op.drop_column("app_branding", "timezone")
