"""warna sidebar aplikasi

Revision ID: 0025
Revises: 0024
Create Date: 2026-10-08 12:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0025"
down_revision: Union[str, None] = "0024"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "app_branding",
        sa.Column(
            "sidebar_color", sa.String(7), nullable=False, server_default="#0B1220"
        ),
    )


def downgrade() -> None:
    op.drop_column("app_branding", "sidebar_color")
