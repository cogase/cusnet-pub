"""pelanggan

Revision ID: 0008
Revises: 0007
Create Date: 2026-08-06 20:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0008'
down_revision: Union[str, None] = '0007'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "customer",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("cid", sa.String(length=40), nullable=False),
        sa.Column("name", sa.String(length=160), nullable=False),
        sa.Column("alias", sa.String(length=80), nullable=True),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("customer_type", sa.String(length=20), nullable=False),
        sa.Column("tier", sa.String(length=20), nullable=False),
        sa.Column("category_id", sa.Integer(), nullable=True),
        sa.Column("source", sa.String(length=20), nullable=True),
        sa.Column("sales_user_id", sa.Integer(), nullable=True),
        sa.Column("install_address", sa.Text(), nullable=True),
        sa.Column("install_lat", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("install_lng", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("billing_same_as_install", sa.Boolean(), nullable=False),
        sa.Column("billing_address", sa.Text(), nullable=True),
        sa.Column("ktp_number", sa.String(length=32), nullable=True),
        sa.Column("npwp_number", sa.String(length=32), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("status_note", sa.Text(), nullable=True),
        sa.Column("invoice_mode", sa.String(length=20), nullable=False),
        sa.Column("payment_type", sa.String(length=20), nullable=False),
        sa.Column("credit_limit", sa.Numeric(precision=14, scale=2), nullable=True),
        sa.Column("ppn_exempt", sa.Boolean(), nullable=False),
        sa.Column("payment_term_days", sa.Integer(), nullable=True),
        sa.Column("joined_at", sa.Date(), nullable=True),
        sa.Column("activated_at", sa.Date(), nullable=True),
        sa.Column("terminated_at", sa.Date(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(["category_id"], ["customer_category.id"]),
        sa.ForeignKeyConstraint(["sales_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("cid"),
    )
    op.create_index("ix_customer_branch_id", "customer", ["branch_id"])
    op.create_index("ix_customer_status", "customer", ["status"])

    op.create_table(
        "customer_contact",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("job_title", sa.String(length=120), nullable=True),
        sa.Column("role", sa.String(length=20), nullable=False),
        sa.Column("phone", sa.String(length=40), nullable=True),
        sa.Column("email", sa.String(length=160), nullable=True),
        sa.Column("is_primary", sa.Boolean(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "uq_kontak_utama_per_pelanggan",
        "customer_contact",
        ["customer_id"],
        unique=True,
        postgresql_where=sa.text("is_primary"),
    )

    op.create_table(
        "customer_document",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.Integer(), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("doc_type", sa.String(length=20), nullable=False),
        sa.Column("original_name", sa.String(length=255), nullable=False),
        sa.Column("path", sa.String(length=500), nullable=False),
        sa.Column("size", sa.Integer(), nullable=False),
        sa.Column("mime", sa.String(length=80), nullable=False),
        sa.Column("uploaded_by_user_id", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["uploaded_by_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_customer_document_customer_id", "customer_document", ["customer_id"]
    )

    op.create_table(
        "customer_note",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.Integer(), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("author_user_id", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["author_user_id"], ["app_user.id"]),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_customer_note_customer_id", "customer_note", ["customer_id"])


def downgrade() -> None:
    op.drop_index("ix_customer_note_customer_id", table_name="customer_note")
    op.drop_table("customer_note")
    op.drop_index(
        "ix_customer_document_customer_id", table_name="customer_document"
    )
    op.drop_table("customer_document")
    op.drop_index("uq_kontak_utama_per_pelanggan", table_name="customer_contact")
    op.drop_table("customer_contact")
    op.drop_index("ix_customer_status", table_name="customer")
    op.drop_index("ix_customer_branch_id", table_name="customer")
    op.drop_table("customer")
