"""langganan

Revision ID: 0009
Revises: 0008
Create Date: 2026-08-06 22:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0009'
down_revision: Union[str, None] = '0008'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _waktu():
    return (
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )


def upgrade() -> None:
    op.create_table(
        "subscription",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.Integer(), nullable=False),
        sa.Column("plan_id", sa.Integer(), nullable=False),
        sa.Column("service_no", sa.String(length=60), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("started_at", sa.Date(), nullable=True),
        sa.Column("activated_at", sa.Date(), nullable=True),
        sa.Column("terminated_at", sa.Date(), nullable=True),
        sa.Column("price_override", sa.Numeric(precision=14, scale=2), nullable=True),
        sa.Column("discount_kind", sa.String(length=20), nullable=True),
        sa.Column("discount_value", sa.Numeric(precision=14, scale=2), nullable=True),
        sa.Column("ip_address", sa.String(length=60), nullable=True),
        sa.Column("vlan", sa.String(length=20), nullable=True),
        sa.Column("interface", sa.String(length=60), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["plan_id"], ["service_plan.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("service_no"),
    )
    op.create_index("ix_subscription_customer_id", "subscription", ["customer_id"])
    op.create_index("ix_subscription_status", "subscription", ["status"])

    op.create_table(
        "subscription_internet",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("capacity_mbps", sa.Integer(), nullable=True),
        sa.Column("internet_kind", sa.String(length=20), nullable=False),
        sa.Column("vendor_id", sa.Integer(), nullable=True),
        sa.Column("odp_name", sa.String(length=120), nullable=True),
        sa.Column("odp_lat", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("odp_lng", sa.Numeric(precision=10, scale=7), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["vendor_id"], ["vendor.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("subscription_id"),
    )

    op.create_table(
        "subscription_p2p",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("capacity_mbps", sa.Integer(), nullable=True),
        sa.Column("vendor_id", sa.Integer(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["vendor_id"], ["vendor.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("subscription_id"),
    )

    op.create_table(
        "p2p_termination",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("side", sa.String(length=1), nullable=False),
        sa.Column("site_name", sa.String(length=120), nullable=False),
        sa.Column("address", sa.Text(), nullable=True),
        sa.Column("lat", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("lng", sa.Numeric(precision=10, scale=7), nullable=True),
        sa.Column("vlan", sa.String(length=20), nullable=True),
        sa.Column("interface", sa.String(length=60), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("subscription_id", "side", name="uq_terminasi_sisi"),
    )
    op.create_index(
        "ix_p2p_termination_subscription_id", "p2p_termination", ["subscription_id"]
    )

    op.create_table(
        "p2p_transit_hop",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("urutan", sa.Integer(), nullable=False),
        sa.Column("vendor_id", sa.Integer(), nullable=True),
        sa.Column("label", sa.String(length=120), nullable=True),
        sa.Column("note", sa.Text(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["vendor_id"], ["vendor.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_p2p_transit_hop_subscription_id", "p2p_transit_hop", ["subscription_id"]
    )

    op.create_table(
        "subscription_addon",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("description", sa.String(length=160), nullable=False),
        sa.Column("qty", sa.Integer(), nullable=False),
        sa.Column("unit_price", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_subscription_addon_subscription_id", "subscription_addon", ["subscription_id"]
    )

    op.create_table(
        "subscription_installment",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("subscription_id", sa.Integer(), nullable=False),
        sa.Column("description", sa.String(length=160), nullable=False),
        sa.Column("total_amount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("terms", sa.Integer(), nullable=False),
        sa.Column("term_amount", sa.Numeric(precision=14, scale=2), nullable=False),
        sa.Column("terms_billed", sa.Integer(), nullable=False),
        sa.Column("started_at", sa.Date(), nullable=True),
        *_waktu(),
        sa.ForeignKeyConstraint(
            ["subscription_id"], ["subscription.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("subscription_id"),
    )


def downgrade() -> None:
    op.drop_table("subscription_installment")
    op.drop_index(
        "ix_subscription_addon_subscription_id", table_name="subscription_addon"
    )
    op.drop_table("subscription_addon")
    op.drop_index("ix_p2p_transit_hop_subscription_id", table_name="p2p_transit_hop")
    op.drop_table("p2p_transit_hop")
    op.drop_index("ix_p2p_termination_subscription_id", table_name="p2p_termination")
    op.drop_table("p2p_termination")
    op.drop_table("subscription_p2p")
    op.drop_table("subscription_internet")
    op.drop_index("ix_subscription_status", table_name="subscription")
    op.drop_index("ix_subscription_customer_id", table_name="subscription")
    op.drop_table("subscription")
