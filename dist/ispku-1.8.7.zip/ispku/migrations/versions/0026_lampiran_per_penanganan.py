"""lampiran evidence per langkah penanganan tiket

Revision ID: 0026
Revises: 0025
Create Date: 2026-10-08 15:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0026"
down_revision: Union[str, None] = "0025"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Kosong berarti lampiran milik tiketnya (cara lama); terisi berarti
    # evidence satu langkah penanganan.
    op.add_column(
        "ticket_attachment",
        sa.Column("comment_id", sa.Integer(), nullable=True),
    )
    op.create_foreign_key(
        "fk_ticket_attachment_comment",
        "ticket_attachment",
        "ticket_comment",
        ["comment_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.create_index(
        "ix_ticket_attachment_comment_id", "ticket_attachment", ["comment_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_ticket_attachment_comment_id", table_name="ticket_attachment")
    op.drop_constraint(
        "fk_ticket_attachment_comment", "ticket_attachment", type_="foreignkey"
    )
    op.drop_column("ticket_attachment", "comment_id")
