"""site layanan pada langganan

Revision ID: 0021
Revises: 0020
Create Date: 2026-10-05 12:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0021"
down_revision: Union[str, None] = "0020"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("subscription", sa.Column("site_name", sa.String(length=120)))


def downgrade() -> None:
    op.drop_column("subscription", "site_name")
