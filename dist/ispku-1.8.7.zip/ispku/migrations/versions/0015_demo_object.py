"""jejak data contoh

Revision ID: 0015
Revises: 0014
Create Date: 2026-08-08 22:00:00.000000

Data contoh menyebar ke belasan tabel. Satu tabel jejak jauh lebih murah
daripada kolom `is_demo` di setiap tabel, dan jauh lebih aman daripada
menghapus "semua yang namanya berawalan DEMO".
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0015'
down_revision: Union[str, None] = '0014'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "demo_object",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("entity_type", sa.String(length=60), nullable=False),
        sa.Column("entity_id", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("entity_type", "entity_id", name="uq_demo_object"),
    )


def downgrade() -> None:
    op.drop_table("demo_object")
