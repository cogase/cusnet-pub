"""pengingat tagihan otomatis

Revision ID: 0018
Revises: 0017
Create Date: 2026-08-14 12:00:00.000000

Tiga kolom pengaturan dan satu tabel jejak. `reminder_offsets` sengaja NULL
secara bawaan: pemasangan yang sudah berjalan tidak boleh tiba-tiba mulai
mengirimi pelanggan email karena satu migrasi.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0018'
down_revision: Union[str, None] = '0017'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "billing_setting",
        sa.Column("reminder_offsets", sa.String(length=60), nullable=True),
    )
    op.add_column(
        "billing_setting",
        sa.Column(
            "reminder_subject_template", sa.String(length=255), nullable=True
        ),
    )
    op.add_column(
        "billing_setting",
        sa.Column("reminder_body_template", sa.Text(), nullable=True),
    )

    op.create_table(
        "invoice_reminder",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("invoice_id", sa.Integer(), nullable=False),
        sa.Column("offset_hari", sa.Integer(), nullable=False),
        sa.Column(
            "queued_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["invoice_id"], ["invoice.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "invoice_id", "offset_hari", name="uq_pengingat_invoice_offset"
        ),
    )
    op.create_index(
        "ix_invoice_reminder_invoice_id",
        "invoice_reminder",
        ["invoice_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_invoice_reminder_invoice_id", table_name="invoice_reminder")
    op.drop_table("invoice_reminder")
    op.drop_column("billing_setting", "reminder_body_template")
    op.drop_column("billing_setting", "reminder_subject_template")
    op.drop_column("billing_setting", "reminder_offsets")
