"""indeks trigram untuk pencarian bebas

Revision ID: 0019
Revises: 0018
Create Date: 2026-08-22 10:00:00.000000

Delapan belas tempat di aplikasi mencari dengan `ILIKE '%kata%'`. Pola
berawalan `%` tidak bisa dilayani index btree sama sekali, jadi setiap
pencarian membaca seluruh tabel.

`pg_trgm` berstatus *trusted* sejak PostgreSQL 13: pemilik basis data bisa
memasangnya tanpa hak superuser. Kalau toh gagal, migrasi ini berhenti dengan
pesan yang menyebut apa yang harus dijalankan — bukan melewatinya diam-diam.
Skema yang tidak cocok dengan model adalah masalah yang jauh lebih mahal
daripada migrasi yang menolak jalan.

Kolomnya dipilih dari kolom yang benar-benar di-OR-kan dalam satu query
pencarian. Melewatkan satu saja membuat Postgres kembali memindai seluruh
tabel: bitmap OR hanya terbentuk kalau setiap cabangnya punya index.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '0019'
down_revision: Union[str, None] = '0018'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

INDEKS = [
    ("ix_customer_name_trgm", "customer", "name"),
    ("ix_customer_cid_trgm", "customer", "cid"),
    ("ix_customer_alias_trgm", "customer", "alias"),
    ("ix_customer_alamat_trgm", "customer", "install_address"),
    ("ix_invoice_number_trgm", "invoice", "number"),
    ("ix_payment_reference_trgm", "payment", "reference"),
    ("ix_ticket_number_trgm", "ticket", "number"),
    ("ix_ticket_title_trgm", "ticket", "title"),
]


def upgrade() -> None:
    try:
        op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
    except Exception as galat:  # noqa: BLE001 — dijelaskan ulang, bukan ditelan
        raise RuntimeError(
            "Gagal memasang extension pg_trgm yang dibutuhkan index pencarian: "
            f"{galat}. Jalankan `CREATE EXTENSION pg_trgm;` pada basis data "
            "aplikasi memakai akun yang berhak, lalu ulangi migrasi."
        ) from galat

    for nama, tabel, kolom in INDEKS:
        op.create_index(
            nama,
            tabel,
            [kolom],
            unique=False,
            postgresql_using="gin",
            postgresql_ops={kolom: "gin_trgm_ops"},
        )


def downgrade() -> None:
    for nama, tabel, _kolom in reversed(INDEKS):
        op.drop_index(nama, table_name=tabel)
    # Extension sengaja TIDAK dibuang: bisa jadi dipakai hal lain di basis data
    # yang sama, dan membuangnya lebih berisiko daripada meninggalkannya.
