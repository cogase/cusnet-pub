"""indeks subscription_id di invoice dan invoice_item

Revision ID: 0017
Revises: 0016
Create Date: 2026-08-14 09:00:00.000000

Penjaga penghapusan langganan menghitung invoice pemakainya lewat kedua
kolom ini. Tanpa indeks, satu penekanan tombol Hapus Layanan adalah
sequential scan atas dua tabel terbesar di aplikasi.

`CREATE INDEX` biasa, bukan `CONCURRENTLY`: tabelnya masih kecil di setiap
pemasangan yang ada, dan `CONCURRENTLY` tidak bisa dijalankan di dalam
transaksi migrasi Alembic.
"""
from typing import Sequence, Union

from alembic import op


revision: str = '0017'
down_revision: Union[str, None] = '0016'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_index(
        "ix_invoice_subscription_id", "invoice", ["subscription_id"], unique=False
    )
    op.create_index(
        "ix_invoice_item_subscription_id",
        "invoice_item",
        ["subscription_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_invoice_item_subscription_id", table_name="invoice_item")
    op.drop_index("ix_invoice_subscription_id", table_name="invoice")
