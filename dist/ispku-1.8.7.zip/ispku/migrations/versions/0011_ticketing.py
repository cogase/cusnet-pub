"""ticketing

Revision ID: 0011
Revises: 0010
Create Date: 2026-08-07 20:00:00.000000

Tiket, kategori beserta SLA-nya, komentar, dan lampiran (M3).

Empat kategori bawaan disisipkan supaya halaman Ticketing bisa langsung
dipakai setelah pemasangan — tanpa kategori, tombol "Tiket Baru" mengarah ke
formulir yang tidak bisa dikirim. Isinya kategori umum ISP, bukan data
pelanggan.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0011'
down_revision: Union[str, None] = '0010'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


KATEGORI_BAWAAN = (
    # kode, nama, prioritas bawaan, SLA respons (jam), SLA selesai (jam)
    ("GANGGUAN", "Gangguan Layanan", "tinggi", 2, 24),
    ("PUTUS", "Layanan Terputus Total", "kritis", 1, 8),
    ("LAMBAT", "Keluhan Kecepatan", "sedang", 4, 48),
    ("PERMINTAAN", "Permintaan Perubahan", "rendah", 8, 120),
)


def upgrade() -> None:
    op.create_table(
        "ticket_category",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(length=20), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column(
            "default_priority", sa.String(length=20), nullable=False,
            server_default="sedang",
        ),
        sa.Column(
            "sla_response_hours", sa.Integer(), nullable=False, server_default="4"
        ),
        sa.Column(
            "sla_resolve_hours", sa.Integer(), nullable=False, server_default="48"
        ),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("code"),
    )

    op.create_table(
        "ticket",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("number", sa.String(length=40), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.Integer(), nullable=True),
        sa.Column("subscription_id", sa.Integer(), nullable=True),
        sa.Column("category_id", sa.Integer(), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("priority", sa.String(length=20), nullable=False, server_default="sedang"),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="baru"),
        sa.Column("assigned_to_user_id", sa.Integer(), nullable=True),
        sa.Column("opened_by_user_id", sa.Integer(), nullable=True),
        sa.Column("opened_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("response_due_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolve_due_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("first_response_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolution", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(["customer_id"], ["customer.id"]),
        sa.ForeignKeyConstraint(["subscription_id"], ["subscription.id"]),
        sa.ForeignKeyConstraint(["category_id"], ["ticket_category.id"]),
        sa.ForeignKeyConstraint(["assigned_to_user_id"], ["app_user.id"]),
        sa.ForeignKeyConstraint(["opened_by_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("number"),
    )
    op.create_index("ix_ticket_branch_status", "ticket", ["branch_id", "status"])
    op.create_index("ix_ticket_customer", "ticket", ["customer_id"])
    op.create_index("ix_ticket_subscription", "ticket", ["subscription_id"])

    op.create_table(
        "ticket_comment",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("ticket_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("is_internal", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["ticket_id"], ["ticket.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_ticket_comment_ticket", "ticket_comment", ["ticket_id", "id"])

    op.create_table(
        "ticket_attachment",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("ticket_id", sa.Integer(), nullable=False),
        sa.Column("branch_id", sa.Integer(), nullable=False),
        sa.Column("original_name", sa.String(length=255), nullable=False),
        sa.Column("path", sa.String(length=500), nullable=False),
        sa.Column("size", sa.Integer(), nullable=False),
        sa.Column("mime", sa.String(length=100), nullable=False),
        sa.Column("uploaded_by_user_id", sa.Integer(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["ticket_id"], ["ticket.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["branch_id"], ["branch.id"]),
        sa.ForeignKeyConstraint(["uploaded_by_user_id"], ["app_user.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_ticket_attachment_ticket", "ticket_attachment", ["ticket_id"])

    kategori = sa.table(
        "ticket_category",
        sa.column("code", sa.String),
        sa.column("name", sa.String),
        sa.column("default_priority", sa.String),
        sa.column("sla_response_hours", sa.Integer),
        sa.column("sla_resolve_hours", sa.Integer),
    )
    op.bulk_insert(
        kategori,
        [
            {
                "code": kode,
                "name": nama,
                "default_priority": prioritas,
                "sla_response_hours": respons,
                "sla_resolve_hours": selesai,
            }
            for kode, nama, prioritas, respons, selesai in KATEGORI_BAWAAN
        ],
    )


def downgrade() -> None:
    op.drop_index("ix_ticket_attachment_ticket", table_name="ticket_attachment")
    op.drop_table("ticket_attachment")
    op.drop_index("ix_ticket_comment_ticket", table_name="ticket_comment")
    op.drop_table("ticket_comment")
    op.drop_index("ix_ticket_subscription", table_name="ticket")
    op.drop_index("ix_ticket_customer", table_name="ticket")
    op.drop_index("ix_ticket_branch_status", table_name="ticket")
    op.drop_table("ticket")
    op.drop_table("ticket_category")
