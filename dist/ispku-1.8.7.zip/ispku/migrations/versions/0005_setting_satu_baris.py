"""setting satu baris

Revision ID: 0005
Revises: 0004
Create Date: 2026-08-06 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0005'
down_revision: Union[str, None] = '0004'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_check_constraint(
        "ck_billing_setting_satu_baris", "billing_setting", "id = 1"
    )


def downgrade() -> None:
    op.drop_constraint(
        "ck_billing_setting_satu_baris", "billing_setting", type_="check"
    )
