#!/bin/sh
# Pemasang ISPKU.
#
#   ./install.sh
#
# Aman dijalankan berulang: `.env` yang sudah ada tidak pernah ditimpa, dan
# superadmin kedua tidak pernah dibuat. Menjalankan ulang setelah berkas
# sumbernya diperbarui (zip baru atau `git pull`) adalah cara memperbarui
# versi. Panduan dari server kosong: docs/panduan-instal-debian.md.
#
# Nilai awal bisa ditentukan sebelum menjalankan skrip. Hanya dipakai saat
# `.env` belum ada; sesudahnya ubah langsung di `.env`.
#   APP_PORT=7070 ./install.sh        port lain bila 6060 sudah terpakai
#   APP_BIND=127.0.0.1 ./install.sh   hanya bisa dibuka lewat nginx di server ini
set -eu

COMPOSE_FILE=docker-compose.prod.yml
ENV_FILE=.env

info()  { printf '\n\033[1m%s\033[0m\n' "$1"; }
galat() { printf '\n\033[31m%s\033[0m\n' "$1" >&2; exit 1; }
nilai_env() { grep -E "^$1=" "$ENV_FILE" | tail -n 1 | cut -d= -f2-; }

acak() {
    # 48 karakter acak dari /dev/urandom, dibersihkan menjadi karakter yang
    # aman dipakai di berkas .env tanpa tanda kutip.
    LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 48
}

# --- Prasyarat -------------------------------------------------------------

command -v docker >/dev/null 2>&1 \
    || galat "Docker belum terpasang. Pasang Docker lebih dulu (docs/panduan-instal-debian.md, Langkah 3)."
docker compose version >/dev/null 2>&1 \
    || galat "Plugin 'docker compose' belum ada. Pasang paket docker-compose-plugin."
# Docker terpasang tapi user ini tidak boleh memakainya — kasus paling
# sering pada pemula yang login sebagai user biasa. Tanpa pemeriksaan ini
# galatnya baru muncul di tengah jalan sebagai "permission denied".
docker info >/dev/null 2>&1 \
    || galat "Docker tidak bisa dipakai oleh user ini. Jalankan sebagai root (ketik: su -), lalu ulangi. Bila sudah root, nyalakan layanannya: systemctl start docker"

cd "$(dirname "$0")"
[ -f "$COMPOSE_FILE" ] || galat "$COMPOSE_FILE tidak ada. Jalankan skrip ini dari dalam folder ISPKU."

# --- 1. Berkas konfigurasi -------------------------------------------------

if [ -f "$ENV_FILE" ]; then
    info "[1/6] $ENV_FILE sudah ada — tidak disentuh."
else
    info "[1/6] Membuat $ENV_FILE dengan sandi acak."
    [ -f .env.example ] || galat ".env.example tidak ada; tidak bisa membuat $ENV_FILE."
    cp .env.example "$ENV_FILE"

    RAHASIA=$(acak)
    SANDI_DB=$(acak)

    # Nilai contoh di .env.example diganti nilai acak. APP_SECRET_KEY bawaan
    # ditolak aplikasi saat start — memang disengaja, supaya pemasangan yang
    # lupa menggantinya tidak pernah menyala.
    if [ -n "${APP_PORT:-}" ]; then
        sed -i "s|^APP_PORT=.*|APP_PORT=${APP_PORT}|" "$ENV_FILE"
    fi
    if [ -n "${APP_BIND:-}" ]; then
        sed -i "s|^APP_BIND=.*|APP_BIND=${APP_BIND}|" "$ENV_FILE"
    fi

    sed -i "s|^APP_SECRET_KEY=.*|APP_SECRET_KEY=${RAHASIA}|" "$ENV_FILE"
    sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=${SANDI_DB}|" "$ENV_FILE"
    sed -i "s|^DATABASE_URL=.*|DATABASE_URL=postgresql+psycopg://cusnet:${SANDI_DB}@db:5432/cusnet|" "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    echo "    Sandi basis data dan APP_SECRET_KEY dibuat acak dan disimpan di $ENV_FILE."
fi

# --- 2. Cadangan sebelum menyentuh apa pun --------------------------------

if docker compose -f "$COMPOSE_FILE" ps --status running --services 2>/dev/null | grep -q '^app$'; then
    info "[2/6] Pemasangan lama terdeteksi — membuat cadangan basis data lebih dulu."
    # `< /dev/null` di setiap `exec` bukan hiasan: tanpa itu perintah di
    # dalam kontainer ikut membaca stdin skrip ini, dan jawaban yang diketik
    # pengguna untuk prompt superadmin di bawah lenyap ditelan. Ketahuan saat
    # install.sh dijalankan tuntas untuk pertama kalinya.
    docker compose -f "$COMPOSE_FILE" exec -T app flask backup-db < /dev/null \
        || galat "Cadangan gagal. Pemasangan dihentikan sebelum menyentuh basis data."
else
    info "[2/6] Belum ada pemasangan yang berjalan — tidak ada yang perlu dicadangkan."
fi

# --- 3. Bangun dan jalankan -----------------------------------------------

info "[3/6] Membangun image dan menjalankan layanan (pertama kali bisa 5-15 menit)."
docker compose -f "$COMPOSE_FILE" up -d --build

info "[4/6] Menunggu aplikasi siap."
siap=0
i=1
while [ "$i" -le 60 ]; do
    if docker compose -f "$COMPOSE_FILE" exec -T app python -c \
        "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/healthz', timeout=2).status == 200 else 1)" \
        </dev/null >/dev/null 2>&1; then
        siap=1
        break
    fi
    sleep 2
    i=$((i + 1))
done

[ "$siap" -eq 1 ] || galat "Aplikasi tidak siap setelah 2 menit. Periksa: docker compose -f $COMPOSE_FILE logs app"

# --- 5. Superadmin ---------------------------------------------------------

info "[5/6] Memeriksa superadmin."
if docker compose -f "$COMPOSE_FILE" exec -T app python -c "
from app import create_app
from app.core.db import db_session
from app.modules.admin.models import User
create_app().app_context().push()
raise SystemExit(0 if db_session.query(User).filter_by(role='superadmin').first() else 1)
" </dev/null >/dev/null 2>&1; then
    echo "    Superadmin sudah ada — dilewati."
else
    echo "    Buat akun superadmin pertama (akun untuk masuk ke aplikasi)."
    printf '    Username superadmin: '; read -r NAMA_PENGGUNA
    printf '    Email              : '; read -r SUREL
    printf '    Nama lengkap       : '; read -r NAMA_LENGKAP
    # Diminta dua kali dan diperiksa di sini: salah ketik pada prompt yang
    # tidak menampilkan huruf baru ketahuan saat masuk pertama kali, dan
    # kalau ditolak aplikasi, seluruh skrip harus diulang.
    while :; do
        printf '    Password (min 8)   : '; stty -echo 2>/dev/null || true; read -r SANDI; stty echo 2>/dev/null || true; echo
        printf '    Ulangi password    : '; stty -echo 2>/dev/null || true; read -r SANDI2; stty echo 2>/dev/null || true; echo
        if [ "${#SANDI}" -lt 8 ]; then
            echo "    Password minimal 8 karakter. Ulangi."
        elif [ "$SANDI" != "$SANDI2" ]; then
            echo "    Kedua password tidak sama. Ulangi."
        else
            break
        fi
    done

    docker compose -f "$COMPOSE_FILE" exec -T app flask seed-superadmin \
        --username "$NAMA_PENGGUNA" --email "$SUREL" \
        --nama "$NAMA_LENGKAP" --password "$SANDI" < /dev/null \
        || galat "Pembuatan superadmin gagal. Aplikasi tetap berjalan; ulangi dengan menjalankan ./install.sh lagi."
fi

# --- 6. Data bawaan --------------------------------------------------------

info "[6/6] Menanam kategori layanan bawaan."
# Aman diulang: kategori yang sudah ada (termasuk yang sudah disunting)
# tidak ditimpa.
docker compose -f "$COMPOSE_FILE" exec -T app flask seed-master < /dev/null \
    || galat "Penanaman kategori layanan gagal. Periksa: docker compose -f $COMPOSE_FILE logs app"

# --- Selesai ---------------------------------------------------------------

PORT=$(nilai_env APP_PORT); PORT=${PORT:-6060}
BIND=$(nilai_env APP_BIND); BIND=${BIND:-0.0.0.0}
PROXY=$(nilai_env TRUSTED_PROXIES); PROXY=${PROXY:-0}

if [ "$BIND" = "127.0.0.1" ]; then
    printf '\n\033[32mISPKU siap.\033[0m  Aplikasi hanya mendengar di 127.0.0.1:%s — buka lewat alamat HTTPS (nginx) Anda.\n' "$PORT"
else
    IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    printf '\n\033[32mISPKU siap.\033[0m  Buka dari peramban: http://%s:%s\n' "${IP:-alamat-ip-server}" "$PORT"
fi

if grep -qE '^HTTPS_ONLY=(false|)$' "$ENV_FILE"; then
    cat <<'PESAN'

PERINGATAN: HTTPS_ONLY=false. Cookie sesi dikirim tanpa enkripsi.
Selama aplikasi ini hanya dibuka dari jaringan lokal, itu wajar. Sebelum
dibuka ke internet: pasang nginx + SSL (docs/panduan-instal-debian.md,
Langkah 7-9), lalu ubah HTTPS_ONLY=true di .env dan jalankan ulang skrip ini.
PESAN
fi

if [ "$PROXY" != "0" ] && [ "$BIND" != "127.0.0.1" ]; then
    cat <<PESAN

PERINGATAN KEAMANAN: TRUSTED_PROXIES=$PROXY tetapi APP_BIND=$BIND.
Port $PORT terbuka langsung ke luar, jadi siapa pun bisa memalsukan alamat
IP-nya dan melewati pembatas percobaan login. Ubah APP_BIND=127.0.0.1 di
.env, lalu jalankan ulang skrip ini.
PESAN
fi

cat <<PESAN

Perintah yang sering dipakai (jalankan dari folder ini):
  Status     : docker compose -f $COMPOSE_FILE ps
  Log        : docker compose -f $COMPOSE_FILE logs -f app
  Cadangan   : docker compose -f $COMPOSE_FILE exec app flask backup-db
  Berhenti   : docker compose -f $COMPOSE_FILE down
PESAN
