import re
from string import Formatter
from zlib import crc32

from sqlalchemy import text

TOKEN_DIKENAL = {"prefix", "branch", "seq", "YYYY", "MM", "cid"}
POLA_NOMOR_LAYANAN_BAWAAN = "{cid}-{seq:04d}"

_LEBAR_MAKS = 20
_ANGKA = re.compile(r"(\d+)")


class NumberingError(ValueError):
    """Pola atau penghitung nomor tidak sah."""


def _lebar_berlebihan(spek: str) -> bool:
    return any(int(angka) > _LEBAR_MAKS for angka in _ANGKA.findall(spek or ""))


def _token_dipakai(pattern: str) -> set[str]:
    """Mengurai pola dengan parser format Python, bukan regex.

    Regex sebelumnya (`\\{([A-Za-z_]+)(?::[^}]+)?\\}`) tidak mengenali bentuk
    seperti `{prefix.__class__}`, `{prefix!r}`, dan `{prefix:>99999}` —
    ketiganya lolos pemeriksaan lalu tetap dievaluasi oleh `str.format`.

    Token posisional (`{0}`) dan penanda kosong (`{}`) sengaja TIDAK ditolak
    di sini — dibiarkan gagal wajar di `pattern.format()` pada `render_pattern`,
    supaya pesannya tetap "Pola nomor tidak sah" seperti pola rusak lain.
    `tests/test_numbering.py::test_render_pattern_menolak_pola_rusak` sudah
    mengandalkan pesan persis itu untuk `{0}` dan `{prefix}-{}`, dan tidak
    boleh diubah.
    """
    dipakai: set[str] = set()

    try:
        bagian = list(Formatter().parse(pattern))
    except ValueError as galat:
        raise NumberingError(
            f"Pola nomor tidak sah: {pattern!r}. Periksa tanda kurung kurawalnya."
        ) from galat

    for _, nama, spek, konversi in bagian:
        if nama is None:
            continue
        if konversi is not None:
            raise NumberingError(
                "Pola nomor tidak boleh memakai konversi seperti !r atau !s."
            )
        if nama == "" or nama.isdigit():
            # Auto-numbering ({}) atau posisional ({0}) — bukan token
            # bernama, biarkan gagal wajar di pattern.format() di bawah.
            continue
        if "." in nama or "[" in nama:
            raise NumberingError(
                "Pola nomor tidak boleh mengakses atribut atau indeks."
            )
        if spek and "{" in spek:
            raise NumberingError(
                "Pola nomor tidak boleh memakai format bersarang seperti "
                "{prefix:{branch}} — lebarnya tidak bisa diperiksa lebih dulu."
            )
        if _lebar_berlebihan(spek):
            raise NumberingError(
                f"Lebar format pada pola nomor terlalu besar, maksimum {_LEBAR_MAKS}."
            )
        dipakai.add(nama)

    return dipakai


def render_pattern(pattern: str, **tokens) -> str:
    dipakai = _token_dipakai(pattern)
    tak_dikenal = dipakai - TOKEN_DIKENAL
    if tak_dikenal:
        raise NumberingError(
            "Pola memuat token yang tidak dikenal: " + ", ".join(sorted(tak_dikenal))
        )
    kurang = dipakai - set(tokens)
    if kurang:
        raise NumberingError(
            "Nilai untuk token berikut belum diberikan: " + ", ".join(sorted(kurang))
        )
    try:
        return pattern.format(**tokens)
    except (IndexError, KeyError, ValueError) as exc:
        raise NumberingError(
            f"Pola nomor tidak sah: {pattern!r}. Periksa tanda kurung kurawal "
            "dan nama tokennya."
        ) from exc


def _lock_key(scope: str) -> int:
    return crc32(scope.encode("utf-8")) - 2**31


def next_value(session, scope: str) -> int:
    session.execute(
        text("SELECT pg_advisory_xact_lock(:kunci)"), {"kunci": _lock_key(scope)}
    )
    nilai = session.execute(
        text(
            """
            INSERT INTO counter (scope, value, created_at, updated_at)
            VALUES (:scope, 1, now(), now())
            ON CONFLICT (scope)
            DO UPDATE SET value = counter.value + 1, updated_at = now()
            RETURNING value
            """
        ),
        {"scope": scope},
    ).scalar_one()
    return int(nilai)


def next_customer_cid(
    session, pattern: str, prefix: str, branch_code: str, branch_id: int
) -> str:
    """Membuat CID pelanggan berikutnya.

    Penghitung di-scope ke `branch_id`, bukan `branch_code`, karena kode cabang
    bisa disunting kapan saja lewat halaman Cabang. Kalau di-scope ke kode,
    mengganti kode cabang memutar ulang deret dan menghasilkan CID kembar.
    """
    seq = next_value(session, f"cid:{branch_id}")
    return render_pattern(pattern, prefix=prefix, branch=branch_code, seq=seq)


def next_service_no(
    session, customer_cid: str, pattern: str = POLA_NOMOR_LAYANAN_BAWAAN
) -> str:
    """Membuat nomor layanan berikutnya untuk satu pelanggan.

    Penghitung di-scope ke CID pelanggan, jadi tiap pelanggan punya deret
    sendiri mulai dari 1.
    """
    seq = next_value(session, f"service:{customer_cid}")
    return render_pattern(pattern, cid=customer_cid, seq=seq)


def next_invoice_number(session, pattern: str, year: int, month: int) -> tuple[str, int]:
    seq = next_value(session, f"invoice:{year:04d}-{month:02d}")
    seq_global = next_value(session, "invoice:global")
    nomor = render_pattern(
        pattern, YYYY=f"{year:04d}", MM=f"{month:02d}", seq=seq
    )
    return nomor, seq_global
