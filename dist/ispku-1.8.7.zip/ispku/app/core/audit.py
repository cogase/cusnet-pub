from datetime import date, datetime, time
from decimal import Decimal

from flask import has_request_context, request
from sqlalchemy import select

from app.core.auth import current_user
from app.modules.admin.models import AuditLog

SENSITIF: frozenset[str] = frozenset(
    {"password_hash", "password", "smtp_password", "client_secret"}
)


def _samarkan(nama: str, nilai):
    return "***" if nama in SENSITIF else nilai


def _json_aman(nilai):
    """`changes` disimpan sebagai JSONB — `Decimal` (mis. harga paket) tidak
    bisa diserialisasi JSON langsung, jadi diubah ke `str` dulu. Dilakukan di
    sini, bukan dengan `float()`, supaya nilai uang tidak pernah singgah
    lewat float di sepanjang jalurnya."""
    if isinstance(nilai, (datetime, date, time)):
        return nilai.isoformat()
    if isinstance(nilai, Decimal):
        return str(nilai)
    if isinstance(nilai, dict):
        return {k: _json_aman(v) for k, v in nilai.items()}
    if isinstance(nilai, list):
        return [_json_aman(v) for v in nilai]
    return nilai


def diff(before: dict | None, after: dict | None) -> dict:
    before = before or {}
    after = after or {}
    hasil = {}

    for nama in sorted(set(before) | set(after)):
        lama = before.get(nama)
        baru = after.get(nama)
        if lama == baru:
            continue
        hasil[nama] = {
            "dari": _json_aman(_samarkan(nama, lama)),
            "jadi": _json_aman(_samarkan(nama, baru)),
        }

    return hasil


def record(
    sesi,
    action: str,
    entity_type: str,
    entity_id: int | None,
    before: dict | None = None,
    after: dict | None = None,
    aktor=None,
) -> AuditLog:
    if aktor is None and has_request_context():
        aktor = current_user()
    ip = request.remote_addr if has_request_context() else None

    entri = AuditLog(
        actor_user_id=aktor.id if aktor else None,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        changes=diff(before, after) or None,
        ip_address=ip,
    )
    sesi.add(entri)
    return entri


def timeline(sesi, entity_type: str, entity_id: int, limit: int = 50) -> list[AuditLog]:
    query = (
        select(AuditLog)
        .where(AuditLog.entity_type == entity_type, AuditLog.entity_id == entity_id)
        .order_by(AuditLog.id.desc())
        .limit(limit)
    )
    return list(sesi.execute(query).scalars().all())
