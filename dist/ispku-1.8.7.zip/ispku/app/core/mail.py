import smtplib
from email.message import EmailMessage
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.sql import func

from app.modules.admin.models import MailOutbox

MAX_ATTEMPTS = 5


def _redaksi(teks: str, rahasia: str) -> str:
    """Menghapus password SMTP dari pesan galat sebelum disimpan."""
    if rahasia:
        teks = teks.replace(rahasia, "***")
    return teks


class MailNotConfigured(RuntimeError):
    """Pengaturan SMTP belum diisi."""


def antre(
    sesi,
    to_address: str,
    subject: str,
    body_html: str,
    attachment_path: str | None = None,
    invoice_id: int | None = None,
) -> MailOutbox:
    pesan = MailOutbox(
        invoice_id=invoice_id,
        to_address=to_address,
        subject=subject,
        body_html=body_html,
        attachment_path=attachment_path,
        status="antre",
        attempts=0,
    )
    sesi.add(pesan)
    return pesan


def _kirim_smtp(config, pesan: MailOutbox) -> None:
    surat = EmailMessage()
    surat["Subject"] = pesan.subject
    surat["From"] = config.SMTP_FROM
    surat["To"] = pesan.to_address
    surat.set_content(
        "Surat ini memerlukan penampil HTML.", subtype="plain"
    )
    surat.add_alternative(pesan.body_html, subtype="html")

    if pesan.attachment_path:
        berkas = Path(pesan.attachment_path)
        surat.add_attachment(
            berkas.read_bytes(),
            maintype="application",
            subtype="pdf",
            filename=berkas.name,
        )

    with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as smtp:
        if config.SMTP_USE_TLS:
            smtp.starttls()
        if config.SMTP_USER:
            smtp.login(config.SMTP_USER, config.SMTP_PASSWORD)
        smtp.send_message(surat)


def kirim_antrean(sesi, config, pengirim=None, batas: int = 50) -> dict:
    if not config.SMTP_HOST or not config.SMTP_FROM:
        raise MailNotConfigured(
            "Pengaturan SMTP belum diisi. Lengkapi di Pengaturan → Sistem."
        )

    pengirim = pengirim or _kirim_smtp

    antrean = (
        sesi.execute(
            select(MailOutbox)
            .where(MailOutbox.status == "antre")
            .order_by(MailOutbox.id)
            .limit(batas)
        )
        .scalars()
        .all()
    )

    terkirim = 0
    gagal = 0

    for pesan in antrean:
        try:
            pengirim(config, pesan)
        except Exception as exc:  # noqa: BLE001  kegagalan SMTP tidak boleh menular
            pesan.attempts += 1
            pesan.last_error = _redaksi(str(exc), config.SMTP_PASSWORD)
            if pesan.attempts >= MAX_ATTEMPTS:
                pesan.status = "gagal"
            gagal += 1
        else:
            pesan.status = "terkirim"
            pesan.sent_at = func.now()
            pesan.last_error = None
            terkirim += 1

    sesi.flush()
    return {"terkirim": terkirim, "gagal": gagal}
