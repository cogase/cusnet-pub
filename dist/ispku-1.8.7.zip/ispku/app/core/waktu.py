"""Satu jam untuk seluruh aplikasi: jam zona pemakai, bukan jam proses.

Kontainer berjalan di UTC dan Postgres pun `Etc/UTC` — hanya sesi basis
datanya yang dipaksa ke `APP_TIMEZONE`. Akibatnya `datetime.date.today()` di
dalam proses menjawab tanggal UTC, dan untuk pemakai di WIB itu **tanggal
kemarin** setiap hari antara pukul 00.00 dan 06.59:

    01.15 WIB 1 September  =  18.15 UTC 31 Agustus  ->  date.today() = 31 Agustus

Yang rusak karenanya bukan hal kecil: pekerjaan terjadwal yang dijalankan
dini hari memakai tanggal kemarin, pembayaran yang dicatat pukul satu pagi
tanggal 1 masuk ke laporan bulan sebelumnya, invoice yang diterbitkan subuh
bernomor bulan lalu, dan langganan yang diterminasi subuh terprorata sehari
lebih panjang.

Dua tempat di aplikasi ini sudah pernah menemukannya sendiri — halaman
dashboard dan laporan tiket — lalu menambalnya masing-masing. Modul ini yang
menggantikan tambalan-tambalan itu, dan `tests/test_arsitektur.py` yang
menjaga supaya jam kedua tidak lahir lagi.
"""

import os
from datetime import date, datetime
from zoneinfo import ZoneInfo

# Sama dengan bawaan `app.core.config._valid_timezone`. Ditulis ulang di sini,
# bukan diimpor, supaya modul ini tetap bisa dipakai tanpa memuat konfigurasi
# — mis. dari properti model yang dipanggil di luar konteks permintaan.
ZONA_BAWAAN = "Asia/Jakarta"


def nama_zona() -> str:
    """Nama zona yang berlaku: konfigurasi aplikasi, lalu environment, lalu bawaan."""
    try:
        from flask import current_app

        return current_app.config["APP_TIMEZONE"]
    except (RuntimeError, KeyError):
        return (os.environ.get("APP_TIMEZONE") or "").strip() or ZONA_BAWAAN


def zona() -> ZoneInfo:
    return ZoneInfo(nama_zona())


def sekarang() -> datetime:
    """Waktu sekarang di zona aplikasi, sudah beserta zonanya.

    Selalu *aware*. `datetime.now()` telanjang menghasilkan waktu naif yang
    diam-diam dibandingkan dengan kolom bertimezone dan menghasilkan galat
    yang membingungkan.
    """
    return datetime.now(zona())


def hari_ini() -> date:
    """Tanggal hari ini menurut zona aplikasi.

    Pengganti `date.today()` di seluruh kode aplikasi.
    """
    return sekarang().date()


def awal_bulan() -> date:
    """Tanggal 1 bulan berjalan menurut zona aplikasi."""
    sekarang_ = sekarang()
    return date(sekarang_.year, sekarang_.month, 1)
