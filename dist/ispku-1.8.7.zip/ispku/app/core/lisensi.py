"""Lisensi produk: berkas kunci bertanda tangan, diperiksa tanpa jaringan.

Tiga kenyataan menentukan bentuknya.

**Dijual on-premise, sering tanpa internet keluar.** Lisensi yang menelepon
pulang akan gagal justru di tempat ia dipakai. Verifikasi di sini murni
luring.

**Ini perangkat lunak penagihan.** Mematikan aplikasi karena lisensi lewat
berarti ISP tidak bisa menerbitkan invoice bulan itu — kerugiannya jatuh ke
pelanggan yang membayar, bukan ke pembajak. Modul ini **tidak pernah**
memblokir apa pun; ia hanya melaporkan keadaan, dan yang memakainya
menampilkan peringatan.

**Kuncinya ada di komputer pembeli.** Yang bisa dijamin hanya "kunci ini
benar diterbitkan penjual" — itulah sebabnya tanda tangannya asimetris
(Ed25519, kunci publik tertanam, kunci privat tidak pernah masuk repositori).
HMAC ditolak: rahasianya harus ikut terpasang di komputer pembeli, sehingga
siapa pun yang memegang aplikasinya bisa menerbitkan lisensi sendiri.
"""

import base64
import binascii
import json
from dataclasses import dataclass
from datetime import date

from app.core.errors import GalatDomain

# Kunci publik penerbit resmi CUSNET. Kunci privat pasangannya dipegang
# penjual dan tidak pernah masuk repositori ini. Pemasangan yang menerbitkan
# lisensinya sendiri cukup mengganti nilai ini lewat `LICENSE_PUBLIC_KEY`.
KUNCI_PUBLIK_BAWAAN = "wI0FJY2NKhR8g3PoL2BlM0q4w1cHrhPKVduYoOhRfy4="

MEDAN = ("pelanggan", "edisi", "batas_pelanggan", "diterbitkan", "kedaluwarsa", "catatan")


class LisensiTidakSah(GalatDomain):
    """Berkas lisensi tidak bisa dibaca atau tanda tangannya tidak cocok."""


@dataclass(frozen=True)
class Lisensi:
    pelanggan: str
    edisi: str
    batas_pelanggan: int | None
    diterbitkan: date | None
    kedaluwarsa: date | None
    catatan: str | None

    def kedaluwarsa_pada(self, hari_ini: date) -> bool:
        return self.kedaluwarsa is not None and hari_ini > self.kedaluwarsa

    def sisa_hari(self, hari_ini: date) -> int | None:
        if self.kedaluwarsa is None:
            return None
        return (self.kedaluwarsa - hari_ini).days


def _tanggal(nilai) -> date | None:
    if not nilai:
        return None
    try:
        return date.fromisoformat(str(nilai))
    except ValueError as galat:
        raise LisensiTidakSah("kunci", "Tanggal di dalam lisensi tidak sah.") from galat


def rakit_muatan(data: dict) -> bytes:
    """Bentuk baku muatan yang ditandatangani.

    Kunci diurutkan dan pemisahnya dipatok: satu spasi yang berbeda antara
    penerbit dan pemeriksa sudah cukup membuat setiap tanda tangan ditolak.
    """
    bersih = {nama: data.get(nama) for nama in MEDAN}
    return json.dumps(bersih, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _kunci_publik(kunci_b64: str):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        mentah = base64.b64decode(kunci_b64, validate=True)
    except (binascii.Error, ValueError) as galat:
        raise LisensiTidakSah(
            "kunci", "Kunci publik penerbit tidak sah di konfigurasi."
        ) from galat
    try:
        return Ed25519PublicKey.from_public_bytes(mentah)
    except ValueError as galat:
        raise LisensiTidakSah(
            "kunci", "Kunci publik penerbit tidak sah di konfigurasi."
        ) from galat


def baca(teks_kunci: str, kunci_publik: str | None = None) -> Lisensi:
    """Membaca dan memverifikasi berkas lisensi. Melempar bila tidak sah."""
    from cryptography.exceptions import InvalidSignature

    bersih = "".join((teks_kunci or "").split())
    if not bersih:
        raise LisensiTidakSah("kunci", "Kunci lisensi kosong.")

    try:
        amplop = json.loads(base64.b64decode(bersih, validate=True))
    except (binascii.Error, ValueError, UnicodeDecodeError) as galat:
        raise LisensiTidakSah(
            "kunci",
            "Kunci lisensi tidak bisa dibaca. Tempelkan seluruh isinya, "
            "termasuk baris terakhir.",
        ) from galat

    if not isinstance(amplop, dict) or "data" not in amplop or "ttd" not in amplop:
        raise LisensiTidakSah("kunci", "Bentuk kunci lisensi tidak dikenal.")

    muatan = rakit_muatan(amplop["data"])
    try:
        tanda_tangan = base64.b64decode(amplop["ttd"], validate=True)
    except (binascii.Error, ValueError) as galat:
        raise LisensiTidakSah("kunci", "Tanda tangan lisensi tidak sah.") from galat

    try:
        _kunci_publik(kunci_publik or KUNCI_PUBLIK_BAWAAN).verify(tanda_tangan, muatan)
    except InvalidSignature as galat:
        raise LisensiTidakSah(
            "kunci",
            "Tanda tangan lisensi tidak cocok. Kunci ini bukan terbitan "
            "penjual, atau isinya sudah diubah.",
        ) from galat

    data = amplop["data"]
    batas = data.get("batas_pelanggan")
    if batas is not None and (not isinstance(batas, int) or batas < 0):
        raise LisensiTidakSah("kunci", "Batas pelanggan di dalam lisensi tidak sah.")

    return Lisensi(
        pelanggan=str(data.get("pelanggan") or "").strip() or "(tanpa nama)",
        edisi=str(data.get("edisi") or "standar"),
        batas_pelanggan=batas,
        diterbitkan=_tanggal(data.get("diterbitkan")),
        kedaluwarsa=_tanggal(data.get("kedaluwarsa")),
        catatan=data.get("catatan") or None,
    )


def keadaan(lisensi: Lisensi | None, jumlah_pelanggan: int, hari_ini: date) -> dict:
    """Keadaan lisensi apa adanya, tanpa memblokir apa pun.

    `nada` dipakai templat untuk memilih warna spanduk; `peringatan` berisi
    kalimat yang bisa dibaca orang non-teknis.
    """
    if lisensi is None:
        return {
            "berlisensi": False,
            "nada": "peringatan",
            "judul": "Belum berlisensi",
            "peringatan": [
                "Pemasangan ini belum memakai kunci lisensi. Aplikasi tetap "
                "berjalan penuh; hubungi penjual untuk memperoleh kuncinya."
            ],
            "lisensi": None,
            "jumlah_pelanggan": jumlah_pelanggan,
        }

    peringatan = []
    nada = "sukses"

    if lisensi.kedaluwarsa_pada(hari_ini):
        nada = "bahaya"
        peringatan.append(
            f"Lisensi kedaluwarsa pada {lisensi.kedaluwarsa:%d %B %Y}. "
            "Aplikasi tetap berjalan penuh — tidak ada fitur yang dimatikan — "
            "tetapi pembaruan dan dukungan mengikuti masa berlaku."
        )
    elif lisensi.sisa_hari(hari_ini) is not None and lisensi.sisa_hari(hari_ini) <= 30:
        nada = "peringatan"
        peringatan.append(
            f"Lisensi berakhir dalam {lisensi.sisa_hari(hari_ini)} hari "
            f"({lisensi.kedaluwarsa:%d %B %Y})."
        )

    if lisensi.batas_pelanggan is not None and jumlah_pelanggan > lisensi.batas_pelanggan:
        nada = "bahaya"
        peringatan.append(
            f"Jumlah pelanggan aktif ({jumlah_pelanggan}) melewati batas "
            f"lisensi ({lisensi.batas_pelanggan}). Tidak ada yang diblokir; "
            "hubungi penjual untuk menaikkan batasnya."
        )

    return {
        "berlisensi": True,
        "nada": nada,
        "judul": f"Berlisensi — {lisensi.pelanggan}",
        "peringatan": peringatan,
        "lisensi": lisensi,
        "jumlah_pelanggan": jumlah_pelanggan,
    }
