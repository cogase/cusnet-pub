"""Templat subjek dan isi email invoice: satu daftar placeholder, dua lapis.

Templatnya diketik operator di Pengaturan > Billing dan dirakit dengan
`str.format`. Sebelum modul ini ada, tidak ada yang memeriksanya saat
disimpan: mengetik `{nama}` alih-alih `{pelanggan}` tersimpan tanpa keluhan,
lalu tombol Kirim gagal berminggu-minggu kemudian dengan `KeyError` yang
lolos jadi 500 — jauh dari tempat salah ketiknya, dan tanpa petunjuk apa pun.

`PLACEHOLDER` adalah satu-satunya sumber kebenaran: dipakai validasi maupun
pengiriman. Placeholder baru cukup ditambahkan sekali di sini, dan penamaan
yang menyimpang otomatis ditolak formulir.
"""

import string

from app.core.errors import GalatDomain

# Placeholder yang tersedia di setiap templat. Urutannya urutan tampil di pesan
# galat, jadi susun dari yang paling sering dicari.
DASAR: tuple[str, ...] = (
    "pelanggan",
    "nomor",
    "total",
    "jatuh_tempo",
    "perusahaan",
    "versi",
)

# Hanya ada saat pengingat dirakit: sisa tagihan sesudah pembayaran sebagian,
# dan jarak hari ke (atau dari) jatuh tempo.
PENGINGAT: tuple[str, ...] = DASAR + ("sisa", "hari")

# Daftar per medan, BUKAN satu daftar bersama. Membolehkan `{hari}` di templat
# pengiriman invoice berarti operator bisa menyimpan placeholder yang tidak
# pernah diisi di sana — dan itu `KeyError` saat tombol Kirim ditekan, yaitu
# persis cacat yang modul ini dibuat untuk mencegah.
PLACEHOLDER: dict[str, tuple[str, ...]] = {
    "email_subject_template": DASAR,
    "email_body_template": DASAR,
    "reminder_subject_template": PENGINGAT,
    "reminder_body_template": PENGINGAT,
}


class TemplatTidakSah(GalatDomain):
    """Templat email memakai placeholder yang tidak dikenal atau rusak."""


def _daftar_tersedia(medan: str | None = None) -> str:
    nama_nama = PLACEHOLDER[medan] if medan else DASAR
    return ", ".join("{" + nama + "}" for nama in nama_nama)


def periksa(field: str, templat: str | None) -> None:
    """Menolak templat yang tidak akan bisa dirender saat kirim.

    Yang ditolak ada tiga: placeholder di luar daftar, kurung yang tidak
    berpasangan, dan penggalian atribut atau indeks (`{pelanggan.__class__}`,
    `{total[0]}`). Yang terakhir sah menurut `str.format` tetapi bukan
    templat — membiarkannya berarti kolom teks di halaman Pengaturan jadi
    jalan membaca objek Python dari dalam aplikasi.
    """
    # Dibaca lebih dulu supaya nama medan yang salah ketik meledak sebagai
    # `KeyError` di sini — bukan diam-diam melewati seluruh pemeriksaan karena
    # templatnya kebetulan kosong.
    tersedia = PLACEHOLDER[field]

    if not templat:
        return

    try:
        potongan = list(string.Formatter().parse(templat))
    except ValueError as galat:
        raise TemplatTidakSah(
            field, f"Templat tidak bisa dibaca: {galat}. Periksa tanda kurungnya."
        ) from galat

    for _teks, nama, _spek, _konversi in potongan:
        if nama is None:
            continue
        if nama == "":
            raise TemplatTidakSah(
                field,
                "Kurung kosong `{}` tidak didukung. Sebutkan namanya, "
                f"misalnya {{pelanggan}}. Yang tersedia: {_daftar_tersedia(field)}.",
            )
        if nama not in tersedia:
            raise TemplatTidakSah(
                field,
                f"Placeholder {{{nama}}} tidak dikenal. "
                f"Yang tersedia: {_daftar_tersedia(field)}.",
            )


def render(templat: str, isian: dict) -> str:
    """Mengisi templat, dan mengubah kegagalannya jadi galat domain.

    Melindungi baris yang sudah terlanjur tersimpan sebelum `periksa` ada,
    dan operator yang menyunting basis data langsung. Tanpa ini yang sampai
    ke layar adalah 500, dan lampiran PDF yang sudah ditulis lebih dulu
    tertinggal di disk selamanya.
    """
    try:
        return templat.format(**isian)
    except (KeyError, IndexError, ValueError, AttributeError) as galat:
        raise TemplatTidakSah(
            "email_body_template",
            "Templat email di Pengaturan > Billing tidak bisa dirakit "
            f"({galat}). Perbaiki dulu templatnya. "
            f"Yang tersedia: {_daftar_tersedia()}.",
        ) from galat
