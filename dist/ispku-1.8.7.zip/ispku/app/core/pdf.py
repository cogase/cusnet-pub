"""Mencetak HTML menjadi PDF dengan WeasyPrint.

**Berkas tidak pernah diambil lewat HTTP.** WeasyPrint yang mengambil sendiri
gambar dari URL akan menabrak penjaga peran aplikasinya sendiri: logo kop
surat dan tanda tangan berada di rute berpenjaga, dan permintaan dari dalam
proses tidak membawa cookie sesi siapa pun. Hasilnya bukan galat, melainkan
PDF yang gambarnya kosong — persis jenis kerusakan yang baru ketahuan setelah
invoice dikirim ke pelanggan.

Karena itu ada `_pengambil`: setiap URL dipetakan ke berkas di disk, dan yang
tidak dikenali ditolak. Sekalian menutup satu jalan keluar: templat yang
kelak memuat gambar dari internet tidak akan diam-diam menghubungi jaringan
dari server pelanggan.
"""

import mimetypes
import pathlib
from urllib.parse import unquote, urlparse

from app.core.errors import GalatDomain


class GalatPdf(GalatDomain):
    """PDF gagal dibuat."""


def _pengambil(peta_berkas: dict, akar_static: pathlib.Path):
    """Membuat url_fetcher WeasyPrint yang hanya membaca disk."""

    def fetcher(url: str):
        if url.startswith("data:"):
            from weasyprint.urls import default_url_fetcher

            return default_url_fetcher(url)

        jalur = unquote(urlparse(url).path)

        berkas = peta_berkas.get(jalur)
        if berkas is None and jalur.startswith("/static/"):
            calon = (akar_static / jalur[len("/static/"):]).resolve()
            if calon.is_file() and calon.is_relative_to(akar_static.resolve()):
                berkas = calon

        if berkas is None:
            # Ditolak, bukan diambil dari jaringan. Server pelanggan sering
            # tanpa akses keluar, dan permintaan yang menggantung membuat
            # pencetakan macet tanpa penjelasan.
            raise GalatPdf(
                "berkas", f"Aset '{jalur}' tidak dikenali saat mencetak PDF."
            )

        berkas = pathlib.Path(berkas)
        mime = mimetypes.guess_type(str(berkas))[0] or "application/octet-stream"
        return {"string": berkas.read_bytes(), "mime_type": mime}

    return fetcher


def dari_html(html: str, peta_berkas: dict, akar_static: str) -> bytes:
    """HTML menjadi PDF. `peta_berkas` memetakan path URL ke berkas di disk."""
    try:
        from weasyprint import HTML
    except Exception as galat:  # noqa: BLE001 - pustaka sistem bisa hilang
        raise GalatPdf(
            "berkas",
            "WeasyPrint tidak bisa dimuat. Image aplikasi harus memasang "
            "libpango, libcairo, dan libgdk-pixbuf.",
        ) from galat

    dokumen = HTML(
        string=html,
        base_url="/",
        url_fetcher=_pengambil(peta_berkas, pathlib.Path(akar_static)),
    )
    return dokumen.write_pdf()
