import os
import pathlib
import uuid
from dataclasses import dataclass

MAX_UPLOAD_BYTES = 5 * 1024 * 1024

TIPE_DIIZINKAN: dict[str, str] = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "application/pdf": ".pdf",
}

_ANGKA_AJAIB = (
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"%PDF-", "application/pdf"),
)


class FileError(ValueError):
    """Berkas unggahan tidak sah."""


class PathDiluarUploadDir(ValueError):
    """Path berkas berada di luar direktori unggahan.

    Bukan galat domain: pengguna tidak bisa memperbaikinya lewat formulir.
    Kalau ini terjadi, baris di basis data rusak atau ada yang sedang mencoba
    membaca berkas sembarang di server lewat rute unduhan.
    """


@dataclass(frozen=True)
class StoredFile:
    path: str
    original_name: str
    size: int
    mime: str


def deteksi_mime(data: bytes) -> str | None:
    for awalan, mime in _ANGKA_AJAIB:
        if data.startswith(awalan):
            return mime
    return None


def _tulis_aman(tujuan: pathlib.Path, data: bytes) -> None:
    """Menulis berkas secara atomik dengan izin ketat sejak byte pertama.

    Berkas sementara dibuat langsung bermode 0600 lewat `os.open`, bukan
    di-`chmod` setelah ditulis — kalau penulisan gagal di tengah, potongan
    dokumen identitas tidak boleh sempat ada dengan izin longgar. Kegagalan
    apa pun membersihkan berkas sementaranya.
    """
    sementara = tujuan.with_name(f".{tujuan.name}.tmp")
    deskriptor = os.open(sementara, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(deskriptor, "wb") as berkas:
            berkas.write(data)
            berkas.flush()
            os.fsync(berkas.fileno())
        sementara.replace(tujuan)
    except BaseException:
        sementara.unlink(missing_ok=True)
        raise


def _nama_aman(nama_asli: str) -> str:
    """Membuang komponen path dan karakter kendali dari nama berkas.

    Karakter kendali membuat header `Content-Disposition` ditolak, sehingga
    berkasnya tidak akan pernah bisa diunduh.
    """
    dasar = pathlib.Path(nama_asli).name
    bersih = "".join(huruf for huruf in dasar if ord(huruf) >= 32)
    return bersih.strip() or "berkas"


def simpan(stream, nama_asli: str, upload_dir: str) -> StoredFile:
    data = stream.read(MAX_UPLOAD_BYTES + 1)

    if not data:
        raise FileError("Berkas kosong.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise FileError("Ukuran berkas melebihi batas 5 MB.")

    mime = deteksi_mime(data)
    if mime is None or mime not in TIPE_DIIZINKAN:
        raise FileError(
            "Tipe berkas tidak didukung. Hanya JPG, PNG, dan PDF yang diterima."
        )

    direktori = pathlib.Path(upload_dir)
    direktori.mkdir(parents=True, exist_ok=True)
    direktori.chmod(0o700)

    tujuan = direktori / f"{uuid.uuid4().hex}{TIPE_DIIZINKAN[mime]}"
    _tulis_aman(tujuan, data)

    return StoredFile(
        path=str(tujuan),
        original_name=_nama_aman(nama_asli),
        size=len(data),
        mime=mime,
    )


def mime_dari_path(path: str) -> str:
    """Menebak tipe MIME dari akhiran berkas yang tersimpan.

    Aman dipakai karena `simpan` yang menamai berkasnya: akhirannya diambil
    dari `TIPE_DIIZINKAN` menurut angka ajaib isi berkas, bukan dari nama yang
    dikirim pengunggah. Jadi akhiran di disk selalu cocok dengan isinya.

    Dipakai baris yang tidak menyimpan kolom mime sendiri (bukti pembayaran,
    logo kop surat). Baris yang punya kolomnya — dokumen pelanggan, lampiran
    tiket — tetap memakai kolom itu.
    """
    akhiran = pathlib.Path(path).suffix.lower()
    for mime, ekstensi in TIPE_DIIZINKAN.items():
        if ekstensi == akhiran:
            return mime
    return "application/octet-stream"


def format_ukuran(byte: int | None) -> str:
    """Ukuran berkas seperti di mockup: `812 KB`, `1.2 MB`."""
    if not byte:
        return "0 KB"
    if byte < 1024 * 1024:
        return f"{byte / 1024:.0f} KB"
    return f"{byte / (1024 * 1024):.1f} MB"


def _di_dalam(path: str, upload_dir: str) -> pathlib.Path:
    """Memastikan `path` benar-benar berada di bawah `upload_dir`.

    `resolve()` dipanggil pada keduanya supaya `..` dan symlink ikut
    diselesaikan — tanpa itu, symlink di dalam direktori unggahan yang
    menunjuk ke `/etc/passwd` lolos dari pemeriksaan awalan string.
    """
    dasar = pathlib.Path(upload_dir).resolve()
    berkas = pathlib.Path(path).resolve()
    if not berkas.is_relative_to(dasar):
        raise PathDiluarUploadDir(
            "Berkas berada di luar direktori unggahan dan tidak akan disajikan."
        )
    return berkas


def sajikan(path: str, nama_asli: str, mime: str, upload_dir: str):
    """Mengirim berkas unggahan sebagai unduhan.

    Selalu `attachment` dan selalu memakai mime yang tersimpan saat diunggah,
    bukan hasil menebak dari nama berkas. Berkas unggahan berasal dari pengguna;
    membiarkan peramban menebak tipenya membuka jalan berkas polyglot dieksekusi
    dalam konteks aplikasi.

    `path` datang dari baris basis data. Satu bug atau satu jalur impor yang
    salah mengubahnya menjadi pembacaan berkas sembarang di server, jadi
    path-nya dikurung ke `upload_dir` lebih dulu.
    """
    from flask import send_file

    return send_file(
        _di_dalam(path, upload_dir),
        mimetype=mime,
        as_attachment=True,
        download_name=nama_asli,
        max_age=0,
    )


def sajikan_sebaris(path: str, nama_asli: str, mime: str, upload_dir: str):
    """Menyajikan berkas unggahan dalam halaman, tetap di dalam upload_dir."""
    from flask import send_file

    return send_file(
        _di_dalam(path, upload_dir),
        mimetype=mime,
        as_attachment=False,
        download_name=nama_asli,
        max_age=0,
    )
