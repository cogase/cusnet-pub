from functools import wraps

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from flask import g, redirect, session, url_for
from sqlalchemy import or_, select

from app.core.db import db_session
from app.modules.admin.models import User

_hasher = PasswordHasher()
SESSION_KEY = "user_id"

_DUMMY_HASH = _hasher.hash("hash-pembanding-agar-waktu-eksekusi-setara")


def hash_password(plain: str) -> str:
    return _hasher.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return _hasher.verify(hashed, plain)
    except (VerifyMismatchError, VerificationError):
        return False


def authenticate(sesi, identifier: str, password: str) -> User | None:
    identifier = (identifier or "").strip()
    if not identifier or not password:
        return None

    user = sesi.execute(
        select(User).where(
            or_(User.username == identifier, User.email == identifier)
        )
    ).scalar_one_or_none()

    if user is None or not user.is_active:
        # Tetap hitung hash pembanding supaya waktu eksekusi tidak membocorkan
        # username mana yang ada di basis data.
        verify_password(password, _DUMMY_HASH)
        return None

    if not verify_password(password, user.password_hash):
        return None
    return user


def login_user(user: User) -> None:
    session.clear()
    session[SESSION_KEY] = user.id
    g.current_user = user


def logout_user() -> None:
    session.clear()
    g.pop("current_user", None)


def current_user() -> User | None:
    if "current_user" in g:
        return g.current_user

    user_id = session.get(SESSION_KEY)
    if user_id is None:
        return None

    user = db_session.get(User, user_id)
    if user is None or not user.is_active:
        session.clear()
        return None

    g.current_user = user
    return user


def login_required(view):
    @wraps(view)
    def pembungkus(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)

    return pembungkus
