"""Dasar formulir: contoh pengisian yang dipasang otomatis.

Placeholder ditaruh di satu peta, bukan ditulis ulang di tiap kelas formulir.
Alasannya sama dengan token warna dan skala huruf: contoh pengisian yang
tersebar akan berbeda-beda antar halaman dalam sebulan, dan yang paling
membutuhkannya — orang yang baru pertama membuka aplikasi — justru yang paling
tidak tahu mana yang benar.

Kuncinya **nama field**, bukan label, karena nama itulah yang stabil.
Formulir yang sudah menuliskan `render_kw={"placeholder": ...}` sendiri tidak
ditimpa: contoh yang lebih spesifik selalu menang.
"""

from flask_wtf import FlaskForm

# Nama field → contoh pengisian. Contohnya sengaja memakai data Indonesia yang
# masuk akal, bukan "lorem ipsum" atau "string".
CONTOH: dict[str, str] = {
    # Identitas pelanggan
    "name": "Contoh: PT Jaringan Nusantara",
    "alias": "Contoh: JNU",
    "cid": "Contoh: CUS-01-00001 (kosongkan agar dibuat otomatis)",
    "npwp_number": "Contoh: 01.234.567.8-901.000",
    "install_address": "Contoh: Jl. Sudirman No. 45, Lt. 3, Jakarta Pusat",
    "billing_address": "Contoh: sama dengan alamat instalasi",
    "install_lat": "Contoh: -6.2088",
    "install_lng": "Contoh: 106.8456",
    "lat": "Contoh: -6.2088",
    "lng": "Contoh: 106.8456",
    "credit_limit": "Contoh: 50.000.000",
    # Kontak
    "phone": "Contoh: 021-5551234 atau 0812-3456-7890",
    "email": "Contoh: noc@jaringan-nusantara.co.id",
    "job_title": "Contoh: Manajer IT",
    "company_website": "Contoh: https://jaringan-nusantara.co.id",
    # Katalog layanan
    "code": "Contoh: INT-DED-100",
    "capacity": "Contoh: 100 Mbps",
    "price": "Contoh: 3.500.000",
    "ppn_rate": "Contoh: 11",
    "description": "Contoh: Internet dedicated 1:1 dengan SLA 99,5%",
    # Langganan dan teknis
    "service_no": "Contoh: CUS-01-00001-0001",
    "ip_address": "Contoh: 103.10.10.2/29",
    "vlan": "Contoh: 313",
    "interface": "Contoh: TenGigabit0/1",
    "site_name": "Contoh: POP Jakarta Pusat",
    "capacity_mbps": "Contoh: 100",
    "odp_name": "Contoh: ODP-JKT-07",
    "olt_name": "Contoh: OLT-JKT-01",
    # Penomoran dan billing
    "cid_prefix": "Contoh: CUS",
    "cid_pattern": "Contoh: {prefix}-{branch}-{seq:05d}",
    "service_no_pattern": "Contoh: {cid}-{seq:04d}",
    "invoice_pattern": "Contoh: INV/{YYYY}/{MM}/{seq:04d}",
    "payment_term_days": "Contoh: 14",
    "amount": "Contoh: 3.885.000",
    "reference": "Contoh: TRF-20260907-001",
    "unit_price": "Contoh: 250.000",
    "qty": "Contoh: 1",
    "total_amount": "Contoh: 3.000.000",
    "terms": "Contoh: 12",
    # Kop surat dan email
    "company_name": "Contoh: PT Jaringan Nusantara",
    "company_address": "Contoh: Jl. Sudirman No. 45, Jakarta Pusat 10210",
    "company_phone": "Contoh: 021-5551234",
    "company_email": "Contoh: billing@jaringan-nusantara.co.id",
    "company_npwp": "Contoh: 01.234.567.8-901.000",
    "signer_name": "Contoh: Budi Santoso",
    "signer_title": "Contoh: Finance Manager",
    "payment_terms_text": "Contoh: Pembayaran paling lambat 14 hari setelah invoice terbit",
    "footer_text": "Contoh: Terima kasih atas kepercayaan Anda",
    "smtp_host": "Contoh: mail.jaringan-nusantara.co.id",
    "smtp_port": "Contoh: 587",
    "smtp_user": "Contoh: billing@jaringan-nusantara.co.id",
    "smtp_from": "Contoh: billing@jaringan-nusantara.co.id",
    "email_subject_template": "Contoh: Invoice {nomor} — {perusahaan}",
    "email_body_template": "Contoh: Yth. {pelanggan}, terlampir invoice {nomor} sebesar {total}, jatuh tempo {jatuh_tempo}.",
    "reminder_offsets": "Contoh: -3, 1, 7  (tiga hari sebelum, sehari sesudah, seminggu sesudah)",
    "reminder_subject_template": "Contoh: Pengingat tagihan {nomor} — {perusahaan}",
    "reminder_body_template": "Contoh: Yth. {pelanggan}, sisa tagihan {nomor} adalah {sisa}, jatuh tempo {jatuh_tempo} ({hari} hari).",
    # Rekening
    "bank_name": "Contoh: Bank Mandiri",
    "account_number": "Contoh: 1234567890",
    "account_holder": "Contoh: PT Jaringan Nusantara",
    "sort_order": "Contoh: 1",
    # Cabang dan pengguna
    "username": "Contoh: budi.santoso",
    "full_name": "Contoh: Budi Santoso",
    "password": "Minimal 12 karakter",
    "address": "Contoh: Jl. Sudirman No. 45, Jakarta Pusat",
    # Tiket
    "title": "Contoh: Internet mati total sejak pukul 08.00",
    "body": "Contoh: Sudah dicek dari sisi kami, link vendor down.",
    "resolution": "Contoh: Kabel FO putus di tiang depan ruko, sudah disambung.",
    # Inventaris
    "mgmt_address": "Contoh: 10.10.0.2 atau sw-core-01.jnu.local",
    "serial_number": "Contoh: FOC2145X0AB",
    "brand": "Contoh: Cisco",
    "model": "Contoh: C9200-48P",
    "speed_mbps": "Contoh: 1000",
    "cidr": "Contoh: 103.10.10.0/29",
    "gateway": "Contoh: 103.10.10.1",
    "vlan_id": "Contoh: 313",
    "note": "Contoh: catatan tambahan yang perlu diingat teknisi",
}


class FormDasar(FlaskForm):
    """`FlaskForm` yang memasang contoh pengisian dari `CONTOH`.

    Hanya untuk isian teks. Dropdown sudah memperlihatkan pilihannya sendiri,
    dan kotak centang tidak punya tempat untuk contoh.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self:
            contoh = CONTOH.get(field.name)
            if not contoh:
                continue
            if field.type in ("SelectField", "BooleanField", "FileField",
                              "SelectMultipleField", "HiddenField", "CSRFTokenField",
                              "PilihanIndonesia"):
                continue
            render_kw = dict(field.render_kw or {})
            # Contoh yang lebih spesifik, yang ditulis di kelas formulirnya
            # sendiri, selalu menang.
            render_kw.setdefault("placeholder", contoh)
            field.render_kw = render_kw
