from dataclasses import dataclass
from typing import Any

from sqlalchemy import func, select


PER_HALAMAN_PILIHAN = (20, 50, 100)
PER_HALAMAN_BAWAAN = 20


def per_halaman_dari(request) -> int:
    """Membaca `per_page` dari query string, dibatasi ke pilihan yang ada.

    Tanpa pembatasan, `?per_page=100000` adalah satu permintaan yang menarik
    seluruh tabel ke memori.
    """
    diminta = request.args.get("per_page", PER_HALAMAN_BAWAAN, type=int)
    return diminta if diminta in PER_HALAMAN_PILIHAN else PER_HALAMAN_BAWAAN


@dataclass(frozen=True)
class Page:
    items: list[Any]
    page: int
    per_page: int
    total: int

    @property
    def halaman_terakhir(self) -> int:
        if self.total == 0:
            return 1
        return ((self.total - 1) // self.per_page) + 1


def paginate(sesi, query, page: int = 1, per_page: int = 10) -> Page:
    page = max(page, 1)
    per_page = max(per_page, 1)

    query_hitung = select(func.count()).select_from(query.order_by(None).subquery())
    total = sesi.execute(query_hitung).scalar_one()

    items = (
        sesi.execute(query.limit(per_page).offset((page - 1) * per_page))
        .scalars()
        .all()
    )

    return Page(items=list(items), page=page, per_page=per_page, total=total)


def paginate_rows(sesi, query, page: int = 1, per_page: int = 10) -> Page:
    """Sama seperti `paginate`, tetapi mengembalikan baris utuh.

    `paginate` memakai `.scalars()` yang hanya mengambil entitas pertama tiap
    baris. Untuk query seperti `select(Customer, Branch)`, kolom kedua akan
    hilang diam-diam. Pakai fungsi ini bila query memilih lebih dari satu
    entitas.
    """
    page = max(page, 1)
    per_page = max(per_page, 1)

    query_hitung = select(func.count()).select_from(query.order_by(None).subquery())
    total = sesi.execute(query_hitung).scalar_one()

    baris = sesi.execute(query.limit(per_page).offset((page - 1) * per_page)).all()

    return Page(items=list(baris), page=page, per_page=per_page, total=total)
