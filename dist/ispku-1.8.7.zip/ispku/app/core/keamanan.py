"""Pengerasan yang tidak punya rumah di modul mana pun.

Header keamanan dan pembatasan laju login. Keduanya berlaku untuk seluruh
aplikasi, bukan untuk satu modul.
"""

from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, func, select

from app.modules.admin.models import LoginAttempt

BATAS_PERCOBAAN = 10
JENDELA_MENIT = 15

# Alamat pengganti untuk permintaan tanpa remote_addr (mis. socket unix).
# Dikumpulkan jadi satu ember supaya batasnya tetap berlaku, bukan lolos.
_IP_TAK_DIKENAL = "tak-dikenal"

HEADER_KEAMANAN = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
}


def _ip(ip: str | None) -> str:
    return (ip or _IP_TAK_DIKENAL)[:45]


def _sejak() -> datetime:
    return datetime.now(timezone.utc) - timedelta(minutes=JENDELA_MENIT)


def terlalu_sering(sesi, ip: str | None) -> bool:
    jumlah = sesi.execute(
        select(func.count())
        .select_from(LoginAttempt)
        .where(
            LoginAttempt.ip_address == _ip(ip),
            LoginAttempt.created_at >= _sejak(),
        )
    ).scalar_one()
    return jumlah >= BATAS_PERCOBAAN


def catat_kegagalan(sesi, ip: str | None, identifier: str) -> None:
    sesi.add(LoginAttempt(ip_address=_ip(ip), identifier=(identifier or "")[:160]))


def bersihkan_percobaan(sesi, ip: str | None) -> None:
    """Menghapus riwayat kegagalan setelah masuk berhasil.

    Sekalian membuang baris kedaluwarsa milik siapa pun, supaya tabelnya tidak
    tumbuh selamanya tanpa perlu tugas terjadwal terpisah.
    """
    sesi.execute(delete(LoginAttempt).where(LoginAttempt.ip_address == _ip(ip)))
    sesi.execute(delete(LoginAttempt).where(LoginAttempt.created_at < _sejak()))


def pasang_header(respons):
    for nama, nilai in HEADER_KEAMANAN.items():
        respons.headers.setdefault(nama, nilai)
    return respons
