"""Perhitungan kontras warna (WCAG 2.1).

Warna aksen dipilih pemasang, dan teks putih dicetak di atasnya di tombol
utama, lencana, dan tautan aktif. Kontras yang buruk tidak terlihat oleh
orang yang memilih warnanya — layar bagus, mata sehat, ruangan terang. Karena
itu rasionya **dihitung**, bukan dinilai.
"""

AMBANG_TEKS_NORMAL = 4.5


def _kanal(nilai: int) -> float:
    s = nilai / 255
    return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4


def urai_hex(warna: str) -> tuple[int, int, int]:
    teks = (warna or "").strip().lstrip("#")
    if len(teks) != 6:
        raise ValueError("Warna harus berbentuk #RRGGBB.")
    return tuple(int(teks[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def luminans(warna: str) -> float:
    merah, hijau, biru = urai_hex(warna)
    return 0.2126 * _kanal(merah) + 0.7152 * _kanal(hijau) + 0.0722 * _kanal(biru)


def kontras(warna_a: str, warna_b: str) -> float:
    """Rasio kontras dua warna, 1.0 sampai 21.0."""
    a, b = luminans(warna_a), luminans(warna_b)
    terang, gelap = max(a, b), min(a, b)
    return (terang + 0.05) / (gelap + 0.05)
