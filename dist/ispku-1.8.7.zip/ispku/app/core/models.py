from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, Numeric, func
from sqlalchemy.orm import Mapped, mapped_column

Money = Numeric(14, 2, asdecimal=True)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


def enum_check(
    nama: str, kolom: str, nilai: tuple[str, ...], boleh_kosong: bool = False
) -> CheckConstraint:
    """CHECK constraint yang dirakit dari tuple enum modelnya sendiri.

    Dirakit, bukan ditulis ulang: daftar yang disalin ke dua tempat akan
    berbeda pada suatu hari, dan yang berbeda adalah nilai yang diterima basis
    data tetapi ditolak aplikasi — atau sebaliknya.

    Nilai enum yang salah tidak pernah gagal dengan keras, ia gagal diam-diam.
    `invoice_mode` di luar daftar membuat batch menerbitkan invoice dengan cara
    yang tidak diminta; `subscription.status` di luar daftar membuat langganan
    hilang dari `STATUS_DITAGIH` sehingga pelanggannya berhenti ditagih tanpa
    ada layar yang memperlihatkannya.
    """
    daftar = ", ".join(f"'{v}'" for v in nilai)
    ekspresi = f"{kolom} IN ({daftar})"
    if boleh_kosong:
        ekspresi = f"{kolom} IS NULL OR {ekspresi}"
    return CheckConstraint(ekspresi, name=nama)
