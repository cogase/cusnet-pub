from collections.abc import Iterable
from decimal import Decimal, ROUND_HALF_UP

DUA_DESIMAL = Decimal("0.01")
NOL = Decimal("0.00")


class MoneyError(ValueError):
    """Nilai uang tidak sah."""


def to_money(value) -> Decimal:
    if isinstance(value, float):
        raise MoneyError(
            "Nilai uang tidak boleh bertipe float. Pakai Decimal atau str."
        )
    if not isinstance(value, Decimal):
        value = Decimal(str(value))
    return value.quantize(DUA_DESIMAL, rounding=ROUND_HALF_UP)


def apply_percent(amount: Decimal, percent: Decimal) -> Decimal:
    return to_money(to_money(amount) * to_money(percent) / Decimal("100"))


def apply_discount(
    amount: Decimal, percent: Decimal | None, nominal: Decimal | None
) -> Decimal:
    if percent is not None and nominal is not None:
        raise MoneyError("Diskon hanya boleh salah satu: persen atau nominal.")

    base = to_money(amount)
    if percent is not None:
        base -= apply_percent(base, percent)
    elif nominal is not None:
        base -= to_money(nominal)

    return to_money(max(base, NOL))


def prorate(monthly_price: Decimal, active_days: int, days_in_period: int) -> Decimal:
    if days_in_period <= 0:
        raise MoneyError("Jumlah hari dalam periode harus lebih dari nol.")
    if active_days < 0 or active_days > days_in_period:
        raise MoneyError(
            "Jumlah hari aktif harus antara 0 dan jumlah hari dalam periode."
        )
    return to_money(
        to_money(monthly_price) * Decimal(active_days) / Decimal(days_in_period)
    )


def total(amounts: Iterable[Decimal]) -> Decimal:
    jumlah = NOL
    for amount in amounts:
        jumlah += to_money(amount)
    return to_money(jumlah)


def _pisah_ribuan(bulat: int) -> str:
    return f"{bulat:,}".replace(",", ".")


def format_rupiah(value: Decimal) -> str:
    nilai = to_money(value)
    bulat = int(nilai.to_integral_value(rounding=ROUND_HALF_UP))
    return f"Rp {_pisah_ribuan(bulat)}"


_SATUAN = (
    "", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan",
    "sembilan", "sepuluh", "sebelas",
)


def _terbilang_bulat(angka: int) -> str:
    """Angka bulat menjadi kata. Dipakai kwitansi.

    "Seribu", bukan "satu ribu"; "seratus", bukan "satu ratus" — itu yang
    membedakan kwitansi yang dibaca orang dari terjemahan mesin.
    """
    if angka < 12:
        return _SATUAN[angka]
    if angka < 20:
        return _terbilang_bulat(angka - 10) + " belas"
    if angka < 100:
        return (
            _terbilang_bulat(angka // 10) + " puluh "
            + _terbilang_bulat(angka % 10)
        ).strip()
    if angka < 200:
        return ("seratus " + _terbilang_bulat(angka - 100)).strip()
    if angka < 1000:
        return (
            _terbilang_bulat(angka // 100) + " ratus "
            + _terbilang_bulat(angka % 100)
        ).strip()
    if angka < 2000:
        return ("seribu " + _terbilang_bulat(angka - 1000)).strip()
    if angka < 1_000_000:
        return (
            _terbilang_bulat(angka // 1000) + " ribu "
            + _terbilang_bulat(angka % 1000)
        ).strip()
    if angka < 1_000_000_000:
        return (
            _terbilang_bulat(angka // 1_000_000) + " juta "
            + _terbilang_bulat(angka % 1_000_000)
        ).strip()
    if angka < 1_000_000_000_000:
        return (
            _terbilang_bulat(angka // 1_000_000_000) + " miliar "
            + _terbilang_bulat(angka % 1_000_000_000)
        ).strip()
    return (
        _terbilang_bulat(angka // 1_000_000_000_000) + " triliun "
        + _terbilang_bulat(angka % 1_000_000_000_000)
    ).strip()


def terbilang(value: Decimal) -> str:
    """Nominal menjadi kalimat rupiah, untuk kwitansi.

    Dibulatkan ke rupiah penuh seperti `format_rupiah`: kwitansi yang
    angkanya berbeda dari huruf pada lembar yang sama adalah kwitansi yang
    dipersoalkan.
    """
    nilai = to_money(value)
    bulat = int(nilai.to_integral_value(rounding=ROUND_HALF_UP))
    if bulat == 0:
        return "Nol rupiah"
    kata = _terbilang_bulat(abs(bulat))
    awalan = "Minus " if bulat < 0 else ""
    return f"{awalan}{kata} rupiah".replace("  ", " ").capitalize()


def _lucuti_nol_ekor(teks: str) -> str:
    """Buang satu nol berlebih di ekor desimal, sisakan minimal satu digit.

    `Decimal("1.00")` tampil sebagai "1.00" padahal cukup "1.0" — quantize ke
    dua desimal selalu mengisi ekor meski tidak signifikan (mis. tepat di
    ambang 1 miliar). Angka dengan desimal signifikan (mis. "1.24") tidak
    tersentuh.
    """
    if "." not in teks:
        return teks
    teks = teks.rstrip("0")
    if teks.endswith("."):
        teks += "0"
    return teks


def format_rupiah_singkat(value: Decimal) -> str:
    nilai = to_money(value)
    absolut = abs(nilai)

    if absolut >= Decimal("1000000"):
        # Bulatkan ke satuan juta HANYA untuk memutuskan cabang Jt atau M.
        # Menentukan satuan dari nilai mentah membuat 999.999.999 tampil
        # sebagai "Rp 1000,0 Jt" alih-alih "Rp 1,0 M". Angka yang DITAMPILKAN
        # selalu dihitung ulang dari nilai asli (bukan dari `juta` yang sudah
        # dibulatkan), supaya tidak terjadi pembulatan dua kali yang bisa
        # menggeser hasil satu langkah (mis. 1.004.999.999 salah menjadi
        # "1,01 M" bila dihitung dari `juta` yang sudah dibulatkan ke 1005.0).
        juta = (nilai / Decimal("1000000")).quantize(
            Decimal("0.1"), rounding=ROUND_HALF_UP
        )
        if abs(juta) >= Decimal("1000"):
            miliar = (nilai / Decimal("1000000000")).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            angka = _lucuti_nol_ekor(str(miliar))
            return f"Rp {angka.replace('.', ',')} M"
        angka = _lucuti_nol_ekor(str(juta))
        return f"Rp {angka.replace('.', ',')} Jt"

    return format_rupiah(nilai)
