"""Galat domain yang dipetakan ke halaman galat oleh app factory."""


class TidakDitemukan(LookupError):
    """Entitas yang diminta tidak ada.

    Turunan `LookupError` supaya pemanggil lama yang menangkap `LookupError`
    tetap bekerja, tetapi penangan galat aplikasi hanya menangkap kelas ini —
    `KeyError` dan `IndexError` yang berarti bug harus tetap menjadi 500 dan
    tetap tercatat di log.
    """


class GalatDomain(ValueError):
    """Aturan bisnis yang dilanggar, beserta field formulir yang disalahkan.

    Setiap galat domain modul mewarisi kelas ini supaya `views.py` cukup
    menangkapnya sekali:

        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))

    Turunan `ValueError` supaya pemanggil lama yang menangkap `ValueError`
    tetap bekerja. `.field` selalu berisi nama field formulir yang benar-benar
    ada — kalau galatnya tidak punya field yang jelas, pakai field terdekat
    yang memicunya, jangan `None`: rute akan memanggil `getattr(form, field)`.
    """

    def __init__(self, field: str, pesan: str):
        super().__init__(pesan)
        self.field = field
