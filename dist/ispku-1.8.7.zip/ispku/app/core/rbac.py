from functools import wraps

from flask import abort, redirect, url_for

from app.core.auth import current_user
from app.modules.admin.models import User

LINTAS_CABANG: frozenset[str] = frozenset({"superadmin"})
HALAMAN_AWAL_PERAN: dict[str, str] = {
    "superadmin": "dashboard.index",
    "admin_cabang": "dashboard.index",
    "billing": "billing.dashboard",
    "teknis": "dashboard.index",
    "viewer": "dashboard.index",
}


def halaman_awal(user: User | None) -> str:
    """Endpoint tujuan bawaan setelah pengguna berhasil masuk."""
    return (
        HALAMAN_AWAL_PERAN.get(user.role, "dashboard.index")
        if user
        else "dashboard.index"
    )


# Operasi cadangan memuat seluruh basis data — hash sandi, KTP, NPWP, semua
# cabang sekaligus — jadi tetap di luar jangkauan admin cabang.
ENDPOINT_CADANGAN: frozenset[str] = frozenset({
    "settings.cadangan_buat",
    "settings.cadangan_unggah",
    "settings.cadangan_unduh",
    "settings.cadangan_hapus",
    "settings.cadangan_pulihkan",
})
# Modul (blueprint) yang boleh diubah tiap peran non-admin, ditambah endpoint
# lepas di luar modul itu. Dipakai tampilan untuk menyembunyikan aksi ubah;
# larangan sebenarnya tetap ditegakkan `require_role` di tiap rute.
MODUL_TULIS_PERAN: dict[str, tuple[str, ...]] = {
    "billing": ("billing.", "customers.", "services."),
    "teknis": ("tickets.", "inventory."),
}
ENDPOINT_TULIS_PERAN: dict[str, frozenset[str]] = {
    "billing": frozenset({
        "admin.cabang_daftar",
        "admin.cabang_ubah",
        "settings.billing",
        "settings.kop",
        "settings.email",
        "settings.rekening_daftar",
        "settings.rekening_baru",
        "settings.rekening_ubah",
        "settings.rekening_hapus",
    }),
}
# Menu utama yang ditampilkan nonaktif per peran.
MENU_NONAKTIF_PERAN: dict[str, frozenset[str]] = {
    "teknis": frozenset({"billing"}),
}
# Entitas audit yang memuat nominal; disembunyikan dari peran tanpa akses
# billing supaya audit log tidak menjadi pintu belakang ke angka tagihan.
ENTITAS_AUDIT_KEUANGAN: frozenset[str] = frozenset({
    "invoice",
    "invoice_item",
    "invoice_run",
    "payment",
    "bank_account",
    "billing_setting",
    "subscription_addon",
    "subscription_installment",
})
PERAN_TANPA_KEUANGAN: frozenset[str] = frozenset({"teknis"})


def boleh_mengubah(user: User | None, endpoint: str | None) -> bool:
    """Apakah halaman `endpoint` menampilkan aksi ubah untuk `user`."""
    if user is None:
        return False
    endpoint = endpoint or ""
    if user.role == "superadmin":
        return True
    if user.role == "admin_cabang":
        return endpoint not in ENDPOINT_CADANGAN
    return endpoint.startswith(
        MODUL_TULIS_PERAN.get(user.role, ())
    ) or endpoint in ENDPOINT_TULIS_PERAN.get(user.role, frozenset())


def menu_dinonaktifkan(user: User | None, kunci_menu: str) -> bool:
    """Apakah menu utama `kunci_menu` ditampilkan nonaktif untuk `user`."""
    if user is None:
        return False
    return kunci_menu in MENU_NONAKTIF_PERAN.get(user.role, frozenset())


class _Sistem:
    """Aktor untuk pekerjaan terjadwal yang tidak dijalankan siapa pun.

    Perintah CLI seperti penerbitan batch dipanggil cron, bukan orang, jadi
    tidak ada user yang bisa diperiksa cabangnya. Sentinel ini melewati
    pemeriksaan cabang secara sadar dan bernama jelas — jauh lebih aman
    daripada membuat `None` berarti "boleh semua", karena `None` juga berarti
    "belum masuk" di jalur permintaan web.

    `id` sengaja `None`: audit log mencatatnya sebagai aksi tanpa aktor
    manusia, bukan atas nama akun siapa pun.
    """

    id = None
    role = "superadmin"
    branch_id = None
    full_name = "Sistem"


SISTEM = _Sistem()


class AccessDenied(PermissionError):
    """User tidak berhak mengakses data cabang tersebut."""


def has_role(user: User | None, *roles: str) -> bool:
    if user is None:
        return False
    return user.role in roles


def is_cross_branch(user: User) -> bool:
    return user.role in LINTAS_CABANG


def _branch_of(user: User) -> int:
    if user.branch_id is None:
        raise AccessDenied(
            "Akun ini tidak terikat cabang mana pun sehingga tidak bisa "
            "mengakses data. Hubungi administrator."
        )
    return user.branch_id


def scoped(query, user: User, model):
    if is_cross_branch(user):
        return query
    return query.where(model.branch_id == _branch_of(user))


def assert_branch_access(user: User, branch_id: int | None) -> None:
    if is_cross_branch(user):
        return
    if branch_id is None or branch_id != _branch_of(user):
        raise AccessDenied("Anda tidak berhak mengakses data cabang lain.")


def require_role(*roles: str):
    def dekorator(view):
        @wraps(view)
        def pembungkus(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("auth.login"))
            if not has_role(user, *roles):
                abort(403)
            return view(*args, **kwargs)

        return pembungkus

    return dekorator
