"""Perhitungan koordinat grafik garis.

Dipisahkan dari templat karena Jinja bukan tempat berhitung: rumus yang
tersebar di antara tag `{% %}` tidak bisa diuji, dan grafik yang salah skala
adalah kebohongan yang tampak meyakinkan.

Tidak ada pustaka grafik. Keluarannya angka; templatlah yang menggambar SVG.
"""

from decimal import Decimal

# Sisi kiri diberi ruang untuk label sumbu Y (nilai rupiah singkat), sisi
# bawah untuk nama bulan.
SISIP_KIRI = 64
SISIP_KANAN = 12
SISIP_ATAS = 12
SISIP_BAWAH = 28


def ringkas_rupiah(nilai) -> str:
    """Angka rupiah sesingkat mungkin tanpa menyesatkan.

    Dipakai label sumbu, bukan angka yang dipertanggungjawabkan; nilai
    penuhnya selalu ada di tooltip.
    """
    angka = Decimal(nilai or 0)
    for batas, satuan in ((1_000_000_000, "M"), (1_000_000, "jt"), (1_000, "rb")):
        if abs(angka) >= batas:
            hasil = angka / Decimal(batas)
            # Satu desimal hanya kalau memang ada isinya.
            teks = f"{hasil:.1f}".rstrip("0").rstrip(".")
            return f"{teks} {satuan}"
    return f"{angka:.0f}"


def _skala_atas(maksimum: Decimal) -> Decimal:
    """Membulatkan batas atas ke angka yang enak dibaca.

    Sumbu yang berhenti tepat di nilai tertinggi membuat titik teratas
    menempel di tepi dan tidak punya garis bantu yang berarti.
    """
    if maksimum <= 0:
        return Decimal("1")
    langkah = Decimal("1")
    while langkah * 10 <= maksimum:
        langkah *= 10
    for pengali in (1, 2, 2.5, 5, 10):
        batas = langkah * Decimal(str(pengali))
        if batas >= maksimum:
            return batas
    return maksimum


def garis_ganda(
    titik: list[dict],
    deret: list[tuple[str, str]],
    kunci_label: str,
    lebar: int = 680,
    tinggi: int = 220,
    garis_bantu: int = 4,
) -> dict:
    """Menghitung koordinat dua deret di satu sumbu.

    `titik` adalah baris data terurut; `deret` memetakan kunci ke nama yang
    ditampilkan, mis. `[("tagihan", "Tagihan"), ("dibayar", "Dibayar")]`.

    Semua deret memakai satu skala Y — dua sumbu Y yang berbeda pada satu
    grafik membuat perpotongan garis tampak berarti padahal tidak.
    """
    dalam_lebar = lebar - SISIP_KIRI - SISIP_KANAN
    dalam_tinggi = tinggi - SISIP_ATAS - SISIP_BAWAH

    nilai_semua = [
        Decimal(baris.get(kunci) or 0) for baris in titik for kunci, _ in deret
    ]
    atas = _skala_atas(max(nilai_semua) if nilai_semua else Decimal("0"))

    def koordinat_x(indeks: int) -> float:
        if len(titik) <= 1:
            return SISIP_KIRI + dalam_lebar / 2
        return SISIP_KIRI + dalam_lebar * indeks / (len(titik) - 1)

    def koordinat_y(nilai) -> float:
        bagian = Decimal(nilai or 0) / atas
        return SISIP_ATAS + dalam_tinggi * float(1 - bagian)

    hasil_deret = []
    for kunci, nama in deret:
        noktah = [
            {
                "x": round(koordinat_x(i), 2),
                "y": round(koordinat_y(baris.get(kunci)), 2),
                "nilai": Decimal(baris.get(kunci) or 0),
                "label": baris.get(kunci_label, ""),
            }
            for i, baris in enumerate(titik)
        ]
        hasil_deret.append(
            {
                "kunci": kunci,
                "nama": nama,
                "noktah": noktah,
                "polyline": " ".join(f"{n['x']},{n['y']}" for n in noktah),
            }
        )

    return {
        "lebar": lebar,
        "tinggi": tinggi,
        "atas": atas,
        "kosong": not nilai_semua or max(nilai_semua) == 0,
        "deret": hasil_deret,
        "sumbu_x": [
            {"x": round(koordinat_x(i), 2), "label": baris.get(kunci_label, "")}
            for i, baris in enumerate(titik)
        ],
        "garis_y": [
            {
                "y": round(SISIP_ATAS + dalam_tinggi * i / garis_bantu, 2),
                "x_kiri": SISIP_KIRI,
                "x_kanan": lebar - SISIP_KANAN,
                "label": ringkas_rupiah(atas * Decimal(garis_bantu - i) / garis_bantu),
            }
            for i in range(garis_bantu + 1)
        ],
    }
