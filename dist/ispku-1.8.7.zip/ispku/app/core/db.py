from flask import Flask
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, scoped_session, sessionmaker


class Base(DeclarativeBase):
    pass


session_factory = sessionmaker(autoflush=False, expire_on_commit=False)
db_session = scoped_session(session_factory)


def create_db_engine(database_url: str, timezone_name: str):
    """Engine yang setiap koneksinya memakai zona waktu aplikasi.

    Kolom waktu dikembalikan psycopg dalam zona waktu SESI koneksinya, dan
    templat menampilkannya apa adanya. Jadi zona sesi harus sama di semua
    koneksi — kalau tidak, jam di layar bergantung pada koneksi mana yang
    kebetulan melayani permintaannya.

    Dulu zonanya dipasang dengan `SET TIME ZONE` tanpa commit. `SET` ikut
    transaksi: begitu transaksi pertama koneksi itu di-rollback, setelannya
    batal dan koneksi kembali ke UTC. Sebagian koneksi WIB, sebagian UTC, dan
    jam di halaman berubah-ubah tujuh jam setiap disegarkan.

    Sekarang setelannya di-commit, dan diperiksa lagi setiap koneksi diambil
    dari pool supaya perubahan zona dari halaman Pengaturan berlaku tanpa
    menyalakan ulang aplikasi. `engine.zona_waktu` adalah zona yang berlaku.
    """
    engine = create_engine(database_url, pool_pre_ping=True, future=True)
    engine.zona_waktu = timezone_name

    def _pasang(dbapi_connection, record):
        zona = engine.zona_waktu
        with dbapi_connection.cursor() as cursor:
            cursor.execute("SELECT set_config('TimeZone', %s, false)", (zona,))
        dbapi_connection.commit()
        record.info["zona_waktu"] = zona

    @event.listens_for(engine, "connect")
    def _saat_tersambung(dbapi_connection, record):
        _pasang(dbapi_connection, record)

    @event.listens_for(engine, "checkout")
    def _saat_diambil(dbapi_connection, record, _proxy):
        if record.info.get("zona_waktu") != engine.zona_waktu:
            _pasang(dbapi_connection, record)

    return engine


def index_ekspresi(index) -> bool:
    """True bila index dibangun dari ekspresi, bukan dari kolom polos.

    Alembic tidak bisa membandingkan index ekspresi (mis.
    `lower(trim(name))`): yang dibaca dari basis data berupa teks mentah,
    sedangkan yang ada di model berupa objek fungsi SQLAlchemy, sehingga
    keduanya selalu tampak berbeda dan `--autogenerate` mengusulkan menghapus
    lalu membuat ulang index yang sama pada setiap revisi.

    Index semacam itu dikecualikan dari perbandingan, dan sebagai gantinya
    diuji langsung ke basis data (lihat
    `tests/test_services_vendor.py::test_index_menolak_nama_kembar_di_basis_data`).
    """
    from sqlalchemy import Column

    return any(not isinstance(bagian, Column) for bagian in index.expressions)


def init_db(app: Flask) -> None:
    from app.core.config import _valid_timezone

    engine = create_db_engine(
        app.config["DATABASE_URL"], _valid_timezone(app.config["APP_TIMEZONE"])
    )
    app.extensions["db_engine"] = engine
    session_factory.configure(bind=engine)

    @app.teardown_appcontext
    def _remove_session(_exception=None):
        db_session.remove()
