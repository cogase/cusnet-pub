import click
from flask import Flask
from sqlalchemy import select

from app.core import audit
from app.core.auth import hash_password
from app.core import rbac
from app.core.db import db_session
from app.core.mail import MailNotConfigured, kirim_antrean
from app.modules.admin.models import User


def register_cli(app: Flask) -> None:
    @app.cli.command("seed-superadmin")
    @click.option("--username", required=True)
    @click.option("--email", required=True)
    @click.option("--password", required=True)
    @click.option("--nama", required=True)
    @click.option(
        "--paksa",
        is_flag=True,
        default=False,
        help="Tetap buat walau sudah ada superadmin.",
    )
    def seed_superadmin(
        username: str, email: str, password: str, nama: str, paksa: bool
    ) -> None:
        """Membuat user superadmin pertama."""
        if len(password) < 8:
            raise click.ClickException("Password minimal 8 karakter.")

        sudah_ada = db_session.execute(
            select(User).where(User.role == "superadmin")
        ).scalars().first()
        if sudah_ada is not None and not paksa:
            raise click.ClickException(
                "Sudah ada superadmin di sistem ini. Buat user baru lewat "
                "halaman Pengaturan, atau jalankan ulang dengan --paksa bila "
                "Anda memang perlu superadmin tambahan."
            )

        bentrok_username = db_session.execute(
            select(User).where(User.username == username)
        ).scalars().first()
        if bentrok_username is not None:
            raise click.ClickException(f"Username '{username}' sudah dipakai.")

        bentrok_email = db_session.execute(
            select(User).where(User.email == email)
        ).scalars().first()
        if bentrok_email is not None:
            raise click.ClickException(f"Email '{email}' sudah dipakai.")

        pengguna = User(
            username=username,
            email=email,
            password_hash=hash_password(password),
            full_name=nama,
            role="superadmin",
            branch_id=None,
        )
        db_session.add(pengguna)
        db_session.flush()
        audit.record(
            db_session,
            "create",
            "user",
            pengguna.id,
            after={
                "username": username,
                "email": email,
                "full_name": nama,
                "role": "superadmin",
                "branch_id": None,
            },
        )
        db_session.commit()
        click.echo(f"Superadmin '{username}' dibuat.")

    @app.cli.command("reset-password")
    @click.option("--username", required=True)
    @click.option(
        "--password",
        prompt="Password baru",
        hide_input=True,
        confirmation_prompt="Ulangi password baru",
    )
    def reset_password(username: str, password: str) -> None:
        """Mereset password sebuah akun. Dipakai saat pemilik akun terkunci
        di luar aplikasinya sendiri dan tidak ada cara lain masuk."""
        target = db_session.execute(
            select(User).where(User.username == username)
        ).scalars().first()
        if target is None:
            raise click.ClickException(f"Username '{username}' tidak ditemukan.")

        if len(password) < 8:
            raise click.ClickException("Password minimal 8 karakter.")

        sebelum = {"password_hash": "hash-lama", "is_active": target.is_active}

        diaktifkan_kembali = not target.is_active
        target.password_hash = hash_password(password)
        if diaktifkan_kembali:
            target.is_active = True
        db_session.flush()

        sesudah = {"password_hash": "hash-baru", "is_active": target.is_active}

        audit.record(
            db_session,
            "update",
            "user",
            target.id,
            before=sebelum,
            after=sesudah,
            aktor=None,
        )
        db_session.commit()

        click.echo(f"Password untuk '{username}' berhasil direset.")
        if diaktifkan_kembali:
            click.echo(
                f"User '{username}' sebelumnya nonaktif, kini diaktifkan kembali."
            )

    @app.cli.command("seed-master")
    def seed_master() -> None:
        """Menanam kategori layanan bawaan. Aman dijalankan berulang."""
        from app.modules.services.service import seed_kategori_layanan

        dibuat = seed_kategori_layanan(db_session)
        db_session.commit()
        click.echo(f"Kategori layanan dibuat: {dibuat}.")

    @app.cli.command("mail-flush")
    def mail_flush() -> None:
        """Mengirim email yang masih mengantre."""
        try:
            hasil = kirim_antrean(db_session, app.extensions["config_object"])
        except MailNotConfigured as exc:
            click.echo(str(exc))
            return

        db_session.commit()
        click.echo(
            f"Email terkirim: {hasil['terkirim']}, gagal: {hasil['gagal']}."
        )

    @app.cli.command("bersih-sementara")
    @click.option(
        "--umur-jam", default=24, show_default=True,
        help="Umur minimum berkas yang boleh dibuang.",
    )
    def bersih_sementara(umur_jam: int) -> None:
        """Membuang berkas kerja yang ditinggalkan.

        Yang dibuang: berkas impor CSV yang diunggah lalu ditinggalkan setelah
        pratinjau. Yang **tidak** dibuang: PDF lampiran email di
        `invoice-pdf/` — lampiran yang hilang sebelum `mail-flush` sempat
        berjalan berarti tagihan terkirim tanpa invoice-nya.
        """
        from app.modules.customers import impor as modul_impor

        upload_dir = app.config["UPLOAD_DIR"]
        dibuang = modul_impor.bersihkan_sementara(upload_dir, umur_jam)
        click.echo(
            f"Berkas impor sementara dibuang: {dibuang} "
            f"(lebih tua dari {umur_jam} jam)."
        )

    @app.cli.command("license-show")
    def license_show() -> None:
        """Menampilkan keadaan lisensi pemasangan ini."""
        from app.modules.settings import license_service

        keadaan = license_service.keadaan(
            db_session, app.config.get("LICENSE_PUBLIC_KEY") or None
        )
        db_session.commit()

        click.echo(keadaan["judul"])
        lisensi = keadaan["lisensi"]
        if lisensi is not None:
            click.echo(f"  Edisi          : {lisensi.edisi}")
            click.echo(
                "  Batas pelanggan: "
                + (
                    "tanpa batas"
                    if lisensi.batas_pelanggan is None
                    else f"{keadaan['jumlah_pelanggan']} / {lisensi.batas_pelanggan}"
                )
            )
            click.echo(
                "  Berlaku sampai : "
                + (
                    lisensi.kedaluwarsa.isoformat()
                    if lisensi.kedaluwarsa
                    else "selamanya"
                )
            )
        for pesan in keadaan["peringatan"]:
            click.echo(f"  ! {pesan}")

    @app.cli.command("license-apply")
    @click.option("--berkas", required=True, help="Berkas berisi kunci lisensi.")
    def license_apply(berkas: str) -> None:
        """Memasang kunci lisensi dari berkas."""
        import pathlib

        from app.core.errors import GalatDomain
        from app.modules.settings import license_service

        sumber = pathlib.Path(berkas)
        if not sumber.is_file():
            click.echo(f"Berkas tidak ada: {berkas}")
            raise SystemExit(1)

        try:
            lisensi = license_service.pasang(
                db_session, rbac.SISTEM, sumber.read_text(),
                app.config.get("LICENSE_PUBLIC_KEY") or None,
            )
        except GalatDomain as galat:
            db_session.rollback()
            click.echo(str(galat))
            raise SystemExit(1)

        db_session.commit()
        click.echo(f"Lisensi dipasang untuk {lisensi.pelanggan}.")

    @app.cli.command("demo-install")
    def demo_install() -> None:
        """Memasang data contoh untuk mempelajari aplikasi."""
        from app.core.errors import GalatDomain
        from app.modules.settings import demo

        try:
            hitung = demo.pasang(db_session, rbac.SISTEM)
        except GalatDomain as galat:
            click.echo(str(galat))
            raise SystemExit(1)

        db_session.commit()
        click.echo("Data contoh dipasang:")
        for nama, jumlah in sorted(hitung.items()):
            click.echo(f"  {nama}: {jumlah}")

    @app.cli.command("demo-remove")
    def demo_remove() -> None:
        """Membuang seluruh data contoh."""
        from app.core.errors import GalatDomain
        from app.modules.settings import demo

        try:
            dibuang = demo.hapus(db_session, rbac.SISTEM)
        except GalatDomain as galat:
            click.echo(str(galat))
            raise SystemExit(1)

        db_session.commit()
        click.echo(f"Data contoh dihapus: {sum(dibuang.values())} baris.")

    @app.cli.command("backup-db")
    @click.option(
        "--out", default=None, help="Path berkas hasil. Bawaan: di BACKUP_DIR."
    )
    def backup_db(out: str | None) -> None:
        """Membuat cadangan basis data (format custom pg_dump)."""
        from app.core import cadangan, waktu
        from app.core.errors import GalatDomain

        stempel = waktu.sekarang()
        try:
            berkas = cadangan.buat(
                app.config["DATABASE_URL"],
                app.config["BACKUP_DIR"],
                stempel,
                tujuan=out,
            )
        except GalatDomain as galat:
            click.echo(str(galat))
            raise SystemExit(1)

        click.echo(f"Cadangan dibuat: {berkas}")

    @app.cli.command("restore-db")
    @click.argument("berkas")
    @click.option(
        "--paksa",
        is_flag=True,
        help="Wajib. Menegaskan bahwa data yang ada sekarang boleh dibuang.",
    )
    def restore_db(berkas: str, paksa: bool) -> None:
        """Memulihkan basis data dari BERKAS cadangan.

        Seluruh data yang ada sekarang dibuang dan diganti isi cadangan.
        """
        from pathlib import Path

        from app.core import cadangan
        from app.core.errors import GalatDomain

        if not paksa:
            click.echo(
                "Pemulihan membuang seluruh data yang ada sekarang. "
                "Ulangi dengan --paksa bila memang itu yang dimaksud."
            )
            raise SystemExit(1)

        sumber = Path(berkas)
        if not sumber.is_file():
            click.echo(f"Berkas cadangan tidak ada: {berkas}")
            raise SystemExit(1)

        try:
            cadangan.pulihkan(
                app.config["DATABASE_URL"],
                sumber,
                engine=app.extensions.get("db_engine"),
            )
        except GalatDomain as galat:
            click.echo(str(galat))
            raise SystemExit(1)

        click.echo(f"Basis data dipulihkan dari {berkas}.")

    @app.cli.command("billing-run")
    @click.option(
        "--period", required=True, help="Periode YYYY-MM, misalnya 2026-09."
    )
    @click.option(
        "--cabang", type=int, default=None, help="Batasi ke satu id cabang."
    )
    def billing_run(period: str, cabang: int | None) -> None:
        """Menerbitkan invoice satu periode untuk seluruh langganan aktif.

        Idempoten: mengulang periode yang sama tidak membuat invoice kedua.
        """
        from app.core.errors import GalatDomain
        from app.modules.billing import service as billing_service

        try:
            mulai, akhir = billing_service.periode_bulan(period)
        except GalatDomain as galat:
            click.echo(str(galat))
            raise SystemExit(1)

        # Dijalankan sebagai `rbac.SISTEM`: perintah ini dipanggil cron, bukan
        # orang, jadi tidak ada user yang bisa diperiksa cabangnya. Pembatasan
        # cabang dilakukan lewat --cabang.
        run = billing_service.jalankan_batch(
            db_session, rbac.SISTEM, mulai, akhir, branch_id=cabang
        )
        db_session.commit()

        click.echo(
            f"Periode {period}: {run.created_count} invoice terbit, "
            f"{run.failed_count} gagal."
        )
        for galat in run.error_summary or []:
            click.echo(f"  - {galat['cid']}: {galat['pesan']}")

    @app.cli.command("billing-harian")
    @click.option(
        "--hari-ini",
        "hari_ini",
        default=None,
        help="Tanggal acuan YYYY-MM-DD. Bawaannya hari ini; dipakai untuk uji "
        "dan untuk menyusul pengingat yang terlewat.",
    )
    def billing_harian(hari_ini: str | None) -> None:
        """Pekerjaan harian billing: segarkan status, lalu antrekan pengingat.

        Dua-duanya dalam satu perintah dengan sengaja. Pengingat memutuskan
        siapa yang ditagih berdasarkan status, jadi pemasangan yang
        menjadwalkan salah satunya saja akan mengingatkan orang yang salah —
        dan tidak akan ada yang tahu.

        Idempoten: pengingat yang sudah pernah diantre tidak diantre lagi,
        dijaga batasan unik `invoice_reminder`, jadi menjalankannya beberapa
        kali sehari aman.
        """
        from datetime import date as _date

        from app.core import waktu
        from app.modules.billing import pengingat as modul_pengingat
        from app.modules.billing import service as billing_service

        try:
            acuan = _date.fromisoformat(hari_ini) if hari_ini else waktu.hari_ini()
        except ValueError:
            click.echo(f"Tanggal '{hari_ini}' tidak sah. Pakai bentuk YYYY-MM-DD.")
            raise SystemExit(1)

        diubah = billing_service.segarkan_semua_status(db_session, hari_ini=acuan)
        hasil = modul_pengingat.jalankan(db_session, rbac.SISTEM, hari_ini=acuan)
        db_session.commit()

        click.echo(f"Status invoice diperbarui: {diubah}.")
        click.echo(
            f"Pengingat diantre: {hasil['diantre']}, "
            f"sudah pernah: {hasil['sudah_pernah']}, "
            f"tanpa email: {hasil['tanpa_email']}, "
            f"disalip proses lain: {hasil['balapan']}."
        )
        if hasil["diantre"]:
            click.echo(
                "Pengiriman sesungguhnya dilakukan `flask mail-flush`."
            )
