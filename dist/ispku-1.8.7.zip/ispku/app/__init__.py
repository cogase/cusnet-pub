import logging
import os
from datetime import timedelta

from flask import Flask, g, jsonify, render_template, request
from sqlalchemy import text

from app.core.config import load_config
from app.core.db import db_session, init_db

# `pwa.*` publik dengan sengaja: manifest, service worker, dan halaman luring
# tidak memuat data dan harus bisa diambil peramban sebelum ada sesi.
RUTE_PUBLIK = frozenset({
    "healthz", "auth.login", "auth.logout", "auth.google", "beranda",
    "pwa.manifest", "pwa.service_worker", "pwa.luring",
    # Logo merek tampil di halaman masuk, yang dibuka sebelum ada sesi.
    "settings.merek_logo",
    "settings.merek_favicon",
    # Situs jualan memang untuk calon pembeli yang belum punya akun.
    "situs",
})

# Sidebar. Tiap halaman punya SATU jalan masuk: Invoice dan Pembayaran hanya
# di bawah Billing, katalog hanya di bawah Layanan. Butir yang sama di dua
# tempat membuat orang mengira itu dua halaman berbeda.
#
# `grup` memberi judul kelompok di atas butir pertamanya.
MENU = [
    {"kunci": "dashboard", "label": "Dashboard", "ikon": "layout-dashboard",
     "url_endpoint": "dashboard.index"},
    {"kunci": "customer", "label": "Customer", "ikon": "users", "grup": "Operasional",
     "url_endpoint": "customers.pelanggan_daftar", "submenu": [
        {"kunci": "customer.daftar", "label": "Daftar Customer",
         "url_endpoint": "customers.pelanggan_daftar"},
        {"kunci": "customer.tambah", "label": "Tambah Customer",
         "url_endpoint": "customers.pelanggan_baru"},
        {"kunci": "customer.kategori", "label": "Kategori Customer",
         "url_endpoint": "customers.kategori_daftar"},
    ]},
    {"kunci": "layanan", "label": "Layanan", "ikon": "package",
     "url_endpoint": "services.layanan_daftar", "submenu": [
        {"kunci": "layanan.daftar", "label": "Daftar Layanan", "url_endpoint": "services.layanan_daftar"},
        {"kunci": "layanan.paket", "label": "Tambah Paket", "url_endpoint": "services.paket_baru"},
        {"kunci": "layanan.kategori", "label": "Kategori Layanan", "url_endpoint": "services.kategori_daftar"},
        {"kunci": "layanan.vendor", "label": "Vendor", "url_endpoint": "services.vendor_daftar"},
    ]},
    {"kunci": "tiket", "label": "Ticketing", "ikon": "ticket",
     "url_endpoint": "tickets.daftar", "submenu": [
        {"kunci": "tiket.daftar", "label": "Daftar Tiket", "url_endpoint": "tickets.daftar"},
        {"kunci": "tiket.baru", "label": "Tiket Baru", "url_endpoint": "tickets.baru"},
        {"kunci": "tiket.kategori", "label": "Kategori & SLA", "url_endpoint": "tickets.kategori_daftar"},
        {"kunci": "tiket.laporan", "label": "Laporan SLA", "url_endpoint": "tickets.laporan"},
    ]},
    {"kunci": "network", "label": "Network", "ikon": "network",
     "url_endpoint": "inventory.ringkasan", "submenu": [
        {"kunci": "network.ringkasan", "label": "Ringkasan", "url_endpoint": "inventory.ringkasan"},
        {"kunci": "network.site", "label": "Site / POP", "url_endpoint": "inventory.site_daftar"},
        {"kunci": "network.perangkat", "label": "Perangkat & Port", "url_endpoint": "inventory.perangkat_daftar"},
        {"kunci": "network.vlan", "label": "VLAN", "url_endpoint": "inventory.vlan_daftar"},
        {"kunci": "network.ip", "label": "Blok IP", "url_endpoint": "inventory.blok_daftar"},
        {"kunci": "network.peta", "label": "Peta Sebaran", "url_endpoint": "inventory.peta"},
    ]},
    {"kunci": "billing", "label": "Billing", "ikon": "file-text", "grup": "Keuangan",
     "url_endpoint": "billing.dashboard", "submenu": [
        {"kunci": "billing.dashboard", "label": "Dashboard Billing", "url_endpoint": "billing.dashboard"},
        {"kunci": "billing.invoice", "label": "Invoice", "url_endpoint": "billing.daftar"},
        {"kunci": "billing.generate", "label": "Generate Invoice", "url_endpoint": "billing.generate"},
        {"kunci": "billing.pembayaran", "label": "Pembayaran", "url_endpoint": "billing.pembayaran_daftar"},
        {"kunci": "billing.laporan", "label": "Laporan", "url_endpoint": "billing.laporan"},
        {"kunci": "billing.rekening", "label": "Rekening Bank", "url_endpoint": "settings.rekening_daftar"},
        {"kunci": "billing.pengaturan", "label": "Pengaturan Billing", "url_endpoint": "settings.billing"},
    ]},
    {"kunci": "pengaturan", "label": "Pengaturan", "ikon": "settings", "grup": "Sistem",
     "url": "#", "submenu": [
        {"kunci": "pengaturan.user", "label": "User & Peran", "url_endpoint": "admin.user_daftar"},
        {"kunci": "pengaturan.cabang", "label": "Cabang", "url_endpoint": "admin.cabang_daftar"},
        {"kunci": "pengaturan.merek", "label": "Merek Aplikasi", "url_endpoint": "settings.merek"},
        {"kunci": "pengaturan.impor", "label": "Impor Data", "url_endpoint": "settings.impor"},
        {"kunci": "pengaturan.demo", "label": "Data Contoh", "url_endpoint": "settings.demo"},
        {"kunci": "pengaturan.lisensi", "label": "Lisensi", "url_endpoint": "settings.lisensi"},
        {"kunci": "pengaturan.audit", "label": "Audit Log", "url_endpoint": "admin.audit_daftar"},
        {"kunci": "pengaturan.sistem", "label": "Sistem", "url_endpoint": "settings.sistem"},
    ]},
]


def create_app(config_overrides: dict | None = None) -> Flask:
    app = Flask(__name__)

    config = load_config(os.environ)
    app.config.from_object(config)
    app.extensions["config_object"] = config
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = config.HTTPS_ONLY

    # Di belakang reverse proxy (nginx), alamat yang dilihat aplikasi adalah
    # alamat proxy itu — untuk SEMUA orang. Pembatas laju login lalu
    # menghitung seluruh pengguna sebagai satu alamat (sepuluh salah ketik
    # dari siapa pun mengunci semua orang 15 menit), dan audit log mencatat
    # alamat yang sama di setiap baris. ProxyFix membaca X-Forwarded-For dan
    # X-Forwarded-Proto hanya sebanyak lapisan proxy yang disebut; nilai
    # kiriman klien di depannya diabaikan. Karena itu port aplikasi WAJIB
    # tidak terbuka langsung ke luar (APP_BIND=127.0.0.1) — kalau terbuka,
    # siapa pun bisa mengirim X-Forwarded-For karangan tanpa lewat proxy.
    if config.TRUSTED_PROXIES:
        from werkzeug.middleware.proxy_fix import ProxyFix

        app.wsgi_app = ProxyFix(
            app.wsgi_app,
            x_for=config.TRUSTED_PROXIES,
            x_proto=config.TRUSTED_PROXIES,
        )

    # Batas badan permintaan. Tanpa ini, unggahan raksasa dibuffer penuh
    # sebelum app/core/files.py sempat menolaknya.
    app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

    # Cookie "ingat saya" tanpa batas umur adalah cookie 31 hari (bawaan
    # Flask). Basis data memuat KTP dan NPWP; 12 jam cukup untuk satu hari
    # kerja.
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=12)

    if not config.HTTPS_ONLY:
        logging.getLogger(__name__).warning(
            "HTTPS_ONLY=false — cookie sesi dikirim tanpa flag Secure. "
            "Jangan dipakai di jaringan publik tanpa TLS."
        )

    if config_overrides:
        app.config.update(config_overrides)

    from app import models_all  # noqa: F401

    init_db(app)

    from app.core.money import format_rupiah, format_rupiah_singkat

    app.add_template_filter(format_rupiah, "rupiah")
    app.add_template_filter(format_rupiah_singkat, "rupiah_singkat")

    from app.core.files import format_ukuran

    app.add_template_filter(format_ukuran, "ukuran")

    @app.get("/healthz")
    def healthz():
        return jsonify({"status": "ok"})

    from app.core.auth import current_user

    def _live_version() -> str:
        """Read a database-wide change marker shared by every app worker."""
        return db_session.execute(
            text("SELECT pg_current_wal_lsn()::text")
        ).scalar_one()

    # Zona waktu pilihan dari Pengaturan → Sistem. Dibaca dari basis data di
    # tiap permintaan (satu pencarian kunci utama): aplikasi berjalan di
    # beberapa worker, dan worker yang tidak melayani penyimpanannya harus
    # ikut berganti zona saat itu juga — bukan menampilkan jam lama sampai
    # dinyalakan ulang.
    ZONA_ENV = app.config["APP_TIMEZONE"]

    def terapkan_zona(zona: str | None) -> None:
        zona = zona or ZONA_ENV
        app.config["APP_TIMEZONE"] = zona
        mesin = app.extensions.get("db_engine")
        if mesin is not None:
            mesin.zona_waktu = zona

    app.extensions["terapkan_zona"] = terapkan_zona

    @app.before_request
    def _muat_zona_waktu():
        if request.endpoint in {"static", "healthz"}:
            return
        from app.modules.settings import branding

        try:
            zona = branding.zona_tersimpan(db_session) or ZONA_ENV
            if zona != app.config["APP_TIMEZONE"]:
                terapkan_zona(zona)
                # Koneksi yang baru dipakai membaca masih berzona lama; dilepas
                # supaya sisa permintaan ini mengambil koneksi berzona baru.
                db_session.rollback()
        except Exception:  # noqa: BLE001 — tabel belum ada saat migrasi pertama
            db_session.rollback()

    @app.before_request
    def _capture_live_version():
        if (
            request.endpoint not in {
                "live_version",
                "static",
                "healthz",
                "pwa.manifest",
                "pwa.service_worker",
                "pwa.luring",
                "settings.merek_logo",
                "settings.merek_favicon",
            }
            and current_user() is not None
        ):
            g.live_version = _live_version()

    @app.get("/live/version")
    def live_version():
        if current_user() is None:
            response = jsonify({"error": "Autentikasi diperlukan."})
            response.status_code = 401
        else:
            response = jsonify({"version": _live_version()})
        response.headers["Cache-Control"] = "no-store, max-age=0"
        return response

    @app.get("/produk")
    def situs():
        """Situs jualan (mockup `cusnet_index.png`).

        Mati secara bawaan dan menjawab **404**, bukan pengalihan: pemasangan
        pelanggan tidak butuh halaman iklan di servernya sendiri, dan
        pengalihan justru memberi tahu bahwa ada sesuatu di sini.

        `/` sengaja tidak diubah — tamu tetap dibawa ke halaman masuk.
        Instalasi demo yang ingin `/` berisi situs ini tinggal mengarahkan
        reverse proxy-nya ke `/produk`.
        """
        from flask import abort, render_template

        if not app.config.get("LANDING_ENABLED"):
            abort(404)
        return render_template("situs/index.html")

    @app.get("/")
    def beranda():
        from flask import redirect, url_for
        from app.core.rbac import halaman_awal

        if current_user() is None:
            return redirect(url_for("auth.login"))
        return redirect(url_for(halaman_awal(current_user())))

    def _token_csrf() -> str:
        from flask_wtf.csrf import generate_csrf

        return generate_csrf()

    def _bangun_menu():
        from flask import url_for

        from app.core.rbac import menu_dinonaktifkan

        pengguna = current_user()
        hasil = []
        for item in MENU:
            salinan = dict(item)
            salinan["dinonaktifkan"] = menu_dinonaktifkan(pengguna, salinan["kunci"])
            item_jadi = "url_endpoint" in salinan
            if "url_endpoint" in salinan:
                salinan["url"] = url_for(salinan.pop("url_endpoint"))
            if "submenu" in salinan:
                anak_anak = []
                ada_anak_jadi = False
                for anak in salinan["submenu"]:
                    salinan_anak = dict(anak)
                    anak_jadi = "url_endpoint" in salinan_anak
                    if "url_endpoint" in salinan_anak:
                        salinan_anak["url"] = url_for(salinan_anak.pop("url_endpoint"))
                    salinan_anak["belum_jadi"] = not anak_jadi
                    salinan_anak["dinonaktifkan"] = salinan["dinonaktifkan"]
                    ada_anak_jadi = ada_anak_jadi or anak_jadi
                    anak_anak.append(salinan_anak)
                salinan["submenu"] = anak_anak
                item_jadi = item_jadi or ada_anak_jadi
                # Induk tanpa halaman sendiri (`url: "#"`) menunjuk ke anak
                # pertama yang sudah jadi. Tanpa ini Master Data dan Pengaturan
                # tidak punya jalan masuk sama sekali: submenu hanya terbuka
                # untuk menu yang sedang aktif, dan induknya tidak pernah bisa
                # dibuat aktif karena tautannya "#".
                if salinan.get("url", "#") == "#":
                    for anak in anak_anak:
                        if not anak["belum_jadi"]:
                            salinan["url"] = anak["url"]
                            break
            salinan["belum_jadi"] = not item_jadi
            hasil.append(salinan)
        return hasil

    def _menu_aktif(endpoint):
        """Menentukan menu dan submenu yang sedang dibuka dari endpoint.

        Anak diperiksa lebih dulu supaya `billing.daftar` — yang muncul sebagai
        induk `Billing` sekaligus anak `Invoice` — membuka submenunya, bukan
        cuma menyalakan induknya.
        """
        if not endpoint:
            return None, None

        for item in MENU:
            for anak in item.get("submenu", []):
                if anak.get("url_endpoint") == endpoint:
                    return item["kunci"], anak["kunci"]
            if item.get("url_endpoint") == endpoint:
                return item["kunci"], None

        # Halaman turunan (detail pelanggan, form, dan sejenisnya) tidak
        # terdaftar di menu. Yang dipakai blueprint-nya, supaya menu induk
        # tetap menyala saat pengguna masuk ke halaman detail.
        blueprint = endpoint.split(".", 1)[0]
        for item in MENU:
            kandidat = [item.get("url_endpoint")] + [
                anak.get("url_endpoint") for anak in item.get("submenu", [])
            ]
            if any(e and e.split(".", 1)[0] == blueprint for e in kandidat):
                return item["kunci"], None

        return None, None

    @app.context_processor
    def _konteks_tata_letak():
        from flask import request

        aktif, submenu_aktif = _menu_aktif(request.endpoint)
        from app.core.rbac import boleh_mengubah

        return {
            "app_version": app.config["APP_VERSION"],
            # Token CSRF untuk permintaan fetch yang tidak lewat formulir
            # (tandai notifikasi dibaca, aksi massal tabel).
            "token_csrf": _token_csrf,
            "zona_waktu": app.config["APP_TIMEZONE"],
            "pengguna": current_user(),
            "boleh_mengubah": boleh_mengubah(current_user(), request.endpoint),
            "live_version": getattr(g, "live_version", ""),
            "menu": _bangun_menu(),
            "menu_aktif": aktif,
            "submenu_aktif": submenu_aktif,
            "merek": _merek(),
            "lisensi_peringatan": _peringatan_lisensi(),
        }

    def _peringatan_lisensi():
        """Kalimat peringatan lisensi, kosong bila tidak ada yang perlu.

        **Tidak menyentuh transaksi sama sekali** — tidak commit, tidak
        rollback, tidak menyisipkan baris. Fungsi ini berjalan di tengah
        `render_template`, dan `rollback()` di sana meng-expire setiap objek
        ORM yang sedang diiterasi templat: sisanya dibaca ulang dari basis
        data, dan baris yang belum ter-commit justru melempar. Barisnya dibuat
        halaman Lisensi yang memang menulis.

        Tidak pernah menjatuhkan halaman: pemasangan yang migrasinya belum
        jalan tetap harus bisa dibuka.
        """
        pengguna = current_user()
        if pengguna is None or pengguna.role != "superadmin":
            return []

        from app.core.db import db_session
        from app.modules.settings import license_service

        try:
            return license_service.keadaan_baca_saja(
                db_session, app.config.get("LICENSE_PUBLIC_KEY") or None
            )["peringatan"]
        except Exception:  # noqa: BLE001
            return []

    def _merek():
        """Merek aplikasi untuk seluruh templat.

        Dibaca sekali per permintaan. Halaman masuk ikut memakainya, jadi
        fungsi ini harus tetap bekerja tanpa sesi — dan tidak boleh
        menjatuhkan halaman kalau tabelnya belum ada (pemasangan yang
        migrasinya belum jalan).
        """
        from app.core.db import db_session
        from app.modules.settings import branding

        try:
            baris = branding.ambil_merek(db_session)
            hasil = branding.konteks(baris)
            db_session.commit()
            return hasil
        except Exception:  # noqa: BLE001
            db_session.rollback()
            return branding.konteks(branding.AppBranding(id=1, **branding.BAWAAN))

    from app.modules.admin.views import bp as admin_bp
    from app.modules.auth.views import bp as auth_bp
    from app.modules.billing.views import bp as billing_bp
    from app.modules.customers.views import bp as customers_bp
    from app.modules.dashboard.views import bp as dashboard_bp
    from app.modules.pwa.views import bp as pwa_bp
    from app.modules.services.views import bp as services_bp
    from app.modules.settings.views import bp as settings_bp
    from app.modules.inventory.views import bp as inventory_bp
    from app.modules.tickets.views import bp as tickets_bp

    app.register_blueprint(admin_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(billing_bp)
    app.register_blueprint(customers_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(pwa_bp)
    app.register_blueprint(services_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(tickets_bp)

    from app.modules.massal.views import bp as massal_bp

    app.register_blueprint(massal_bp)

    from app.cli import register_cli

    register_cli(app)

    from app.core.keamanan import pasang_header

    app.after_request(pasang_header)

    @app.after_request
    def _jawab_kirim_langsung(response):
        """Mengubah pengalihan menjadi JSON untuk formulir yang dikirim fetch.

        `static/js/live.js` mengirim formulir tanpa memuat ulang halaman. Kalau
        pengalihannya diikuti fetch begitu saja, pesan flash habis terpakai di
        respons yang tidak pernah ditampilkan. Dengan menyerahkan alamat
        tujuannya, skrip bisa memutuskan: menukar isi halaman di tempat, atau
        pindah halaman seperti biasa.
        """
        if (
            request.headers.get("X-Live-Submit") == "1"
            and 300 <= response.status_code < 400
            and response.headers.get("Location")
        ):
            jawaban = jsonify({"redirect": response.headers["Location"]})
            jawaban.headers["Cache-Control"] = "no-store, max-age=0"
            # Cookie sesi dari respons asli (flash, login) ikut dibawa.
            for nilai in response.headers.getlist("Set-Cookie"):
                jawaban.headers.add("Set-Cookie", nilai)
            return jawaban
        return response

    from app.core.errors import TidakDitemukan
    from app.core.rbac import AccessDenied

    @app.errorhandler(AccessDenied)
    def _tangani_akses_ditolak(_galat):
        return render_template("galat/403.html"), 403

    @app.errorhandler(403)
    def _tangani_403(_galat):
        return render_template("galat/403.html"), 403

    @app.errorhandler(TidakDitemukan)
    def _tangani_tidak_ditemukan(_galat):
        return render_template("galat/404.html"), 404

    @app.errorhandler(404)
    def _tangani_404(_galat):
        return render_template("galat/404.html"), 404

    @app.errorhandler(413)
    def _tangani_413(_galat):
        return render_template("galat/413.html"), 413

    @app.errorhandler(500)
    def _tangani_500(_galat):
        return render_template("galat/500.html"), 500

    return app
