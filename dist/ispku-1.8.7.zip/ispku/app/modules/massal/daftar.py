"""Daftar entitas yang mendukung aksi massal dan impor di tabel standar.

Satu tempat untuk menjawab, per entitas: siapa yang boleh, fungsi service
mana yang menghapus/mengubah/membuat, kolom apa yang boleh diubah massal, dan
kolom apa yang diterima impor CSV.

Tidak ada logika bisnis baru di sini. Setiap aksi massal memanggil fungsi
service yang SAMA dengan tombol per baris, satu per satu, di dalam satu
transaksi — jadi pemeriksaan cabang, penjaga hapus, dan audit log-nya ikut
berlaku persis seperti biasa.
"""

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Callable

from sqlalchemy import select

from app.core.errors import GalatDomain

ADMIN = ("superadmin", "admin_cabang")
ADMIN_BILLING = ADMIN + ("billing",)
ADMIN_TEKNIS = ADMIN + ("teknis",)

YA = {"1", "ya", "y", "true", "aktif", "yes"}
TIDAK = {"0", "tidak", "t", "false", "nonaktif", "no"}


class ImporTidakSah(GalatDomain):
    """Nilai di berkas impor yang tidak bisa dipakai."""


@dataclass(frozen=True)
class Medan:
    """Satu kolom yang boleh diubah massal."""

    nama: str
    label: str
    pilihan: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class Kolom:
    """Satu kolom di berkas impor."""

    nama: str
    wajib: bool = False
    jenis: str = "teks"  # teks | bulat | desimal | ya_tidak
    contoh: str = ""


@dataclass(frozen=True)
class Entitas:
    kunci: str
    label: str
    peran: tuple[str, ...]
    hapus: Callable | None = None
    ubah: Callable | None = None
    buat: Callable | None = None
    medan: tuple[Medan, ...] = ()
    kolom: tuple[Kolom, ...] = ()
    # Entitas bercabang menerima kolom `cabang` (kode) saat impor.
    bercabang: bool = False
    # Kolom rujukan: nama kolom impor -> fungsi (sesi, user, nilai) -> id.
    rujukan: dict = field(default_factory=dict)


def _ya_tidak(*, ya="Aktif", tidak="Nonaktif"):
    return (("1", ya), ("0", tidak))


def _pilihan(nilai, label=None):
    label = label or {}
    return tuple((n, label.get(n, n.replace("_", " ").capitalize())) for n in nilai)


def _site_dari_kode(sesi, user, kode):
    from app.core import rbac
    from app.modules.inventory.models import Site

    site = sesi.execute(
        rbac.scoped(select(Site).where(Site.code == kode), user, Site)
    ).scalars().first()
    if site is None:
        raise ImporTidakSah("site", f"Site berkode '{kode}' tidak ditemukan.")
    return site.id


def _bangun() -> dict[str, Entitas]:
    from app.modules.admin import service as admin
    from app.modules.customers import service as customers
    from app.modules.customers.models import STATUS_PELANGGAN
    from app.modules.inventory import service as inventory
    from app.modules.inventory.models import (
        JENIS_BLOK_IP, JENIS_PERANGKAT, JENIS_SITE, JENIS_VLAN, STATUS_PERANGKAT,
    )
    from app.modules.services import service as services
    from app.modules.settings import service as settings
    from app.modules.tickets import service as tickets
    from app.modules.tickets.forms import LABEL_PRIORITAS
    from app.modules.tickets.models import PRIORITAS

    aktif = Medan("is_active", "Status aktif", _ya_tidak())
    semua = [
        Entitas(
            "customer", "customer", ADMIN_BILLING,
            hapus=customers.hapus_pelanggan, ubah=customers.ubah_pelanggan,
            medan=(Medan("status", "Status", _pilihan(STATUS_PELANGGAN)),),
        ),
        Entitas(
            "kategori_customer", "kategori customer", ADMIN_BILLING,
            hapus=customers.hapus_kategori_pelanggan, ubah=customers.ubah_kategori_pelanggan,
            buat=customers.buat_kategori_pelanggan, medan=(aktif,),
            kolom=(Kolom("name", True, contoh="Korporat"), Kolom("is_active", jenis="ya_tidak", contoh="ya")),
        ),
        Entitas(
            "paket", "paket layanan", ADMIN_BILLING,
            hapus=services.hapus_paket, ubah=services.ubah_paket, medan=(aktif,),
        ),
        Entitas(
            "kategori_layanan", "kategori layanan", ADMIN_BILLING,
            hapus=services.hapus_kategori, ubah=services.ubah_kategori, medan=(aktif,),
        ),
        Entitas(
            "vendor", "vendor", ADMIN_BILLING,
            hapus=services.hapus_vendor, ubah=services.ubah_vendor, buat=services.buat_vendor,
            medan=(aktif,),
            kolom=(
                Kolom("name", True, contoh="PT Serat Nusantara"),
                Kolom("kind"),
                Kolom("contact_name", contoh="Budi"),
                Kolom("contact_phone", contoh="021-5551234"),
                Kolom("contact_email", contoh="noc@vendor.id"),
                Kolom("note"),
                Kolom("is_active", jenis="ya_tidak", contoh="ya"),
            ),
        ),
        Entitas(
            "tiket", "tiket", ADMIN_TEKNIS,
            hapus=tickets.hapus, ubah=tickets.ubah,
            medan=(Medan("priority", "Prioritas", _pilihan(PRIORITAS, LABEL_PRIORITAS)),),
        ),
        Entitas(
            "kategori_tiket", "kategori tiket", ADMIN_TEKNIS,
            hapus=tickets.hapus_kategori, ubah=tickets.ubah_kategori, medan=(aktif,),
        ),
        Entitas(
            "site", "site", ADMIN_TEKNIS,
            hapus=inventory.hapus_site, ubah=inventory.ubah_site, buat=inventory.tambah_site,
            medan=(aktif, Medan("kind", "Jenis", _pilihan(JENIS_SITE))), bercabang=True,
            kolom=(
                Kolom("code", True, contoh="POP-JKT-01"),
                Kolom("name", True, contoh="POP Jakarta Pusat"),
                Kolom("kind", contoh=JENIS_SITE[0]),
                Kolom("address", contoh="Jl. Sudirman No. 1"),
                Kolom("lat", jenis="desimal", contoh="-6.2088"),
                Kolom("lng", jenis="desimal", contoh="106.8456"),
                Kolom("note"),
            ),
        ),
        Entitas(
            "perangkat", "perangkat", ADMIN_TEKNIS,
            hapus=inventory.hapus_perangkat, ubah=inventory.ubah_perangkat,
            buat=inventory.tambah_perangkat, bercabang=True,
            medan=(Medan("status", "Status", _pilihan(STATUS_PERANGKAT)),),
            rujukan={"site": ("site_id", _site_dari_kode)},
            kolom=(
                Kolom("name", True, contoh="RTR-JKT-01"),
                Kolom("site", True, contoh="POP-JKT-01"),
                Kolom("kind", contoh=JENIS_PERANGKAT[0]),
                Kolom("brand", contoh="MikroTik"),
                Kolom("model", contoh="CCR2004"),
                Kolom("mgmt_address", contoh="10.0.0.1"),
                Kolom("serial_number"),
                Kolom("status", contoh=STATUS_PERANGKAT[0]),
                Kolom("note"),
            ),
        ),
        Entitas(
            "vlan", "VLAN", ADMIN_TEKNIS,
            hapus=inventory.hapus_vlan, ubah=inventory.ubah_vlan, buat=inventory.tambah_vlan,
            medan=(Medan("kind", "Jenis", _pilihan(JENIS_VLAN)),), bercabang=True,
            rujukan={"site": ("site_id", _site_dari_kode)},
            kolom=(
                Kolom("vlan_id", True, jenis="bulat", contoh="313"),
                Kolom("name", contoh="Pelanggan Metro"),
                Kolom("kind", contoh=JENIS_VLAN[0]),
                Kolom("site", contoh="POP-JKT-01"),
                Kolom("note"),
            ),
        ),
        Entitas(
            "blok", "blok IP", ADMIN_TEKNIS,
            hapus=inventory.hapus_blok, ubah=inventory.ubah_blok, buat=inventory.tambah_blok,
            medan=(Medan("kind", "Jenis", _pilihan(JENIS_BLOK_IP)),), bercabang=True,
            rujukan={"site": ("site_id", _site_dari_kode)},
            kolom=(
                Kolom("cidr", True, contoh="103.10.10.0/29"),
                Kolom("kind", contoh=JENIS_BLOK_IP[0]),
                Kolom("gateway", contoh="103.10.10.1"),
                Kolom("site", contoh="POP-JKT-01"),
                Kolom("note"),
            ),
        ),
        Entitas(
            "cabang", "cabang", ("superadmin",),
            hapus=admin.hapus_cabang, ubah=admin.ubah_cabang, buat=admin.buat_cabang,
            medan=(aktif,),
            kolom=(
                Kolom("code", True, contoh="02"),
                Kolom("name", True, contoh="Bandung"),
                Kolom("address"), Kolom("phone"),
                Kolom("is_active", jenis="ya_tidak", contoh="ya"),
            ),
        ),
        Entitas(
            "rekening", "rekening bank", ADMIN_BILLING,
            hapus=settings.hapus_rekening, ubah=settings.ubah_rekening, medan=(aktif,),
        ),
        # Akun tidak dihapus massal — jejak auditnya menunjuk ke sana — tetapi
        # boleh dinonaktifkan.
        Entitas("user", "user", ADMIN, ubah=admin.ubah_user, medan=(aktif,)),
    ]
    return {satu.kunci: satu for satu in semua}


_DAFTAR: dict[str, Entitas] | None = None


def ambil(kunci: str) -> Entitas | None:
    global _DAFTAR
    if _DAFTAR is None:
        _DAFTAR = _bangun()
    return _DAFTAR.get(kunci)


# --- Aksi ------------------------------------------------------------------


def nilai_medan(entitas: Entitas, nama: str, mentah: str):
    """Memeriksa nilai ubah massal terhadap pilihan yang sah."""
    medan = next((m for m in entitas.medan if m.nama == nama), None)
    if medan is None:
        raise ImporTidakSah("medan", "Kolom ini tidak bisa diubah massal.")
    if mentah not in {n for n, _ in medan.pilihan}:
        raise ImporTidakSah("nilai", f"Nilai '{mentah}' tidak dikenal untuk {medan.label}.")
    if nama == "is_active":
        return mentah == "1"
    return mentah


def hapus_banyak(sesi, user, entitas: Entitas, ids: list[int]) -> int:
    for satu in ids:
        entitas.hapus(sesi, user, satu)
    sesi.flush()
    return len(ids)


def ubah_banyak(sesi, user, entitas: Entitas, ids: list[int], nama: str, mentah: str) -> int:
    nilai = nilai_medan(entitas, nama, mentah)
    for satu in ids:
        entitas.ubah(sesi, user, satu, {nama: nilai})
    sesi.flush()
    return len(ids)


def kolom_impor(entitas: Entitas, user) -> list[Kolom]:
    """Kolom templat impor; `cabang` hanya untuk yang lintas cabang."""
    from app.core import rbac

    kolom = list(entitas.kolom)
    if entitas.bercabang and rbac.is_cross_branch(user):
        kolom.append(Kolom("cabang", True, contoh="01"))
    return kolom


def templat_csv(entitas: Entitas, user) -> str:
    import io

    from app.core import csv_aman

    kolom = kolom_impor(entitas, user)
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow([k.nama for k in kolom])
    tulis.writerow([k.contoh for k in kolom])
    return keluaran.getvalue()


def _konversi(kolom: Kolom, mentah: str):
    teks = (mentah or "").strip()
    if not teks:
        if kolom.wajib:
            raise ImporTidakSah(kolom.nama, f"Kolom {kolom.nama} wajib diisi.")
        return True if kolom.jenis == "ya_tidak" else None
    try:
        if kolom.jenis == "bulat":
            return int(teks)
        if kolom.jenis == "desimal":
            return Decimal(teks.replace(",", "."))
    except (ValueError, InvalidOperation) as galat:
        raise ImporTidakSah(kolom.nama, f"Kolom {kolom.nama}: '{teks}' bukan angka.") from galat
    if kolom.jenis == "ya_tidak":
        if teks.lower() in YA:
            return True
        if teks.lower() in TIDAK:
            return False
        raise ImporTidakSah(kolom.nama, f"Kolom {kolom.nama}: isi 'ya' atau 'tidak'.")
    return teks


BATAS_BARIS_IMPOR = 2000


def impor_csv(sesi, user, entitas: Entitas, isi: str) -> int:
    """Membuat satu baris per baris CSV. Satu gagal, semuanya batal.

    Galat menyebut nomor baris seperti yang terlihat di Excel (kepala kolom
    adalah baris 1).
    """
    import csv
    import io

    from app.core import rbac
    from app.modules.admin.models import Branch

    pembaca = csv.DictReader(io.StringIO(isi.lstrip("﻿")))
    kolom = kolom_impor(entitas, user)
    kepala = {(n or "").strip() for n in (pembaca.fieldnames or [])}
    kurang = [k.nama for k in kolom if k.wajib and k.nama not in kepala]
    if kurang:
        raise ImporTidakSah("berkas", "Kolom wajib tidak ada di berkas: " + ", ".join(kurang) + ".")

    jumlah = 0
    for nomor, baris in enumerate(pembaca, start=2):
        if not any((v or "").strip() for v in baris.values()):
            continue
        if jumlah >= BATAS_BARIS_IMPOR:
            raise ImporTidakSah("berkas", f"Maksimal {BATAS_BARIS_IMPOR} baris per berkas.")
        try:
            data = {}
            for satu in kolom:
                nilai = _konversi(satu, baris.get(satu.nama, ""))
                if satu.nama == "cabang":
                    cabang = sesi.execute(
                        select(Branch).where(Branch.code == nilai)
                    ).scalars().first()
                    if cabang is None:
                        raise ImporTidakSah("cabang", f"Cabang berkode '{nilai}' tidak ditemukan.")
                    data["branch_id"] = cabang.id
                elif satu.nama in entitas.rujukan:
                    tujuan, cari = entitas.rujukan[satu.nama]
                    data[tujuan] = cari(sesi, user, nilai) if nilai else None
                elif nilai is not None:
                    data[satu.nama] = nilai
            if entitas.bercabang and "branch_id" not in data:
                data["branch_id"] = rbac._branch_of(user)
            entitas.buat(sesi, user, data)
        except (GalatDomain, rbac.AccessDenied) as galat:
            raise ImporTidakSah("berkas", f"Baris {nomor}: {galat}") from galat
        jumlah += 1
    if not jumlah:
        raise ImporTidakSah("berkas", "Berkas tidak berisi baris data.")
    sesi.flush()
    return jumlah
