"""Aksi massal dan impor untuk tabel standar.

Dipanggil `static/js/tabel.js` lewat fetch, jadi semua jawabannya JSON.
Hak akses ditentukan per entitas di `daftar.py`, bukan per rute: satu rute
melayani semua tabel.
"""

from flask import Blueprint, Response, abort, jsonify, request

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.rbac import AccessDenied, require_role
from app.modules.customers.forms import HapusForm
from app.modules.massal import daftar

bp = Blueprint("massal", __name__)

SEMUA_PERAN = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
BATAS_SEKALI = 500


def _entitas(kunci: str) -> daftar.Entitas:
    entitas = daftar.ambil(kunci)
    if entitas is None:
        abort(404)
    if current_user().role not in entitas.peran:
        abort(403)
    return entitas


def _ids() -> list[int]:
    ids = []
    for mentah in request.form.getlist("id"):
        try:
            ids.append(int(mentah))
        except ValueError:
            continue
    return list(dict.fromkeys(ids))[:BATAS_SEKALI]


def _galat(pesan: str, kode: int = 400):
    return jsonify(error=pesan), kode


@bp.get("/massal/<kunci>/meta")
@require_role(*SEMUA_PERAN)
def meta(kunci: str):
    """Apa yang boleh dilakukan pengguna ini pada tabel `kunci`."""
    entitas = daftar.ambil(kunci)
    if entitas is None:
        abort(404)
    boleh = current_user().role in entitas.peran
    return jsonify(
        label=entitas.label,
        hapus=boleh and entitas.hapus is not None,
        medan=[
            {"nama": m.nama, "label": m.label, "pilihan": [list(p) for p in m.pilihan]}
            for m in (entitas.medan if boleh and entitas.ubah else ())
        ],
        impor=boleh and entitas.buat is not None and bool(entitas.kolom),
        kolom=[
            {"nama": k.nama, "wajib": k.wajib}
            for k in (daftar.kolom_impor(entitas, current_user()) if boleh else ())
        ],
    )


@bp.post("/massal/<kunci>/hapus")
@require_role(*SEMUA_PERAN)
def hapus(kunci: str):
    entitas = _entitas(kunci)
    if entitas.hapus is None:
        abort(404)
    if not HapusForm().validate_on_submit():
        return _galat("Permintaan tidak sah. Muat ulang halaman lalu coba lagi.")
    ids = _ids()
    if not ids:
        return _galat("Tidak ada baris yang dipilih.")
    try:
        jumlah = daftar.hapus_banyak(db_session, current_user(), entitas, ids)
    except (GalatDomain, AccessDenied, TidakDitemukan) as galat:
        db_session.rollback()
        return _galat(f"Tidak ada yang dihapus. {galat}")
    db_session.commit()
    return jsonify(ok=True, pesan=f"{jumlah} {entitas.label} dihapus.")


@bp.post("/massal/<kunci>/ubah")
@require_role(*SEMUA_PERAN)
def ubah(kunci: str):
    entitas = _entitas(kunci)
    if entitas.ubah is None:
        abort(404)
    if not HapusForm().validate_on_submit():
        return _galat("Permintaan tidak sah. Muat ulang halaman lalu coba lagi.")
    ids = _ids()
    if not ids:
        return _galat("Tidak ada baris yang dipilih.")
    try:
        jumlah = daftar.ubah_banyak(
            db_session, current_user(), entitas, ids,
            request.form.get("medan") or "", request.form.get("nilai") or "",
        )
    except (GalatDomain, AccessDenied, TidakDitemukan) as galat:
        db_session.rollback()
        return _galat(f"Tidak ada yang diubah. {galat}")
    db_session.commit()
    return jsonify(ok=True, pesan=f"{jumlah} {entitas.label} diubah.")


@bp.get("/massal/<kunci>/templat.csv")
@require_role(*SEMUA_PERAN)
def templat(kunci: str):
    entitas = _entitas(kunci)
    if entitas.buat is None or not entitas.kolom:
        abort(404)
    return Response(
        daftar.templat_csv(entitas, current_user()),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="templat-{kunci}.csv"'},
    )


@bp.post("/massal/<kunci>/impor")
@require_role(*SEMUA_PERAN)
def impor(kunci: str):
    entitas = _entitas(kunci)
    if entitas.buat is None or not entitas.kolom:
        abort(404)
    if not HapusForm().validate_on_submit():
        return _galat("Permintaan tidak sah. Muat ulang halaman lalu coba lagi.")
    berkas = request.files.get("berkas")
    if berkas is None or not berkas.filename:
        return _galat("Pilih berkas CSV yang akan diimpor.")
    try:
        isi = berkas.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        return _galat("Berkas harus CSV berenkode UTF-8 (di Excel: Simpan sebagai CSV UTF-8).")
    try:
        jumlah = daftar.impor_csv(db_session, current_user(), entitas, isi)
    except (GalatDomain, AccessDenied) as galat:
        db_session.rollback()
        return _galat(f"Tidak ada yang diimpor. {galat}")
    db_session.commit()
    return jsonify(ok=True, pesan=f"{jumlah} {entitas.label} diimpor.")
