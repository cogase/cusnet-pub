import logging
import pathlib
from datetime import date
from decimal import Decimal

from sqlalchemy import and_, func, or_, select, update

from app.core import audit, files, rbac
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.pagination import Page, paginate, paginate_rows
from app.modules.admin.models import AuditLog, Branch
from app.modules.customers.models import (
    JENIS_DOKUMEN,
    MODE_INVOICE,
    PERAN_KONTAK,
    STATUS_PELANGGAN,
    SUMBER_PELANGGAN,
    TIER_PELANGGAN,
    TIPE_PELANGGAN,
    TIPE_PEMBAYARAN,
    Customer,
    CustomerCategory,
    CustomerContact,
    CustomerDocument,
    CustomerNote,
)
from app.modules.settings import service as setting_service

_log = logging.getLogger(__name__)

KOLOM_KATEGORI_PELANGGAN = ("name", "is_active")

KOLOM_PELANGGAN = (
    "cid",
    "name",
    "alias",
    "branch_id",
    "customer_type",
    "tier",
    "category_id",
    "source",
    "sales_user_id",
    "install_address",
    "install_lat",
    "install_lng",
    "billing_same_as_install",
    "billing_address",
    "ktp_number",
    "npwp_number",
    "status",
    "status_note",
    "invoice_mode",
    "payment_type",
    "credit_limit",
    "ppn_exempt",
    "payment_term_days",
    "joined_at",
    "activated_at",
    "terminated_at",
)

KREDIT_LIMIT_MAKS = Decimal("999999999999.99")

# Enum yang wajib ditegakkan di lapisan service, bukan hanya di SelectField.
# Kode yang memanggil service langsung — impor CSV, CLI, uji — menembus
# formulir sepenuhnya.
PILIHAN_PELANGGAN: dict[str, tuple[str, ...]] = {
    "customer_type": TIPE_PELANGGAN,
    "tier": TIER_PELANGGAN,
    "status": STATUS_PELANGGAN,
    "source": SUMBER_PELANGGAN,
    "invoice_mode": MODE_INVOICE,
    "payment_type": TIPE_PEMBAYARAN,
}


class NilaiSudahDipakai(GalatDomain):
    """Nilai unik yang diminta sudah dipakai baris lain."""


class NilaiTidakDikenal(GalatDomain):
    """Nilai enum di luar daftar yang tersedia."""


class NilaiTidakSah(GalatDomain):
    """Nilai numerik di luar batas yang masuk akal."""


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def daftar_kategori_pelanggan(sesi, page: int = 1, per_page: int = 50) -> Page:
    query = select(CustomerCategory).order_by(CustomerCategory.name)
    return paginate(sesi, query, page, per_page)


# Pelanggan adalah tabel transaksi, bukan master: dropdown-nya tidak boleh
# memuat semuanya. Batasnya dipertahankan, tapi pemotongannya dilaporkan.
BATAS_PILIHAN = 200


def pilihan_pelanggan(sesi, user, batas: int = BATAS_PILIHAN):
    """Baris `(Customer, Branch)` untuk dropdown, beserta tanda terpotong.

    Mengembalikan `(baris, terpotong)`. Pemanggil WAJIB memakai `terpotong` —
    dropdown yang diam-diam kehilangan pelanggan ke-201 membuat operator
    menyimpulkan datanya belum dibuat.
    """
    halaman = daftar_pelanggan(sesi, user, page=1, per_page=batas)
    return halaman.items, halaman.total > batas


def semua_kategori_pelanggan(sesi) -> list[CustomerCategory]:
    """Seluruh kategori pelanggan tanpa halaman. Untuk dropdown."""
    return list(
        sesi.execute(
            select(CustomerCategory).order_by(CustomerCategory.name)
        ).scalars().all()
    )


def ambil_kategori_pelanggan(sesi, kategori_id: int) -> CustomerCategory:
    kategori = sesi.get(CustomerCategory, kategori_id)
    if kategori is None:
        raise TidakDitemukan("Kategori customer tidak ditemukan.")
    return kategori


def _pastikan_nama_kategori_bebas(sesi, nama: str, kecuali_id: int | None = None) -> None:
    query = select(CustomerCategory).where(CustomerCategory.name == nama)
    if kecuali_id is not None:
        query = query.where(CustomerCategory.id != kecuali_id)
    if sesi.execute(query).scalars().first() is not None:
        raise NilaiSudahDipakai("name", f"Kategori '{nama}' sudah ada.")


def buat_kategori_pelanggan(sesi, aktor, data: dict) -> CustomerCategory:
    _pastikan_nama_kategori_bebas(sesi, data.get("name"))

    kategori = CustomerCategory(
        **{k: data.get(k) for k in KOLOM_KATEGORI_PELANGGAN if k in data}
    )
    sesi.add(kategori)
    sesi.flush()

    audit.record(
        sesi, "create", "customer_category", kategori.id,
        after=_potret(kategori, KOLOM_KATEGORI_PELANGGAN),
        aktor=aktor,
    )
    return kategori


def ubah_kategori_pelanggan(sesi, aktor, kategori_id: int, data: dict) -> CustomerCategory:
    kategori = ambil_kategori_pelanggan(sesi, kategori_id)
    if "name" in data:
        _pastikan_nama_kategori_bebas(sesi, data["name"], kecuali_id=kategori.id)

    sebelum = _potret(kategori, KOLOM_KATEGORI_PELANGGAN)
    for nama in KOLOM_KATEGORI_PELANGGAN:
        if nama in data:
            setattr(kategori, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "customer_category", kategori.id,
        before=sebelum, after=_potret(kategori, KOLOM_KATEGORI_PELANGGAN),
        aktor=aktor,
    )
    return kategori


def hapus_kategori_pelanggan(sesi, aktor, kategori_id: int) -> None:
    kategori = ambil_kategori_pelanggan(sesi, kategori_id)
    sesi.execute(
        update(Customer)
        .where(Customer.category_id == kategori.id)
        .values(category_id=None)
    )
    audit.record(
        sesi, "delete", "customer_category", kategori.id,
        before=_potret(kategori, KOLOM_KATEGORI_PELANGGAN), aktor=aktor,
    )
    sesi.delete(kategori)
    sesi.flush()


def _pastikan_pilihan(data: dict) -> None:
    for field, pilihan in PILIHAN_PELANGGAN.items():
        nilai = data.get(field)
        if field not in data or nilai is None or nilai == "":
            continue
        if nilai not in pilihan:
            raise NilaiTidakDikenal(
                field,
                f"Nilai '{nilai}' tidak dikenal. Pilih salah satu: "
                + ", ".join(pilihan),
            )


def _bersihkan_nominal(data: dict) -> dict:
    bersih = dict(data)

    if bersih.get("credit_limit") is not None:
        bersih["credit_limit"] = to_money(bersih["credit_limit"])
        if bersih["credit_limit"] < 0:
            raise NilaiTidakSah("credit_limit", "Kredit limit tidak boleh negatif.")
        if bersih["credit_limit"] > KREDIT_LIMIT_MAKS:
            raise NilaiTidakSah(
                "credit_limit",
                "Kredit limit terlalu besar. Maksimum Rp 999.999.999.999,99.",
            )

    if bersih.get("payment_term_days") is not None and not (
        0 <= int(bersih["payment_term_days"]) <= 365
    ):
        raise NilaiTidakSah(
            "payment_term_days", "Termin bayar harus antara 0 dan 365 hari."
        )

    return bersih


def _pastikan_cid_bebas(sesi, cid: str, kecuali_id: int | None = None) -> None:
    query = select(Customer).where(Customer.cid == cid)
    if kecuali_id is not None:
        query = query.where(Customer.id != kecuali_id)
    if sesi.execute(query).scalars().first() is not None:
        raise NilaiSudahDipakai("cid", f"CID '{cid}' sudah dipakai pelanggan lain.")


def _pastikan_kategori_ada(sesi, category_id: int | None) -> None:
    if category_id is None:
        return
    if sesi.get(CustomerCategory, category_id) is None:
        raise NilaiTidakDikenal("category_id", "Kategori customer tidak ditemukan.")


def _ambil_cabang(sesi, branch_id: int | None) -> Branch:
    cabang = sesi.get(Branch, branch_id) if branch_id else None
    if cabang is None:
        raise NilaiTidakDikenal("branch_id", "Cabang tidak ditemukan.")
    return cabang


def buat_pelanggan(sesi, aktor, data: dict) -> Customer:
    """Membuat pelanggan baru beserta CID-nya.

    Urutan pengambilan kunci penting dan tidak boleh dibalik di jalur mana pun
    (m1a-catatan-lanjutan.md §1.6): pengaturan lebih dulu — lewat
    `setting_service.buat_cid` yang memanggil `ambil_setting` — baru penghitung
    penomoran. Jalur kedua yang membalik urutannya menghasilkan deadlock yang
    hanya muncul di bawah beban.
    """
    cabang = _ambil_cabang(sesi, data.get("branch_id"))
    rbac.assert_branch_access(aktor, cabang.id)
    _pastikan_pilihan(data)
    _pastikan_kategori_ada(sesi, data.get("category_id"))
    bersih = _bersihkan_nominal(data)

    cid = (bersih.get("cid") or "").strip()
    if cid:
        # CID manual tidak menggeser penghitung otomatis — deret berikutnya
        # tetap melanjutkan dari nomor terakhir yang dibuat sistem.
        _pastikan_cid_bebas(sesi, cid)
    else:
        cid = setting_service.buat_cid(sesi, cabang)
        _pastikan_cid_bebas(sesi, cid)
    bersih["cid"] = cid

    pelanggan = Customer(**{k: bersih.get(k) for k in KOLOM_PELANGGAN if k in bersih})
    sesi.add(pelanggan)
    sesi.flush()

    audit.record(
        sesi, "create", "customer", pelanggan.id,
        after=_potret(pelanggan, KOLOM_PELANGGAN), aktor=aktor,
    )
    return pelanggan


def ambil_pelanggan(sesi, user, customer_id: int) -> Customer:
    pelanggan = sesi.get(Customer, customer_id)
    if pelanggan is None:
        raise TidakDitemukan("Customer tidak ditemukan.")
    rbac.assert_branch_access(user, pelanggan.branch_id)
    return pelanggan


class PelangganDipakai(GalatDomain):
    """Pelanggan sudah punya jejak yang tidak boleh ikut hilang."""


def _pemakai_pelanggan(sesi, customer_id: int) -> list[str]:
    """Sebutan jejak yang menghalangi penghapusan, beserta jumlahnya.

    Dikembalikan sebagai daftar kalimat, bukan angka mentah: operator perlu
    tahu HARUS membereskan apa, bukan sekadar bahwa ia tidak boleh menghapus.
    """
    from app.modules.billing.models import Invoice
    from app.modules.customers.subscriptions import Subscription
    from app.modules.tickets.models import Ticket

    penghalang = []
    for model, kolom, satuan in (
        (Invoice, Invoice.customer_id, "invoice"),
        (Subscription, Subscription.customer_id, "layanan"),
        (Ticket, Ticket.customer_id, "tiket"),
    ):
        jumlah = sesi.execute(
            select(func.count()).select_from(model).where(kolom == customer_id)
        ).scalar_one()
        if jumlah:
            penghalang.append(f"{jumlah} {satuan}")
    return penghalang


def hapus_pelanggan(sesi, aktor, customer_id: int) -> None:
    """Menghapus pelanggan beserta layanan, tagihan, pembayaran, dan tiketnya."""
    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)
    from app.modules.customers import subscription_service

    subscription_service.hapus_data_pelanggan(sesi, aktor, customer_id)

    # Berkas dibuang SEBELUM barisnya hilang: sesudah itu tidak ada lagi yang
    # tahu path-nya. Dokumen pelanggan berisi KTP dan NPWP — "hapus pelanggan"
    # yang meninggalkan pindaian identitasnya di volume unggahan bukan
    # penghapusan. Kegagalan membuang berkas TIDAK membatalkan penghapusan:
    # baris yang menunjuk berkas yang sudah hilang tidak boleh mengunci
    # pelanggannya selamanya.
    dokumen = sesi.execute(
        select(CustomerDocument).where(CustomerDocument.customer_id == customer_id)
    ).scalars().all()
    for satu in dokumen:
        try:
            pathlib.Path(satu.path).unlink(missing_ok=True)
        except OSError:
            _log.warning("Berkas dokumen gagal dibuang: %s", satu.path)

    audit.record(
        sesi, "delete", "customer", pelanggan.id,
        before=_potret(pelanggan, KOLOM_PELANGGAN), aktor=aktor,
    )
    sesi.delete(pelanggan)
    sesi.flush()


def ubah_pelanggan(sesi, aktor, customer_id: int, data: dict) -> Customer:
    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)

    if "branch_id" in data and data["branch_id"] != pelanggan.branch_id:
        # Dua pemeriksaan, bukan satu: pindah cabang berarti aktor harus
        # berhak atas cabang asal DAN cabang tujuan.
        rbac.assert_branch_access(aktor, data["branch_id"])
        _ambil_cabang(sesi, data["branch_id"])

    _pastikan_pilihan(data)
    _pastikan_kategori_ada(sesi, data.get("category_id"))
    bersih = _bersihkan_nominal(data)

    if "cid" in bersih:
        cid = (bersih["cid"] or "").strip()
        if not cid:
            raise NilaiTidakSah("cid", "CID tidak boleh dikosongkan.")
        _pastikan_cid_bebas(sesi, cid, kecuali_id=pelanggan.id)
        bersih["cid"] = cid

    sebelum = _potret(pelanggan, KOLOM_PELANGGAN)
    for nama in KOLOM_PELANGGAN:
        if nama in bersih:
            setattr(pelanggan, nama, bersih[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "customer", pelanggan.id,
        before=sebelum, after=_potret(pelanggan, KOLOM_PELANGGAN), aktor=aktor,
    )
    return pelanggan


def _query_pelanggan(
    user,
    q: str | None = None,
    status: str | None = None,
    branch_id: int | None = None,
    category_id: int | None = None,
    customer_type: str | None = None,
    kategori_layanan_id: int | None = None,
    sejak: date | None = None,
    sampai: date | None = None,
):
    """Merakit query pelanggan lengkap dengan seluruh filternya.

    Seluruh filter menempel DI SINI, sebelum query diserahkan ke
    `paginate_rows`. `paginate_rows` membangun query hitung dari subquery-nya
    sendiri; filter yang ditambahkan setelahnya tidak ikut terhitung dan
    jumlah datanya bohong. Ini sudah menggigit sekali di halaman Layanan.
    """
    query = (
        select(Customer, Branch)
        .join(Branch, Customer.branch_id == Branch.id)
        .order_by(Customer.id.desc())
    )
    query = rbac.scoped(query, user, Customer)

    if q:
        pola = f"%{q.strip()}%"
        query = query.where(
            or_(
                Customer.name.ilike(pola),
                Customer.alias.ilike(pola),
                Customer.cid.ilike(pola),
                Customer.install_address.ilike(pola),
            )
        )
    if status:
        query = query.where(Customer.status == status)
    if branch_id:
        query = query.where(Customer.branch_id == branch_id)
    if category_id:
        query = query.where(Customer.category_id == category_id)
    if customer_type:
        query = query.where(Customer.customer_type == customer_type)
    if kategori_layanan_id:
        # Diimpor di dalam fungsi: modul langganan mengimpor modul ini, jadi
        # impor di kepala berkas membuat lingkaran impor.
        from app.modules.customers.subscriptions import Subscription
        from app.modules.services.models import ServicePlan

        query = query.where(
            Customer.id.in_(
                select(Subscription.customer_id)
                .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
                .where(
                    ServicePlan.category_id == kategori_layanan_id,
                    Subscription.status == "active",
                )
            )
        )
    if sejak:
        query = query.where(Customer.joined_at >= sejak)
    if sampai:
        query = query.where(Customer.joined_at <= sampai)

    return query


def daftar_pelanggan(sesi, user, page: int = 1, per_page: int = 10, **filter) -> Page:
    return paginate_rows(sesi, _query_pelanggan(user, **filter), page, per_page)


def pelanggan_berikutnya(sesi, user, customer_id: int, **filter) -> int | None:
    """Pelanggan sesudah `customer_id` pada daftar yang sedang dibuka.

    TERIKAT pada `ORDER BY Customer.id DESC` di `_query_pelanggan`: karena
    kuncinya tunggal dan menurun, "berikutnya" berarti id terbesar yang masih
    lebih kecil. Kalau urutan daftar kelak diubah, cara ini ikut salah — ada
    uji yang mengunci asumsi itu supaya merahnya muncul di sini, bukan pada
    tombol yang diam-diam melompat ke pelanggan acak.

    `None` kalau sudah di baris terakhir. Filternya sama persis dengan
    daftarnya, termasuk penyaringan cabang.
    """
    query = (
        _query_pelanggan(user, **filter)
        .where(Customer.id < customer_id)
        .limit(1)
    )
    baris = sesi.execute(query).first()
    return baris[0].id if baris else None


# Ekspor tidak dipaginasi, tetapi tetap dibatasi: satu permintaan yang
# menarik seluruh tabel ke memori lalu merangkainya jadi satu string adalah
# cara termudah menjatuhkan worker di pemasangan yang datanya sudah besar.
BATAS_EKSPOR = 20_000


def ekspor_pelanggan(sesi, user, kolom: list[str], **filter):
    """Pelanggan yang lolos filter sebagai CSV, beserta tanda terpotong.

    Mengembalikan `(teks_csv, terpotong)`. Pemanggil wajib memberi tahu
    pemakainya kalau `terpotong` — berkas yang tampak utuh padahal kehilangan
    segalanya setelah baris ke-20.000 adalah kegagalan yang tidak pernah
    ketahuan.

    Memakai `_query_pelanggan` yang sama dengan halaman daftar — termasuk
    penyaringan cabangnya. Query kedua yang ditulis khusus untuk ekspor
    adalah tempat kebocoran antar cabang berikutnya.
    """
    from app.modules.customers import ekspor as modul_ekspor

    baris = sesi.execute(_query_pelanggan(user, **filter).limit(BATAS_EKSPOR)).all()
    kontak = kontak_utama_untuk(sesi, [pelanggan.id for pelanggan, _ in baris])
    return modul_ekspor.csv_pelanggan(baris, kolom, kontak), len(baris) >= BATAS_EKSPOR


KOLOM_KONTAK = ("name", "job_title", "role", "phone", "email", "is_primary")


class KontakUtamaTerakhir(GalatDomain):
    """Kontak utama tidak boleh dihapus selagi masih ada kontak lain."""


def _pastikan_peran_kontak(data: dict) -> None:
    peran = data.get("role")
    if peran and peran not in PERAN_KONTAK:
        raise NilaiTidakDikenal(
            "role", "Peran kontak harus salah satu dari: " + ", ".join(PERAN_KONTAK)
        )


def _lepas_utama_lain(sesi, customer_id: int, kecuali_id: int | None = None) -> None:
    """Melepas tanda utama dari kontak lain SEBELUM yang baru ditandai.

    Urutannya penting: unique index parsial `uq_kontak_utama_per_pelanggan`
    menolak dua baris utama, jadi menandai dulu lalu melepas belakangan
    berakhir sebagai IntegrityError di layar pengguna.
    """
    query = select(CustomerContact).where(
        CustomerContact.customer_id == customer_id,
        CustomerContact.is_primary.is_(True),
    )
    if kecuali_id is not None:
        query = query.where(CustomerContact.id != kecuali_id)

    for kontak in sesi.execute(query).scalars().all():
        kontak.is_primary = False
    sesi.flush()


def daftar_kontak(sesi, user, customer_id: int) -> list[CustomerContact]:
    ambil_pelanggan(sesi, user, customer_id)
    return list(
        sesi.execute(
            select(CustomerContact)
            .where(CustomerContact.customer_id == customer_id)
            .order_by(CustomerContact.is_primary.desc(), CustomerContact.name)
        ).scalars().all()
    )


def ambil_kontak(sesi, user, kontak_id: int) -> CustomerContact:
    kontak = sesi.get(CustomerContact, kontak_id)
    if kontak is None:
        raise TidakDitemukan("Kontak tidak ditemukan.")
    ambil_pelanggan(sesi, user, kontak.customer_id)
    return kontak


def buat_kontak(sesi, aktor, customer_id: int, data: dict) -> CustomerContact:
    ambil_pelanggan(sesi, aktor, customer_id)
    _pastikan_peran_kontak(data)

    sudah_ada = sesi.execute(
        select(func.count())
        .select_from(CustomerContact)
        .where(CustomerContact.customer_id == customer_id)
    ).scalar_one()

    bersih = dict(data)
    # Kontak pertama selalu jadi utama. Pelanggan tanpa PIC utama membuat
    # kolom "PIC & Kontak" di daftar kosong selamanya.
    if sudah_ada == 0:
        bersih["is_primary"] = True
    if bersih.get("is_primary"):
        _lepas_utama_lain(sesi, customer_id)

    kontak = CustomerContact(
        customer_id=customer_id,
        **{k: bersih.get(k) for k in KOLOM_KONTAK if k in bersih},
    )
    sesi.add(kontak)
    sesi.flush()

    audit.record(
        sesi, "create", "customer_contact", kontak.id,
        after=_potret(kontak, KOLOM_KONTAK), aktor=aktor,
    )
    return kontak


def ubah_kontak(sesi, aktor, kontak_id: int, data: dict) -> CustomerContact:
    kontak = ambil_kontak(sesi, aktor, kontak_id)
    _pastikan_peran_kontak(data)

    if data.get("is_primary"):
        _lepas_utama_lain(sesi, kontak.customer_id, kecuali_id=kontak.id)

    sebelum = _potret(kontak, KOLOM_KONTAK)
    for nama in KOLOM_KONTAK:
        if nama in data:
            setattr(kontak, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "customer_contact", kontak.id,
        before=sebelum, after=_potret(kontak, KOLOM_KONTAK), aktor=aktor,
    )
    return kontak


def hapus_kontak(sesi, aktor, kontak_id: int) -> None:
    kontak = ambil_kontak(sesi, aktor, kontak_id)

    if kontak.is_primary:
        lain = sesi.execute(
            select(func.count())
            .select_from(CustomerContact)
            .where(
                CustomerContact.customer_id == kontak.customer_id,
                CustomerContact.id != kontak.id,
            )
        ).scalar_one()
        if lain:
            raise KontakUtamaTerakhir(
                "is_primary",
                "Tunjuk kontak utama pengganti lebih dulu sebelum menghapus "
                "kontak utama yang sekarang.",
            )

    audit.record(
        sesi, "delete", "customer_contact", kontak.id,
        before=_potret(kontak, KOLOM_KONTAK), aktor=aktor,
    )
    sesi.delete(kontak)
    sesi.flush()


def daftar_catatan(
    sesi, user, customer_id: int, limit: int | None = None
) -> list[CustomerNote]:
    ambil_pelanggan(sesi, user, customer_id)
    query = (
        select(CustomerNote)
        .where(CustomerNote.customer_id == customer_id)
        .order_by(CustomerNote.id.desc())
    )
    if limit is not None:
        query = query.limit(limit)
    return list(sesi.execute(query).scalars().all())


def buat_catatan(sesi, aktor, customer_id: int, body: str) -> CustomerNote:
    ambil_pelanggan(sesi, aktor, customer_id)

    isi = (body or "").strip()
    if not isi:
        raise NilaiTidakSah("body", "Catatan tidak boleh kosong.")

    catatan = CustomerNote(
        customer_id=customer_id,
        body=isi,
        # Penulis diambil dari aktor, bukan dari formulir: penulis yang bisa
        # dikirim dari formulir berarti siapa pun bisa menandatangani catatan
        # atas nama orang lain.
        author_user_id=aktor.id if aktor else None,
    )
    sesi.add(catatan)
    sesi.flush()

    audit.record(
        sesi, "create", "customer_note", catatan.id,
        after={"customer_id": customer_id, "body": isi}, aktor=aktor,
    )
    return catatan


def ambil_catatan(sesi, user, catatan_id: int) -> CustomerNote:
    catatan = sesi.get(CustomerNote, catatan_id)
    if catatan is None:
        raise TidakDitemukan("Catatan tidak ditemukan.")
    ambil_pelanggan(sesi, user, catatan.customer_id)
    return catatan


def hapus_catatan(sesi, aktor, catatan_id: int) -> None:
    catatan = ambil_catatan(sesi, aktor, catatan_id)

    audit.record(
        sesi, "delete", "customer_note", catatan.id,
        before={"customer_id": catatan.customer_id, "body": catatan.body},
        aktor=aktor,
    )
    sesi.delete(catatan)
    sesi.flush()


KOLOM_DOKUMEN = (
    "customer_id",
    "branch_id",
    "doc_type",
    "original_name",
    "path",
    "size",
    "mime",
)


def daftar_dokumen(sesi, user, customer_id: int) -> list[CustomerDocument]:
    ambil_pelanggan(sesi, user, customer_id)
    return list(
        sesi.execute(
            select(CustomerDocument)
            .where(CustomerDocument.customer_id == customer_id)
            .order_by(CustomerDocument.id.desc())
        ).scalars().all()
    )


def ambil_dokumen(sesi, user, dokumen_id: int) -> CustomerDocument:
    """Mengambil dokumen setelah memeriksa cabangnya.

    Pemeriksaan memakai `dokumen.branch_id` — kolom di baris dokumen itu
    sendiri — bukan hasil join ke pelanggan. Rute unduhan yang lupa join tidak
    boleh berakhir sebagai unduhan tanpa pemeriksaan.
    """
    dokumen = sesi.get(CustomerDocument, dokumen_id)
    if dokumen is None:
        raise TidakDitemukan("Dokumen tidak ditemukan.")
    rbac.assert_branch_access(user, dokumen.branch_id)
    return dokumen


def unggah_dokumen(
    sesi,
    aktor,
    customer_id: int,
    stream,
    nama_asli: str,
    doc_type: str,
    upload_dir: str,
) -> CustomerDocument:
    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)

    if doc_type not in JENIS_DOKUMEN:
        raise NilaiTidakDikenal(
            "doc_type",
            "Jenis dokumen harus salah satu dari: " + ", ".join(JENIS_DOKUMEN),
        )

    tersimpan = files.simpan(stream, nama_asli, upload_dir)

    dokumen = CustomerDocument(
        customer_id=pelanggan.id,
        # Disalin dari pelanggan, tidak pernah dari formulir.
        branch_id=pelanggan.branch_id,
        doc_type=doc_type,
        original_name=tersimpan.original_name,
        path=tersimpan.path,
        size=tersimpan.size,
        mime=tersimpan.mime,
        uploaded_by_user_id=aktor.id if aktor else None,
    )
    sesi.add(dokumen)
    sesi.flush()

    audit.record(
        sesi, "create", "customer_document", dokumen.id,
        after=_potret(dokumen, KOLOM_DOKUMEN), aktor=aktor,
    )
    return dokumen


def hapus_dokumen(sesi, aktor, dokumen_id: int) -> None:
    dokumen = ambil_dokumen(sesi, aktor, dokumen_id)

    audit.record(
        sesi, "delete", "customer_document", dokumen.id,
        before=_potret(dokumen, KOLOM_DOKUMEN), aktor=aktor,
    )
    path = dokumen.path
    sesi.delete(dokumen)
    sesi.flush()

    try:
        pathlib.Path(path).unlink(missing_ok=True)
    except OSError:
        # Berkas yatim lebih baik daripada baris yatim yang menunjuk berkas
        # hilang dan membuat halaman detail 500.
        _log.warning("Gagal menghapus berkas dokumen %s", path, exc_info=True)


def timeline_pelanggan(sesi, user, customer_id: int, limit: int = 50) -> list[AuditLog]:
    """Menggabungkan jejak audit pelanggan beserta anak-anaknya.

    `audit.timeline` hanya melihat satu `entity_type`. Kontak, dokumen, dan
    catatan punya `entity_type` sendiri, dan tanpa penggabungan ini tab
    Timeline hanya memperlihatkan perubahan kolom pelanggan.

    Batasan yang diketahui: baris anak yang sudah dihapus tidak lagi punya id
    di tabelnya, jadi jejak penghapusannya tidak ikut terkumpul di sini.
    """
    ambil_pelanggan(sesi, user, customer_id)

    syarat = [
        and_(AuditLog.entity_type == "customer", AuditLog.entity_id == customer_id)
    ]
    for tipe, model in (
        ("customer_contact", CustomerContact),
        ("customer_document", CustomerDocument),
        ("customer_note", CustomerNote),
    ):
        daftar_id = sesi.execute(
            select(model.id).where(model.customer_id == customer_id)
        ).scalars().all()
        if daftar_id:
            syarat.append(
                and_(
                    AuditLog.entity_type == tipe,
                    AuditLog.entity_id.in_(daftar_id),
                )
            )

    return list(
        sesi.execute(
            select(AuditLog)
            .where(or_(*syarat))
            .order_by(AuditLog.id.desc())
            .limit(limit)
        ).scalars().all()
    )


def inisial(nama: str) -> str:
    """Dua huruf pertama dari dua kata pertama, seperti `PM` di mockup."""
    kata = [k for k in (nama or "").split() if k]
    return "".join(k[0] for k in kata[:2]).upper() or "?"


def kontak_utama_untuk(sesi, customer_ids: list[int]) -> dict[int, CustomerContact]:
    """Kontak utama untuk sekumpulan pelanggan dalam satu query.

    Dipanggil sekali per halaman daftar. Membacanya dari templat berarti satu
    query per baris.
    """
    if not customer_ids:
        return {}

    baris = sesi.execute(
        select(CustomerContact).where(
            CustomerContact.customer_id.in_(customer_ids),
            CustomerContact.is_primary.is_(True),
        )
    ).scalars().all()
    return {kontak.customer_id: kontak for kontak in baris}


def ringkasan_pelanggan(sesi, user) -> dict:
    """Angka untuk lima kartu statistik di halaman Daftar Customer."""
    query = rbac.scoped(
        select(Customer.status, func.count(Customer.id)).group_by(Customer.status),
        user,
        Customer,
    )
    per_status = dict(sesi.execute(query).all())

    hasil = {status: per_status.get(status, 0) for status in STATUS_PELANGGAN}
    hasil["total"] = sum(per_status.values())
    return hasil
