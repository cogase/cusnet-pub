"""Pemilih kolom dan ekspor CSV daftar pelanggan.

Satu daftar kolom dipakai dua tempat: kolom mana yang tampil di tabel, dan
kolom mana yang ikut ke berkas CSV. Dua daftar terpisah berarti "Kolom" dan
"Export" perlahan bercerai — yang dilihat di layar tidak lagi sama dengan
yang terunduh.

Filternya juga bukan query baru: ekspor memakai `_query_pelanggan` yang sama
dengan halaman daftar, termasuk penyaringan cabangnya. Query kedua yang
ditulis khusus untuk ekspor adalah tempat kebocoran antar cabang berikutnya.
"""

import io

from app.core import csv_aman

# Kolom yang punya tempat di tabel. `wajib` tidak bisa dimatikan: tabel tanpa
# CID dan nama tidak bisa dibaca siapa pun.
#
# `csv` memetakan satu kolom layar ke satu atau beberapa kolom berkas — "PIC
# & Kontak" tampil sebagai satu sel bertumpuk di layar, tetapi di CSV harus
# menjadi tiga kolom supaya bisa disaring dan diurutkan.
KOLOM_TABEL = (
    {"kunci": "cid", "judul": "CID", "wajib": True, "csv": ("cid",)},
    {"kunci": "nama", "judul": "Nama Customer", "wajib": True, "csv": ("nama",)},
    {"kunci": "alias", "judul": "Alias", "csv": ("alias",)},
    {"kunci": "layanan", "judul": "Layanan", "csv": ()},
    {"kunci": "alamat", "judul": "Alamat Instalasi", "csv": ("alamat_instalasi",)},
    {
        "kunci": "pic",
        "judul": "PIC & Kontak",
        "csv": ("pic_nama", "pic_telepon", "pic_email"),
    },
    {"kunci": "status", "judul": "Status", "csv": ("status",)},
    {"kunci": "cabang", "judul": "Cabang", "csv": ("cabang",)},
)

# Kolom yang tidak muat di tabel tetapi memang dibutuhkan di berkas rekap.
KOLOM_CSV_TAMBAHAN = (
    {"kunci": "tipe", "judul": "Tipe"},
    {"kunci": "tier", "judul": "Tier"},
    {"kunci": "alamat_tagihan", "judul": "Alamat Tagihan"},
    {"kunci": "npwp", "judul": "NPWP"},
    {"kunci": "mode_invoice", "judul": "Mode Invoice"},
    {"kunci": "tipe_pembayaran", "judul": "Tipe Pembayaran"},
    {"kunci": "bergabung", "judul": "Tanggal Bergabung"},
    {"kunci": "aktivasi", "judul": "Tanggal Aktivasi"},
)

# Nomor KTP sengaja tidak ada di daftar mana pun. NPWP dipakai untuk
# penagihan dan memang dibutuhkan di berkas rekap; nomor KTP tidak punya
# kegunaan di luar berkas pelanggan, dan satu CSV yang bocor jauh lebih mudah
# tersebar daripada satu halaman detail.

KUNCI_TABEL = tuple(k["kunci"] for k in KOLOM_TABEL)
WAJIB = tuple(k["kunci"] for k in KOLOM_TABEL if k.get("wajib"))
KUNCI_TAMBAHAN = tuple(k["kunci"] for k in KOLOM_CSV_TAMBAHAN)
SEMUA_KUNCI = KUNCI_TABEL + KUNCI_TAMBAHAN

JUDUL_CSV = {
    "cid": "CID",
    "nama": "Nama Customer",
    "alias": "Alias",
    "alamat_instalasi": "Alamat Instalasi",
    "pic_nama": "PIC",
    "pic_telepon": "Telepon PIC",
    "pic_email": "Email PIC",
    "status": "Status",
    "cabang": "Cabang",
    **{k["kunci"]: k["judul"] for k in KOLOM_CSV_TAMBAHAN},
}


def kolom_terpilih(diminta) -> list[str]:
    """Kunci kolom yang jadi dipakai, apa pun yang dikirim peramban.

    Tanpa pilihan sama sekali berarti tampilan bawaan: seluruh kolom tabel,
    tanpa kolom tambahan. Kolom wajib selalu ikut, kunci asing dibuang, dan
    urutannya mengikuti daftar di modul ini — kolom yang berpindah tempat
    setiap ekspor menyulitkan siapa pun yang menyusun rumus di Excel.
    """
    diminta = {kunci for kunci in (diminta or ()) if kunci in SEMUA_KUNCI}
    if not diminta:
        return list(KUNCI_TABEL)
    dipilih = diminta | set(WAJIB)
    return [kunci for kunci in SEMUA_KUNCI if kunci in dipilih]


def kolom_csv(dipilih: list[str]) -> list[str]:
    """Kolom berkas CSV untuk pilihan kolom `dipilih`."""
    peta = {k["kunci"]: k["csv"] for k in KOLOM_TABEL}
    hasil = []
    for kunci in dipilih:
        hasil.extend(peta.get(kunci, (kunci,)))
    return hasil


def _nilai(kunci: str, pelanggan, cabang, kontak) -> str:
    if kunci == "cid":
        return pelanggan.cid
    if kunci == "nama":
        return pelanggan.name
    if kunci == "alias":
        return pelanggan.alias or ""
    if kunci == "tipe":
        return pelanggan.customer_type
    if kunci == "tier":
        return pelanggan.tier
    if kunci == "status":
        return pelanggan.status
    if kunci == "cabang":
        return f"{cabang.code} — {cabang.name}" if cabang else ""
    if kunci == "alamat_instalasi":
        return pelanggan.install_address or ""
    if kunci == "alamat_tagihan":
        if pelanggan.billing_same_as_install:
            return pelanggan.install_address or ""
        return pelanggan.billing_address or ""
    if kunci == "pic_nama":
        return kontak.name if kontak else ""
    if kunci == "pic_telepon":
        return (kontak.phone or "") if kontak else ""
    if kunci == "pic_email":
        return (kontak.email or "") if kontak else ""
    if kunci == "npwp":
        return pelanggan.npwp_number or ""
    if kunci == "mode_invoice":
        return pelanggan.invoice_mode
    if kunci == "tipe_pembayaran":
        return pelanggan.payment_type
    if kunci == "bergabung":
        return pelanggan.joined_at.isoformat() if pelanggan.joined_at else ""
    if kunci == "aktivasi":
        return pelanggan.activated_at.isoformat() if pelanggan.activated_at else ""
    raise KeyError(kunci)


def csv_pelanggan(baris, dipilih: list[str], kontak_per_pelanggan: dict) -> str:
    kolom = kolom_csv(dipilih)
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow([JUDUL_CSV[kunci] for kunci in kolom])
    for pelanggan, cabang in baris:
        kontak = kontak_per_pelanggan.get(pelanggan.id)
        tulis.writerow([_nilai(kunci, pelanggan, cabang, kontak) for kunci in kolom])
    return keluaran.getvalue()
