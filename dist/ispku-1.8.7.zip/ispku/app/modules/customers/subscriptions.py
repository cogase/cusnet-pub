from datetime import date
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import Money, TimestampMixin, enum_check

STATUS_LANGGANAN: tuple[str, ...] = ("pending", "active", "suspend", "terminasi")
JENIS_INTERNET: tuple[str, ...] = ("dedicated", "broadband")
JENIS_DISKON: tuple[str, ...] = ("persen", "nominal")
SISI_TERMINASI: tuple[str, ...] = ("1", "2")


class Subscription(Base, TimestampMixin):
    __tablename__ = "subscription"
    __table_args__ = (
        enum_check("ck_subscription_status", "status", STATUS_LANGGANAN),
        enum_check(
            "ck_subscription_jenis_diskon",
            "discount_kind",
            JENIS_DISKON,
            boleh_kosong=True,
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id", ondelete="CASCADE"), nullable=False, index=True
    )
    plan_id: Mapped[int] = mapped_column(ForeignKey("service_plan.id"), nullable=False)
    service_no: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending", index=True
    )
    started_at: Mapped[date | None] = mapped_column(Date)
    activated_at: Mapped[date | None] = mapped_column(Date)
    terminated_at: Mapped[date | None] = mapped_column(Date)
    site_name: Mapped[str | None] = mapped_column(String(120))
    # Kosong berarti ikut harga paket. Disalin ke invoice saat terbit di M2,
    # sehingga perubahan harga paket kelak tidak mengubah invoice lama.
    price_override: Mapped[Decimal | None] = mapped_column(Money)
    discount_kind: Mapped[str | None] = mapped_column(String(20))
    discount_value: Mapped[Decimal | None] = mapped_column(Money)
    # Kolom identitas yang berlaku untuk semua kategori (spesifikasi §5.4).
    ip_address: Mapped[str | None] = mapped_column(String(60))
    vlan: Mapped[str | None] = mapped_column(String(20))
    interface: Mapped[str | None] = mapped_column(String(60))
    note: Mapped[str | None] = mapped_column(Text)


class SubscriptionInternet(Base, TimestampMixin):
    """Detail teknis kategori berbentuk `internet`. Satu baris per langganan."""

    __tablename__ = "subscription_internet"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    capacity_mbps: Mapped[int | None] = mapped_column(Integer)
    internet_kind: Mapped[str] = mapped_column(
        String(20), nullable=False, default="dedicated"
    )
    # Kosong berarti infrastruktur sendiri.
    vendor_id: Mapped[int | None] = mapped_column(ForeignKey("vendor.id"))
    odp_name: Mapped[str | None] = mapped_column(String(120))
    odp_lat: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    odp_lng: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))


class SubscriptionP2P(Base, TimestampMixin):
    """Detail teknis kategori berbentuk `point_to_point`."""

    __tablename__ = "subscription_p2p"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    capacity_mbps: Mapped[int | None] = mapped_column(Integer)
    vendor_id: Mapped[int | None] = mapped_column(ForeignKey("vendor.id"))


class P2PTermination(Base, TimestampMixin):
    """Ujung sirkuit titik-ke-titik. Tepat dua baris per langganan.

    `side` unik per langganan: sisi kembar membuat topologi menggambar ujung
    yang sama dua kali dan menyembunyikan ujung yang sebenarnya.
    """

    __tablename__ = "p2p_termination"
    __table_args__ = (
        UniqueConstraint("subscription_id", "side", name="uq_terminasi_sisi"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False, index=True
    )
    side: Mapped[str] = mapped_column(String(1), nullable=False)
    site_name: Mapped[str] = mapped_column(String(120), nullable=False)
    address: Mapped[str | None] = mapped_column(Text)
    lat: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    lng: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    vlan: Mapped[str | None] = mapped_column(String(20))
    interface: Mapped[str | None] = mapped_column(String(60))


class P2PTransitHop(Base, TimestampMixin):
    """Vendor transit di antara dua terminasi. Nol atau lebih."""

    __tablename__ = "p2p_transit_hop"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False, index=True
    )
    urutan: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    vendor_id: Mapped[int | None] = mapped_column(ForeignKey("vendor.id"))
    label: Mapped[str | None] = mapped_column(String(120))
    # Identitas sirkuit di sisi vendor. Saat gangguan, inilah yang ditanyakan
    # NOC vendor lebih dulu — tanpa ini teknisi harus mencarinya di email lama.
    circuit_id: Mapped[str | None] = mapped_column(String(80))
    vendor_phone: Mapped[str | None] = mapped_column(String(40))
    vlan: Mapped[str | None] = mapped_column(String(20))
    # Jalur kabel dan keterangan fisik: lewat mana, di tiang siapa, warna
    # tube berapa. Bebas teks karena tiap ISP menuliskannya dengan cara
    # sendiri.
    physical_note: Mapped[str | None] = mapped_column(Text)
    note: Mapped[str | None] = mapped_column(Text)


class SubscriptionAddon(Base, TimestampMixin):
    """Biaya tambahan berulang yang menempel pada langganan."""

    __tablename__ = "subscription_addon"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False, index=True
    )
    description: Mapped[str] = mapped_column(String(160), nullable=False)
    qty: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    unit_price: Mapped[Decimal] = mapped_column(Money, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class SubscriptionInstallment(Base, TimestampMixin):
    """Biaya sekali yang dicicil, mis. instalasi.

    `terms_billed` bertambah satu tiap periode yang sudah ditagih. Batch
    invoice M2 membacanya untuk memutuskan berhenti; menyimpannya di sini —
    bukan menghitung dari jumlah baris invoice — membuat pengulangan batch
    tidak menagih dua kali.
    """

    __tablename__ = "subscription_installment"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    description: Mapped[str] = mapped_column(
        String(160), nullable=False, default="Biaya Instalasi"
    )
    total_amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    terms: Mapped[int] = mapped_column(Integer, nullable=False)
    term_amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    terms_billed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    started_at: Mapped[date | None] = mapped_column(Date)
