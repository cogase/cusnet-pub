"""Perakit topologi titik-ke-titik sebagai SVG.

Dirender di server, tanpa pustaka JavaScript: pemasangan pelanggan tidak
dijamin punya akses internet, dan seluruh aset harus ikut dalam berkas.

    [ Site A ]───( Vendor Transit X )───[ Site B ]
     VLAN 100                            VLAN 100
     ge-0/0/1                            xe-1/0/3
"""

from markupsafe import escape

LEBAR_KOTAK = 190
LEBAR_PENGHUBUNG = 90
TINGGI = 150
TINGGI_KOTAK = 78
JARAK_TEPI = 12


MAKS_HURUF = 26


def _potong(teks: str) -> str:
    """Memendekkan teks supaya tidak meluber keluar kotak."""
    teks = str(teks)
    return teks if len(teks) <= MAKS_HURUF else teks[: MAKS_HURUF - 1] + "…"


def _kotak(
    x: int, judul: str, baris: list[str], nada: str,
    tautan: str | None = None, keterangan: list[str] | None = None,
) -> str:
    """Satu kotak beserta baris keterangannya.

    `keterangan` menjadi `<title>` — teks yang ditampilkan peramban saat
    kursor berhenti di atas kotak, tanpa JavaScript. `tautan` membungkus
    kotaknya menjadi tautan ke bagian lain halaman.
    """
    isi = []
    if keterangan:
        isi.append(f"<title>{escape(chr(10).join(keterangan))}</title>")
    isi += [
        f'<rect x="{x}" y="26" width="{LEBAR_KOTAK}" height="{TINGGI_KOTAK}" rx="10" '
        f'fill="{nada}" stroke="#E5E9F0"/>',
        f'<text x="{x + LEBAR_KOTAK // 2}" y="52" text-anchor="middle" '
        f'class="topologi__judul">{escape(_potong(judul))}</text>',
    ]
    for nomor, teks in enumerate(t for t in baris if t):
        isi.append(
            f'<text x="{x + LEBAR_KOTAK // 2}" y="{72 + nomor * 16}" '
            f'text-anchor="middle" class="topologi__ket">{escape(_potong(teks))}</text>'
        )
    gabung = "".join(isi)
    if tautan:
        return f'<a class="topologi__tautan" href="{escape(tautan)}">{gabung}</a>'
    return f"<g>{gabung}</g>"


def _simpul_hop(baris) -> dict:
    """Kotak satu hop: label, circuit ID, dan VLAN; sisanya muncul saat disorot."""
    ambil = lambda nama: getattr(baris, nama, None) or ""  # noqa: E731
    keterangan = [
        f"Fisik / jalur kabel: {ambil('physical_note')}" if ambil("physical_note") else "",
        f"Catatan: {ambil('note')}" if ambil("note") else "",
        f"No. telp vendor: {ambil('vendor_phone')}" if ambil("vendor_phone") else "",
    ]
    keterangan = [k for k in keterangan if k]
    hop_id = getattr(baris, "id", None)
    return {
        "judul": ambil("label") or "Vendor transit",
        "baris": [
            ambil("circuit_id"),
            f"VLAN {ambil('vlan')}" if ambil("vlan") else "",
        ],
        "nada": "#FFEDD5",
        "tautan": f"#hop-{hop_id}" if hop_id is not None else "#hop-vendor",
        "keterangan": keterangan
        or ["Belum ada keterangan fisik, catatan, atau nomor telepon."],
    }


def _penghubung(x: int) -> str:
    tengah = 26 + TINGGI_KOTAK // 2
    return (
        f'<line x1="{x}" y1="{tengah}" x2="{x + LEBAR_PENGHUBUNG}" y2="{tengah}" '
        'stroke="#94A3B8" stroke-width="2"/>'
    )


def rakit_svg(terminasi: list, hop: list) -> str:
    """Merakit markup topologi.

    `viewBox` dihitung dari isi, bukan dari kanvas: `viewBox` seukuran kanvas
    membuat gambar menyusut drastis begitu hop-nya banyak, dan itu sudah
    pernah terjadi pada data produksi di proyek lain. Kanvasnya diberi lebar
    piksel supaya pembungkusnya bisa menggulir secara native.
    """
    if not terminasi:
        return '<p class="form__bantuan">Belum ada terminasi. Isi kedua ujungnya dulu.</p>'

    urut = sorted(terminasi, key=lambda t: t.side)
    simpul: list[dict] = []

    if urut:
        simpul.append(
            {
                "judul": urut[0].site_name,
                "baris": [
                    f"VLAN {urut[0].vlan}" if urut[0].vlan else "",
                    urut[0].interface or "",
                ],
                "nada": "#EFF6FF",
            }
        )
    for baris in sorted(hop, key=lambda h: h.urutan):
        simpul.append(_simpul_hop(baris))
    if len(urut) > 1:
        simpul.append(
            {
                "judul": urut[1].site_name,
                "baris": [
                    f"VLAN {urut[1].vlan}" if urut[1].vlan else "",
                    urut[1].interface or "",
                ],
                "nada": "#EFF6FF",
            }
        )

    lebar = (
        JARAK_TEPI * 2
        + len(simpul) * LEBAR_KOTAK
        + max(len(simpul) - 1, 0) * LEBAR_PENGHUBUNG
    )

    bagian = []
    x = JARAK_TEPI
    for nomor, satu in enumerate(simpul):
        if nomor:
            bagian.append(_penghubung(x - LEBAR_PENGHUBUNG))
        bagian.append(
            _kotak(
                x, satu["judul"], satu["baris"], satu["nada"],
                tautan=satu.get("tautan"), keterangan=satu.get("keterangan"),
            )
        )
        x += LEBAR_KOTAK + LEBAR_PENGHUBUNG

    # Tanpa atribut `xmlns`: SVG sebaris di dalam HTML sudah mendapat namespace
    # dari parser peramban, sedangkan menuliskannya menaruh URL berskema http
    # di halaman — persis yang dilarang aturan tanpa CDN dan dipindai uji
    # penjaga, walau URL itu tidak pernah diambil dari jaringan.
    return (
        f'<svg class="topologi__gambar" width="{lebar}" height="{TINGGI}" '
        f'viewBox="0 0 {lebar} {TINGGI}" role="img" aria-label="Topologi layanan">'
        + "".join(bagian)
        + "</svg>"
    )
