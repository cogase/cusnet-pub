"""Impor pelanggan dari CSV.

Pemasangan baru hampir selalu berisi data yang sudah hidup di Excel. Modul
ini membacanya, memeriksanya baris per baris, lalu menulisnya lewat
`service.buat_pelanggan` yang sama dengan formulir — bukan `Customer(...)`
langsung — supaya validasi, penomoran CID, dan audit log berlaku sama.
"""

import csv
import io
import pathlib
import re
from dataclasses import dataclass, field
from datetime import date

from app.core.errors import GalatDomain

# Berkas lebih besar dari ini ditolak, bukan diproses sampai worker mati.
BATAS_BARIS = 5_000

KOLOM_WAJIB = ("nama", "cabang")

KOLOM = (
    "nama",
    "cabang",
    "cid",
    "alias",
    "tipe",
    "tier",
    "kategori",
    "alamat_instalasi",
    "alamat_tagihan",
    "npwp",
    "status",
    "mode_invoice",
    "tipe_pembayaran",
    "bergabung",
    "kontak_nama",
    "kontak_telepon",
    "kontak_email",
)

CONTOH = {
    "nama": "PT Contoh Jaya",
    "cabang": "01",
    "cid": "",
    "alias": "Contoh",
    "tipe": "corporate",
    "tier": "regular",
    "kategori": "",
    "alamat_instalasi": "Jl. Contoh No. 1, Jakarta",
    "alamat_tagihan": "",
    "npwp": "01.234.567.8-901.000",
    "status": "active",
    "mode_invoice": "gabungan",
    "tipe_pembayaran": "postpaid",
    "bergabung": "2026-01-31",
    "kontak_nama": "Budi",
    "kontak_telepon": "081234567890",
    "kontak_email": "budi@contoh.id",
}


class ImporTidakSah(GalatDomain):
    """Berkas impor ditolak seluruhnya."""


POLA_TOKEN = re.compile(r"^[0-9a-f]{32}$")


def simpan_sementara(isi: bytes, upload_dir: str) -> str:
    """Menyimpan berkas unggahan sampai pengguna menekan Terapkan.

    Pratinjau dan penulisan adalah dua permintaan, dan berkasnya tidak bisa
    dikirim ulang oleh halaman hasil. Menaruhnya di sesi berarti berkas
    ribuan baris hidup di cookie; menaruhnya di memori berarti permintaan
    kedua bisa mendarat di worker gunicorn yang lain.
    """
    import secrets

    folder = pathlib.Path(upload_dir) / "impor"
    folder.mkdir(parents=True, exist_ok=True)
    token = secrets.token_hex(16)
    (folder / f"{token}.csv").write_bytes(isi)
    return token


def baca_sementara(upload_dir: str, token: str) -> bytes:
    if not POLA_TOKEN.match(token or ""):
        raise ImporTidakSah("berkas", "Berkas impor tidak dikenal. Unggah ulang.")
    berkas = pathlib.Path(upload_dir) / "impor" / f"{token}.csv"
    if not berkas.is_file():
        raise ImporTidakSah(
            "berkas",
            "Berkas impor sudah tidak ada. Unggah ulang lalu periksa kembali.",
        )
    return berkas.read_bytes()


def bersihkan_sementara(upload_dir: str, umur_jam: int = 24, sekarang=None) -> int:
    """Membuang berkas impor sementara yang ditinggalkan.

    Pengguna yang menutup halaman setelah pratinjau meninggalkan berkasnya di
    disk. Berkasnya kecil dan tidak bisa dibaca tanpa token, tetapi berisi
    data pelanggan — menumpuk selamanya bukan pilihan.

    Batas umur, bukan "hapus semua": pratinjau yang sedang dibaca orang lain
    tidak boleh ikut lenyap di tengah jalan.
    """
    import time

    folder = pathlib.Path(upload_dir) / "impor"
    if not folder.is_dir():
        return 0

    batas = (sekarang if sekarang is not None else time.time()) - umur_jam * 3600
    dibuang = 0
    for berkas in folder.iterdir():
        if not berkas.is_file() or berkas.suffix != ".csv":
            continue
        try:
            if berkas.stat().st_mtime < batas:
                berkas.unlink()
                dibuang += 1
        except OSError:
            continue
    return dibuang


def buang_sementara(upload_dir: str, token: str) -> None:
    if not POLA_TOKEN.match(token or ""):
        return
    (pathlib.Path(upload_dir) / "impor" / f"{token}.csv").unlink(missing_ok=True)


@dataclass
class BarisImpor:
    nomor: int
    data: dict
    galat: str | None = None

    @property
    def sah(self) -> bool:
        return self.galat is None


@dataclass
class HasilPeriksa:
    baris: list[BarisImpor] = field(default_factory=list)

    @property
    def sah(self) -> list[BarisImpor]:
        return [b for b in self.baris if b.sah]

    @property
    def bergalat(self) -> list[BarisImpor]:
        return [b for b in self.baris if not b.sah]


def templat_csv() -> str:
    keluaran = io.StringIO()
    tulis = csv.DictWriter(keluaran, fieldnames=list(KOLOM))
    tulis.writeheader()
    tulis.writerow(CONTOH)
    return keluaran.getvalue()


def _baca(isi: bytes | str) -> list[dict]:
    if isinstance(isi, bytes):
        try:
            # utf-8-sig: Excel di Windows menulis BOM, dan tanpa ini judul
            # kolom pertama terbaca "﻿nama" lalu seluruh baris dianggap
            # kehilangan kolom nama.
            teks = isi.decode("utf-8-sig")
        except UnicodeDecodeError as galat:
            raise ImporTidakSah(
                "berkas",
                "Berkas bukan teks UTF-8. Simpan ulang dari Excel dengan "
                "format 'CSV UTF-8'.",
            ) from galat
    else:
        teks = isi

    contoh = teks[:2000]
    try:
        dialek = csv.Sniffer().sniff(contoh, delimiters=",;\t")
    except csv.Error:
        # Berkas satu kolom atau judul saja tidak bisa ditebak pemisahnya;
        # koma adalah tebakan yang paling tidak mengejutkan.
        dialek = csv.excel

    pembaca = csv.DictReader(io.StringIO(teks), dialect=dialek)
    if not pembaca.fieldnames:
        raise ImporTidakSah("berkas", "Berkas kosong.")

    judul = {(nama or "").strip().lower() for nama in pembaca.fieldnames}
    hilang = [nama for nama in KOLOM_WAJIB if nama not in judul]
    if hilang:
        raise ImporTidakSah(
            "berkas",
            "Kolom wajib belum ada di baris judul: " + ", ".join(hilang)
            + ". Unduh templatnya lalu isi di sana.",
        )

    baris = []
    for satu in pembaca:
        baris.append({(k or "").strip().lower(): (v or "") for k, v in satu.items()})
        if len(baris) > BATAS_BARIS:
            raise ImporTidakSah(
                "berkas",
                f"Berkas berisi lebih dari {BATAS_BARIS:,} baris. Pecah menjadi "
                "beberapa berkas lalu impor bergantian.".replace(",", "."),
            )
    return baris


def _tanggal(teks: str, nama_kolom: str) -> date | None:
    teks = (teks or "").strip()
    if not teks:
        return None
    try:
        return date.fromisoformat(teks)
    except ValueError as galat:
        raise ValueError(
            f"kolom {nama_kolom} '{teks}' bukan tanggal YYYY-MM-DD"
        ) from galat


def periksa(sesi, aktor, isi) -> HasilPeriksa:
    """Membaca dan memeriksa berkas tanpa menulis apa pun."""
    from sqlalchemy import select

    from app.core import rbac
    from app.modules.admin.models import Branch
    from app.modules.customers.models import Customer, CustomerCategory

    mentah = _baca(isi)

    cabang_per_kode = {
        c.code: c for c in sesi.execute(select(Branch)).scalars().all()
    }
    kategori_per_nama = {
        k.name.strip().lower(): k
        for k in sesi.execute(select(CustomerCategory)).scalars().all()
    }
    cid_terpakai = set(sesi.execute(select(Customer.cid)).scalars().all())

    hasil = HasilPeriksa()
    cid_di_berkas: set[str] = set()

    # Nomor baris dihitung dari 2: baris 1 adalah judul kolom, dan orang yang
    # membetulkan berkasnya membacanya di Excel, bukan di indeks nol.
    for urut, satu in enumerate(mentah, start=2):
        baris = BarisImpor(nomor=urut, data={})
        try:
            baris.data = _rakit(
                satu, cabang_per_kode, kategori_per_nama, aktor, rbac
            )
            cid = baris.data.get("cid") or ""
            if cid and cid in cid_terpakai:
                raise ValueError(
                    f"CID '{cid}' sudah dipakai pelanggan yang ada; baris dilewati"
                )
            if cid and cid in cid_di_berkas:
                raise ValueError(f"CID '{cid}' muncul dua kali di berkas ini")
            if cid:
                cid_di_berkas.add(cid)
        except ValueError as galat:
            baris.galat = str(galat)
        hasil.baris.append(baris)

    return hasil


def _rakit(satu: dict, cabang_per_kode, kategori_per_nama, aktor, rbac) -> dict:
    nama = (satu.get("nama") or "").strip()
    if not nama:
        raise ValueError("kolom nama kosong")

    kode_cabang = (satu.get("cabang") or "").strip()
    cabang = cabang_per_kode.get(kode_cabang)
    if cabang is None:
        raise ValueError(
            f"kode cabang '{kode_cabang}' tidak dikenal"
            if kode_cabang
            else "kolom cabang kosong"
        )
    if aktor is not None and not rbac.is_cross_branch(aktor):
        # Diperiksa di sini, bukan hanya di `buat_pelanggan`, supaya barisnya
        # muncul di pratinjau sebagai baris bergalat — bukan meledak di
        # tengah penulisan setelah pengguna menekan Terapkan.
        if rbac._branch_of(aktor) != cabang.id:
            raise ValueError(
                f"cabang '{kode_cabang}' bukan cabang Anda"
            )

    data = {
        "name": nama,
        "branch_id": cabang.id,
        "cid": (satu.get("cid") or "").strip() or None,
        "alias": (satu.get("alias") or "").strip() or None,
        "install_address": (satu.get("alamat_instalasi") or "").strip() or None,
        "npwp_number": (satu.get("npwp") or "").strip() or None,
        "joined_at": _tanggal(satu.get("bergabung", ""), "bergabung"),
    }

    alamat_tagihan = (satu.get("alamat_tagihan") or "").strip()
    if alamat_tagihan:
        data["billing_same_as_install"] = False
        data["billing_address"] = alamat_tagihan

    for kolom_csv, kolom_data in (
        ("tipe", "customer_type"),
        ("tier", "tier"),
        ("status", "status"),
        ("mode_invoice", "invoice_mode"),
        ("tipe_pembayaran", "payment_type"),
    ):
        nilai = (satu.get(kolom_csv) or "").strip()
        if nilai:
            data[kolom_data] = nilai

    nama_kategori = (satu.get("kategori") or "").strip()
    if nama_kategori:
        kategori = kategori_per_nama.get(nama_kategori.lower())
        if kategori is None:
            raise ValueError(f"kategori customer '{nama_kategori}' tidak dikenal")
        data["category_id"] = kategori.id

    kontak = {
        "name": (satu.get("kontak_nama") or "").strip(),
        "phone": (satu.get("kontak_telepon") or "").strip() or None,
        "email": (satu.get("kontak_email") or "").strip() or None,
    }
    if kontak["name"]:
        data["_kontak"] = kontak
    elif kontak["phone"] or kontak["email"]:
        raise ValueError("kontak_telepon/kontak_email diisi tapi kontak_nama kosong")

    return data


def terapkan(sesi, aktor, hasil: HasilPeriksa) -> int:
    """Menulis baris yang sah. Mengembalikan jumlah pelanggan yang dibuat.

    Satu transaksi: bila ada baris yang gagal ditulis, tidak ada satu pun
    yang tertulis. Impor setengah jadi lebih sulit dibersihkan daripada impor
    yang gagal total — pemakainya tidak tahu di baris mana ia harus
    melanjutkan.
    """
    from app.core.errors import GalatDomain as _GalatDomain
    from app.modules.customers import service
    from app.modules.customers.models import CustomerContact

    dibuat = 0
    for baris in hasil.sah:
        data = dict(baris.data)
        kontak = data.pop("_kontak", None)
        try:
            pelanggan = service.buat_pelanggan(sesi, aktor, data)
        except _GalatDomain as galat:
            sesi.rollback()
            raise ImporTidakSah(
                "berkas",
                f"Baris {baris.nomor} gagal ditulis: {galat}. "
                "Tidak ada satu baris pun yang disimpan.",
            ) from galat

        if kontak:
            sesi.add(
                CustomerContact(
                    customer_id=pelanggan.id,
                    name=kontak["name"],
                    phone=kontak["phone"],
                    email=kontak["email"],
                    role="pic_utama",
                    is_primary=True,
                )
            )
            sesi.flush()
        dibuat += 1

    return dibuat
