from datetime import date
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import Money, TimestampMixin, enum_check

TIPE_PELANGGAN: tuple[str, ...] = ("corporate", "sme", "personal")
TIER_PELANGGAN: tuple[str, ...] = ("regular", "premium")
SUMBER_PELANGGAN: tuple[str, ...] = (
    "referral",
    "marketing",
    "walk_in",
    "tender",
    "lainnya",
)
STATUS_PELANGGAN: tuple[str, ...] = ("pending", "active", "suspend", "terminasi")
MODE_INVOICE: tuple[str, ...] = ("gabungan", "terpisah")
TIPE_PEMBAYARAN: tuple[str, ...] = ("postpaid", "prepaid")
PERAN_KONTAK: tuple[str, ...] = ("pic_utama", "billing", "teknis")
JENIS_DOKUMEN: tuple[str, ...] = ("ktp", "npwp", "kontrak", "bast", "lainnya")


class CustomerCategory(Base, TimestampMixin):
    __tablename__ = "customer_category"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


# Kolom yang di-OR-kan di satu query pencarian. Melewatkan satu saja membuat
# Postgres kembali memindai seluruh tabel: bitmap OR hanya terbentuk kalau
# SETIAP cabangnya punya index.
def _trigram(nama: str, tabel: str, kolom: str) -> Index:
    """Index GIN trigram untuk `ILIKE '%kata%'`.

    Pola berawalan `%` tidak bisa dilayani index btree sama sekali. `pg_trgm`
    berstatus *trusted* sejak PostgreSQL 13, jadi pemilik basis data bisa
    memasangnya sendiri tanpa hak superuser.
    """
    return Index(
        nama,
        kolom,
        postgresql_using="gin",
        postgresql_ops={kolom: "gin_trgm_ops"},
    )


class Customer(Base, TimestampMixin):
    __tablename__ = "customer"
    __table_args__ = (
        _trigram("ix_customer_name_trgm", "customer", "name"),
        _trigram("ix_customer_cid_trgm", "customer", "cid"),
        _trigram("ix_customer_alias_trgm", "customer", "alias"),
        _trigram("ix_customer_alamat_trgm", "customer", "install_address"),
        enum_check("ck_customer_status", "status", STATUS_PELANGGAN),
        enum_check("ck_customer_mode_invoice", "invoice_mode", MODE_INVOICE),
        enum_check("ck_customer_tipe", "customer_type", TIPE_PELANGGAN),
        enum_check("ck_customer_tipe_bayar", "payment_type", TIPE_PEMBAYARAN),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cid: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    alias: Mapped[str | None] = mapped_column(String(80))
    branch_id: Mapped[int] = mapped_column(
        ForeignKey("branch.id"), nullable=False, index=True
    )
    customer_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default="corporate"
    )
    tier: Mapped[str] = mapped_column(String(20), nullable=False, default="regular")
    category_id: Mapped[int | None] = mapped_column(ForeignKey("customer_category.id"))
    source: Mapped[str | None] = mapped_column(String(20))
    sales_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))

    install_address: Mapped[str | None] = mapped_column(Text)
    # Koordinat memakai NUMERIC, bukan FLOAT: presisinya pasti, dan titik
    # instalasi yang bergeser beberapa meter karena pembulatan biner adalah
    # kunjungan teknisi ke alamat yang salah.
    install_lat: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    install_lng: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    billing_same_as_install: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    billing_address: Mapped[str | None] = mapped_column(Text)

    ktp_number: Mapped[str | None] = mapped_column(String(32))
    npwp_number: Mapped[str | None] = mapped_column(String(32))

    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending", index=True
    )
    status_note: Mapped[str | None] = mapped_column(Text)

    invoice_mode: Mapped[str] = mapped_column(
        String(20), nullable=False, default="gabungan"
    )
    payment_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default="postpaid"
    )
    credit_limit: Mapped[Decimal | None] = mapped_column(Money)
    ppn_exempt: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # Kosong berarti ikut termin global di billing_setting.
    payment_term_days: Mapped[int | None] = mapped_column(Integer)

    joined_at: Mapped[date | None] = mapped_column(Date)
    activated_at: Mapped[date | None] = mapped_column(Date)
    terminated_at: Mapped[date | None] = mapped_column(Date)


class CustomerContact(Base, TimestampMixin):
    """Kontak pelanggan. Tepat satu boleh bertanda `is_primary`.

    Ditegakkan unique index parsial, bukan hanya kode service: dua permintaan
    bersamaan yang sama-sama menandai kontak utama akan lolos pemeriksaan
    aplikasi dan menghasilkan dua PIC utama yang tampil bergantian di layar.
    """

    __tablename__ = "customer_contact"
    __table_args__ = (
        Index(
            "uq_kontak_utama_per_pelanggan",
            "customer_id",
            unique=True,
            postgresql_where=text("is_primary"),
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    job_title: Mapped[str | None] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(20), nullable=False, default="pic_utama")
    phone: Mapped[str | None] = mapped_column(String(40))
    email: Mapped[str | None] = mapped_column(String(160))
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class CustomerDocument(Base, TimestampMixin):
    """Dokumen pelanggan.

    `branch_id` sengaja disalin dari pelanggan, bukan dibaca lewat join saat
    unduhan: rute unduhan memeriksanya dengan `rbac.assert_branch_access`, dan
    pemeriksaan hak akses tidak boleh bergantung pada join yang bisa lupa
    ditulis.
    """

    __tablename__ = "customer_document"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id", ondelete="CASCADE"), nullable=False, index=True
    )
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    doc_type: Mapped[str] = mapped_column(String(20), nullable=False, default="lainnya")
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    path: Mapped[str] = mapped_column(String(500), nullable=False)
    size: Mapped[int] = mapped_column(Integer, nullable=False)
    mime: Mapped[str] = mapped_column(String(80), nullable=False)
    uploaded_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))


class CustomerNote(Base, TimestampMixin):
    __tablename__ = "customer_note"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id", ondelete="CASCADE"), nullable=False, index=True
    )
    body: Mapped[str] = mapped_column(Text, nullable=False)
    author_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
