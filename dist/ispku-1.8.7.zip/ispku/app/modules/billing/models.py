from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core import waktu
from app.core.db import Base
from app.core.models import Money, TimestampMixin, enum_check

STATUS_INVOICE: tuple[str, ...] = (
    "draft",
    "issued",
    "partial",
    "paid",
    "overdue",
    "void",
)
SUMBER_ITEM: tuple[str, ...] = ("langganan", "addon", "cicilan", "manual")
METODE_BAYAR: tuple[str, ...] = ("transfer", "tunai")
STATUS_RUN: tuple[str, ...] = ("berjalan", "selesai", "gagal")


class BankAccount(Base, TimestampMixin):
    __tablename__ = "bank_account"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bank_name: Mapped[str] = mapped_column(String(80), nullable=False)
    account_number: Mapped[str] = mapped_column(String(40), nullable=False)
    account_holder: Mapped[str] = mapped_column(String(120), nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=99)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class Invoice(Base, TimestampMixin):
    """Satu tagihan untuk satu pelanggan pada satu periode.

    `number` dan `seq_no` kosong selama status `draft`: nomor hanya diberikan
    saat diterbitkan (spesifikasi §6), supaya draft yang dibatalkan tidak
    menghabiskan nomor dan membuat deret berlubang.
    """

    __tablename__ = "invoice"
    __table_args__ = (
        # Satu invoice per pelanggan per periode per langganan. Inilah yang
        # membuat batch idempoten: pengulangan periode yang sama ditolak basis
        # data, bukan hanya oleh pemeriksaan aplikasi yang bisa balapan
        # antar-worker.
        #
        # `coalesce(subscription_id, 0)` dipakai karena mode gabungan
        # meninggalkan kolom itu kosong, dan di Postgres dua NULL tidak pernah
        # dianggap kembar — tanpa coalesce, justru mode gabungan yang lolos
        # dari penjagaan ini. Mode terpisah memang menghasilkan beberapa
        # invoice untuk pelanggan dan periode yang sama, satu per langganan.
        #
        # Invoice pembetulan dikecualikan (ia memang invoice kedua untuk
        # periode yang sama dan menunjuk invoice asalnya), begitu pula invoice
        # yang di-void supaya periodenya bisa diterbitkan ulang.
        # Nomor invoice dicari dengan `ILIKE '%...%'` di dua halaman; pola
        # berawalan `%` tidak bisa dilayani index btree sama sekali.
        Index(
            "ix_invoice_number_trgm",
            "number",
            postgresql_using="gin",
            postgresql_ops={"number": "gin_trgm_ops"},
        ),
        enum_check("ck_invoice_status", "status", STATUS_INVOICE),
        Index(
            "uq_invoice_pelanggan_periode",
            text("customer_id"),
            text("period_start"),
            text("coalesce(subscription_id, 0)"),
            unique=True,
            postgresql_where=text("corrects_invoice_id IS NULL AND status <> 'void'"),
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    number: Mapped[str | None] = mapped_column(String(60), unique=True)
    seq_no: Mapped[int | None] = mapped_column(Integer)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id"), nullable=False, index=True
    )
    branch_id: Mapped[int] = mapped_column(
        ForeignKey("branch.id"), nullable=False, index=True
    )
    # Terindeks karena penjaga hapus langganan menghitung pemakainya lewat
    # kolom ini; tanpa indeks, satu penekanan tombol Hapus Layanan adalah
    # sequential scan atas tabel terbesar di aplikasi.
    subscription_id: Mapped[int | None] = mapped_column(
        ForeignKey("subscription.id"), index=True
    )

    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    issued_at: Mapped[date | None] = mapped_column(Date)
    due_at: Mapped[date | None] = mapped_column(Date)

    subtotal: Mapped[Decimal] = mapped_column(Money, nullable=False)
    discount_total: Mapped[Decimal] = mapped_column(Money, nullable=False)
    # Tarif disalin saat terbit; perubahan tarif kemudian tidak boleh mengubah
    # invoice lama (spesifikasi §7).
    ppn_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False)
    ppn_amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    total: Mapped[Decimal] = mapped_column(Money, nullable=False)

    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="draft", index=True
    )
    note: Mapped[str | None] = mapped_column(Text)
    void_reason: Mapped[str | None] = mapped_column(Text)
    corrects_invoice_id: Mapped[int | None] = mapped_column(ForeignKey("invoice.id"))
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))

    @property
    def status_efektif(self) -> str:
        """Status yang berlaku hari ini, dihitung — tidak disimpan.

        Dipakai templat supaya halaman tetap benar di antara dua kali jalannya
        `flask billing-harian`, dan tetap benar di pemasangan yang lupa
        menjadwalkannya sama sekali. Yang menyimpan hanya pekerjaan terjadwal:
        permintaan baca tidak boleh menulis.
        """
        from app.modules.billing.service import status_efektif as hitung

        return hitung(self.status, self.due_at, waktu.hari_ini())


class InvoiceItem(Base, TimestampMixin):
    __tablename__ = "invoice_item"
    __table_args__ = (enum_check("ck_invoice_item_sumber", "source", SUMBER_ITEM),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(
        ForeignKey("invoice.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subscription_id: Mapped[int | None] = mapped_column(
        ForeignKey("subscription.id"), index=True
    )
    source: Mapped[str] = mapped_column(String(20), nullable=False, default="langganan")
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    subdescription: Mapped[str | None] = mapped_column(String(255))
    period_start: Mapped[date | None] = mapped_column(Date)
    period_end: Mapped[date | None] = mapped_column(Date)
    qty: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    unit_price: Mapped[Decimal] = mapped_column(Money, nullable=False)
    discount: Mapped[Decimal] = mapped_column(Money, nullable=False, default=Decimal("0"))
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    is_prorated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class Payment(Base, TimestampMixin):
    __tablename__ = "payment"
    __table_args__ = (
        Index(
            "ix_payment_reference_trgm",
            "reference",
            postgresql_using="gin",
            postgresql_ops={"reference": "gin_trgm_ops"},
        ),
        enum_check("ck_payment_metode", "method", METODE_BAYAR),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(
        ForeignKey("invoice.id", ondelete="CASCADE"), nullable=False, index=True
    )
    paid_at: Mapped[date] = mapped_column(Date, nullable=False)
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    method: Mapped[str] = mapped_column(String(20), nullable=False, default="transfer")
    bank_account_id: Mapped[int | None] = mapped_column(ForeignKey("bank_account.id"))
    reference: Mapped[str | None] = mapped_column(String(120))
    proof_path: Mapped[str | None] = mapped_column(String(500))
    recorded_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    note: Mapped[str | None] = mapped_column(Text)


class InvoiceRun(Base, TimestampMixin):
    """Satu kali penerbitan batch beserta ringkasan kegagalannya.

    Batch tidak berhenti total saat satu pelanggan gagal: kegagalannya dicatat
    di `error_summary` dan sisanya tetap diproses (spesifikasi §10).
    """

    __tablename__ = "invoice_run"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    created_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="berjalan")
    error_summary: Mapped[list | None] = mapped_column(JSONB)


class InvoiceReminder(Base, TimestampMixin):
    """Jejak pengingat yang sudah pernah diantre untuk satu invoice.

    Tanpa tabel ini, cron yang dijalankan dua kali sehari mengantre pengingat
    dua kali sehari — dan pelanggan mengira ditagih dua kali. Batasan uniknya
    yang menegakkan, bukan pemeriksaan aplikasi yang bisa balapan antar-worker.

    `queued_at`, bukan `sent_at`: yang terjadi di sini adalah masuk antrean.
    Pengirimannya milik `flask mail-flush`, dan bisa gagal berkali-kali
    sesudahnya tanpa membuat baris ini bohong.
    """

    __tablename__ = "invoice_reminder"
    __table_args__ = (
        UniqueConstraint(
            "invoice_id", "offset_hari", name="uq_pengingat_invoice_offset"
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(
        ForeignKey("invoice.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # Negatif berarti sebelum jatuh tempo, positif sesudahnya. Nol tidak pernah
    # dipakai: hari jatuh tempo itu sendiri belum terlambat.
    offset_hari: Mapped[int] = mapped_column(Integer, nullable=False)
    queued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
