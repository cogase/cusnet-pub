"""Pengingat tagihan otomatis.

Yang mengirim tetap `flask mail-flush` seperti seluruh email lain di aplikasi
ini; modul ini hanya memutuskan **siapa** dan **kapan**, lalu menaruhnya di
`mail_outbox`. Pemisahan itu bukan gaya: kegagalan SMTP tidak boleh
menggagalkan pekerjaan terjadwal, dan percobaan ulang sudah jadi milik
`mail-flush`.

Dua aturan yang menopang seluruh berkas ini:

- **Tidak pernah dua kali.** Setiap pengingat yang diantre mencatat barisnya di
  `invoice_reminder`, dan batasan uniknya yang menegakkan — bukan pemeriksaan
  aplikasi yang bisa balapan antar-worker atau antar-cron.
- **Mati secara bawaan.** `reminder_offsets` kosong berarti modul ini tidak
  menyentuh apa pun. Pemasangan baru tidak boleh diam-diam mulai mengirimi
  pelanggan email.
"""

from datetime import date

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app.core.mail import antre
from app.core.money import format_rupiah, to_money
from app.core import templat_email, waktu
from app.modules.billing.models import Invoice, InvoiceReminder, Payment
from app.modules.customers.models import Customer, CustomerContact
from app.modules.settings import service as setting_service

# Status yang masih pantas ditagih. `draft` belum pernah sampai ke pelanggan,
# `paid` sudah selesai, `void` dibatalkan.
STATUS_DIINGATKAN: tuple[str, ...] = ("issued", "partial", "overdue")

SUBJEK_BAWAAN = "Pengingat tagihan {nomor} — {perusahaan}"
ISI_BAWAAN = (
    "<p>Yth. {pelanggan},</p>"
    "<p>Kami mengingatkan tagihan bernomor <strong>{nomor}</strong> "
    "dengan sisa <strong>{sisa}</strong>, jatuh tempo {jatuh_tempo}.</p>"
    "<p>Terima kasih.</p>"
)


def offsets(setting) -> list[int]:
    """Daftar offset hari yang berlaku. Kosong berarti fiturnya mati."""
    teks = (setting.reminder_offsets or "").strip()
    if not teks:
        return []
    return [int(p.strip()) for p in teks.split(",") if p.strip()]


def _sisa_per_invoice(sesi):
    return (
        select(Payment.invoice_id, func.sum(Payment.amount).label("dibayar"))
        .group_by(Payment.invoice_id)
        .subquery()
    )


def _kandidat(sesi, hari_ini: date, daftar_offset: list[int]):
    """Invoice yang jatuh tempo tepat `offset` hari dari hari ini.

    Dihitung dari sisi tanggal jatuh tempo (`due_at == hari_ini - offset`),
    bukan dengan mengambil semua invoice lalu menyaring di Python: pemasangan
    dengan puluhan ribu invoice tidak boleh menarik seluruh tabel tiap pagi.
    """
    dibayar = _sisa_per_invoice(sesi)
    query = (
        select(Invoice, Customer, func.coalesce(dibayar.c.dibayar, 0))
        .join(Customer, Invoice.customer_id == Customer.id)
        .join(dibayar, dibayar.c.invoice_id == Invoice.id, isouter=True)
        .where(
            Invoice.status.in_(STATUS_DIINGATKAN),
            Invoice.due_at.is_not(None),
            Invoice.due_at.in_(
                [hari_ini - _hari(offset) for offset in daftar_offset]
            ),
        )
        .order_by(Invoice.id)
    )
    # Sengaja TIDAK di-`rbac.scoped`: pekerjaan terjadwal berjalan sebagai
    # `rbac.SISTEM` yang memang lintas cabang, dan pengingat yang hanya
    # mengenai satu cabang adalah pengingat yang diam-diam tidak lengkap.
    return sesi.execute(query).all()


def _hari(offset: int):
    from datetime import timedelta

    return timedelta(days=offset)


def _email_tagihan(sesi, pelanggan_id: int) -> str | None:
    """Alamat tujuan: kontak berperan `billing` dulu, baru kontak mana pun."""
    kontak = list(
        sesi.execute(
            select(CustomerContact)
            .where(
                CustomerContact.customer_id == pelanggan_id,
                CustomerContact.email.is_not(None),
                CustomerContact.email != "",
            )
            .order_by(CustomerContact.is_primary.desc(), CustomerContact.id)
        ).scalars().all()
    )
    if not kontak:
        return None
    billing = next((k for k in kontak if k.role == "billing"), None)
    return (billing or kontak[0]).email


def _sudah_diantre(sesi, invoice_id: int, offset: int) -> bool:
    return sesi.execute(
        select(func.count())
        .select_from(InvoiceReminder)
        .where(
            InvoiceReminder.invoice_id == invoice_id,
            InvoiceReminder.offset_hari == offset,
        )
    ).scalar_one() > 0


def jalankan(sesi, aktor, hari_ini: date | None = None) -> dict:
    """Mengantre seluruh pengingat yang jatuh hari ini.

    Mengembalikan hitungan, bukan hanya jumlah yang berhasil: operator yang
    mengira semua pelanggan sudah diingatkan tidak akan pernah tahu bahwa
    sepuluh di antaranya tidak punya alamat email.
    """
    setting = setting_service.ambil_setting(sesi)
    daftar_offset = offsets(setting)
    hasil = {"diantre": 0, "tanpa_email": 0, "sudah_pernah": 0, "balapan": 0}
    if not daftar_offset:
        return hasil

    # Diperiksa sekali di depan, sebelum satu pun email diantre, dan TIDAK
    # menunggu ada kandidat. Kalau `render` yang menemukan templat rusak di
    # tengah loop, pekerjaan harian mati dengan sebagian pelanggan sudah
    # diingatkan dan sebagian belum — dan mengulangnya tidak memperbaiki apa
    # pun, karena yang terlanjur sudah tercatat di `invoice_reminder`.
    for medan in ("reminder_subject_template", "reminder_body_template"):
        templat_email.periksa(medan, getattr(setting, medan))

    sekarang = hari_ini or waktu.hari_ini()

    for invoice, pelanggan, dibayar in _kandidat(sesi, sekarang, daftar_offset):
        sisa = to_money(invoice.total - to_money(dibayar))
        if sisa <= 0:
            # Statusnya bisa saja belum sempat diperbarui; yang menentukan
            # boleh-tidaknya menagih adalah sisanya, bukan lencananya.
            continue

        offset = (sekarang - invoice.due_at).days
        if offset not in daftar_offset:
            continue
        if _sudah_diantre(sesi, invoice.id, offset):
            hasil["sudah_pernah"] += 1
            continue

        tujuan = _email_tagihan(sesi, pelanggan.id)
        if tujuan is None:
            hasil["tanpa_email"] += 1
            continue

        isian = {
            "nomor": invoice.number or "-",
            "pelanggan": pelanggan.name,
            "perusahaan": setting.company_name or "ISPKU",
            "total": format_rupiah(invoice.total),
            "sisa": format_rupiah(sisa),
            "jatuh_tempo": invoice.due_at.strftime("%d %b %Y"),
            # Selalu positif; kalimat templatnya yang membedakan arah.
            "hari": abs(offset),
            "versi": "",
        }
        # Dibungkus savepoint: `_sudah_diantre` menutup jendela balapan hampir
        # selalu, tapi tidak selalu — dua cron yang menyalip bisa sama-sama
        # lolos pemeriksaan itu sebelum salah satunya menulis. Tanpa savepoint,
        # `IntegrityError` dari baris kedua meracuni transaksi dan seluruh sisa
        # pelanggan hari itu tidak jadi diingatkan, diam-diam.
        try:
            with sesi.begin_nested():
                antre(
                    sesi,
                    tujuan,
                    templat_email.render(
                        setting.reminder_subject_template or SUBJEK_BAWAAN, isian
                    ),
                    templat_email.render(
                        setting.reminder_body_template or ISI_BAWAAN, isian
                    ),
                    # Tanpa lampiran dengan sengaja: invoicenya sudah dikirim
                    # beserta PDF saat terbit, dan merender ulang PDF untuk tiap
                    # pelanggan tiap pengingat tidak menambah apa pun.
                    attachment_path=None,
                    invoice_id=invoice.id,
                )
                sesi.add(InvoiceReminder(invoice_id=invoice.id, offset_hari=offset))
        except IntegrityError:
            # Proses lain sudah mengantrekannya lebih dulu. Bukan kegagalan,
            # tapi tetap dihitung: angka yang tidak nol berarti ada dua jadwal
            # yang saling menyalip, dan itu pantas diketahui operator.
            hasil["balapan"] += 1
            continue

        hasil["diantre"] += 1

    return hasil
