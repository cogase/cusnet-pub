"""Laporan billing: tunggakan, pendapatan, dan rekap periode.

Seluruh angka melewati `rbac.scoped` lewat `Invoice.branch_id`. Ekspor CSV
memakai angka yang sama persis dengan yang tampil di layar — laporan yang
berbeda antara layar dan berkas unduhan adalah laporan yang tidak bisa
dipakai berdebat dengan siapa pun.
"""

import io
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select

from app.core import csv_aman, rbac, waktu
from app.core.money import to_money
from app.modules.admin.models import Branch
from app.modules.billing.models import Invoice, Payment
from app.modules.customers.models import Customer

# Nama bulan singkat. `strftime('%b')` mengikuti locale peladen, dan peladen
# pelanggan hampir pasti C/en_US — label "Sep" bercampur "Agu" adalah bug yang
# baru terlihat setelah dipasang.
BULAN_SINGKAT = (
    "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
    "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
)

# Ember umur piutang dalam hari sejak jatuh tempo.
EMBER_UMUR = (
    ("0-30", 0, 30),
    ("31-60", 31, 60),
    ("61-90", 61, 90),
    (">90", 91, 100000),
)


def _dibayar_per_invoice(sesi):
    return (
        select(Payment.invoice_id, func.sum(Payment.amount).label("dibayar"))
        .group_by(Payment.invoice_id)
        .subquery()
    )


def tunggakan(sesi, user, hari_ini: date | None = None) -> list[dict]:
    """Invoice yang belum lunas beserta umur piutangnya."""
    sekarang = hari_ini or waktu.hari_ini()
    dibayar = _dibayar_per_invoice(sesi)

    query = (
        select(Invoice, Customer, func.coalesce(dibayar.c.dibayar, 0))
        .join(Customer, Invoice.customer_id == Customer.id)
        .join(dibayar, dibayar.c.invoice_id == Invoice.id, isouter=True)
        .where(Invoice.status.in_(("issued", "partial", "overdue")))
        .order_by(Invoice.due_at)
    )
    query = rbac.scoped(query, user, Invoice)

    hasil = []
    for invoice, pelanggan, jumlah_dibayar in sesi.execute(query).all():
        sisa = to_money(invoice.total - to_money(jumlah_dibayar))
        if sisa <= 0:
            continue
        umur = (sekarang - invoice.due_at).days if invoice.due_at else 0
        hasil.append(
            {
                "invoice": invoice,
                "pelanggan": pelanggan,
                "dibayar": to_money(jumlah_dibayar),
                "sisa": sisa,
                "umur_hari": max(umur, 0),
                "ember": _ember(max(umur, 0)),
            }
        )
    return hasil


def _ember(umur: int) -> str:
    for nama, mulai, akhir in EMBER_UMUR:
        if mulai <= umur <= akhir:
            return nama
    return ">90"


def ringkasan_umur(baris: list[dict]) -> dict[str, Decimal]:
    """Menjumlahkan sisa tagihan per ember umur piutang."""
    hasil = {nama: Decimal("0.00") for nama, _, _ in EMBER_UMUR}
    for satu in baris:
        hasil[satu["ember"]] += satu["sisa"]
    return hasil


def pendapatan_per_cabang(
    sesi, user, mulai: date, akhir: date
) -> list[dict]:
    """Pembayaran yang benar-benar masuk per cabang dalam rentang tanggal.

    Dihitung dari pembayaran, bukan dari invoice terbit: invoice yang terbit
    tapi belum dibayar bukan pendapatan.
    """
    query = (
        select(
            Branch,
            func.coalesce(func.sum(Payment.amount), 0),
            func.count(Payment.id),
        )
        .select_from(Payment)
        .join(Invoice, Payment.invoice_id == Invoice.id)
        .join(Branch, Invoice.branch_id == Branch.id)
        .where(Payment.paid_at >= mulai, Payment.paid_at <= akhir)
        .group_by(Branch.id)
        .order_by(Branch.code)
    )
    query = rbac.scoped(query, user, Invoice)

    return [
        {"cabang": cabang, "jumlah": to_money(jumlah), "transaksi": transaksi}
        for cabang, jumlah, transaksi in sesi.execute(query).all()
    ]


def rekap_periode(sesi, user, period_start: date) -> dict:
    """Ringkasan satu periode tagihan: terbit, dibayar, dan sisanya."""
    dibayar = _dibayar_per_invoice(sesi)

    query = (
        select(
            func.count(Invoice.id),
            func.coalesce(func.sum(Invoice.total), 0),
            func.coalesce(func.sum(dibayar.c.dibayar), 0),
        )
        .select_from(Invoice)
        .join(dibayar, dibayar.c.invoice_id == Invoice.id, isouter=True)
        .where(Invoice.period_start == period_start, Invoice.status != "void")
    )
    query = rbac.scoped(query, user, Invoice)

    jumlah, tagihan, terbayar = sesi.execute(query).one()
    return {
        "period_start": period_start,
        "jumlah_invoice": jumlah,
        "total_tagihan": to_money(tagihan),
        "total_dibayar": to_money(terbayar),
        "sisa": to_money(to_money(tagihan) - to_money(terbayar)),
    }


def _mundur_bulan(acuan: date, mundur: int) -> date:
    """Tanggal 1 dari `mundur` bulan sebelum bulan `acuan`."""
    bulan = acuan.month - mundur
    tahun = acuan.year
    while bulan <= 0:
        bulan += 12
        tahun -= 1
    return date(tahun, bulan, 1)


def tren_pendapatan(sesi, user, hari_ini: date | None = None, bulan: int = 6) -> list[dict]:
    """Tagihan dan pembayaran per periode untuk `bulan` bulan terakhir.

    Dua deret dengan sumbu waktu yang sama tetapi arti berbeda:

    - **Tagihan** dikelompokkan menurut `period_start` invoice — bulan yang
      ditagih.
    - **Dibayar** dikelompokkan menurut `period_start` invoice yang dibayar,
      bukan tanggal uangnya masuk. Pembayaran Oktober atas tagihan September
      masuk ke September.

    Dipilih begitu supaya kedua deret bisa dibandingkan langsung: "berapa dari
    tagihan bulan ini yang sudah tertagih". Mengelompokkan pembayaran menurut
    `paid_at` menjawab pertanyaan lain (arus kas), dan mencampur keduanya di
    satu grafik menghasilkan angka yang tidak berarti apa-apa.
    """
    sekarang = hari_ini or waktu.hari_ini()
    periode = [_mundur_bulan(sekarang, i) for i in range(bulan - 1, -1, -1)]
    awal = periode[0]

    tagih_query = (
        select(
            Invoice.period_start,
            func.coalesce(func.sum(Invoice.total), 0),
        )
        .where(Invoice.period_start >= awal, Invoice.status != "void")
        .group_by(Invoice.period_start)
    )
    tagih_query = rbac.scoped(tagih_query, user, Invoice)
    tagihan = {
        baris_periode: to_money(jumlah)
        for baris_periode, jumlah in sesi.execute(tagih_query).all()
    }

    bayar_query = (
        select(
            Invoice.period_start,
            func.coalesce(func.sum(Payment.amount), 0),
        )
        .select_from(Payment)
        .join(Invoice, Payment.invoice_id == Invoice.id)
        .where(Invoice.period_start >= awal, Invoice.status != "void")
        .group_by(Invoice.period_start)
    )
    bayar_query = rbac.scoped(bayar_query, user, Invoice)
    dibayar = {
        baris_periode: to_money(jumlah)
        for baris_periode, jumlah in sesi.execute(bayar_query).all()
    }

    return [
        {
            "period_start": p,
            "bulan": f"{BULAN_SINGKAT[p.month - 1]} {p.year % 100:02d}",
            # Bulan tanpa invoice dirender nol, bukan dilewati: garis yang
            # melompati bulan kosong membuat penurunan tampak seperti
            # kenaikan datar.
            "tagihan": tagihan.get(p, Decimal("0.00")),
            "dibayar": dibayar.get(p, Decimal("0.00")),
        }
        for p in periode
    ]


def csv_tunggakan(baris: list[dict]) -> str:
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(
        ["Nomor", "CID", "Customer", "Jatuh Tempo", "Total", "Dibayar", "Sisa", "Umur (hari)", "Ember"]
    )
    for satu in baris:
        invoice = satu["invoice"]
        tulis.writerow(
            [
                invoice.number or f"Draft #{invoice.id}",
                satu["pelanggan"].cid,
                satu["pelanggan"].name,
                invoice.due_at.isoformat() if invoice.due_at else "",
                invoice.total,
                satu["dibayar"],
                satu["sisa"],
                satu["umur_hari"],
                satu["ember"],
            ]
        )
    return keluaran.getvalue()


def csv_pendapatan(baris: list[dict]) -> str:
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(["Kode Cabang", "Cabang", "Jumlah Transaksi", "Total Pendapatan"])
    for satu in baris:
        tulis.writerow(
            [
                satu["cabang"].code,
                satu["cabang"].name,
                satu["transaksi"],
                satu["jumlah"],
            ]
        )
    return keluaran.getvalue()
