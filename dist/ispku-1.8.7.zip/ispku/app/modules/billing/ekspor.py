"""Ekspor CSV Daftar Invoice.

Angka ditulis polos (`5550000.00`, bukan `Rp 5.550.000`): berkas ini
dijumlahkan di Excel, tidak dibaca sebagai kalimat. Tanggal ditulis ISO
supaya urut sebagai teks maupun tanggal.

Status lewat-tempo dihitung di sini, tidak diambil mentah dari basis data.
Halaman daftar memanggil `segarkan_status`, yang **menyunting** invoice;
permintaan unduhan tidak boleh menyunting 20.000 baris sebagai efek samping.
Akibatnya berkas bisa menyebut Overdue selagi basis data masih menyimpan
`issued` — itu keadaan yang benar, dan kebalikannya (berkas yang menyebut
Unpaid untuk tagihan yang jelas telat) jauh lebih buruk.
"""

import io
from datetime import date

from app.core import csv_aman, waktu
from app.core.money import to_money
from app.modules.billing.forms import LABEL_STATUS_INVOICE

JUDUL = (
    "No. Invoice",
    "CID",
    "Customer",
    "Cabang",
    "Periode Mulai",
    "Periode Akhir",
    "Tanggal Terbit",
    "Jatuh Tempo",
    "Subtotal",
    "Diskon",
    "PPN",
    "Total",
    "Dibayar",
    "Sisa",
    "Status",
)


def status_terbaca(invoice, hari_ini: date) -> str:
    """Status invoice sebagaimana layar menampilkannya, tanpa menyimpannya.

    Aturannya tidak ditulis ulang di sini: dipinjam dari
    `service.status_efektif`, satu-satunya tempat aturan lewat-tempo hidup.
    Dua salinan aturan yang sama akan berbeda pada suatu hari, dan yang
    berbeda adalah tagihan.
    """
    from app.modules.billing.service import status_efektif

    status = status_efektif(invoice.status, invoice.due_at, hari_ini)
    return LABEL_STATUS_INVOICE.get(status, status)


def _tanggal(nilai) -> str:
    return nilai.isoformat() if nilai else ""


def csv_invoice(baris, hari_ini: date | None = None) -> str:
    """`baris` adalah `(Invoice, Customer, Branch, dibayar)` dari query daftar."""
    sekarang = hari_ini or waktu.hari_ini()
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(JUDUL)
    for invoice, pelanggan, cabang, dibayar in baris:
        dibayar = to_money(dibayar or 0)
        tulis.writerow(
            [
                invoice.number or f"Draft #{invoice.id}",
                pelanggan.cid,
                pelanggan.name,
                f"{cabang.code} — {cabang.name}" if cabang else "",
                _tanggal(invoice.period_start),
                _tanggal(invoice.period_end),
                _tanggal(invoice.issued_at),
                _tanggal(invoice.due_at),
                invoice.subtotal,
                invoice.discount_total,
                invoice.ppn_amount,
                invoice.total,
                dibayar,
                to_money(invoice.total - dibayar),
                status_terbaca(invoice, sekarang),
            ]
        )
    return keluaran.getvalue()
