"""Pencatatan pembayaran invoice.

Status invoice **dihitung** dari jumlah pembayaran, tidak pernah disetel
manual (spesifikasi §7). Itu sebabnya setiap jalur yang menambah atau
membatalkan pembayaran memanggil `perbarui_status` di transaksi yang sama —
status yang disetel tangan pasti melenceng dari uang yang benar-benar masuk.
"""

from datetime import date
from decimal import Decimal

from sqlalchemy import func, select

from app.core import audit, files, rbac, waktu
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.pagination import Page, paginate_rows
from app.modules.billing.models import METODE_BAYAR, BankAccount, Invoice, Payment
from app.modules.billing.service import ambil_invoice
from app.modules.customers.models import Customer

KOLOM_PEMBAYARAN = (
    "invoice_id",
    "paid_at",
    "amount",
    "method",
    "bank_account_id",
    "reference",
    "note",
)


class KelebihanBayar(GalatDomain):
    """Jumlah pembayaran melampaui sisa tagihan."""


class InvoiceBelumTerbit(GalatDomain):
    """Invoice draft atau void tidak bisa dibayar."""


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def total_dibayar(sesi, invoice_id: int) -> Decimal:
    nilai = sesi.execute(
        select(func.coalesce(func.sum(Payment.amount), 0)).where(
            Payment.invoice_id == invoice_id
        )
    ).scalar_one()
    return to_money(nilai)


def sisa_tagihan(sesi, invoice) -> Decimal:
    return to_money(invoice.total - total_dibayar(sesi, invoice.id))


def perbarui_status(sesi, invoice, hari_ini: date | None = None) -> Invoice:
    """Menghitung ulang status invoice dari pembayarannya.

    Invoice `draft` dan `void` tidak ikut dihitung: keduanya bukan tagihan
    yang berjalan.
    """
    if invoice.status in ("draft", "void"):
        return invoice

    dibayar = total_dibayar(sesi, invoice.id)
    sekarang = hari_ini or waktu.hari_ini()

    if dibayar >= invoice.total and invoice.total > 0:
        invoice.status = "paid"
    elif dibayar > 0:
        invoice.status = "partial"
    elif invoice.due_at is not None and sekarang > invoice.due_at:
        invoice.status = "overdue"
    else:
        invoice.status = "issued"

    sesi.flush()
    return invoice


def daftar(sesi, user, invoice_id: int) -> list[Payment]:
    ambil_invoice(sesi, user, invoice_id)
    return list(
        sesi.execute(
            select(Payment)
            .where(Payment.invoice_id == invoice_id)
            .order_by(Payment.paid_at, Payment.id)
        ).scalars().all()
    )


def ambil(sesi, user, payment_id: int) -> Payment:
    pembayaran = sesi.get(Payment, payment_id)
    if pembayaran is None:
        raise TidakDitemukan("Pembayaran tidak ditemukan.")
    ambil_invoice(sesi, user, pembayaran.invoice_id)
    return pembayaran


def catat(
    sesi,
    aktor,
    invoice_id: int,
    data: dict,
    berkas=None,
    nama_berkas: str | None = None,
    upload_dir: str | None = None,
) -> Payment:
    invoice = ambil_invoice(sesi, aktor, invoice_id)
    if invoice.status in ("draft", "void"):
        raise InvoiceBelumTerbit(
            "invoice_id",
            "Invoice ini belum diterbitkan atau sudah dibatalkan, jadi belum "
            "bisa menerima pembayaran.",
        )

    jumlah = to_money(data.get("amount") or 0)
    if jumlah <= 0:
        raise GalatDomain("amount", "Jumlah pembayaran harus lebih dari nol.")

    sisa = sisa_tagihan(sesi, invoice)
    if jumlah > sisa:
        raise KelebihanBayar(
            "amount",
            f"Jumlah melebihi sisa tagihan. Sisa yang belum dibayar {sisa}.",
        )

    metode = data.get("method") or "transfer"
    if metode not in METODE_BAYAR:
        raise GalatDomain(
            "method", "Metode pembayaran harus salah satu dari: " + ", ".join(METODE_BAYAR)
        )

    rekening_id = data.get("bank_account_id") or None
    if rekening_id and sesi.get(BankAccount, rekening_id) is None:
        raise GalatDomain("bank_account_id", "Rekening tujuan tidak ditemukan.")

    pembayaran = Payment(
        invoice_id=invoice.id,
        paid_at=data.get("paid_at") or waktu.hari_ini(),
        amount=jumlah,
        method=metode,
        bank_account_id=rekening_id,
        reference=data.get("reference"),
        note=data.get("note"),
        recorded_by_user_id=aktor.id if aktor else None,
    )

    if berkas is not None and upload_dir:
        tersimpan = files.simpan(berkas, nama_berkas or "bukti", upload_dir)
        pembayaran.proof_path = tersimpan.path

    sesi.add(pembayaran)
    sesi.flush()

    perbarui_status(sesi, invoice)

    audit.record(
        sesi, "create", "payment", pembayaran.id,
        after=_potret(pembayaran, KOLOM_PEMBAYARAN), aktor=aktor,
    )
    return pembayaran


def batalkan(sesi, aktor, payment_id: int) -> int:
    """Membatalkan satu pembayaran dan menghitung ulang status invoicenya."""
    pembayaran = ambil(sesi, aktor, payment_id)
    invoice = ambil_invoice(sesi, aktor, pembayaran.invoice_id)

    audit.record(
        sesi, "delete", "payment", pembayaran.id,
        before=_potret(pembayaran, KOLOM_PEMBAYARAN), aktor=aktor,
    )
    sesi.delete(pembayaran)
    sesi.flush()

    perbarui_status(sesi, invoice)
    return invoice.id


def daftar_semua(
    sesi,
    user,
    page: int = 1,
    per_page: int = 10,
    q: str | None = None,
    metode: str | None = None,
) -> Page:
    query = (
        select(Payment, Invoice, Customer)
        .join(Invoice, Payment.invoice_id == Invoice.id)
        .join(Customer, Invoice.customer_id == Customer.id)
        .order_by(Payment.id.desc())
    )
    query = rbac.scoped(query, user, Invoice)

    if q:
        pola = f"%{q.strip()}%"
        query = query.where(
            func.coalesce(Invoice.number, "").ilike(pola)
            | Customer.name.ilike(pola)
            | func.coalesce(Payment.reference, "").ilike(pola)
        )
    if metode:
        query = query.where(Payment.method == metode)

    return paginate_rows(sesi, query, page, per_page)


def ringkasan_pembayaran(sesi, user) -> dict:
    """Total dibayar dan outstanding untuk kartu di halaman Billing."""
    dibayar = sesi.execute(
        rbac.scoped(
            select(func.coalesce(func.sum(Payment.amount), 0))
            .select_from(Payment)
            .join(Invoice, Payment.invoice_id == Invoice.id)
            .where(Invoice.status != "void"),
            user,
            Invoice,
        )
    ).scalar_one()
    tagihan = sesi.execute(
        rbac.scoped(
            select(func.coalesce(func.sum(Invoice.total), 0)).where(
                Invoice.status.notin_(("void", "draft"))
            ),
            user,
            Invoice,
        )
    ).scalar_one()

    return {
        "total_dibayar": to_money(dibayar),
        "outstanding": to_money(max(to_money(tagihan) - to_money(dibayar), Decimal("0"))),
    }
