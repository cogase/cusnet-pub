from app.core import waktu
from app.core.forms import FormDasar
from flask_wtf.file import FileAllowed, FileField
from wtforms import DateField, IntegerField, StringField, TextAreaField
from wtforms.validators import DataRequired, InputRequired, Length, NumberRange, Optional

from app.modules.customers.forms import PilihanIndonesia
from app.modules.services.forms import DesimalIndonesia

LABEL_STATUS_INVOICE = {
    "draft": "Draft",
    "issued": "Unpaid",
    "partial": "Partial",
    "paid": "Paid",
    "overdue": "Overdue",
    "void": "Cancelled",
}
NADA_STATUS_INVOICE = {
    "draft": "netral",
    "issued": "peringatan",
    "partial": "jingga",
    "paid": "sukses",
    "overdue": "bahaya",
    "void": "netral",
}


class GenerateInvoiceForm(FormDasar):
    # Dulu isian teks bebas berbentuk YYYY-MM. Mengetik periode berarti salah
    # ketik satu digit menerbitkan seluruh tagihan ke bulan yang salah, dan
    # itu bukan kesalahan yang murah. Pilihannya diisi rute.
    period = PilihanIndonesia(
        "Periode", validators=[DataRequired(message="Periode wajib dipilih.")]
    )
    branch_id = PilihanIndonesia("Cabang", coerce=int)


def pilihan_periode(hari_ini=None, mundur: int = 6, maju: int = 1) -> list[tuple[str, str]]:
    """Daftar periode `YYYY-MM` beserta labelnya, terbaru di atas.

    Rentangnya sengaja pendek: menerbitkan tagihan untuk periode dua tahun lalu
    hampir selalu salah pencet, dan daftar sepanjang itu justru menyembunyikan
    bulan yang benar.
    """
    from datetime import date

    from app.modules.billing.reports import BULAN_SINGKAT

    acuan = hari_ini or waktu.hari_ini()
    hasil = []
    for geser in range(maju, -mundur - 1, -1):
        bulan = acuan.month + geser
        tahun = acuan.year + (bulan - 1) // 12
        bulan = (bulan - 1) % 12 + 1
        kunci = f"{tahun:04d}-{bulan:02d}"
        label = f"{BULAN_SINGKAT[bulan - 1]} {tahun}"
        if geser == 0:
            label += " (bulan ini)"
        hasil.append((kunci, label))
    return hasil


class AlasanForm(FormDasar):
    """Dipakai void dan pembetulan — keduanya wajib beralasan."""

    alasan = TextAreaField(
        "Alasan",
        validators=[DataRequired(message="Alasan wajib diisi."), Length(max=500)],
    )


class ItemManualForm(FormDasar):
    description = StringField(
        "Deskripsi",
        validators=[DataRequired(message="Deskripsi wajib diisi."), Length(max=255)],
    )
    qty = IntegerField(
        "Jumlah",
        default=1,
        validators=[
            InputRequired(message="Jumlah wajib diisi."),
            NumberRange(min=1, message="Jumlah minimal 1."),
        ],
    )
    unit_price = DesimalIndonesia(
        "Harga Satuan",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Harga satuan wajib diisi."),
            NumberRange(min=0, message="Harga satuan tidak boleh negatif."),
        ],
    )
    subdescription = StringField(
        "Keterangan", validators=[Optional(), Length(max=255)]
    )


class PembayaranForm(FormDasar):
    paid_at = DateField("Tanggal Bayar", validators=[Optional()])
    amount = DesimalIndonesia(
        "Jumlah",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Jumlah wajib diisi."),
            NumberRange(min=0, message="Jumlah tidak boleh negatif."),
        ],
    )
    method = PilihanIndonesia(
        "Metode", choices=[("transfer", "Transfer"), ("tunai", "Tunai")]
    )
    bank_account_id = PilihanIndonesia("Rekening Tujuan", coerce=int)
    reference = StringField("No. Referensi", validators=[Optional(), Length(max=120)])
    note = StringField("Catatan", validators=[Optional(), Length(max=200)])
    bukti = FileField(
        "Bukti Bayar",
        validators=[
            Optional(),
            FileAllowed(
                ["jpg", "jpeg", "png", "pdf"],
                message="Hanya JPG, PNG, dan PDF yang diterima.",
            ),
        ],
    )
