"""Penerbitan invoice: menyiapkan draft, memberi nomor, dan batch periode."""

import calendar
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import case, func, select, update

from app.core import audit, rbac, waktu
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.numbering import NumberingError, next_invoice_number
from app.core.pagination import Page, paginate_rows
from app.modules.billing import engine
from app.modules.billing.models import Invoice, InvoiceItem, InvoiceRun
from app.modules.customers.models import Customer
from app.modules.customers.subscriptions import (
    Subscription,
    SubscriptionAddon,
    SubscriptionInstallment,
)
from app.modules.services.models import ServicePlan
from app.modules.settings import service as setting_service

KOLOM_INVOICE = (
    "number",
    "seq_no",
    "customer_id",
    "branch_id",
    "subscription_id",
    "period_start",
    "period_end",
    "issued_at",
    "due_at",
    "subtotal",
    "discount_total",
    "ppn_rate",
    "ppn_amount",
    "total",
    "status",
)

# Langganan berstatus ini ikut ditagih. `terminasi` tidak ditagih untuk periode
# setelah tanggal berhentinya — mesinnya yang memutuskan lewat `hari_aktif`,
# jadi langganan terminasi tetap ikut diambil supaya periode terakhirnya
# terprorata dengan benar.
STATUS_DITAGIH = ("active", "suspend", "terminasi")

# Sama dengan `subscription_service.HARGA_MAKS`: batas kolom `Money`. Nilai di
# atasnya ditolak basis data, dan galatnya sampai ke layar sebagai 500 tanpa
# keterangan apa pun.
HARGA_MAKS_ITEM = Decimal("999999999999.99")


class InvoiceSudahAda(GalatDomain):
    """Pelanggan ini sudah punya invoice untuk periode tersebut."""


class TidakAdaYangDitagih(GalatDomain):
    """Tidak ada satu pun baris yang bisa ditagih pada periode ini."""


class InvoiceTidakBisaDiterbitkan(GalatDomain):
    """Invoice tidak berstatus draft."""


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def periode_bulan(teks: str) -> tuple[date, date]:
    """`"2026-09"` menjadi (1 September 2026, 30 September 2026)."""
    try:
        tahun, bulan = teks.strip().split("-")
        tahun, bulan = int(tahun), int(bulan)
        mulai = date(tahun, bulan, 1)
    except (ValueError, AttributeError) as galat:
        raise GalatDomain(
            "period", f"Periode '{teks}' tidak sah. Pakai bentuk YYYY-MM, mis. 2026-09."
        ) from galat

    akhir = date(tahun, bulan, calendar.monthrange(tahun, bulan)[1])
    return mulai, akhir


def _langganan_ditagih(sesi, customer_id: int, period_end: date) -> list:
    """Langganan pelanggan yang berpotensi ditagih di periode ini."""
    return list(
        sesi.execute(
            select(Subscription, ServicePlan)
            .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
            .where(
                Subscription.customer_id == customer_id,
                Subscription.status.in_(STATUS_DITAGIH),
            )
            .order_by(Subscription.id)
        ).all()
    )


def _baris_untuk_langganan(sesi, langganan, paket, period_start, period_end) -> list:
    """Baris langganan, addon aktifnya, dan satu termin cicilannya."""
    baris = []

    utama = engine.baris_langganan(langganan, paket, period_start, period_end)
    if utama is None:
        # Langganan yang tidak aktif sehari pun juga tidak menyeret addon dan
        # cicilannya: menagih biaya tambahan atas layanan yang sudah berhenti
        # adalah tagihan yang tidak bisa dijelaskan ke pelanggan.
        return baris
    baris.append(utama)

    addon = sesi.execute(
        select(SubscriptionAddon).where(
            SubscriptionAddon.subscription_id == langganan.id,
            SubscriptionAddon.is_active.is_(True),
        )
    ).scalars().all()
    baris.extend(engine.baris_addon(satu, period_start, period_end) for satu in addon)

    cicilan = sesi.execute(
        select(SubscriptionInstallment).where(
            SubscriptionInstallment.subscription_id == langganan.id
        )
    ).scalars().first()
    if cicilan is not None:
        termin = engine.baris_cicilan(cicilan, period_start, period_end)
        if termin is not None:
            baris.append(termin)

    return baris


def _tarif_ppn(sesi, pelanggan, paket_paket: list) -> Decimal:
    """Tarif PPN yang berlaku: dari paket bila ditetapkan, kalau tidak dari setting.

    Bila satu invoice memuat paket bertarif berbeda, tarif tertinggi yang
    dipakai — invoice hanya punya satu kolom tarif, dan menagih kurang dari
    yang seharusnya adalah selisih yang harus ditombok sendiri saat pelaporan
    pajak. Kasus ini dicatat di catatan lanjutan supaya bisa diperbaiki dengan
    pajak per baris kalau memang dibutuhkan.
    """
    if pelanggan.ppn_exempt:
        return Decimal("0.00")

    tarif_paket = [p.ppn_rate for p in paket_paket if p.ppn_rate is not None]
    if tarif_paket:
        return max(tarif_paket)
    return setting_service.ambil_setting(sesi).ppn_rate


def _invoice_sudah_ada(sesi, customer_id: int, period_start: date) -> bool:
    ada = sesi.execute(
        select(Invoice.id).where(
            Invoice.customer_id == customer_id,
            Invoice.period_start == period_start,
            Invoice.corrects_invoice_id.is_(None),
            Invoice.status != "void",
        )
    ).scalars().first()
    return ada is not None


def _simpan_invoice(sesi, aktor, pelanggan, hasil, period_start, period_end,
                    subscription_id=None) -> Invoice:
    invoice = Invoice(
        customer_id=pelanggan.id,
        branch_id=pelanggan.branch_id,
        subscription_id=subscription_id,
        period_start=period_start,
        period_end=period_end,
        subtotal=hasil.subtotal,
        discount_total=hasil.discount_total,
        ppn_rate=hasil.ppn_rate,
        ppn_amount=hasil.ppn_amount,
        total=hasil.total,
        status="draft",
        created_by_user_id=aktor.id if aktor else None,
    )
    sesi.add(invoice)
    sesi.flush()

    for baris in hasil.items:
        sesi.add(
            InvoiceItem(
                invoice_id=invoice.id,
                subscription_id=baris.subscription_id,
                source=baris.source,
                description=baris.description,
                subdescription=baris.subdescription,
                period_start=baris.period_start,
                period_end=baris.period_end,
                qty=baris.qty,
                unit_price=baris.unit_price,
                discount=baris.discount,
                amount=baris.amount,
                is_prorated=baris.is_prorated,
            )
        )
    sesi.flush()

    audit.record(
        sesi, "create", "invoice", invoice.id,
        after=_potret(invoice, KOLOM_INVOICE), aktor=aktor,
    )
    return invoice


def siapkan_invoice(
    sesi, aktor, customer_id: int, period_start: date, period_end: date
) -> Invoice:
    """Menyiapkan satu invoice draft gabungan untuk pelanggan ini.

    Draft belum bernomor dan belum menggeser cicilan; keduanya terjadi di
    `terbitkan`, supaya draft yang dibatalkan tidak menghabiskan nomor invoice
    maupun memajukan termin cicilan pelanggan.
    """
    from app.modules.customers.service import ambil_pelanggan

    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)
    if _invoice_sudah_ada(sesi, pelanggan.id, period_start):
        raise InvoiceSudahAda(
            "period_start",
            f"Pelanggan {pelanggan.cid} sudah punya invoice untuk periode ini.",
        )

    baris = []
    paket_paket = []
    for langganan, paket in _langganan_ditagih(sesi, pelanggan.id, period_end):
        baris_langganan = _baris_untuk_langganan(
            sesi, langganan, paket, period_start, period_end
        )
        if baris_langganan:
            paket_paket.append(paket)
        baris.extend(baris_langganan)

    if not baris:
        raise TidakAdaYangDitagih(
            "period_start",
            f"Pelanggan {pelanggan.cid} tidak punya layanan yang ditagih pada "
            "periode ini.",
        )

    hasil = engine.rakit_invoice(
        baris, _tarif_ppn(sesi, pelanggan, paket_paket), pelanggan.ppn_exempt
    )
    return _simpan_invoice(sesi, aktor, pelanggan, hasil, period_start, period_end)


def siapkan_invoice_terpisah(
    sesi, aktor, customer_id: int, period_start: date, period_end: date
) -> list[Invoice]:
    """Satu invoice per langganan, untuk pelanggan bermode `terpisah`."""
    from app.modules.customers.service import ambil_pelanggan

    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)
    hasil_invoice = []

    for langganan, paket in _langganan_ditagih(sesi, pelanggan.id, period_end):
        sudah = sesi.execute(
            select(Invoice.id).where(
                Invoice.customer_id == pelanggan.id,
                Invoice.subscription_id == langganan.id,
                Invoice.period_start == period_start,
                Invoice.status != "void",
            )
        ).scalars().first()
        if sudah is not None:
            continue

        baris = _baris_untuk_langganan(
            sesi, langganan, paket, period_start, period_end
        )
        if not baris:
            continue

        hasil = engine.rakit_invoice(
            baris, _tarif_ppn(sesi, pelanggan, [paket]), pelanggan.ppn_exempt
        )
        hasil_invoice.append(
            _simpan_invoice(
                sesi, aktor, pelanggan, hasil, period_start, period_end,
                subscription_id=langganan.id,
            )
        )

    if not hasil_invoice:
        raise TidakAdaYangDitagih(
            "period_start",
            f"Pelanggan {pelanggan.cid} tidak punya layanan yang ditagih pada "
            "periode ini.",
        )
    return hasil_invoice


def ambil_invoice(sesi, user, invoice_id: int) -> Invoice:
    invoice = sesi.get(Invoice, invoice_id)
    if invoice is None:
        raise TidakDitemukan("Invoice tidak ditemukan.")
    rbac.assert_branch_access(user, invoice.branch_id)
    return invoice


def _termin_bayar(sesi, pelanggan) -> int:
    if pelanggan.payment_term_days is not None:
        return pelanggan.payment_term_days
    return setting_service.ambil_setting(sesi).payment_term_days


def terbitkan(sesi, aktor, invoice_id: int, hari_ini: date | None = None) -> Invoice:
    """Memberi nomor, tanggal terbit, dan jatuh tempo — lalu memajukan cicilan.

    Nomor diambil dari penghitung ber-advisory-lock, bukan `SEQUENCE`: sequence
    melompat saat transaksi dibatalkan, dan lompatan nomor invoice adalah
    pertanyaan yang harus dijawab ke auditor pajak.
    """
    from app.modules.customers.service import ambil_pelanggan

    invoice = ambil_invoice(sesi, aktor, invoice_id)
    if invoice.status != "draft":
        raise InvoiceTidakBisaDiterbitkan(
            "status", "Hanya invoice berstatus draft yang bisa diterbitkan."
        )

    pelanggan = ambil_pelanggan(sesi, aktor, invoice.customer_id)
    setting = setting_service.ambil_setting(sesi)
    terbit = hari_ini or waktu.hari_ini()

    sebelum = _potret(invoice, KOLOM_INVOICE)

    nomor, seq_global = next_invoice_number(
        sesi, setting.invoice_pattern, terbit.year, terbit.month
    )
    invoice.number = nomor
    invoice.seq_no = seq_global
    invoice.issued_at = terbit
    invoice.due_at = terbit + timedelta(days=_termin_bayar(sesi, pelanggan))
    invoice.status = "issued"

    # Cicilan baru dimajukan sekarang, bukan saat draft dibuat: draft yang
    # dibatalkan tidak boleh menggeser termin pelanggan.
    for item in sesi.execute(
        select(InvoiceItem).where(
            InvoiceItem.invoice_id == invoice.id, InvoiceItem.source == "cicilan"
        )
    ).scalars().all():
        cicilan = sesi.execute(
            select(SubscriptionInstallment).where(
                SubscriptionInstallment.subscription_id == item.subscription_id
            )
        ).scalars().first()
        if cicilan is not None and cicilan.terms_billed < cicilan.terms:
            cicilan.terms_billed += 1

    sesi.flush()

    audit.record(
        sesi, "issue", "invoice", invoice.id,
        before=sebelum, after=_potret(invoice, KOLOM_INVOICE), aktor=aktor,
    )
    return invoice


def _tanggal_terbit(sesi, period_start: date) -> date:
    """Tanggal terbit batch: `invoice_day` pada bulan periodenya.

    Dibatasi 1–28 di `setting_service.ubah_setting`, jadi tanggalnya selalu
    ada di bulan mana pun. Nilai di luar batas yang terlanjur tersimpan
    sebelum batas itu ada dijepit di sini, bukan dibiarkan melempar
    `ValueError` di tengah batch seribu pelanggan.
    """
    hari = setting_service.ambil_setting(sesi).invoice_day or 1
    return date(period_start.year, period_start.month, min(max(hari, 1), 28))


def _pelanggan_untuk_batch(sesi, aktor, branch_id: int | None) -> list[Customer]:
    query = (
        select(Customer)
        .where(
            Customer.id.in_(
                select(Subscription.customer_id).where(
                    Subscription.status.in_(STATUS_DITAGIH)
                )
            )
        )
        .order_by(Customer.id)
    )
    if branch_id:
        query = query.where(Customer.branch_id == branch_id)
    query = rbac.scoped(query, aktor, Customer)
    return list(sesi.execute(query).scalars().all())


def jalankan_batch(
    sesi,
    aktor,
    period_start: date,
    period_end: date,
    branch_id: int | None = None,
    hari_ini: date | None = None,
) -> InvoiceRun:
    """Menerbitkan invoice satu periode untuk seluruh pelanggan yang berlangganan.

    Batch tidak berhenti total saat satu pelanggan gagal: kegagalannya dicatat
    di `error_summary` dan sisanya tetap diproses (spesifikasi §10). Satu
    pelanggan dengan data rusak tidak boleh membatalkan penerbitan seribu
    pelanggan lain.

    Tanggal terbitnya `invoice_day` pada bulan periodenya, bukan hari batch
    dijalankan: tagihan periode September selalu terbit dan jatuh tempo di
    tanggal yang sama, entah batchnya ditekan 28 Agustus, 1 September, atau 9
    September karena operator sedang cuti. `hari_ini` yang dioper eksplisit
    tetap menang — data contoh dan uji yang memakainya tidak berubah artinya.
    """
    terbit = hari_ini or _tanggal_terbit(sesi, period_start)

    run = InvoiceRun(
        period_start=period_start,
        period_end=period_end,
        actor_user_id=aktor.id if aktor else None,
        status="berjalan",
    )
    sesi.add(run)
    sesi.flush()

    dibuat = 0
    gagal = []

    for pelanggan in _pelanggan_untuk_batch(sesi, aktor, branch_id):
        try:
            if pelanggan.invoice_mode == "terpisah":
                invoice_baru = siapkan_invoice_terpisah(
                    sesi, aktor, pelanggan.id, period_start, period_end
                )
            else:
                invoice_baru = [
                    siapkan_invoice(
                        sesi, aktor, pelanggan.id, period_start, period_end
                    )
                ]

            for invoice in invoice_baru:
                terbitkan(sesi, aktor, invoice.id, hari_ini=terbit)
                dibuat += 1
        except (InvoiceSudahAda, TidakAdaYangDitagih):
            # Bukan kegagalan: pelanggan ini memang tidak punya yang ditagih,
            # atau invoicenya sudah terbit di jalannya batch sebelumnya.
            continue
        except (GalatDomain, NumberingError, ValueError) as galat:
            gagal.append(
                {
                    "customer_id": pelanggan.id,
                    "cid": pelanggan.cid,
                    "pesan": str(galat),
                }
            )

    run.created_count = dibuat
    run.failed_count = len(gagal)
    run.error_summary = gagal or None
    run.status = "selesai"
    sesi.flush()

    audit.record(
        sesi, "run", "invoice_run", run.id,
        after={
            "period_start": period_start,
            "period_end": period_end,
            "created_count": dibuat,
            "failed_count": len(gagal),
        },
        aktor=aktor,
    )
    return run


def _saring_invoice(query, user, q, status, customer_id):
    """Seluruh filter Daftar Invoice, termasuk penyaringan cabang.

    Dipakai halaman daftar DAN ekspor. Query kedua yang ditulis khusus untuk
    ekspor adalah tempat kebocoran antar cabang berikutnya — dan berkas yang
    bocor jauh lebih mudah tersebar daripada satu halaman.
    """
    query = rbac.scoped(query, user, Invoice)

    if q:
        pola = f"%{q.strip()}%"
        query = query.where(
            func.coalesce(Invoice.number, "").ilike(pola)
            | Customer.name.ilike(pola)
            | Customer.cid.ilike(pola)
        )
    if status:
        # Disaring lewat status yang DIHITUNG, bukan kolom tersimpan: yang
        # paling mungkin belum sempat disentuh pekerjaan terjadwal justru
        # invoice yang paling baru lewat tempo — dan itu yang paling dicari.
        query = query.where(ekspresi_status_efektif() == status)
    if customer_id:
        query = query.where(Invoice.customer_id == customer_id)

    return query


def daftar_invoice(
    sesi,
    user,
    page: int = 1,
    per_page: int = 10,
    q: str | None = None,
    status: str | None = None,
    customer_id: int | None = None,
) -> Page:
    """Daftar invoice beserta pelanggannya. Seluruh filter menempel di sini."""
    query = (
        select(Invoice, Customer)
        .join(Customer, Invoice.customer_id == Customer.id)
        .order_by(Invoice.id.desc())
    )
    query = _saring_invoice(query, user, q, status, customer_id)

    return paginate_rows(sesi, query, page, per_page)


BATAS_EKSPOR = 20_000


def ekspor_invoice(
    sesi,
    user,
    q: str | None = None,
    status: str | None = None,
    customer_id: int | None = None,
    hari_ini: date | None = None,
) -> tuple[str, bool]:
    """Invoice yang lolos filter sebagai CSV, beserta tanda terpotong.

    Tidak menyunting apa pun — lihat `ekspor.status_terbaca`. Kolom Dibayar
    memakai subkueri yang sama dengan laporan tunggakan, bukan penjumlahan
    kedua yang ditulis khusus di sini.
    """
    from app.modules.admin.models import Branch
    from app.modules.billing import ekspor as modul_ekspor
    from app.modules.billing.reports import _dibayar_per_invoice

    dibayar = _dibayar_per_invoice(sesi)
    query = (
        select(Invoice, Customer, Branch, func.coalesce(dibayar.c.dibayar, 0))
        .join(Customer, Invoice.customer_id == Customer.id)
        .join(Branch, Invoice.branch_id == Branch.id)
        .join(dibayar, dibayar.c.invoice_id == Invoice.id, isouter=True)
        .order_by(Invoice.id.desc())
    )
    query = _saring_invoice(query, user, q, status, customer_id)

    baris = sesi.execute(query.limit(BATAS_EKSPOR)).all()
    return (
        modul_ekspor.csv_invoice(baris, hari_ini),
        len(baris) >= BATAS_EKSPOR,
    )


def daftar_item(sesi, user, invoice_id: int) -> list[InvoiceItem]:
    ambil_invoice(sesi, user, invoice_id)
    return list(
        sesi.execute(
            select(InvoiceItem)
            .where(InvoiceItem.invoice_id == invoice_id)
            .order_by(InvoiceItem.id)
        ).scalars().all()
    )


class InvoiceTidakBisaDiubah(GalatDomain):
    """Invoice yang sudah terbit tidak boleh disunting."""


class AlasanWajib(GalatDomain):
    """Void dan pembetulan wajib menyebut alasannya."""


class InvoiceSudahDibayar(GalatDomain):
    """Invoice yang sudah punya pembayaran tidak bisa di-void."""


def _pastikan_draft(invoice) -> None:
    if invoice.status != "draft":
        raise InvoiceTidakBisaDiubah(
            "status",
            "Invoice yang sudah diterbitkan tidak bisa disunting. Buat invoice "
            "pembetulan kalau angkanya salah.",
        )


def hitung_ulang(sesi, invoice) -> Invoice:
    """Menjumlahkan ulang invoice dari baris-barisnya.

    Memakai `ppn_rate` yang sudah tersimpan di invoice, bukan tarif setting
    terbaru: tarif disalin saat terbit dan perubahan tarif kemudian tidak
    boleh mengubah invoice lama.
    """
    baris = sesi.execute(
        select(InvoiceItem).where(InvoiceItem.invoice_id == invoice.id)
    ).scalars().all()

    hasil = engine.rakit_invoice(
        [
            engine.BarisItem(
                source=item.source,
                description=item.description,
                unit_price=item.unit_price,
                amount=item.amount,
                qty=item.qty,
                discount=item.discount,
            )
            for item in baris
        ],
        ppn_rate=invoice.ppn_rate,
        ppn_exempt=invoice.ppn_rate == Decimal("0.00"),
    )

    invoice.subtotal = hasil.subtotal
    invoice.discount_total = hasil.discount_total
    invoice.ppn_amount = hasil.ppn_amount
    invoice.total = hasil.total
    sesi.flush()
    return invoice


def tambah_item_manual(sesi, aktor, invoice_id: int, data: dict) -> InvoiceItem:
    invoice = ambil_invoice(sesi, aktor, invoice_id)
    _pastikan_draft(invoice)

    qty = int(data.get("qty") or 1)
    if qty < 1:
        raise GalatDomain("qty", "Jumlah minimal 1.")

    # Ditegakkan di service, bukan hanya di `ItemManualForm`: impor, CLI, dan
    # uji menembus formulir sepenuhnya. Harga negatif yang lolos menghasilkan
    # invoice bertotal negatif — tidak bisa dibayar (pencatatan pembayaran
    # menolak nol dan negatif), tidak bisa ditagih, tetapi tetap terhitung di
    # laporan. Nol tetap boleh: baris bernilai nol dipakai sebagai keterangan.
    harga = to_money(data.get("unit_price") or 0)
    if harga < 0:
        raise GalatDomain("unit_price", "Harga satuan tidak boleh negatif.")
    if harga > HARGA_MAKS_ITEM:
        raise GalatDomain(
            "unit_price",
            "Harga satuan terlalu besar. Maksimum Rp 999.999.999.999,99.",
        )

    item = InvoiceItem(
        invoice_id=invoice.id,
        source="manual",
        description=(data.get("description") or "").strip() or "Penyesuaian",
        subdescription=data.get("subdescription"),
        qty=qty,
        unit_price=harga,
        discount=Decimal("0.00"),
        amount=to_money(harga * qty),
    )
    sesi.add(item)
    sesi.flush()
    hitung_ulang(sesi, invoice)

    audit.record(
        sesi, "create", "invoice_item", item.id,
        after={"invoice_id": invoice.id, "description": item.description,
               "amount": item.amount},
        aktor=aktor,
    )
    return item


def hapus_item(sesi, aktor, item_id: int) -> int:
    item = sesi.get(InvoiceItem, item_id)
    if item is None:
        raise TidakDitemukan("Baris invoice tidak ditemukan.")
    invoice = ambil_invoice(sesi, aktor, item.invoice_id)
    _pastikan_draft(invoice)

    audit.record(
        sesi, "delete", "invoice_item", item.id,
        before={"invoice_id": invoice.id, "description": item.description,
                "amount": item.amount},
        aktor=aktor,
    )
    sesi.delete(item)
    sesi.flush()
    hitung_ulang(sesi, invoice)
    return invoice.id


def _sudah_dibayar(sesi, invoice_id: int) -> bool:
    from app.modules.billing.models import Payment

    ada = sesi.execute(
        select(Payment.id).where(Payment.invoice_id == invoice_id)
    ).scalars().first()
    return ada is not None


def void(sesi, aktor, invoice_id: int, alasan: str) -> Invoice:
    """Membatalkan invoice. Wajib beralasan dan tercatat di audit.

    Invoice yang sudah punya pembayaran tidak bisa di-void sebelum
    pembayarannya dibatalkan (spesifikasi §7) — angka yang sudah masuk kas
    tidak boleh menggantung tanpa tagihan.
    """
    invoice = ambil_invoice(sesi, aktor, invoice_id)
    bersih = (alasan or "").strip()
    if not bersih:
        raise AlasanWajib("void_reason", "Alasan pembatalan wajib diisi.")
    if invoice.status == "void":
        raise InvoiceTidakBisaDiubah("status", "Invoice ini sudah dibatalkan.")
    if _sudah_dibayar(sesi, invoice.id):
        raise InvoiceSudahDibayar(
            "status",
            "Invoice ini sudah punya pembayaran. Batalkan pembayarannya lebih "
            "dulu sebelum membatalkan invoice.",
        )

    sebelum = _potret(invoice, KOLOM_INVOICE)
    invoice.status = "void"
    invoice.void_reason = bersih
    sesi.flush()

    audit.record(
        sesi, "void", "invoice", invoice.id,
        before=sebelum, after=_potret(invoice, KOLOM_INVOICE), aktor=aktor,
    )
    return invoice


def buat_pembetulan(sesi, aktor, invoice_id: int, alasan: str) -> Invoice:
    """Membuat invoice pengganti dan mem-void invoice asalnya.

    Invoice yang sudah diterbitkan tidak pernah disunting (spesifikasi §7);
    koreksi selalu berupa invoice baru yang menunjuk asalnya, supaya laporan
    dan riwayat pelanggan tetap bisa ditelusuri.
    """
    asal = ambil_invoice(sesi, aktor, invoice_id)
    bersih = (alasan or "").strip()
    if not bersih:
        raise AlasanWajib("void_reason", "Alasan pembetulan wajib diisi.")
    if asal.status == "void":
        raise InvoiceTidakBisaDiubah(
            "status", "Invoice yang sudah dibatalkan tidak bisa dibetulkan lagi."
        )

    pengganti = Invoice(
        customer_id=asal.customer_id,
        branch_id=asal.branch_id,
        subscription_id=asal.subscription_id,
        period_start=asal.period_start,
        period_end=asal.period_end,
        subtotal=asal.subtotal,
        discount_total=asal.discount_total,
        ppn_rate=asal.ppn_rate,
        ppn_amount=asal.ppn_amount,
        total=asal.total,
        status="draft",
        corrects_invoice_id=asal.id,
        note=f"Pembetulan atas {asal.number or 'draft'}: {bersih}",
        created_by_user_id=aktor.id if aktor else None,
    )
    sesi.add(pengganti)
    sesi.flush()

    for item in sesi.execute(
        select(InvoiceItem).where(InvoiceItem.invoice_id == asal.id)
    ).scalars().all():
        sesi.add(
            InvoiceItem(
                invoice_id=pengganti.id,
                subscription_id=item.subscription_id,
                source=item.source,
                description=item.description,
                subdescription=item.subdescription,
                period_start=item.period_start,
                period_end=item.period_end,
                qty=item.qty,
                unit_price=item.unit_price,
                discount=item.discount,
                amount=item.amount,
                is_prorated=item.is_prorated,
            )
        )
    sesi.flush()

    sebelum = _potret(asal, KOLOM_INVOICE)
    asal.status = "void"
    asal.void_reason = f"Diganti invoice pembetulan #{pengganti.id}: {bersih}"
    sesi.flush()

    audit.record(
        sesi, "void", "invoice", asal.id,
        before=sebelum, after=_potret(asal, KOLOM_INVOICE), aktor=aktor,
    )
    audit.record(
        sesi, "create", "invoice", pengganti.id,
        after=_potret(pengganti, KOLOM_INVOICE), aktor=aktor,
    )
    return pengganti


# Status yang ikut aturan lewat-tempo. Sisanya (`draft`, `partial`, `paid`,
# `void`) ditentukan hal lain dan tidak pernah disentuh perhitungan ini.
_STATUS_BERTENGGAT: tuple[str, ...] = ("issued", "overdue")


def status_efektif(status: str, due_at: date | None, hari_ini: date) -> str:
    """Status yang BERLAKU hari ini, tanpa menyentuh basis data.

    Satu-satunya tempat aturan lewat-tempo ditulis dalam Python. Halaman
    daftar, halaman detail, ekspor, dan pekerjaan terjadwal semuanya
    memakainya, supaya tidak ada dua tempat yang bisa menjawab berbeda untuk
    invoice yang sama.

    Hari jatuh tempo itu sendiri belum terlambat — baru sehari sesudahnya.
    """
    if status not in _STATUS_BERTENGGAT or due_at is None:
        return status
    return "overdue" if hari_ini > due_at else "issued"


def ekspresi_status_efektif(hari_ini: date | None = None):
    """Aturan yang sama sebagai ekspresi SQL, untuk menyaring dan menghitung.

    Menyaring `?status=overdue` lewat kolom tersimpan akan melewatkan invoice
    yang belum sempat disentuh pekerjaan terjadwal — dan yang paling mungkin
    terlewat justru yang paling baru lewat tempo.
    """
    sekarang = hari_ini or waktu.hari_ini()
    return case(
        (
            Invoice.status.in_(_STATUS_BERTENGGAT) & (Invoice.due_at.is_not(None)),
            case(
                (Invoice.due_at < sekarang, "overdue"),
                else_="issued",
            ),
        ),
        else_=Invoice.status,
    )


def segarkan_semua_status(sesi, hari_ini: date | None = None) -> int:
    """Menyimpan status lewat-tempo untuk seluruh invoice sekaligus.

    Dipanggil `flask billing-harian`, bukan halaman daftar: permintaan baca
    tidak boleh menulis. Dua arah dengan sengaja — tanggal jatuh tempo bisa
    disunting, dan invoice yang tenggatnya dimundurkan harus kembali `issued`.

    Mengembalikan jumlah baris yang benar-benar berubah, bukan jumlah yang
    diperiksa: angka yang selalu sama dengan jumlah invoice tidak memberi tahu
    apa pun.
    """
    sekarang = hari_ini or waktu.hari_ini()

    jadi_overdue = sesi.execute(
        update(Invoice)
        .where(
            Invoice.status == "issued",
            Invoice.due_at.is_not(None),
            Invoice.due_at < sekarang,
        )
        .values(status="overdue")
    ).rowcount
    jadi_issued = sesi.execute(
        update(Invoice)
        .where(
            Invoice.status == "overdue",
            Invoice.due_at.is_not(None),
            Invoice.due_at >= sekarang,
        )
        .values(status="issued")
    ).rowcount
    sesi.flush()
    return jadi_overdue + jadi_issued


def segarkan_status(sesi, invoice, hari_ini: date | None = None) -> Invoice:
    """Menandai invoice yang lewat jatuh tempo sebagai `overdue`.

    Status `partial` dan `paid` dihitung dari pembayaran, yang lahir di M2c.
    Hari jatuh tempo itu sendiri belum terlambat — baru sehari sesudahnya.
    """
    if invoice.status not in ("issued", "overdue") or invoice.due_at is None:
        return invoice

    sekarang = hari_ini or waktu.hari_ini()
    seharusnya = "overdue" if sekarang > invoice.due_at else "issued"
    if invoice.status != seharusnya:
        invoice.status = seharusnya
        sesi.flush()
    return invoice


def ringkasan_billing(sesi, user) -> dict:
    """Angka lima kartu di halaman Billing.

    Total Dibayar dan Outstanding bersumber pembayaran yang baru ada di M2c;
    dikembalikan nol dan ditandai di layar, bukan dikarang.
    """
    efektif = ekspresi_status_efektif()
    per_status = dict(
        sesi.execute(
            rbac.scoped(
                select(efektif, func.count(Invoice.id)).group_by(efektif),
                user,
                Invoice,
            )
        ).all()
    )
    total_tagihan = sesi.execute(
        rbac.scoped(
            select(func.coalesce(func.sum(Invoice.total), 0)).where(
                Invoice.status != "void"
            ),
            user,
            Invoice,
        )
    ).scalar_one()

    return {
        "per_status": per_status,
        "total_invoice": sum(per_status.values()),
        "total_tagihan": to_money(total_tagihan),
        "overdue": per_status.get("overdue", 0),
        "draft": per_status.get("draft", 0),
    }


def timeline_invoice(sesi, user, invoice_id: int) -> list:
    """Jejak audit satu invoice, terbaru dulu."""
    from app.modules.admin.models import AuditLog

    ambil_invoice(sesi, user, invoice_id)
    return list(
        sesi.execute(
            select(AuditLog)
            .where(
                AuditLog.entity_type == "invoice", AuditLog.entity_id == invoice_id
            )
            .order_by(AuditLog.id.desc())
            .limit(50)
        ).scalars().all()
    )


class EmailPelangganKosong(GalatDomain):
    """Pelanggan belum punya kontak beremail, jadi invoice tidak bisa dikirim."""


SUBJEK_BAWAAN = "Invoice {nomor} — {perusahaan}"
ISI_BAWAAN = (
    "<p>Yth. {pelanggan},</p>"
    "<p>Berikut tagihan Anda dengan nomor <strong>{nomor}</strong> "
    "sebesar <strong>{total}</strong>, jatuh tempo {jatuh_tempo}.</p>"
    "<p>Terima kasih.</p>"
)


def antre_email_invoice(
    sesi, aktor, invoice_id: int, versi: str = "", lampiran_path: str | None = None
) -> None:
    """Menaruh invoice ke antrean email.

    Tidak mengirim langsung: kegagalan SMTP tidak boleh menggagalkan apa pun
    di layar (spesifikasi §7), dan pengiriman tetap lewat `flask mail-flush`
    yang punya percobaan ulang.
    """
    from app.core.mail import antre
    from app.core.money import format_rupiah
    from app.modules.customers.service import ambil_pelanggan, daftar_kontak

    invoice = ambil_invoice(sesi, aktor, invoice_id)
    if invoice.status == "draft":
        raise GalatDomain(
            "status", "Terbitkan invoice ini lebih dulu sebelum mengirimkannya."
        )

    pelanggan = ambil_pelanggan(sesi, aktor, invoice.customer_id)
    kontak = [k for k in daftar_kontak(sesi, aktor, pelanggan.id) if k.email]
    if not kontak:
        raise EmailPelangganKosong(
            "email",
            f"Pelanggan {pelanggan.cid} belum punya kontak beremail. Tambahkan "
            "kontak lebih dulu di halaman customer.",
        )

    setting = setting_service.ambil_setting(sesi)
    isian = {
        "nomor": invoice.number or "-",
        "pelanggan": pelanggan.name,
        "perusahaan": setting.company_name or "ISPKU",
        "total": format_rupiah(invoice.total),
        "jatuh_tempo": invoice.due_at.strftime("%d %b %Y") if invoice.due_at else "-",
        "versi": versi,
    }

    from app.core import templat_email

    subjek = templat_email.render(setting.email_subject_template or SUBJEK_BAWAAN, isian)
    isi = templat_email.render(setting.email_body_template or ISI_BAWAAN, isian)

    tujuan = next((k for k in kontak if k.role == "billing"), kontak[0])
    antre(
        sesi,
        tujuan.email,
        subjek,
        isi,
        attachment_path=lampiran_path,
        invoice_id=invoice.id,
    )

    audit.record(
        sesi, "send", "invoice", invoice.id,
        after={
            "tujuan": tujuan.email,
            "nomor": invoice.number,
            "lampiran": bool(lampiran_path),
        },
        aktor=aktor,
    )
