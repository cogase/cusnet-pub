from datetime import datetime, timezone
from urllib.parse import urlsplit

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from app.core import keamanan
from app.core.auth import authenticate, login_user, logout_user
from app.core.db import db_session
from app.core.rbac import halaman_awal
from app.modules.auth.forms import LoginForm

bp = Blueprint("auth", __name__)

_KARAKTER_DIBUANG = "\t\r\n"


def _tujuan_aman(tujuan: str | None) -> str | None:
    """Hanya menerima path relatif di dalam aplikasi ini.

    Karakter kendali dibuang dan garis miring terbalik dinormalkan lebih dulu,
    karena peramban melakukan hal yang sama sebelum mem-parsing URL. Tanpa itu,
    bentuk seperti `/\\host` dan `/%09/host` lolos dari pemeriksaan tetapi tetap
    dibaca peramban sebagai alamat domain luar.
    """
    if not tujuan:
        return None

    bersih = "".join(huruf for huruf in tujuan if huruf not in _KARAKTER_DIBUANG)
    bersih = bersih.replace("\\", "/")

    if not bersih.startswith("/") or bersih.startswith("//"):
        return None

    pecah = urlsplit(bersih)
    if pecah.scheme or pecah.netloc:
        return None

    return bersih


@bp.route("/masuk", methods=["GET", "POST"])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        if keamanan.terlalu_sering(db_session, request.remote_addr):
            flash(
                "Terlalu banyak percobaan masuk dari alamat ini. "
                "Coba lagi dalam 15 menit.",
                "bahaya",
            )
            return render_template("auth/login.html", form=form)

        user = authenticate(db_session, form.identifier.data, form.password.data)
        if user is None:
            keamanan.catat_kegagalan(
                db_session, request.remote_addr, form.identifier.data
            )
            db_session.commit()
            flash("Username atau password salah.", "bahaya")
        else:
            keamanan.bersihkan_percobaan(db_session, request.remote_addr)
            login_user(user)
            session.permanent = bool(form.remember.data)
            user.last_login_at = datetime.now(timezone.utc)
            db_session.commit()
            return redirect(
                _tujuan_aman(request.args.get("next"))
                or url_for(halaman_awal(user))
            )

    return render_template("auth/login.html", form=form)


@bp.post("/keluar")
def logout():
    logout_user()
    return redirect(url_for("auth.login"))


@bp.get("/masuk/google")
def google():
    if not current_app.config["GOOGLE_OAUTH_CLIENT_ID"]:
        flash("Login Google belum dikonfigurasi. Hubungi administrator.", "peringatan")
        return redirect(url_for("auth.login"))

    flash(
        "Login Google sudah dikonfigurasi tetapi belum diaktifkan pada versi ini.",
        "peringatan",
    )
    return redirect(url_for("auth.login"))
