from app.core.forms import FormDasar
from wtforms import BooleanField, PasswordField, StringField
from wtforms.validators import DataRequired


class LoginForm(FormDasar):
    identifier = StringField(
        "Email / Username",
        validators=[DataRequired(message="Email atau username wajib diisi.")],
    )
    password = PasswordField(
        "Password",
        validators=[DataRequired(message="Password wajib diisi.")],
    )
    remember = BooleanField("Ingat saya")
