import re

from app.core.forms import FormDasar
from flask_wtf.file import FileAllowed, FileField
from wtforms import BooleanField, IntegerField, StringField, TextAreaField
from wtforms.validators import (
    DataRequired,
    Email,
    InputRequired,
    Length,
    NumberRange,
    Optional,
    Regexp,
)

from app.modules.services.forms import DesimalIndonesia

POLA_WARNA = re.compile(r"^#[0-9A-Fa-f]{6}$")


class PengaturanBillingForm(FormDasar):
    cid_prefix = StringField(
        "Awalan CID",
        validators=[DataRequired(message="Awalan CID wajib diisi."), Length(max=20)],
    )
    cid_pattern = StringField(
        "Pola CID",
        validators=[DataRequired(message="Pola CID wajib diisi."), Length(max=120)],
    )
    service_no_pattern = StringField(
        "Pola Nomor Layanan",
        validators=[
            DataRequired(message="Pola nomor layanan wajib diisi."),
            Length(max=120),
        ],
    )
    invoice_pattern = StringField(
        "Pola Nomor Invoice",
        validators=[
            DataRequired(message="Pola nomor invoice wajib diisi."),
            Length(max=120),
        ],
    )
    ppn_rate = DesimalIndonesia(
        "Tarif PPN (%)",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Tarif PPN wajib diisi."),
            NumberRange(min=0, max=100, message="Tarif PPN harus antara 0 dan 100."),
        ],
    )
    payment_term_days = IntegerField(
        "Jatuh Tempo Pembayaran (hari)",
        validators=[
            InputRequired(message="Jatuh tempo wajib diisi."),
            NumberRange(
                min=0, max=365, message="Jatuh tempo harus antara 0 dan 365 hari."
            ),
        ],
    )
    invoice_day = IntegerField(
        "Tanggal Terbit Tagihan",
        validators=[
            InputRequired(message="Tanggal terbit tagihan wajib diisi."),
            NumberRange(
                min=1,
                max=28,
                message="Tanggal terbit tagihan harus antara 1 dan 28.",
            ),
        ],
    )


class KopSuratForm(FormDasar):
    """Kop surat invoice. Kolomnya sudah ada sejak M2a; ini formulirnya."""

    company_name = StringField("Nama Perusahaan", validators=[Optional(), Length(max=160)])
    company_address = TextAreaField("Alamat", validators=[Optional(), Length(max=500)])
    company_phone = StringField("Telepon", validators=[Optional(), Length(max=40)])
    company_email = StringField(
        "Email",
        validators=[Optional(), Email(message="Format email tidak sah."), Length(max=160)],
    )
    company_website = StringField("Situs Web", validators=[Optional(), Length(max=160)])
    company_npwp = StringField("NPWP", validators=[Optional(), Length(max=32)])
    signer_name = StringField("Nama Penanda Tangan", validators=[Optional(), Length(max=120)])
    signer_title = StringField("Jabatan Penanda Tangan", validators=[Optional(), Length(max=120)])
    payment_terms_text = TextAreaField(
        "Syarat Pembayaran", validators=[Optional(), Length(max=1000)]
    )
    footer_text = TextAreaField("Catatan Kaki", validators=[Optional(), Length(max=1000)])
    accent_color = StringField(
        "Warna Aksen",
        validators=[
            DataRequired(message="Warna aksen wajib diisi."),
            Regexp(POLA_WARNA, message="Warna aksen harus berbentuk #RRGGBB."),
        ],
    )
    logo = FileField(
        "Logo",
        validators=[FileAllowed(["png", "jpg", "jpeg"], "Logo harus PNG atau JPG.")],
    )
    signature = FileField(
        "Tanda Tangan",
        validators=[FileAllowed(["png", "jpg", "jpeg"], "Tanda tangan harus PNG atau JPG.")],
    )
    hapus_logo = BooleanField("Hapus logo")
    hapus_signature = BooleanField("Hapus tanda tangan")


class EmailPengirimanForm(FormDasar):
    """SMTP dan templat email pengiriman invoice.

    `smtp_password` sengaja tidak pernah dikembalikan ke formulir. Yang
    dikirim balik ke peramban akan tersimpan di riwayat dan pengelola kata
    sandi; dibiarkan kosong berarti sandi lama dipertahankan.
    """

    smtp_host = StringField("SMTP Host", validators=[Optional(), Length(max=160)])
    smtp_port = IntegerField(
        "SMTP Port",
        validators=[
            Optional(),
            NumberRange(min=1, max=65535, message="Port harus antara 1 dan 65535."),
        ],
    )
    smtp_user = StringField("SMTP User", validators=[Optional(), Length(max=160)])
    smtp_password = StringField(
        "SMTP Password (kosongkan bila tidak diubah)",
        validators=[Optional(), Length(max=255)],
    )
    smtp_from = StringField(
        "Alamat Pengirim",
        validators=[Optional(), Email(message="Format email tidak sah."), Length(max=160)],
    )
    email_subject_template = StringField(
        "Templat Subjek", validators=[Optional(), Length(max=255)]
    )
    email_body_template = TextAreaField(
        "Templat Isi", validators=[Optional(), Length(max=4000)]
    )

    # Pengingat tagihan otomatis. Kosong = mati, dan itu bawaannya: mengirimi
    # pelanggan email tanpa operator menyalakannya sendiri adalah kejutan yang
    # tidak boleh datang dari pemasangan baru.
    reminder_offsets = StringField(
        "Pengingat Tagihan (hari, dipisah koma — kosongkan untuk mematikan)",
        validators=[Optional(), Length(max=60)],
    )
    reminder_subject_template = StringField(
        "Templat Subjek Pengingat", validators=[Optional(), Length(max=255)]
    )
    reminder_body_template = TextAreaField(
        "Templat Isi Pengingat", validators=[Optional(), Length(max=4000)]
    )


class RekeningForm(FormDasar):
    bank_name = StringField(
        "Nama Bank",
        validators=[DataRequired(message="Nama bank wajib diisi."), Length(max=80)],
    )
    account_number = StringField(
        "Nomor Rekening",
        validators=[DataRequired(message="Nomor rekening wajib diisi."), Length(max=40)],
    )
    account_holder = StringField(
        "Atas Nama",
        validators=[DataRequired(message="Nama pemilik wajib diisi."), Length(max=120)],
    )
    sort_order = IntegerField(
        "Urutan",
        default=99,
        validators=[
            InputRequired(message="Urutan wajib diisi."),
            NumberRange(min=0, max=999, message="Urutan harus antara 0 dan 999."),
        ],
    )
    is_active = BooleanField("Aktif", default=True)


class HapusRekeningForm(FormDasar):
    """Formulir kosong; ada hanya untuk token CSRF pada tombol hapus."""


class MerekForm(FormDasar):
    """Merek aplikasi per ISP. Bukan kop surat invoice — lihat `KopSuratForm`."""

    app_name = StringField(
        "Nama Aplikasi",
        validators=[DataRequired(message="Nama aplikasi wajib diisi."), Length(max=60)],
    )
    app_name_suffix = StringField(
        "Akhiran Nama (dicetak miring)", validators=[Optional(), Length(max=30)]
    )
    tagline = StringField("Tagline", validators=[Optional(), Length(max=120)])
    accent_color = StringField(
        "Warna Aksen",
        validators=[
            DataRequired(message="Warna aksen wajib diisi."),
            Regexp(POLA_WARNA, message="Warna aksen harus berbentuk #RRGGBB."),
        ],
    )
    sidebar_color = StringField(
        "Warna Sidebar",
        validators=[
            DataRequired(message="Warna sidebar wajib diisi."),
            Regexp(POLA_WARNA, message="Warna sidebar harus berbentuk #RRGGBB."),
        ],
    )
    login_headline = StringField(
        "Judul di Halaman Masuk", validators=[Optional(), Length(max=160)]
    )
    login_body = TextAreaField(
        "Paragraf di Halaman Masuk", validators=[Optional(), Length(max=600)]
    )
    footer_text = StringField(
        "Catatan Kaki", validators=[Optional(), Length(max=160)]
    )
    logo = FileField(
        "Logo Aplikasi",
        validators=[FileAllowed(["png", "jpg", "jpeg"], "Logo harus PNG atau JPG.")],
    )
    hapus_logo = BooleanField("Kembalikan ke logo bawaan")
    favicon = FileField(
        "Favicon",
        validators=[FileAllowed(["png"], "Favicon harus PNG.")],
    )
    hapus_favicon = BooleanField("Kembalikan ke favicon bawaan")


class CadanganForm(FormDasar):
    """Formulir kosong; ada hanya untuk token CSRF tombol buat/hapus cadangan."""


KATA_PEMULIHAN = "PULIHKAN"


class PemulihanForm(FormDasar):
    """Konfirmasi pemulihan basis data.

    Kata konfirmasi diketik manual dengan sengaja: pemulihan membuang seluruh
    data yang ada sekarang, dan tombol yang bisa terpencet tanpa sadar terlalu
    murah untuk operasi sebesar itu.
    """

    nama = StringField("Berkas cadangan", validators=[DataRequired()])
    konfirmasi = StringField(
        f"Ketik {KATA_PEMULIHAN} untuk melanjutkan",
        validators=[DataRequired(message=f"Ketik {KATA_PEMULIHAN} untuk melanjutkan.")],
    )

    def validate_konfirmasi(self, field):
        from wtforms.validators import ValidationError

        if (field.data or "").strip() != KATA_PEMULIHAN:
            raise ValidationError(
                f"Ketik persis {KATA_PEMULIHAN} untuk menegaskan bahwa seluruh "
                "data yang ada sekarang boleh dibuang."
            )
