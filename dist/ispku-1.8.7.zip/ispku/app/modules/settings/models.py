from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import TimestampMixin


class BillingSetting(Base, TimestampMixin):
    """Pengaturan billing. Selalu tepat satu baris (id = 1)."""

    __tablename__ = "billing_setting"
    __table_args__ = (
        CheckConstraint("id = 1", name="ck_billing_setting_satu_baris"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cid_prefix: Mapped[str] = mapped_column(String(20), nullable=False, default="CUS")
    cid_pattern: Mapped[str] = mapped_column(
        String(120), nullable=False, default="{prefix}-{branch}-{seq:05d}"
    )
    service_no_pattern: Mapped[str] = mapped_column(
        String(120), nullable=False, default="{cid}-{seq:04d}"
    )
    invoice_pattern: Mapped[str] = mapped_column(
        String(120), nullable=False, default="INV/{YYYY}/{MM}/{seq:04d}"
    )
    ppn_rate: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), nullable=False, default=Decimal("11.00")
    )
    payment_term_days: Mapped[int] = mapped_column(Integer, nullable=False, default=14)
    # Tanggal terbit tagihan. Dibatasi 1–28 di lapisan service: tanggal 29–31
    # tidak ada di setiap bulan, dan batch yang diam-diam tidak pernah jalan di
    # Februari adalah bug yang baru ketahuan setahun kemudian.
    invoice_day: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    # Kop surat invoice (spesifikasi §8).
    company_name: Mapped[str | None] = mapped_column(String(160))
    company_address: Mapped[str | None] = mapped_column(Text)
    company_phone: Mapped[str | None] = mapped_column(String(40))
    company_email: Mapped[str | None] = mapped_column(String(160))
    company_website: Mapped[str | None] = mapped_column(String(160))
    company_npwp: Mapped[str | None] = mapped_column(String(32))
    logo_path: Mapped[str | None] = mapped_column(String(500))
    signature_path: Mapped[str | None] = mapped_column(String(500))
    signer_name: Mapped[str | None] = mapped_column(String(120))
    signer_title: Mapped[str | None] = mapped_column(String(120))
    payment_terms_text: Mapped[str | None] = mapped_column(Text)
    footer_text: Mapped[str | None] = mapped_column(Text)
    accent_color: Mapped[str] = mapped_column(
        String(7), nullable=False, default="#2563EB"
    )

    # SMTP dan templat email.
    smtp_host: Mapped[str | None] = mapped_column(String(160))
    smtp_port: Mapped[int | None] = mapped_column(Integer)
    smtp_user: Mapped[str | None] = mapped_column(String(160))
    smtp_password: Mapped[str | None] = mapped_column(String(255))
    smtp_from: Mapped[str | None] = mapped_column(String(160))
    email_subject_template: Mapped[str | None] = mapped_column(String(255))
    email_body_template: Mapped[str | None] = mapped_column(Text)

    # Pengingat tagihan otomatis. Daftar offset hari relatif jatuh tempo,
    # dipisah koma: `-3, 1, 7` berarti tiga hari sebelum, sehari sesudah, dan
    # seminggu sesudah. Kosong berarti MATI — dan itu nilai bawaannya:
    # pemasangan baru tidak boleh diam-diam mulai mengirimi pelanggan email.
    reminder_offsets: Mapped[str | None] = mapped_column(String(60))
    reminder_subject_template: Mapped[str | None] = mapped_column(String(255))
    reminder_body_template: Mapped[str | None] = mapped_column(Text)


class LicenseState(Base, TimestampMixin):
    """Kunci lisensi yang sedang berlaku. Selalu tepat satu baris (id = 1).

    Disimpan di basis data, bukan di `.env`: lisensi diperpanjang oleh orang
    yang memegang aplikasinya, bukan oleh yang memegang shell server.
    Memaksanya lewat `.env` berarti setiap perpanjangan butuh teknisi dan
    restart kontainer.
    """

    __tablename__ = "license_state"
    __table_args__ = (
        CheckConstraint("id = 1", name="ck_license_state_satu_baris"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key_text: Mapped[str | None] = mapped_column(Text)
    applied_by_user_id: Mapped[int | None] = mapped_column(Integer)


class DemoObject(Base):
    """Jejak setiap baris yang dibuat pemasang data contoh.

    Data contoh menyebar ke belasan tabel. Menandainya lewat kolom `is_demo`
    di setiap tabel berarti belasan migrasi dan belasan tempat yang bisa lupa
    mengisinya; menandainya lewat pola nama ("semua yang berawalan DEMO")
    berarti data sungguhan yang kebetulan bernama serupa ikut terhapus.

    Yang dipakai: satu tabel jejak. Penghapusan menyusurinya dari yang
    terbaru ke yang terlama, sehingga urutan ketergantungan terjaga sendiri —
    anak selalu dibuat sesudah induknya.
    """

    __tablename__ = "demo_object"
    __table_args__ = (
        UniqueConstraint("entity_type", "entity_id", name="uq_demo_object"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(60), nullable=False)
    entity_id: Mapped[int] = mapped_column(Integer, nullable=False)


class AppBranding(Base, TimestampMixin):
    """Merek aplikasi per ISP. Selalu tepat satu baris (id = 1).

    Sengaja terpisah dari `BillingSetting`. Kolom `company_name`, `logo_path`,
    dan `accent_color` di sana adalah **kop surat invoice**, dan invoice
    memang boleh berbeda dari aplikasinya: banyak ISP memakai badan hukum
    yang namanya bukan nama dagangnya. Menumpangkan keduanya berarti
    mengganti nama aplikasi ikut mengubah nama di invoice.
    """

    __tablename__ = "app_branding"
    __table_args__ = (
        CheckConstraint("id = 1", name="ck_app_branding_satu_baris"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    app_name: Mapped[str] = mapped_column(String(60), nullable=False, default="ISPKU")
    # Bagian yang dicetak miring di sebelah nama. Boleh kosong.
    app_name_suffix: Mapped[str | None] = mapped_column(String(30), default="CRM")
    tagline: Mapped[str | None] = mapped_column(
        String(120), default="ISP Customer & Billing System"
    )
    logo_path: Mapped[str | None] = mapped_column(String(500))
    favicon_path: Mapped[str | None] = mapped_column(String(500))
    accent_color: Mapped[str] = mapped_column(
        String(7), nullable=False, default="#2563EB"
    )
    # Latar sidebar. Warna tulisannya diturunkan dari sini (terang di atas
    # latar gelap, gelap di atas latar terang), tidak disimpan sendiri.
    sidebar_color: Mapped[str] = mapped_column(
        String(7), nullable=False, default="#0B1220", server_default="#0B1220"
    )
    # Zona waktu tampilan. Kosong = mengikuti APP_TIMEZONE di .env.
    timezone: Mapped[str | None] = mapped_column(String(64))
    login_headline: Mapped[str | None] = mapped_column(String(160))
    login_body: Mapped[str | None] = mapped_column(Text)
    footer_text: Mapped[str | None] = mapped_column(String(160))
