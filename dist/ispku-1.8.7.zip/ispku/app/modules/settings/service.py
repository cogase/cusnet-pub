import re
from decimal import Decimal

from sqlalchemy import select, text

from app.core import audit, templat_email
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.numbering import (
    NumberingError,
    next_customer_cid,
    next_service_no,
    render_pattern,
)
from app.modules.settings.models import BillingSetting

KOLOM_SETTING = (
    "cid_prefix",
    "cid_pattern",
    "service_no_pattern",
    "invoice_pattern",
    "ppn_rate",
    "payment_term_days",
    "invoice_day",
)

KOLOM_KOP = (
    "company_name",
    "company_address",
    "company_phone",
    "company_email",
    "company_website",
    "company_npwp",
    "signer_name",
    "signer_title",
    "payment_terms_text",
    "footer_text",
    "accent_color",
)

# `smtp_password` sengaja di luar daftar ini: nilainya tidak pernah ikut
# dicatat audit dan tidak pernah dikembalikan ke formulir.
KOLOM_EMAIL = (
    "smtp_host",
    "smtp_port",
    "smtp_user",
    "smtp_from",
    "email_subject_template",
    "email_body_template",
    "reminder_offsets",
    "reminder_subject_template",
    "reminder_body_template",
)

MIME_GAMBAR = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}

# Kunci advisory khusus untuk pembuatan baris pengaturan. Angkanya sembarang,
# yang penting tetap dan tidak dipakai scope penomoran lain.
_KUNCI_SETTING = 918_273_645

ID_SETTING = 1


class PolaTidakSah(GalatDomain):
    """Pola penomoran tidak sah.

    Galat domain milik modul ini sendiri — bukan `NumberingError` dari
    `app.core.numbering` yang ditandai atribut tambahan. `NumberingError`
    bisa juga muncul dari `buat_cid`/`next_customer_cid` (mis. pola rusak
    yang lolos tersimpan), dan pada jalur itu tidak ada field form yang
    relevan, sehingga menempeli `.field` padanya membuat pemanggil lain yang
    menangkap `NumberingError` meledak dengan `AttributeError` begitu
    mengakses `.field` yang tidak ada.
    """


class NilaiTidakSah(GalatDomain):
    """Nilai numerik di luar batas yang masuk akal."""


# Batas offset pengingat. Negatif = sebelum jatuh tempo, positif = sesudah.
# Nol tidak pernah sah: hari jatuh tempo itu sendiri belum terlambat, aturan
# yang sama yang dipakai `segarkan_status`.
OFFSET_MIN, OFFSET_MAKS = -90, 180
OFFSET_MAKS_ENTRI = 5


def _bersihkan_offsets(nilai) -> str | None:
    """Membaca "-3, 1, 7" jadi teks baku, atau menolaknya.

    Divalidasi di sini, bukan hanya di formulir: CLI dan uji menembus formulir
    sepenuhnya, dan satu entri rusak berarti pekerjaan terjadwal harian mati
    diam-diam untuk seluruh pemasangan.
    """
    if nilai is None:
        return None
    teks = str(nilai).strip()
    if not teks:
        return None

    angka = []
    for potongan in teks.split(","):
        potongan = potongan.strip()
        if not potongan:
            continue
        try:
            hari = int(potongan)
        except ValueError:
            raise NilaiTidakSah(
                "reminder_offsets",
                f"'{potongan}' bukan bilangan bulat. Tulis daftar hari dipisah "
                "koma, misalnya -3, 1, 7.",
            ) from None
        if hari == 0:
            raise NilaiTidakSah(
                "reminder_offsets",
                "0 bukan pilihan: hari jatuh tempo itu sendiri belum terlambat. "
                "Pakai angka negatif untuk sebelum jatuh tempo.",
            )
        if not (OFFSET_MIN <= hari <= OFFSET_MAKS):
            raise NilaiTidakSah(
                "reminder_offsets",
                f"{hari} di luar rentang {OFFSET_MIN} sampai {OFFSET_MAKS} hari.",
            )
        if hari in angka:
            raise NilaiTidakSah(
                "reminder_offsets",
                f"{hari} disebut dua kali — itu dua email di hari yang sama.",
            )
        angka.append(hari)

    if len(angka) > OFFSET_MAKS_ENTRI:
        raise NilaiTidakSah(
            "reminder_offsets",
            f"Paling banyak {OFFSET_MAKS_ENTRI} pengingat per invoice.",
        )
    if not angka:
        return None
    return ", ".join(str(h) for h in sorted(angka))


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def ambil_setting(sesi) -> BillingSetting:
    """Mengembalikan satu-satunya baris setting, membuatnya bila belum ada.

    Barisnya selalu ber-id 1. Pembuatannya diserialisasikan dengan advisory
    lock — tanpa itu, dua permintaan bersamaan pada pemasangan baru (mis.
    beberapa worker gunicorn membuka halaman pengaturan sekaligus) sama-sama
    melihat tabel kosong dan sama-sama menyisipkan baris, menghasilkan dua
    baris pengaturan yang bikin prefix/pola CID tampak berubah sendiri.
    `CheckConstraint("id = 1")` di model jadi lapis pertahanan kedua.
    """
    setting = sesi.get(BillingSetting, ID_SETTING)
    if setting is not None:
        return setting

    sesi.execute(
        text("SELECT pg_advisory_xact_lock(:kunci)"), {"kunci": _KUNCI_SETTING}
    )

    setting = sesi.get(BillingSetting, ID_SETTING)
    if setting is None:
        setting = BillingSetting(id=ID_SETTING)
        sesi.add(setting)
        sesi.flush()
    return setting


def ubah_setting(sesi, aktor, data: dict) -> BillingSetting:
    setting = ambil_setting(sesi)

    # Pola divalidasi sebelum disimpan. Pola rusak baru ketahuan saat pelanggan
    # pertama dibuat kalau tidak diperiksa di sini. `NumberingError` dibungkus
    # jadi `PolaTidakSah` (galat domain milik modul ini) supaya rute bisa
    # menempelkannya ke field form yang tepat tanpa menyentuh atribut pada
    # galat milik `app.core.numbering`.
    if "cid_pattern" in data:
        try:
            render_pattern(data["cid_pattern"], prefix="CUS", branch="01", seq=1)
        except NumberingError as galat:
            raise PolaTidakSah("cid_pattern", str(galat)) from galat
    if "service_no_pattern" in data:
        try:
            render_pattern(data["service_no_pattern"], cid="CUS-01-00001", seq=1)
        except NumberingError as galat:
            raise PolaTidakSah("service_no_pattern", str(galat)) from galat
    if "invoice_pattern" in data:
        try:
            render_pattern(data["invoice_pattern"], YYYY="2026", MM="09", seq=1)
        except NumberingError as galat:
            raise PolaTidakSah("invoice_pattern", str(galat)) from galat

    bersih = dict(data)
    if bersih.get("ppn_rate") is not None:
        bersih["ppn_rate"] = to_money(bersih["ppn_rate"])

    if bersih.get("ppn_rate") is not None and not (
        Decimal("0") <= bersih["ppn_rate"] <= Decimal("100")
    ):
        raise NilaiTidakSah("ppn_rate", "Tarif PPN harus antara 0 dan 100.")

    if bersih.get("payment_term_days") is not None and not (
        0 <= int(bersih["payment_term_days"]) <= 365
    ):
        raise NilaiTidakSah(
            "payment_term_days", "Termin bayar harus antara 0 dan 365 hari."
        )

    # Dibatasi 1–28, bukan 1–31: tanggal 29–31 tidak ada di setiap bulan, dan
    # batch yang diam-diam tidak pernah jalan di Februari adalah bug yang baru
    # ketahuan setahun kemudian.
    if bersih.get("invoice_day") is not None and not (
        1 <= int(bersih["invoice_day"]) <= 28
    ):
        raise NilaiTidakSah(
            "invoice_day", "Tanggal terbit tagihan harus antara 1 dan 28."
        )

    sebelum = _potret(setting, KOLOM_SETTING)
    for nama in KOLOM_SETTING:
        if nama in bersih:
            setattr(setting, nama, bersih[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "billing_setting", setting.id,
        before=sebelum, after=_potret(setting, KOLOM_SETTING),
        aktor=aktor,
    )
    return setting


class WarnaTidakSah(GalatDomain):
    """Warna aksen bukan #RRGGBB."""


def ubah_kop(sesi, aktor, data: dict, berkas: dict | None = None) -> BillingSetting:
    """Menyimpan kop surat. `berkas` memetakan kolom path ke `StoredFile`.

    Unggahan sudah disimpan pemanggil lewat `files.simpan` — service ini tidak
    menyentuh berkas, hanya kolomnya. Path lama tidak dihapus dari disk:
    invoice yang sudah dicetak sebagai PDF tidak terpengaruh, tetapi halaman
    cetak lama yang dibuka ulang akan mencari berkasnya.
    """
    setting = ambil_setting(sesi)

    if data.get("accent_color") is not None and not re.fullmatch(
        r"#[0-9A-Fa-f]{6}", str(data["accent_color"])
    ):
        raise WarnaTidakSah("accent_color", "Warna aksen harus berbentuk #RRGGBB.")

    sebelum = _potret(setting, KOLOM_KOP + ("logo_path", "signature_path"))
    for nama in KOLOM_KOP:
        if nama in data:
            nilai = data[nama]
            if isinstance(nilai, str):
                nilai = nilai.strip() or None
            if nama == "accent_color" and nilai is None:
                continue
            setattr(setting, nama, nilai)

    for kolom, tersimpan in (berkas or {}).items():
        setattr(setting, kolom, tersimpan.path if tersimpan is not None else None)

    sesi.flush()
    audit.record(
        sesi, "update", "billing_setting", setting.id,
        before=sebelum,
        after=_potret(setting, KOLOM_KOP + ("logo_path", "signature_path")),
        aktor=aktor,
    )
    return setting


def ubah_email(sesi, aktor, data: dict) -> BillingSetting:
    """Menyimpan SMTP dan templat email.

    Sandi kosong berarti sandi lama dipertahankan — formulir tidak pernah
    menerima sandi yang tersimpan, jadi menyimpan nilai kosong apa adanya akan
    menghapus sandi setiap kali templat email disunting.
    """
    setting = ambil_setting(sesi)

    # Diperiksa sebelum disimpan, sama seperti pola CID dan pola invoice di
    # `ubah_setting`. Templat rusak yang lolos ke basis data baru gagal saat
    # tombol Kirim ditekan — berminggu-minggu kemudian, dan sebagai 500.
    for nama in (
        "email_subject_template",
        "email_body_template",
        "reminder_subject_template",
        "reminder_body_template",
    ):
        if nama in data:
            templat_email.periksa(nama, data[nama])

    if "reminder_offsets" in data:
        data = dict(data)
        data["reminder_offsets"] = _bersihkan_offsets(data["reminder_offsets"])

    sebelum = _potret(setting, KOLOM_EMAIL)
    for nama in KOLOM_EMAIL:
        if nama in data:
            nilai = data[nama]
            if isinstance(nilai, str):
                nilai = nilai.strip() or None
            setattr(setting, nama, nilai)

    sandi = (data.get("smtp_password") or "").strip()
    if sandi:
        setting.smtp_password = sandi

    sesi.flush()
    audit.record(
        sesi, "update", "billing_setting", setting.id,
        before=sebelum, after=_potret(setting, KOLOM_EMAIL),
        aktor=aktor,
    )
    return setting


def buat_nomor_layanan(sesi, customer_cid: str) -> str:
    """Merakit nomor layanan berikutnya memakai pola dari pengaturan."""
    setting = ambil_setting(sesi)
    return next_service_no(sesi, customer_cid, setting.service_no_pattern)


def buat_cid(sesi, cabang) -> str:
    """Merakit CID pelanggan berikutnya untuk cabang tersebut."""
    setting = ambil_setting(sesi)
    return next_customer_cid(
        sesi,
        setting.cid_pattern,
        setting.cid_prefix,
        cabang.code,
        branch_id=cabang.id,
    )


def daftar_rekening_aktif(sesi) -> list:
    """Rekening yang ditampilkan di invoice, terurut."""
    from app.modules.billing.models import BankAccount

    return list(
        sesi.execute(
            select(BankAccount)
            .where(BankAccount.is_active.is_(True))
            .order_by(BankAccount.sort_order, BankAccount.id)
        ).scalars().all()
    )


# --- Rekening bank --------------------------------------------------------
#
# Modelnya sudah dipakai halaman cetak sejak M2b; CRUD-nya baru ada di sini.

KOLOM_REKENING = (
    "bank_name",
    "account_number",
    "account_holder",
    "is_active",
    "sort_order",
)


def daftar_rekening(sesi) -> list:
    """Semua rekening, termasuk yang nonaktif, untuk halaman pengelolaan."""
    from app.modules.billing.models import BankAccount

    return list(
        sesi.execute(
            select(BankAccount).order_by(BankAccount.sort_order, BankAccount.id)
        ).scalars().all()
    )


def ambil_rekening(sesi, rekening_id: int):
    from app.modules.billing.models import BankAccount

    rekening = sesi.get(BankAccount, rekening_id)
    if rekening is None:
        raise TidakDitemukan("Rekening tidak ditemukan.")
    return rekening


def tambah_rekening(sesi, aktor, data: dict):
    from app.modules.billing.models import BankAccount

    rekening = BankAccount(**{k: data[k] for k in KOLOM_REKENING if k in data})
    sesi.add(rekening)
    sesi.flush()
    audit.record(
        sesi, "create", "bank_account", rekening.id,
        after=_potret(rekening, KOLOM_REKENING), aktor=aktor,
    )
    return rekening


def ubah_rekening(sesi, aktor, rekening_id: int, data: dict):
    rekening = ambil_rekening(sesi, rekening_id)
    sebelum = _potret(rekening, KOLOM_REKENING)
    for nama in KOLOM_REKENING:
        if nama in data:
            setattr(rekening, nama, data[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "bank_account", rekening.id,
        before=sebelum, after=_potret(rekening, KOLOM_REKENING), aktor=aktor,
    )
    return rekening


def hapus_rekening(sesi, aktor, rekening_id: int) -> int:
    """Menghapus rekening.

    Rekening tidak direferensikan baris lain — yang tercetak di invoice adalah
    teksnya, bukan tautannya — jadi penghapusan tidak meninggalkan tautan
    menggantung. Invoice lama tetap memperlihatkan rekening yang berlaku saat
    dicetak hanya kalau dicetak ulang; kalau itu jadi masalah, nonaktifkan
    saja alih-alih menghapus.
    """
    rekening = ambil_rekening(sesi, rekening_id)
    sebelum = _potret(rekening, KOLOM_REKENING)
    sesi.delete(rekening)
    sesi.flush()
    audit.record(
        sesi, "delete", "bank_account", rekening_id, before=sebelum, aktor=aktor
    )
    return rekening_id
