"""Informasi sistem untuk halaman Pengaturan → Sistem.

Terpisah dari `service.py` karena tidak menyentuh `billing_setting` sama
sekali: yang dibaca di sini adalah keadaan mesin — versi, ukuran, dan
konfigurasi yang sedang berjalan.
"""

import os
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from sqlalchemy import text

from app.core import waktu


def ukuran_folder(folder: str) -> int:
    """Total byte seluruh berkas di dalam `folder`, 0 bila belum ada."""
    akar = Path(folder)
    if not akar.is_dir():
        return 0
    total = 0
    for induk, _, berkas_berkas in os.walk(akar):
        for nama in berkas_berkas:
            berkas = Path(induk) / nama
            try:
                total += berkas.stat().st_size
            except OSError:
                # Berkas terhapus di tengah penelusuran bukan alasan untuk
                # menggagalkan seluruh halaman.
                continue
    return total


def _versi_postgres(sesi) -> str:
    baris = sesi.execute(text("SHOW server_version")).scalar()
    return str(baris or "").strip()


def info(sesi, config) -> dict:
    zona = waktu.zona()
    return {
        "versi_aplikasi": config["APP_VERSION"],
        "zona_waktu": config["APP_TIMEZONE"],
        "waktu_server": datetime.now(zona),
        "versi_postgres": _versi_postgres(sesi),
        "ukuran_basis_data": int(
            sesi.execute(text("SELECT pg_database_size(current_database())")).scalar()
            or 0
        ),
        "nama_basis_data": sesi.execute(text("SELECT current_database()")).scalar(),
        "ukuran_unggahan": ukuran_folder(config["UPLOAD_DIR"]),
        "folder_unggahan": config["UPLOAD_DIR"],
        "folder_cadangan": config["BACKUP_DIR"],
        "smtp_terisi": bool((config.get("SMTP_HOST") or "").strip()),
        "https_only": bool(config["HTTPS_ONLY"]),
    }
