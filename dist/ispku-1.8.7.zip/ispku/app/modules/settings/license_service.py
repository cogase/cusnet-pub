"""Penyimpanan dan pembacaan lisensi yang sedang berlaku.

Aturan yang tidak boleh dilanggar: **tidak ada yang diblokir karena lisensi.**
Fungsi di sini hanya melaporkan keadaan; yang memakainya menampilkan
peringatan. Lihat alasannya di `app/core/lisensi.py`.
"""

from datetime import date

from sqlalchemy import func, select, text

from app.core import audit, lisensi as inti, waktu
from app.modules.settings.models import LicenseState

ID_LISENSI = 1
_KUNCI_LOCK = 918_273_647


def ambil_baris(sesi) -> LicenseState:
    baris = sesi.get(LicenseState, ID_LISENSI)
    if baris is not None:
        return baris

    sesi.execute(text("SELECT pg_advisory_xact_lock(:kunci)"), {"kunci": _KUNCI_LOCK})
    baris = sesi.get(LicenseState, ID_LISENSI)
    if baris is None:
        baris = LicenseState(id=ID_LISENSI)
        sesi.add(baris)
        sesi.flush()
    return baris


def jumlah_pelanggan(sesi) -> int:
    """Pelanggan yang membebani lisensi.

    Yang berstatus `terminasi` tidak dihitung: pelanggan yang sudah berhenti
    berlangganan bukan beban lisensi, dan menghitungnya membuat batas lisensi
    tercapai oleh riwayat, bukan oleh pemakaian.
    """
    from app.modules.customers.models import Customer

    return sesi.execute(
        select(func.count())
        .select_from(Customer)
        .where(Customer.status != "terminasi")
    ).scalar_one()


def lisensi_aktif(sesi, kunci_publik: str | None = None):
    """Objek lisensi yang tersimpan, atau None bila belum ada / tidak sah."""
    baris = ambil_baris(sesi)
    if not (baris.key_text or "").strip():
        return None
    try:
        return inti.baca(baris.key_text, kunci_publik)
    except inti.LisensiTidakSah:
        # Kunci yang tersimpan hanya bisa tidak sah kalau kunci publik
        # penerbitnya diganti setelah lisensi dipasang. Bukan alasan
        # menjatuhkan halaman.
        return None


def keadaan_baca_saja(
    sesi, kunci_publik: str | None = None, hari_ini: date | None = None
) -> dict:
    """Keadaan lisensi **tanpa menyentuh transaksi**.

    Dipakai spanduk peringatan, yang dirender di tengah `render_template`.
    Versi biasa memanggil `ambil_baris` yang menyisipkan baris bila belum ada;
    menulis dari dalam perenderan berarti commit atau rollback di tengah
    templat yang sedang mengiterasi objek ORM. Di sini barisnya dibaca apa
    adanya, dan ketiadaannya berarti "belum berlisensi".
    """
    baris = sesi.get(LicenseState, ID_LISENSI)
    teks = (baris.key_text or "").strip() if baris is not None else ""

    lisensi = None
    if teks:
        try:
            lisensi = inti.baca(teks, kunci_publik)
        except inti.LisensiTidakSah:
            lisensi = None

    return inti.keadaan(lisensi, jumlah_pelanggan(sesi), hari_ini or waktu.hari_ini())


def keadaan(sesi, kunci_publik: str | None = None, hari_ini: date | None = None) -> dict:
    return inti.keadaan(
        lisensi_aktif(sesi, kunci_publik),
        jumlah_pelanggan(sesi),
        hari_ini or waktu.hari_ini(),
    )


def pasang(sesi, aktor, teks_kunci: str, kunci_publik: str | None = None):
    """Menyimpan kunci baru setelah diverifikasi.

    Diverifikasi **sebelum** disimpan: kunci yang tidak sah tidak boleh
    menghapus lisensi yang sedang berlaku. Pemasangan yang salah tempel
    seharusnya tidak berakhir tanpa lisensi sama sekali.
    """
    lisensi = inti.baca(teks_kunci, kunci_publik)

    baris = ambil_baris(sesi)
    baris.key_text = "".join((teks_kunci or "").split())
    baris.applied_by_user_id = aktor.id if aktor else None
    sesi.flush()

    audit.record(
        sesi, "update", "license", baris.id,
        after={
            "pelanggan": lisensi.pelanggan,
            "edisi": lisensi.edisi,
            "kedaluwarsa": lisensi.kedaluwarsa.isoformat() if lisensi.kedaluwarsa else None,
        },
        aktor=aktor,
    )
    return lisensi


def lepas(sesi, aktor) -> None:
    """Membuang kunci lisensi. Aplikasi tetap berjalan penuh tanpanya."""
    baris = ambil_baris(sesi)
    baris.key_text = None
    baris.applied_by_user_id = aktor.id if aktor else None
    sesi.flush()
    audit.record(sesi, "delete", "license", baris.id, before={"kunci": "***"}, aktor=aktor)
