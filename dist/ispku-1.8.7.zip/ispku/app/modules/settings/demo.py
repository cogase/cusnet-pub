"""Data contoh untuk mempelajari aplikasi, beserta cara membuangnya lagi.

Semua baris dibuat lewat service masing-masing modul, bukan `Model(...)`
langsung. Data contoh yang dibuat lewat jalan pintas akan berbeda dari data
yang dibuat pengguna — nomor tidak berderet, audit log kosong, aturan bisnis
terlewat — dan orang yang mempelajarinya belajar hal yang salah.

Setiap baris yang dibuat dicatat di `demo_object`. Penghapusan menyusuri
jejak itu dari yang terbaru ke yang terlama, jadi urutan ketergantungan
terjaga sendiri: anak selalu dibuat sesudah induknya.
"""

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import delete, func, select

from app.core import audit, waktu
from app.core.db import Base
from app.core.errors import GalatDomain
from app.modules.settings.models import DemoObject

# Awalan yang membuat data contoh mudah dikenali di layar. Bukan penanda yang
# dipakai penghapusan — itu tugas `demo_object`.
TANDA = "DEMO"


class DemoSudahAda(GalatDomain):
    """Data contoh sudah terpasang."""


class DemoTidakAda(GalatDomain):
    """Tidak ada data contoh yang bisa dihapus."""


class DemoMasihDipakai(GalatDomain):
    """Ada data sungguhan yang menempel pada baris data contoh."""


def _peta_tabel() -> dict:
    """Nama tabel ke kelas modelnya, dirakit dari registry SQLAlchemy."""
    hasil = {}
    for mapper in Base.registry.mappers:
        hasil[mapper.class_.__tablename__] = mapper.class_
    return hasil


def _catat(sesi, obj) -> None:
    sesi.add(
        DemoObject(entity_type=obj.__tablename__, entity_id=obj.id)
    )
    sesi.flush()


def _hapus_sisa_cabang_contoh(
    sesi, aktor, branch_id: int, dibuang: dict
) -> None:
    """Hapus sisa baris operasional yang masih menempel pada cabang contoh.

    Urutan eksplisit menghapus baris anak lebih dulu. Akun pengguna
    dipertahankan dan dilepas dari cabang contoh, bukan dihapus.
    """
    from app.modules.admin.models import AuditLog, User
    from app.modules.billing.models import Invoice
    from app.modules.customers.models import Customer, CustomerDocument
    from app.modules.inventory.models import Device, DevicePort, IpBlock, Site, Vlan
    from app.modules.tickets.models import Ticket, TicketAttachment

    akun = sesi.execute(
        select(User).where(User.branch_id == branch_id)
    ).scalars().all()
    for user in akun:
        sebelum = {"branch_id": user.branch_id}
        user.branch_id = None
        audit.record(
            sesi,
            "update",
            "user",
            user.id,
            before=sebelum,
            after={"branch_id": None},
            aktor=aktor,
        )
    if akun:
        dibuang["akun_pengguna_dilepas"] = (
            dibuang.get("akun_pengguna_dilepas", 0) + len(akun)
        )

    for model in (
        CustomerDocument,
        TicketAttachment,
        Ticket,
        Invoice,
        DevicePort,
        Device,
        Vlan,
        IpBlock,
        Customer,
        Site,
    ):
        ids = sesi.execute(
            select(model.id).where(model.branch_id == branch_id)
        ).scalars().all()
        if not ids:
            continue

        sesi.execute(
            delete(AuditLog).where(
                AuditLog.entity_type == model.__tablename__,
                AuditLog.entity_id.in_(ids),
            )
        )
        hasil = sesi.execute(
            delete(model).where(model.id.in_(ids)),
            execution_options={"synchronize_session": False},
        )
        dibuang[model.__tablename__] = (
            dibuang.get(model.__tablename__, 0) + (hasil.rowcount or 0)
        )


def status(sesi) -> dict:
    total = sesi.execute(select(func.count()).select_from(DemoObject)).scalar_one()
    per_tabel = sesi.execute(
        select(DemoObject.entity_type, func.count())
        .group_by(DemoObject.entity_type)
        .order_by(DemoObject.entity_type)
    ).all()
    return {
        "terpasang": total > 0,
        "total": total,
        "per_tabel": [{"tabel": nama, "jumlah": jumlah} for nama, jumlah in per_tabel],
    }


# --- Pemasangan -----------------------------------------------------------


def pasang(sesi, aktor) -> dict:
    """Membuat seluruh data contoh. Menolak bila sudah ada."""
    if status(sesi)["terpasang"]:
        raise DemoSudahAda(
            "berkas",
            "Data contoh sudah terpasang. Hapus dulu sebelum memasang ulang.",
        )

    hitung = {}
    cabang = _cabang(sesi, aktor, hitung)
    vendor = _vendor(sesi, aktor, cabang, hitung)
    kategori_pelanggan = _kategori_pelanggan(sesi, aktor, hitung)
    paket = _paket(sesi, aktor, hitung)
    pelanggan = _pelanggan(sesi, aktor, cabang, kategori_pelanggan, hitung)
    langganan = _langganan(sesi, aktor, pelanggan, paket, vendor, hitung)
    _jaringan(sesi, aktor, cabang, langganan, hitung)
    _tiket(sesi, aktor, cabang, pelanggan, langganan, hitung)
    _tagihan(sesi, aktor, cabang, pelanggan, hitung)
    return hitung


def _tambah(hitung: dict, nama: str, jumlah: int = 1) -> None:
    hitung[nama] = hitung.get(nama, 0) + jumlah


def _cabang(sesi, aktor, hitung):
    from app.modules.admin import service as admin_service

    hasil = []
    for kode, nama, alamat in (
        ("D1", f"{TANDA} Jakarta", "Jl. Contoh Raya No. 1, Jakarta Selatan"),
        ("D2", f"{TANDA} Bandung", "Jl. Contoh Asia No. 2, Bandung"),
    ):
        baris = admin_service.buat_cabang(
            sesi, aktor,
            {"code": kode, "name": nama, "address": alamat, "phone": "021-5550100",
             "is_active": True},
        )
        _catat(sesi, baris)
        _tambah(hitung, "cabang")
        hasil.append(baris)
    return hasil


def _vendor(sesi, aktor, cabang, hitung):
    from app.modules.services import service as layanan_service

    baris = layanan_service.buat_vendor(
        sesi, aktor,
        {"name": f"{TANDA} Nusantara Fiber", "contact_name": "Sdr. Contoh",
         "phone": "021-5550200", "email": "noc@contoh.id", "is_active": True},
    )
    _catat(sesi, baris)
    _tambah(hitung, "vendor")
    return baris


def _kategori_pelanggan(sesi, aktor, hitung):
    from app.modules.customers import service as pelanggan_service

    hasil = []
    for nama in (f"{TANDA} Korporat", f"{TANDA} UMKM"):
        baris = pelanggan_service.buat_kategori_pelanggan(
            sesi, aktor, {"name": nama, "is_active": True}
        )
        _catat(sesi, baris)
        _tambah(hitung, "kategori_pelanggan")
        hasil.append(baris)
    return hasil


def _paket(sesi, aktor, hitung):
    from app.modules.services import service as layanan_service

    kategori = {}
    for kode, nama, bentuk, warna in (
        ("DEMOINT", f"{TANDA} Internet", "internet", "biru"),
        ("DEMOP2P", f"{TANDA} Point-to-Point", "point_to_point", "ungu"),
        ("DEMOLAIN", f"{TANDA} Layanan Lain", "generic", "hijau"),
    ):
        baris = layanan_service.buat_kategori(
            sesi, aktor,
            {"code": kode, "name": nama, "form_kind": bentuk,
             "badge_color": warna, "is_active": True},
        )
        _catat(sesi, baris)
        _tambah(hitung, "kategori_layanan")
        kategori[bentuk] = baris

    paket = {}
    for kode, nama, bentuk, harga in (
        ("DEMO-BB20", f"{TANDA} Broadband 20 Mbps", "internet", "500000"),
        ("DEMO-DED50", f"{TANDA} Dedicated 50 Mbps", "internet", "4500000"),
        ("DEMO-P2P100", f"{TANDA} Metro Link 100 Mbps", "point_to_point", "7500000"),
        ("DEMO-COLO", f"{TANDA} Colocation 1U", "generic", "1500000"),
    ):
        baris = layanan_service.buat_paket(
            sesi, aktor,
            {"category_id": kategori[bentuk].id, "code": kode, "name": nama,
             "price": Decimal(harga), "is_active": True},
        )
        _catat(sesi, baris)
        _tambah(hitung, "paket")
        paket[kode] = baris
    return paket


CONTOH_PELANGGAN = (
    # (nama, alias, tipe, status, cabang ke-, alamat, PIC, telepon)
    ("PT Bumi Contoh Sejahtera", "Bumi Contoh", "corporate", "active", 0,
     "Jl. Jenderal Sudirman Kav. 10, Jakarta Pusat", "Andi Prasetyo", "0811100001"),
    ("CV Terang Benderang", "Terang", "sme", "active", 0,
     "Jl. Kebon Jeruk No. 45, Jakarta Barat", "Budi Santoso", "0811100002"),
    ("Yayasan Cahaya Ilmu", "Cahaya Ilmu", "corporate", "active", 0,
     "Jl. Margonda Raya No. 88, Depok", "Citra Dewi", "0811100003"),
    ("Toko Maju Jaya", "Maju Jaya", "sme", "suspend", 1,
     "Jl. Braga No. 12, Bandung", "Dedi Kurniawan", "0811100004"),
    ("PT Sinar Data Nusantara", "Sinar Data", "corporate", "active", 1,
     "Jl. Setiabudi No. 200, Bandung", "Eka Putri", "0811100005"),
    ("Warnet Bintang", "Bintang", "personal", "pending", 1,
     "Jl. Dipatiukur No. 7, Bandung", "Fajar Nugroho", "0811100006"),
)


def _pelanggan(sesi, aktor, cabang, kategori_pelanggan, hitung):
    from app.modules.customers import service as pelanggan_service

    hasil = []
    for urut, (nama, alias, tipe, status_pelanggan, cabang_ke, alamat, pic, telepon) in enumerate(
        CONTOH_PELANGGAN
    ):
        baris = pelanggan_service.buat_pelanggan(
            sesi, aktor,
            {
                "name": nama,
                "alias": alias,
                "branch_id": cabang[cabang_ke].id,
                "customer_type": tipe,
                "tier": "premium" if tipe == "corporate" else "regular",
                "category_id": kategori_pelanggan[0 if tipe == "corporate" else 1].id,
                "status": status_pelanggan,
                "install_address": alamat,
                "billing_same_as_install": True,
                "invoice_mode": "gabungan",
                "payment_type": "postpaid",
                "joined_at": date(2026, 1, 1) + timedelta(days=urut * 15),
                "source": "referral",
            },
        )
        _catat(sesi, baris)
        _tambah(hitung, "pelanggan")

        kontak = pelanggan_service.buat_kontak(
            sesi, aktor, baris.id,
            {"name": pic, "role": "pic_utama", "phone": telepon,
             "email": f"{pic.split()[0].lower()}@contoh.id", "is_primary": True,
             "job_title": "IT Manager"},
        )
        _catat(sesi, kontak)
        _tambah(hitung, "kontak")

        catatan = pelanggan_service.buat_catatan(
            sesi, aktor, baris.id,
            "Catatan contoh: pelanggan ini bagian dari data pembelajaran dan "
            "boleh dihapus kapan saja lewat Pengaturan → Data Contoh.",
        )
        _catat(sesi, catatan)
        _tambah(hitung, "catatan")
        hasil.append(baris)
    return hasil


def _langganan(sesi, aktor, pelanggan, paket, vendor, hitung):
    from app.modules.customers import subscription_service

    rencana = (
        # (pelanggan ke-, kode paket, status, ip, vlan, interface)
        (0, "DEMO-DED50", "active", "103.10.10.2", "110", "ether1"),
        (1, "DEMO-BB20", "active", "103.10.10.3", "111", "ether2"),
        (2, "DEMO-BB20", "active", "103.10.10.4", "112", "ether3"),
        (3, "DEMO-BB20", "suspend", "103.10.20.2", "120", "ether1"),
        (4, "DEMO-P2P100", "active", "103.10.20.3", "121", "ae0.100"),
        (4, "DEMO-COLO", "active", None, None, None),
    )

    hasil = []
    for pelanggan_ke, kode, status_langganan, ip, vlan, antarmuka in rencana:
        data = {
            "plan_id": paket[kode].id,
            "status": status_langganan,
            "started_at": date(2026, 2, 1),
            "activated_at": date(2026, 2, 1) if status_langganan != "pending" else None,
        }
        if ip:
            data.update({"ip_address": ip, "vlan": vlan, "interface": antarmuka})

        baris = subscription_service.buat_langganan(
            sesi, aktor, pelanggan[pelanggan_ke].id, data
        )
        _catat(sesi, baris)
        _tambah(hitung, "langganan")

        if kode.startswith("DEMO-BB") or kode.startswith("DEMO-DED"):
            detail = subscription_service.simpan_detail_internet(
                sesi, aktor, baris.id,
                {"capacity_mbps": 50 if "DED" in kode else 20,
                 "internet_kind": "dedicated" if "DED" in kode else "broadband",
                 "vendor_id": vendor.id if "BB" in kode else None,
                 "odp_name": "ODP-DEMO-01"},
            )
            _catat(sesi, detail)
            _tambah(hitung, "detail_internet")

        hasil.append(baris)
    return hasil


def _jaringan(sesi, aktor, cabang, langganan, hitung):
    from app.modules.inventory import service as inventaris

    site = []
    for kode, nama, cabang_ke, lat, lng in (
        ("DEMO-POP1", f"{TANDA} POP Kuningan", 0, "-6.2297", "106.8296"),
        ("DEMO-POP2", f"{TANDA} POP Dago", 1, "-6.8915", "107.6107"),
    ):
        baris = inventaris.tambah_site(
            sesi, aktor,
            {"code": kode, "name": nama, "branch_id": cabang[cabang_ke].id,
             "kind": "pop", "lat": Decimal(lat), "lng": Decimal(lng),
             "is_active": True},
        )
        _catat(sesi, baris)
        _tambah(hitung, "site")
        site.append(baris)

    port_bebas = []
    for urut, satu_site in enumerate(site):
        perangkat = inventaris.tambah_perangkat(
            sesi, aktor,
            {"site_id": satu_site.id, "name": f"{TANDA}-SW-{urut + 1:02d}",
             "kind": "switch", "brand": "Contoh", "model": "CX-2400",
             "mgmt_address": f"10.99.{urut}.1", "status": "aktif"},
        )
        _catat(sesi, perangkat)
        _tambah(hitung, "perangkat")

        for nomor in range(1, 5):
            port = inventaris.tambah_port(
                sesi, aktor, perangkat.id,
                {"name": f"Gi0/{nomor}", "kind": "access", "speed_mbps": 1000},
            )
            _catat(sesi, port)
            _tambah(hitung, "port")
            port_bebas.append(port)

        vlan = inventaris.tambah_vlan(
            sesi, aktor,
            {"vlan_id": 110 + urut * 10, "name": f"{TANDA} Pelanggan {urut + 1}",
             "site_id": satu_site.id, "branch_id": satu_site.branch_id,
             "kind": "pelanggan"},
        )
        _catat(sesi, vlan)
        _tambah(hitung, "vlan")

        blok = inventaris.tambah_blok(
            sesi, aktor,
            {"cidr": f"103.10.{10 + urut * 10}.0/29", "kind": "publik",
             "site_id": satu_site.id, "branch_id": satu_site.branch_id,
             "gateway": f"103.10.{10 + urut * 10}.1"},
        )
        _catat(sesi, blok)
        _tambah(hitung, "blok_ip")

    # Alokasi port ke langganan yang punya alamat IP — supaya halaman Port dan
    # halaman Blok IP sama-sama berisi, bukan hanya salah satunya.
    for port, satu_langganan in zip(port_bebas, langganan):
        if satu_langganan.ip_address is None:
            continue
        try:
            inventaris.alokasi_port(sesi, aktor, port.id, satu_langganan.id)
            _tambah(hitung, "port_dialokasikan")
        except GalatDomain:
            continue


def _tiket(sesi, aktor, cabang, pelanggan, langganan, hitung):
    from app.modules.tickets import service as tiket_service

    kategori = []
    for kode, nama, prioritas, respons, selesai in (
        ("DEMOGGN", f"{TANDA} Gangguan Layanan", "tinggi", 2, 8),
        ("DEMOREQ", f"{TANDA} Permintaan Perubahan", "sedang", 8, 72),
    ):
        baris = tiket_service.tambah_kategori(
            sesi, aktor,
            {"code": kode, "name": nama, "default_priority": prioritas,
             "sla_response_hours": respons, "sla_resolve_hours": selesai,
             "is_active": True},
        )
        _catat(sesi, baris)
        _tambah(hitung, "kategori_tiket")
        kategori.append(baris)

    sekarang = datetime.now(timezone.utc)
    rencana = (
        (0, 0, "Internet putus sejak pagi", "kritis", "proses", 0),
        (1, 0, "Koneksi lambat di jam sibuk", "sedang", "baru", 1),
        (2, 1, "Minta tambah kapasitas jadi 50 Mbps", "sedang", "selesai", 2),
        (4, 0, "Link metro flapping", "tinggi", "pending", 3),
    )
    for pelanggan_ke, kategori_ke, judul, prioritas, status_tiket, mundur_hari in rencana:
        tiket = tiket_service.buat(
            sesi, aktor,
            {
                "branch_id": pelanggan[pelanggan_ke].branch_id,
                "customer_id": pelanggan[pelanggan_ke].id,
                "category_id": kategori[kategori_ke].id,
                "title": judul,
                "description": (
                    "Tiket contoh. Isinya dibuat untuk memperlihatkan alur "
                    "penanganan gangguan dari dibuka sampai ditutup."
                ),
                "priority": prioritas,
            },
            sekarang=sekarang - timedelta(days=mundur_hari, hours=3),
        )
        _catat(sesi, tiket)
        _tambah(hitung, "tiket")

        komentar = tiket_service.tambah_komentar(
            sesi, aktor, tiket.id,
            "Sudah dicek dari sisi POP, perangkat pelanggan tidak menjawab ping.",
            True,
            sekarang=sekarang - timedelta(days=mundur_hari, hours=2),
        )
        _catat(sesi, komentar)
        _tambah(hitung, "komentar_tiket")

        if status_tiket in ("proses", "pending", "selesai"):
            tiket_service.ubah_status(
                sesi, aktor, tiket.id, "proses",
                sekarang=sekarang - timedelta(days=mundur_hari, hours=2),
            )
        if status_tiket == "pending":
            tiket_service.ubah_status(
                sesi, aktor, tiket.id, "pending",
                sekarang=sekarang - timedelta(days=mundur_hari, hours=1),
            )
        if status_tiket == "selesai":
            tiket_service.ubah_status(
                sesi, aktor, tiket.id, "selesai",
                resolusi="Kapasitas dinaikkan dan sudah dikonfirmasi pelanggan.",
                sekarang=sekarang - timedelta(days=mundur_hari, hours=1),
            )


def _tagihan(sesi, aktor, cabang_contoh, pelanggan_contoh, hitung):
    from app.modules.billing import payments
    from app.modules.billing import service as billing_service

    hari_ini = waktu.hari_ini()
    awal = hari_ini.replace(day=1)
    akhir = (awal + timedelta(days=32)).replace(day=1) - timedelta(days=1)

    # Dijalankan per cabang contoh, bukan seluruh pemasangan: `jalankan_batch`
    # tanpa `branch_id` menagih SETIAP pelanggan yang berlangganan, termasuk
    # pelanggan sungguhan milik ISP-nya. Itu berarti data contoh menerbitkan
    # invoice sungguhan atas nama orang lain.
    for cabang in cabang_contoh:
        run = billing_service.jalankan_batch(
            sesi, aktor, awal, akhir, branch_id=cabang.id, hari_ini=hari_ini
        )
        _catat(sesi, run)
        _tambah(hitung, "batch_invoice")

    from app.modules.billing.models import Invoice

    # Dan invoice yang diambil hanya milik pelanggan contoh. Menyaring cuma
    # dengan periode akan mengangkat invoice sungguhan periode berjalan ke
    # dalam jejak data contoh — lalu menghapusnya saat "Hapus Data Contoh"
    # ditekan, beserta pembayarannya lewat ON DELETE CASCADE.
    id_pelanggan = [satu.id for satu in pelanggan_contoh]
    invoice_baru = sesi.execute(
        select(Invoice)
        .where(
            Invoice.period_start == awal,
            Invoice.customer_id.in_(id_pelanggan),
        )
        .order_by(Invoice.id)
    ).scalars().all()

    for urut, invoice in enumerate(invoice_baru):
        # Baris invoice dan pembayaran ikut terhapus lewat ON DELETE CASCADE
        # saat invoice-nya dibuang, jadi tidak perlu dicatat satu per satu.
        _catat(sesi, invoice)
        _tambah(hitung, "invoice")

        if invoice.status == "draft":
            billing_service.terbitkan(sesi, aktor, invoice.id, hari_ini=hari_ini)

        # Satu lunas, satu dibayar sebagian, sisanya dibiarkan terbuka —
        # supaya laporan tunggakan dan umur piutang punya isi yang berbeda.
        if urut == 0:
            bayar = invoice.total
        elif urut == 1:
            bayar = (invoice.total / 2).quantize(Decimal("1"))
        else:
            continue

        payments.catat(
            sesi, aktor, invoice.id,
            {"amount": bayar, "method": "transfer", "paid_at": hari_ini,
             "reference": f"{TANDA}-TRF-{urut + 1:03d}"},
        )
        _tambah(hitung, "pembayaran")


# --- Penghapusan ----------------------------------------------------------


def hapus(sesi, aktor) -> dict:
    """Hapus data contoh dan sisa data operasional di cabang contoh.

    Menyusuri jejak dari yang terbaru ke yang terlama, lalu membersihkan sisa
    data operasional yang masih terhubung ke cabang contoh. Akun pengguna
    dipertahankan dan dilepas dari cabang tersebut.
    """
    from app.modules.admin.models import AuditLog

    jejak = sesi.execute(
        select(DemoObject).order_by(DemoObject.id.desc())
    ).scalars().all()
    if not jejak:
        raise DemoTidakAda("berkas", "Tidak ada data contoh yang terpasang.")

    from sqlalchemy.exc import IntegrityError

    peta = _peta_tabel()
    dibuang = {}
    tertangani = []
    for baris in jejak:
        model = peta.get(baris.entity_type)
        if model is None:
            # Tabel yang namanya berubah sejak data contoh dipasang. Jejaknya
            # sengaja TIDAK dibuang: baris yang tak bisa dikenali lagi harus
            # tetap bisa ditemukan, bukan menjadi data mirip-sungguhan yang
            # tak berjejak.
            continue

        try:
            obj = sesi.get(model, baris.entity_id)
            if obj is not None:
                if baris.entity_type == "branch":
                    _hapus_sisa_cabang_contoh(
                        sesi, aktor, baris.entity_id, dibuang
                    )
                sesi.delete(obj)
                dibuang[baris.entity_type] = (
                    dibuang.get(baris.entity_type, 0) + 1
                )
            # Hapus juga audit milik objek yang sudah dibuang.
            sesi.execute(
                delete(AuditLog).where(
                    AuditLog.entity_type == baris.entity_type,
                    AuditLog.entity_id == baris.entity_id,
                )
            )
            sesi.flush()
        except IntegrityError as galat:
            # Data sungguhan yang menempel pada baris contoh — misalnya tiket
            # yang dibuat operator untuk pelanggan contoh, atau pengguna
            # sungguhan di cabang contoh. Ditolak dengan kalimat yang bisa
            # dikerjakan, bukan halaman 500.
            sesi.rollback()
            raise DemoMasihDipakai(
                "berkas",
                f"Data contoh tidak bisa dihapus seluruhnya: masih ada data "
                f"lain yang menempel pada {baris.entity_type} "
                f"#{baris.entity_id}. Pindahkan atau hapus data itu lebih "
                "dulu, lalu ulangi.",
            ) from galat

        tertangani.append(baris.id)

    if tertangani:
        sesi.execute(delete(DemoObject).where(DemoObject.id.in_(tertangani)))
    sesi.flush()
    return dibuang
