from flask import Blueprint, render_template, request, url_for

from app.core.auth import current_user
from app.core.db import db_session
from app.core.grafik import garis_ganda
from app.core import rbac, waktu
from app.core.money import format_rupiah_singkat
from app.core.rbac import require_role
from app.modules.billing import reports
from app.modules.billing.forms import LABEL_STATUS_INVOICE, NADA_STATUS_INVOICE
from app.modules.dashboard import service
from app.modules.billing import service as billing_service
from app.modules.inventory import service as inventory_service
from app.modules.tickets import service as ticket_service
from app.modules.tickets.forms import (
    LABEL_PRIORITAS,
    NADA_PRIORITAS,
)
from app.modules.tickets.forms import LABEL_STATUS as LABEL_STATUS_TIKET
from app.modules.tickets.forms import NADA_STATUS as NADA_STATUS_TIKET
from app.modules.tickets.models import STATUS_TIKET

bp = Blueprint("dashboard", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")


def _ruas(pasangan):
    """Ruas bilah komposisi: `(label, jumlah, nada, href)` menjadi dict."""
    return [
        {"label": label, "jumlah": jumlah, "nada": nada, "href": href, "teks": None}
        for label, jumlah, nada, href in pasangan
    ]


def _ruas_uang(pasangan):
    """Seperti `_ruas` untuk nilai rupiah: bilah memakai angkanya, legenda
    menampilkan bentuk singkatnya."""
    return [
        {
            "label": label, "jumlah": int(nilai), "nada": nada, "href": href,
            "teks": format_rupiah_singkat(nilai),
        }
        for label, nilai, nada, href in pasangan
    ]


@bp.get("/dashboard")
@require_role(*BACA)
def index():
    """Dasbor operasional, disusun menurut peran.

    Peran tanpa akses billing (teknis) mendapat papan tiket dan jaringan
    tanpa satu pun angka uang — angkanya tidak dihitung sama sekali, bukan
    sekadar disembunyikan di templat.
    """
    user = current_user()
    tampil_uang = user.role not in rbac.PERAN_TANPA_KEUANGAN
    bulan = 6 if request.args.get("bulan") == "6" else 12

    ringkasan = service.ringkasan(db_session, user)
    ringkasan_tiket = ticket_service.ringkasan(db_session, user)
    jaringan = inventory_service.ringkasan(db_session, user)
    per_status_tiket = ringkasan_tiket["per_status"]
    per_status_customer = {
        baris["status"]: baris for baris in ringkasan["per_status_customer"]
    }

    konteks = {
        "peran": user.role,
        "tampil_uang": tampil_uang,
        "sapaan": service.sapaan(),
        "hari_ini": waktu.hari_ini(),
        "cakupan": "Semua cabang" if rbac.is_cross_branch(user) else "Cabang Anda",
        "bulan": bulan,
        "ringkasan": ringkasan,
        "ringkasan_tiket": ringkasan_tiket,
        "jaringan": jaringan,
        "tiket_baru": per_status_tiket.get("baru", 0),
        "tiket_proses": per_status_tiket.get("proses", 0),
        "customer_pending": per_status_customer.get("pending", {}).get("jumlah", 0),
        "customer_suspend": per_status_customer.get("suspend", {}).get("jumlah", 0),
        "tiket_operasional": service.tiket_operasional(db_session, user, limit=6),
        "aktivitas": service.aktivitas_terbaru(db_session, user, limit=6),
        "label_status_tiket": LABEL_STATUS_TIKET,
        "label_prioritas": LABEL_PRIORITAS,
        "nada_prioritas": NADA_PRIORITAS,
        "ruas_tiket": _ruas(
            (
                LABEL_STATUS_TIKET[status],
                per_status_tiket.get(status, 0),
                NADA_STATUS_TIKET[status],
                url_for("tickets.daftar", status=status),
            )
            for status in STATUS_TIKET
        ),
        "ruas_port": _ruas(
            [
                ("Terpakai", jaringan["port_terpakai"], "info",
                 url_for("inventory.perangkat_daftar")),
                ("Bebas", jaringan["port_bebas"], "sehat",
                 url_for("inventory.perangkat_daftar")),
            ]
        ),
    }

    if tampil_uang:
        rekap = reports.rekap_periode(db_session, user, waktu.awal_bulan())
        tagihan = billing_service.ringkasan_billing(db_session, user)
        konteks.update(
            uang=service.ringkasan_uang(db_session, user),
            rekap=rekap,
            invoice_draf=tagihan["per_status"].get("draft", 0),
            invoice_terbaru=service.invoice_terbaru(db_session, user),
            invoice_tunggakan=service.invoice_tunggakan(db_session, user),
            pelanggan_teratas=service.pelanggan_teratas(db_session, user),
            tren=garis_ganda(
                reports.tren_pendapatan(db_session, user, bulan=bulan),
                [("tagihan", "Tagihan"), ("dibayar", "Dibayar")],
                kunci_label="bulan",
                lebar=460,
                tinggi=230,
            ),
            label_status=LABEL_STATUS_INVOICE,
            nada_status=NADA_STATUS_INVOICE,
            ruas_customer=_ruas(
                (
                    baris["label"], baris["jumlah"], baris["nada"],
                    url_for("customers.pelanggan_daftar", status=baris["status"]),
                )
                for baris in ringkasan["per_status_customer"]
            ),
            ruas_tagihan=_ruas_uang(
                [
                    ("Terbayar", rekap["total_dibayar"], "sehat",
                     url_for("billing.pembayaran_daftar")),
                    ("Belum terbayar", max(rekap["sisa"], 0), "antrean",
                     url_for("billing.daftar", status="issued")),
                ]
            ),
        )

    return render_template("dashboard/index.html", **konteks)
