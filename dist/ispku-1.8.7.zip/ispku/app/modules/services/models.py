from decimal import Decimal

from sqlalchemy import (
    Boolean,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    func,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import Money, TimestampMixin

JENIS_VENDOR: tuple[str, ...] = ("transit", "metro", "last_mile", "lainnya")

# Bentuk formulir teknis yang tersedia. Kategori baru boleh dibuat pengguna,
# tetapi harus memilih salah satu dari ketiganya — bentuk baru adalah pekerjaan
# pengembang, bukan konfigurasi.
BENTUK_FORMULIR: tuple[str, ...] = ("internet", "point_to_point", "generic")

# Warna lencana kategori. Tinggal di sini, bukan di forms.py, supaya
# service.py bisa menegakkannya tanpa mengimpor lapisan formulir.
WARNA_LENCANA: tuple[str, ...] = ("biru", "hijau", "ungu", "jingga", "merah", "netral")

KATEGORI_LAYANAN_BAWAAN: tuple[dict, ...] = (
    {"code": "INTERNET", "name": "Internet", "form_kind": "internet",
     "badge_color": "biru", "icon": "wifi", "sort_order": 1},
    {"code": "LOCAL_LINK", "name": "Local Link", "form_kind": "point_to_point",
     "badge_color": "jingga", "icon": "share-2", "sort_order": 2},
    {"code": "METRO_ETHERNET", "name": "Metro Ethernet", "form_kind": "point_to_point",
     "badge_color": "ungu", "icon": "git-branch", "sort_order": 3},
    {"code": "IP_TRANSIT", "name": "IP Transit", "form_kind": "generic",
     "badge_color": "biru", "icon": "globe", "sort_order": 4},
    {"code": "COLOCATION", "name": "Colocation", "form_kind": "generic",
     "badge_color": "merah", "icon": "server", "sort_order": 5},
    {"code": "LAINNYA", "name": "Lainnya", "form_kind": "generic",
     "badge_color": "netral", "icon": "box", "sort_order": 6},
)


class Vendor(Base, TimestampMixin):
    __tablename__ = "vendor"
    __table_args__ = (
        # "PT Sama" dan "pt sama" adalah vendor yang sama. Index fungsional
        # dibuat selagi tabelnya masih kosong; setelah ada ratusan baris,
        # membersihkan duplikatnya jauh lebih mahal.
        Index(
            "uq_vendor_nama_lower",
            func.lower(func.trim(text("name"))),
            unique=True,
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="lainnya")
    contact_name: Mapped[str | None] = mapped_column(String(120))
    contact_phone: Mapped[str | None] = mapped_column(String(40))
    contact_email: Mapped[str | None] = mapped_column(String(160))
    note: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class ServiceCategory(Base, TimestampMixin):
    __tablename__ = "service_category"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    form_kind: Mapped[str] = mapped_column(String(20), nullable=False)
    badge_color: Mapped[str] = mapped_column(String(20), nullable=False, default="netral")
    icon: Mapped[str] = mapped_column(String(40), nullable=False, default="box")
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=99)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class ServicePlan(Base, TimestampMixin):
    __tablename__ = "service_plan"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(
        ForeignKey("service_category.id"), nullable=False
    )
    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    capacity: Mapped[str | None] = mapped_column(String(80))
    price: Mapped[Decimal] = mapped_column(Money, nullable=False)
    ppn_rate: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    description: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
