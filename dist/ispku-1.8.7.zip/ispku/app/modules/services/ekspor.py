"""Ekspor CSV Daftar Layanan.

Kolomnya tetap, tanpa pemilih kolom. Pemilih kolom di Daftar Customer ada
karena tabelnya sendiri punya pemilih kolom, dan satu daftar dipakai keduanya
supaya "Kolom" dan "Export" tidak perlahan bercerai. Tabel Paket tidak punya
pemilih kolom, jadi pemilih yang hanya berlaku untuk berkas justru menghasilkan
kolom yang tidak pernah ada di layar — kebalikan dari alasan pola itu dibuat.

Angka ditulis polos (`500000.00`, bukan `Rp 500.000`): berkas ini dijumlahkan
di Excel, tidak dibaca sebagai kalimat.
"""

import io

from app.core import csv_aman

JUDUL = (
    "Kode",
    "Nama Paket",
    "Kategori",
    "Kapasitas",
    "Harga",
    "PPN (%)",
    "Status",
    "Deskripsi",
)


def csv_paket(baris) -> str:
    """`baris` adalah pasangan `(ServicePlan, ServiceCategory)`, apa adanya
    dari query halaman daftar."""
    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(JUDUL)
    for paket, kategori in baris:
        tulis.writerow(
            [
                paket.code,
                paket.name,
                kategori.name if kategori else "",
                paket.capacity or "",
                paket.price,
                paket.ppn_rate if paket.ppn_rate is not None else "",
                "Aktif" if paket.is_active else "Nonaktif",
                paket.description or "",
            ]
        )
    return keluaran.getvalue()
