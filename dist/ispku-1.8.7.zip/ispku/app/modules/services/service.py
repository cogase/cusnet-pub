from decimal import Decimal

from sqlalchemy import func, or_, select, update

from app.core import audit
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.pagination import Page, paginate, paginate_rows
from app.modules.services.models import (
    BENTUK_FORMULIR,
    JENIS_VENDOR,
    KATEGORI_LAYANAN_BAWAAN,
    WARNA_LENCANA,
    ServiceCategory,
    ServicePlan,
    Vendor,
)

KOLOM_KATEGORI = (
    "code",
    "name",
    "form_kind",
    "badge_color",
    "icon",
    "sort_order",
    "is_active",
)

KOLOM_VENDOR = (
    "name",
    "kind",
    "contact_name",
    "contact_phone",
    "contact_email",
    "note",
    "is_active",
)

HARGA_MAKS = Decimal("999999999999.99")

KOLOM_PAKET = (
    "category_id",
    "code",
    "name",
    "capacity",
    "price",
    "ppn_rate",
    "description",
    "is_active",
)


class NilaiSudahDipakai(GalatDomain):
    """Nilai unik yang diminta sudah dipakai baris lain."""


class BentukFormulirTidakDikenal(GalatDomain):
    """`form_kind` di luar tiga bentuk formulir yang tersedia."""


class KategoriSudahDipakai(GalatDomain):
    """Kategori sudah dipakai paket layanan, sehingga bentuk formulirnya terkunci."""


class NilaiTidakSah(GalatDomain):
    """Nilai numerik di luar batas yang masuk akal."""


class NilaiTidakDikenal(GalatDomain):
    """Nilai enum di luar daftar yang tersedia."""


class PaketSudahDipakai(GalatDomain):
    """Paket sudah dipakai langganan, sehingga kategorinya terkunci."""


def _jumlah_langganan_paket(sesi, plan_id: int) -> int:
    """Berapa langganan yang menahan paket ini.

    Diimpor di dalam fungsi, bukan di kepala berkas: modul langganan mengimpor
    katalog layanan, jadi impor di kepala membuat lingkaran impor.
    """
    from app.modules.customers.subscriptions import Subscription

    return sesi.execute(
        select(func.count())
        .select_from(Subscription)
        .where(Subscription.plan_id == plan_id)
    ).scalar_one()


def _jumlah_langganan_kategori(sesi, kategori_id: int) -> int:
    from app.modules.customers.subscriptions import Subscription

    return sesi.execute(
        select(func.count())
        .select_from(Subscription)
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .where(ServicePlan.category_id == kategori_id)
    ).scalar_one()


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def seed_kategori_layanan(sesi) -> int:
    """Menanam enam kategori bawaan. Aman dijalankan berulang."""
    dibuat = 0
    for bawaan in KATEGORI_LAYANAN_BAWAAN:
        ada = sesi.execute(
            select(ServiceCategory).where(ServiceCategory.code == bawaan["code"])
        ).scalars().first()
        if ada is None:
            sesi.add(ServiceCategory(**bawaan))
            dibuat += 1
    return dibuat


def daftar_vendor(sesi, page: int = 1, per_page: int = 10) -> Page:
    return paginate(sesi, select(Vendor).order_by(Vendor.name), page, per_page)


def semua_vendor(sesi) -> list[Vendor]:
    """Seluruh vendor tanpa halaman. Untuk dropdown."""
    return list(sesi.execute(select(Vendor).order_by(Vendor.name)).scalars().all())


def ambil_vendor(sesi, vendor_id: int) -> Vendor:
    vendor = sesi.get(Vendor, vendor_id)
    if vendor is None:
        raise TidakDitemukan("Vendor tidak ditemukan.")
    return vendor


def _rapikan_nama(nilai: str | None) -> str:
    return (nilai or "").strip()


def _pastikan_nama_bebas(sesi, nama: str, kecuali_id: int | None = None) -> None:
    """Membandingkan `lower(trim(...))`, bukan nilai persis.

    "PT Sama" dan "pt sama" adalah vendor yang sama bagi manusia yang membaca
    daftarnya. Basis data juga menegakkannya lewat unique index fungsional —
    pemeriksaan di sini hanya supaya pesannya bisa dibaca, bukan
    `IntegrityError`.
    """
    bersih = _rapikan_nama(nama)
    query = select(Vendor).where(
        func.lower(func.trim(Vendor.name)) == bersih.lower()
    )
    if kecuali_id is not None:
        query = query.where(Vendor.id != kecuali_id)
    if sesi.execute(query).scalars().first() is not None:
        raise NilaiSudahDipakai("name", f"Vendor '{bersih}' sudah terdaftar.")


def _pastikan_jenis_vendor(data: dict) -> None:
    jenis = data.get("kind")
    if jenis and jenis not in JENIS_VENDOR:
        raise NilaiTidakDikenal(
            "kind", "Jenis vendor harus salah satu dari: " + ", ".join(JENIS_VENDOR)
        )


def buat_vendor(sesi, aktor, data: dict) -> Vendor:
    data = dict(data)
    _pastikan_jenis_vendor(data)
    if "name" in data:
        data["name"] = _rapikan_nama(data["name"])
    _pastikan_nama_bebas(sesi, data.get("name"))

    vendor = Vendor(**{k: data.get(k) for k in KOLOM_VENDOR if k in data})
    sesi.add(vendor)
    sesi.flush()

    audit.record(
        sesi, "create", "vendor", vendor.id,
        after=_potret(vendor, KOLOM_VENDOR), aktor=aktor,
    )
    return vendor


def ubah_vendor(sesi, aktor, vendor_id: int, data: dict) -> Vendor:
    vendor = ambil_vendor(sesi, vendor_id)
    data = dict(data)
    _pastikan_jenis_vendor(data)
    if "name" in data:
        data["name"] = _rapikan_nama(data["name"])
        _pastikan_nama_bebas(sesi, data["name"], kecuali_id=vendor.id)

    sebelum = _potret(vendor, KOLOM_VENDOR)
    for nama in KOLOM_VENDOR:
        if nama in data:
            setattr(vendor, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "vendor", vendor.id,
        before=sebelum, after=_potret(vendor, KOLOM_VENDOR),
        aktor=aktor,
    )
    return vendor


def hapus_vendor(sesi, aktor, vendor_id: int) -> None:
    vendor = ambil_vendor(sesi, vendor_id)
    from app.modules.customers.subscriptions import (
        P2PTransitHop,
        SubscriptionInternet,
        SubscriptionP2P,
    )

    for model in (SubscriptionInternet, SubscriptionP2P, P2PTransitHop):
        sesi.execute(update(model).where(model.vendor_id == vendor.id).values(vendor_id=None))
    audit.record(
        sesi, "delete", "vendor", vendor.id,
        before=_potret(vendor, KOLOM_VENDOR), aktor=aktor,
    )
    sesi.delete(vendor)
    sesi.flush()


def _query_kategori():
    return select(ServiceCategory).order_by(
        ServiceCategory.sort_order, ServiceCategory.name
    )


def daftar_kategori(sesi, page: int = 1, per_page: int = 50) -> Page:
    return paginate(sesi, _query_kategori(), page, per_page)


def semua_kategori(sesi) -> list[ServiceCategory]:
    """Seluruh kategori layanan tanpa halaman. Untuk dropdown."""
    return list(sesi.execute(_query_kategori()).scalars().all())


def semua_paket(sesi, aktif: bool | None = None) -> list:
    """Seluruh paket (beserta kategorinya) tanpa halaman. Untuk dropdown.

    Mengembalikan baris `(ServicePlan, ServiceCategory)` seperti
    `_query_paket`, supaya label dropdown bisa menyebut kategorinya.
    """
    return list(sesi.execute(_query_paket(aktif=aktif)).all())


def ambil_kategori(sesi, kategori_id: int) -> ServiceCategory:
    kategori = sesi.get(ServiceCategory, kategori_id)
    if kategori is None:
        raise TidakDitemukan("Kategori layanan tidak ditemukan.")
    return kategori


def _pastikan_bentuk_formulir(nilai: str | None) -> None:
    if nilai not in BENTUK_FORMULIR:
        raise BentukFormulirTidakDikenal(
            "form_kind",
            "Bentuk formulir harus salah satu dari: " + ", ".join(BENTUK_FORMULIR),
        )


def _pastikan_kode_kategori_bebas(sesi, kode: str, kecuali_id: int | None = None) -> None:
    query = select(ServiceCategory).where(ServiceCategory.code == kode)
    if kecuali_id is not None:
        query = query.where(ServiceCategory.id != kecuali_id)
    if sesi.execute(query).scalars().first() is not None:
        raise NilaiSudahDipakai("code", f"Kode kategori '{kode}' sudah dipakai.")


def _pastikan_warna_lencana(data: dict) -> None:
    warna = data.get("badge_color")
    if warna and warna not in WARNA_LENCANA:
        raise NilaiTidakDikenal(
            "badge_color", "Warna lencana harus salah satu dari: " + ", ".join(WARNA_LENCANA)
        )


def buat_kategori(sesi, aktor, data: dict) -> ServiceCategory:
    _pastikan_bentuk_formulir(data.get("form_kind"))
    _pastikan_warna_lencana(data)
    _pastikan_kode_kategori_bebas(sesi, data.get("code"))

    kategori = ServiceCategory(**{k: data.get(k) for k in KOLOM_KATEGORI if k in data})
    sesi.add(kategori)
    sesi.flush()

    audit.record(
        sesi, "create", "service_category", kategori.id,
        after=_potret(kategori, KOLOM_KATEGORI),
        aktor=aktor,
    )
    return kategori


def ubah_kategori(sesi, aktor, kategori_id: int, data: dict) -> ServiceCategory:
    kategori = ambil_kategori(sesi, kategori_id)
    _pastikan_warna_lencana(data)
    if "form_kind" in data:
        _pastikan_bentuk_formulir(data["form_kind"])
    if "form_kind" in data and data["form_kind"] != kategori.form_kind:
        jumlah_langganan = _jumlah_langganan_kategori(sesi, kategori.id)
        if jumlah_langganan:
            raise KategoriSudahDipakai(
                "form_kind",
                f"Bentuk formulir tidak bisa diubah karena sudah ada "
                f"{jumlah_langganan} layanan berlangganan di kategori ini. "
                "Data teknis yang sudah terkumpul akan kehilangan artinya.",
            )
        dipakai = sesi.execute(
            select(ServicePlan).where(ServicePlan.category_id == kategori.id).limit(1)
        ).scalars().first()
        if dipakai is not None:
            raise KategoriSudahDipakai(
                "form_kind",
                "Bentuk formulir tidak bisa diubah karena sudah ada paket layanan "
                "di kategori ini. Pindahkan paketnya lebih dulu, atau buat "
                "kategori baru.",
            )
    if "code" in data:
        _pastikan_kode_kategori_bebas(sesi, data["code"], kecuali_id=kategori.id)

    sebelum = _potret(kategori, KOLOM_KATEGORI)
    for nama in KOLOM_KATEGORI:
        if nama in data:
            setattr(kategori, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "service_category", kategori.id,
        before=sebelum, after=_potret(kategori, KOLOM_KATEGORI),
        aktor=aktor,
    )
    return kategori


def hapus_kategori(sesi, aktor, kategori_id: int) -> None:
    kategori = ambil_kategori(sesi, kategori_id)
    paket_ids = list(
        sesi.execute(
            select(ServicePlan.id).where(ServicePlan.category_id == kategori.id)
        ).scalars()
    )
    for paket_id in paket_ids:
        hapus_paket(sesi, aktor, paket_id)
    audit.record(
        sesi, "delete", "service_category", kategori.id,
        before=_potret(kategori, KOLOM_KATEGORI), aktor=aktor,
    )
    sesi.delete(kategori)
    sesi.flush()


def ringkasan_layanan(sesi) -> dict:
    """Angka untuk kartu statistik dan tab kategori di halaman Layanan."""
    jumlah_per_kategori = dict(
        sesi.execute(
            select(ServicePlan.category_id, func.count(ServicePlan.id))
            .group_by(ServicePlan.category_id)
        ).all()
    )

    kategori = sesi.execute(
        select(ServiceCategory).order_by(ServiceCategory.sort_order, ServiceCategory.name)
    ).scalars().all()

    return {
        "total_paket": sum(jumlah_per_kategori.values()),
        "per_kategori": [
            {"kategori": k, "jumlah_paket": jumlah_per_kategori.get(k.id, 0)}
            for k in kategori
        ],
    }


def _query_paket(
    kategori_id: int | None = None,
    q: str | None = None,
    aktif: bool | None = None,
):
    """Query daftar paket beserta seluruh filternya.

    Dipakai halaman daftar DAN ekspor. Query kedua yang ditulis khusus untuk
    ekspor adalah tempat berkas dan layar mulai menyaring berbeda — dan yang
    mengunduh berkasnya justru orang yang tidak sanggup membaca layarnya.
    """
    query = (
        select(ServicePlan, ServiceCategory)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .order_by(ServiceCategory.sort_order, ServicePlan.name)
    )

    if kategori_id is not None:
        query = query.where(ServicePlan.category_id == kategori_id)
    if aktif is not None:
        query = query.where(ServicePlan.is_active.is_(aktif))
    if q:
        pola = f"%{q.strip()}%"
        query = query.where(
            or_(ServicePlan.name.ilike(pola), ServicePlan.code.ilike(pola))
        )

    return query


def daftar_paket(
    sesi,
    page: int = 1,
    per_page: int = 10,
    kategori_id: int | None = None,
    q: str | None = None,
    aktif: bool | None = None,
) -> Page:
    return paginate_rows(
        sesi, _query_paket(kategori_id, q, aktif), page, per_page
    )


BATAS_EKSPOR = 20_000


def ekspor_paket(sesi, **filter) -> tuple[str, bool]:
    """Paket yang lolos filter sebagai CSV, beserta tanda terpotong.

    Pemanggil wajib memberi tahu pemakainya kalau `terpotong` — berkas yang
    tampak utuh padahal kehilangan segalanya setelah baris ke-20.000 adalah
    kegagalan yang tidak pernah ketahuan.
    """
    from app.modules.services import ekspor as modul_ekspor

    baris = sesi.execute(_query_paket(**filter).limit(BATAS_EKSPOR)).all()
    return modul_ekspor.csv_paket(baris), len(baris) >= BATAS_EKSPOR


def ambil_paket(sesi, paket_id: int) -> ServicePlan:
    paket = sesi.get(ServicePlan, paket_id)
    if paket is None:
        raise TidakDitemukan("Paket layanan tidak ditemukan.")
    return paket


def ambil_paket_dengan_kategori(sesi, paket_id: int):
    """Paket beserta kategorinya dalam satu query.

    Halaman detail langganan butuh keduanya; dua panggilan terpisah berarti
    dua query untuk data yang selalu diambil bersamaan.
    """
    baris = sesi.execute(
        select(ServicePlan, ServiceCategory)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .where(ServicePlan.id == paket_id)
    ).first()
    if baris is None:
        raise TidakDitemukan("Paket layanan tidak ditemukan.")
    return baris


def set_aktif_paket(sesi, aktor, paket_id: int, aktif: bool) -> ServicePlan:
    """Menyalakan atau mematikan paket.

    Nonaktif menutup pemesanan baru; langganan yang sedang berjalan sengaja
    TIDAK disentuh. Paket yang dipakai invoice lama tidak boleh lenyap, dan
    memutus layanan pelanggan adalah keputusan yang diambil per langganan,
    bukan efek samping dari merapikan katalog.
    """
    paket = ambil_paket(sesi, paket_id)
    if paket.is_active == aktif:
        return paket

    sebelum = _potret(paket, KOLOM_PAKET)
    paket.is_active = aktif
    sesi.flush()

    audit.record(
        sesi, "update", "service_plan", paket.id,
        before=sebelum, after=_potret(paket, KOLOM_PAKET),
        aktor=aktor,
    )
    return paket


def _pastikan_kode_paket_bebas(sesi, kode: str, kecuali_id: int | None = None) -> None:
    query = select(ServicePlan).where(ServicePlan.code == kode)
    if kecuali_id is not None:
        query = query.where(ServicePlan.id != kecuali_id)
    if sesi.execute(query).scalars().first() is not None:
        raise NilaiSudahDipakai("code", f"Kode paket '{kode}' sudah dipakai.")


def _bersihkan_nominal(data: dict) -> dict:
    """Melewatkan nominal lewat `to_money` supaya float ditolak keras."""
    bersih = dict(data)
    if bersih.get("price") is not None:
        bersih["price"] = to_money(bersih["price"])
    if bersih.get("ppn_rate") is not None:
        bersih["ppn_rate"] = to_money(bersih["ppn_rate"])

    if bersih.get("price") is not None and bersih["price"] < 0:
        raise NilaiTidakSah("price", "Harga tidak boleh negatif.")
    if bersih.get("price") is not None and bersih["price"] > HARGA_MAKS:
        raise NilaiTidakSah(
            "price", "Harga terlalu besar. Maksimum Rp 999.999.999.999,99."
        )
    if bersih.get("ppn_rate") is not None and not (
        Decimal("0") <= bersih["ppn_rate"] <= Decimal("100")
    ):
        raise NilaiTidakSah("ppn_rate", "Tarif PPN harus antara 0 dan 100.")

    return bersih


def buat_paket(sesi, aktor, data: dict) -> ServicePlan:
    ambil_kategori(sesi, data.get("category_id"))
    _pastikan_kode_paket_bebas(sesi, data.get("code"))
    data = _bersihkan_nominal(data)

    paket = ServicePlan(**{k: data.get(k) for k in KOLOM_PAKET if k in data})
    sesi.add(paket)
    sesi.flush()

    audit.record(
        sesi, "create", "service_plan", paket.id,
        after=_potret(paket, KOLOM_PAKET), aktor=aktor,
    )
    return paket


def ubah_paket(sesi, aktor, paket_id: int, data: dict) -> ServicePlan:
    paket = ambil_paket(sesi, paket_id)
    if "category_id" in data and data["category_id"] != paket.category_id:
        tujuan = ambil_kategori(sesi, data["category_id"])
        asal = ambil_kategori(sesi, paket.category_id)
        # Melunasi m1a-catatan-lanjutan.md §1.3: `ubah_kategori` menjaga
        # form_kind dari sisi kategori, tetapi kategori paket sendiri bisa
        # dipindah. Memindahkannya ke kategori berbentuk lain membatalkan
        # data teknis langganan yang sudah terkumpul.
        if tujuan.form_kind != asal.form_kind:
            jumlah = _jumlah_langganan_paket(sesi, paket.id)
            if jumlah:
                raise PaketSudahDipakai(
                    "category_id",
                    f"Paket ini dipakai {jumlah} layanan berlangganan, jadi tidak "
                    f"bisa dipindah ke kategori berbentuk '{tujuan.form_kind}'. "
                    "Pindahkan langganannya lebih dulu, atau pilih kategori "
                    f"berbentuk '{asal.form_kind}'.",
                )
    elif "category_id" in data:
        ambil_kategori(sesi, data["category_id"])
    if "code" in data:
        _pastikan_kode_paket_bebas(sesi, data["code"], kecuali_id=paket.id)
    data = _bersihkan_nominal(data)

    sebelum = _potret(paket, KOLOM_PAKET)
    for nama in KOLOM_PAKET:
        if nama in data:
            setattr(paket, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "service_plan", paket.id,
        before=sebelum, after=_potret(paket, KOLOM_PAKET),
        aktor=aktor,
    )
    return paket


def hapus_paket(sesi, aktor, paket_id: int) -> None:
    paket = ambil_paket(sesi, paket_id)
    from app.modules.customers.subscriptions import Subscription
    from app.modules.customers import subscription_service

    langganan_ids = list(
        sesi.execute(
            select(Subscription.id).where(Subscription.plan_id == paket.id)
        ).scalars()
    )
    for langganan_id in langganan_ids:
        subscription_service.hapus_langganan(sesi, aktor, langganan_id)
    audit.record(
        sesi, "delete", "service_plan", paket.id,
        before=_potret(paket, KOLOM_PAKET), aktor=aktor,
    )
    sesi.delete(paket)
    sesi.flush()
