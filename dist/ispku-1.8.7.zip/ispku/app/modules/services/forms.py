from app.core.forms import FormDasar
from wtforms import (
    BooleanField,
    DecimalField,
    IntegerField,
    SelectField,
    StringField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    InputRequired,
    Length,
    NumberRange,
    Optional,
)

from app.modules.services.models import BENTUK_FORMULIR, JENIS_VENDOR, WARNA_LENCANA

LABEL_JENIS_VENDOR = {
    "transit": "Transit",
    "metro": "Metro",
    "last_mile": "Last Mile",
    "lainnya": "Lainnya",
}

LABEL_BENTUK_FORMULIR = {
    "internet": "Internet (kapasitas, jenis, ODP/OLT)",
    "point_to_point": "Titik-ke-titik (dua terminasi, VLAN, transit)",
    "generic": "Umum (tanpa detail teknis khusus)",
}


class DesimalIndonesia(DecimalField):
    """`DecimalField` dengan pesan galat berbahasa Indonesia.

    Bawaan WTForms melempar "Not a valid decimal value." (Inggris) bila
    isian bukan angka yang sah.
    """

    def process_formdata(self, valuelist):
        try:
            super().process_formdata(valuelist)
        except ValueError as galat:
            self.data = None
            raise ValueError(
                "Masukkan angka yang sah, contoh: 2750000 atau 2750000.50"
            ) from galat


class DesimalOpsional(DesimalIndonesia):
    """`DesimalIndonesia` yang menerima isian kosong sebagai `None`.

    `DecimalField` bawaan WTForms memanggil `Decimal(valuelist[0])` sebelum
    validator `Optional()` sempat berjalan, sehingga isian kosong selalu
    gagal dengan galat meski field-nya opsional. Kelas ini menangkap isian
    kosong lebih dulu supaya `Optional()` benar-benar berfungsi.
    """

    def process_formdata(self, valuelist):
        if valuelist and isinstance(valuelist[0], str) and valuelist[0].strip() == "":
            self.data = None
            return
        super().process_formdata(valuelist)


class VendorForm(FormDasar):
    name = StringField(
        "Nama Vendor",
        validators=[DataRequired(message="Nama vendor wajib diisi."), Length(max=160)],
    )
    kind = SelectField(
        "Jenis", choices=[(j, LABEL_JENIS_VENDOR[j]) for j in JENIS_VENDOR]
    )
    contact_name = StringField("Nama Kontak", validators=[Optional(), Length(max=120)])
    contact_phone = StringField("Telepon", validators=[Optional(), Length(max=40)])
    contact_email = StringField(
        "Email",
        validators=[Optional(), Email(message="Format email tidak sah."), Length(max=160)],
    )
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=2000)])
    is_active = BooleanField("Aktif", default=True)


class KategoriLayananForm(FormDasar):
    code = StringField(
        "Kode",
        validators=[DataRequired(message="Kode kategori wajib diisi."), Length(max=30)],
    )
    name = StringField(
        "Nama Kategori",
        validators=[DataRequired(message="Nama kategori wajib diisi."), Length(max=80)],
    )
    form_kind = SelectField(
        "Bentuk Formulir",
        choices=[(b, LABEL_BENTUK_FORMULIR[b]) for b in BENTUK_FORMULIR],
    )
    badge_color = SelectField(
        "Warna Lencana", choices=[(w, w.title()) for w in WARNA_LENCANA]
    )
    icon = StringField("Ikon", validators=[Optional(), Length(max=40)], default="box")
    sort_order = IntegerField(
        "Urutan", validators=[Optional(), NumberRange(min=1, max=999)], default=99
    )
    is_active = BooleanField("Aktif", default=True)


class PaketLayananForm(FormDasar):
    category_id = SelectField("Kategori", coerce=int)
    code = StringField(
        "Kode Paket",
        validators=[DataRequired(message="Kode paket wajib diisi."), Length(max=30)],
    )
    name = StringField(
        "Nama Paket",
        validators=[DataRequired(message="Nama paket wajib diisi."), Length(max=160)],
    )
    capacity = StringField(
        "Paket / Kapasitas", validators=[Optional(), Length(max=80)]
    )
    price = DesimalIndonesia(
        "Harga per Bulan",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Harga wajib diisi."),
            NumberRange(
                min=0,
                max=999999999999.99,
                message="Harga tidak boleh negatif.",
            ),
        ],
    )
    ppn_rate = DesimalOpsional(
        "Tarif PPN (%)",
        places=2,
        use_locale=False,
        validators=[
            Optional(),
            NumberRange(min=0, max=100, message="Tarif PPN harus antara 0 dan 100."),
        ],
    )
    description = TextAreaField("Deskripsi", validators=[Optional(), Length(max=2000)])
    is_active = BooleanField("Aktif", default=True)
