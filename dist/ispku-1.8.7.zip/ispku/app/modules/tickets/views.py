"""Rute modul tiket.

Peran: `teknis` memiliki akses penuh ke ticketing. `billing` dan `viewer`
hanya membaca.
"""

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app.core import waktu
from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.files import FileError, sajikan
from app.core.pagination import per_halaman_dari
from app.core.rbac import require_role
from app.modules.admin import service as admin_service
from app.modules.customers import service as customer_service
from app.modules.customers import subscription_service
from app.modules.tickets import service
from app.modules.tickets.forms import (
    LABEL_PRIORITAS,
    LABEL_STATUS,
    NADA_PRIORITAS,
    NADA_STATUS,
    HapusTiketForm,
    KategoriTiketForm,
    KomentarForm,
    LampiranTiketForm,
    StatusForm,
    TiketForm,
)

bp = Blueprint("tickets", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
TULIS = ("superadmin", "admin_cabang", "teknis")
MASTER = ("superadmin", "admin_cabang", "teknis")

KOSONG = (0, "—")


def _isi_pilihan(form: TiketForm, user) -> None:
    """Mengisi pilihan cabang, kategori, pelanggan, dan petugas.

    Daftarnya dibatasi hak akses aktor: staf cabang tidak boleh melihat — apa
    lagi memilih — cabang atau pelanggan cabang lain.
    """
    cabang = admin_service.semua_cabang(db_session, user)
    form.branch_id.choices = [(c.id, c.name) for c in cabang]

    kategori = service.daftar_kategori(db_session, hanya_aktif=True)
    form.category_id.choices = [(k.id, k.name) for k in kategori]

    # Pelanggan adalah satu-satunya pilihan di formulir ini yang berasal dari
    # tabel TRANSAKSI, bukan master: pemasangan dengan puluhan ribu pelanggan
    # tidak boleh merender puluhan ribu `<option>`. Jadi di sini batasnya
    # dipertahankan — tetapi pemotongannya DIKATAKAN, tidak didiamkan, sesuai
    # aturan yang sudah dipakai ekspor.
    baris_pelanggan, terpotong = customer_service.pilihan_pelanggan(db_session, user)
    form.customer_id.choices = [KOSONG] + [
        (pelanggan.id, f"{pelanggan.cid} — {pelanggan.name}")
        for pelanggan, _cabang in baris_pelanggan
    ]
    if terpotong:
        form.customer_id.choices.append(
            (
                0,
                f"— daftar dipotong di {customer_service.BATAS_PILIHAN} pelanggan; "
                "buka tiket dari halaman Detail Customer —",
            )
        )

    petugas = admin_service.semua_user(db_session, user)
    form.assigned_to_user_id.choices = [KOSONG] + [
        (u.id, f"{u.full_name} ({u.role})") for u in petugas
    ]

    # Layanan disaring menurut pelanggan yang sedang dipilih; tanpa pelanggan
    # daftarnya kosong, bukan seluruh langganan di basis data.
    pilihan_layanan = [KOSONG]
    dipilih = form.customer_id.data
    if dipilih:
        pilihan_layanan += [
            (langganan.id, f"{langganan.service_no or '—'} — {paket.name}")
            for langganan, paket, _kategori in subscription_service.daftar_langganan(
                db_session, user, dipilih
            )
        ]
    form.subscription_id.choices = pilihan_layanan


def _konteks_label() -> dict:
    return {
        "label_prioritas": LABEL_PRIORITAS,
        "label_status": LABEL_STATUS,
        "nada_prioritas": NADA_PRIORITAS,
        "nada_status": NADA_STATUS,
    }


def _filter_tiket() -> dict:
    """Filter daftar tiket dari query string. Dipakai layar dan ekspor."""
    return {
        "q": request.args.get("q") or None,
        "status": request.args.get("status") or None,
        "prioritas": request.args.get("prioritas") or None,
        "category_id": request.args.get("kategori", type=int),
        "assigned_to": request.args.get("petugas", type=int),
    }


@bp.get("/tiket")
@require_role(*BACA)
def daftar():
    user = current_user()
    filter_aktif = _filter_tiket()
    halaman = service.daftar(
        db_session,
        user,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        **filter_aktif,
    )
    return render_template(
        "tickets/daftar.html",
        halaman=halaman,
        ringkasan=service.ringkasan(db_session, user),
        kategori_pilihan=service.daftar_kategori(db_session),
        petugas_pilihan=admin_service.semua_user(db_session, user),
        filter_aktif=filter_aktif,
        sla=service.terlambat,
        **_konteks_label(),
    )


@bp.route("/tiket/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def baru():
    user = current_user()
    form = TiketForm()
    _isi_pilihan(form, user)

    if form.validate_on_submit():
        try:
            tiket = service.buat(db_session, user, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash(f"Tiket {tiket.number} dibuka.", "sukses")
            return redirect(url_for("tickets.detail", tiket_id=tiket.id))

    return render_template("tickets/form.html", form=form, tiket=None)


@bp.get("/tiket/<int:tiket_id>")
@require_role(*BACA)
def detail(tiket_id: int):
    user = current_user()
    tiket = service.ambil(db_session, user, tiket_id)

    form_status = StatusForm(data={"status": tiket.status})
    # Hanya perpindahan yang memang diizinkan yang muncul di daftar; tombol
    # yang selalu ditolak adalah tombol yang membohongi penggunanya.
    form_status.status.choices = [
        (s, LABEL_STATUS[s]) for s in service.TRANSISI[tiket.status]
    ]

    komentar = service.daftar_komentar(db_session, user, tiket_id)
    lampiran = service.daftar_lampiran(db_session, user, tiket_id)
    return render_template(
        "tickets/detail.html",
        tiket=tiket,
        kategori=service.ambil_kategori(db_session, tiket.category_id),
        komentar=komentar,
        penulis=admin_service.penulis_komentar(db_session, [k.user_id for k in komentar]),
        lampiran=[b for b in lampiran if b.comment_id is None],
        evidence=service.evidence_per_langkah(lampiran),
        batas_evidence=service.BATAS_EVIDENCE,
        sla=service.terlambat(tiket),
        form_komentar=KomentarForm(),
        form_status=form_status,
        form_lampiran=LampiranTiketForm(),
        form_hapus=HapusTiketForm(),
        **_konteks_label(),
    )


@bp.post("/tiket/<int:tiket_id>/hapus")
@require_role(*MASTER)
def hapus(tiket_id: int):
    if not HapusTiketForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman tiket.", "bahaya")
        return redirect(url_for("tickets.detail", tiket_id=tiket_id))
    service.hapus(db_session, current_user(), tiket_id)
    db_session.commit()
    flash("Tiket beserta komentar dan lampirannya dihapus.", "sukses")
    return redirect(url_for("tickets.daftar"))


@bp.get("/tiket/<int:tiket_id>.csv")
@require_role(*BACA)
def ekspor_tiket(tiket_id: int):
    """Satu tiket beserta riwayat komentarnya sebagai berkas CSV."""
    from flask import Response

    user = current_user()
    tiket = service.ambil(db_session, user, tiket_id)
    komentar = service.daftar_komentar(db_session, user, tiket_id)

    penulis = admin_service.penulis_komentar(
        db_session, [k.user_id for k in komentar]
    )
    pelanggan = (
        customer_service.ambil_pelanggan(db_session, user, tiket.customer_id)
        if tiket.customer_id
        else None
    )
    langganan = (
        subscription_service.ambil_langganan(db_session, user, tiket.subscription_id)
        if tiket.subscription_id
        else None
    )

    isi = service.csv_tiket(
        tiket,
        service.ambil_kategori(db_session, tiket.category_id),
        [(k, penulis.get(k.user_id)) for k in komentar],
        pelanggan,
        langganan,
        service.terlambat(tiket),
    )
    nama = f"{tiket.number.replace('/', '-')}.csv"
    return Response(
        isi,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nama}"'},
    )


def _kirim_pdf_tiket(nama_berkas: str, **konteks):
    """Merender templat cetak tiket menjadi PDF lewat WeasyPrint."""
    from flask import Response, current_app

    from app.core import pdf, waktu
    from app.modules.settings import branding
    from app.modules.settings import service as setting_service

    user = current_user()
    setting = setting_service.ambil_setting(db_session)
    merek = branding.konteks(branding.ambil_merek(db_session))
    html = render_template(
        "tickets/cetak.html",
        perusahaan=setting.company_name or merek["nama_penuh"],
        aksen=merek["warna"],
        pencetak=user.full_name,
        dicetak=waktu.sekarang(),
        **konteks,
        **_konteks_label(),
    )
    db_session.commit()
    return Response(
        pdf.dari_html(html, {}, current_app.static_folder),
        mimetype="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{nama_berkas}"'},
    )


@bp.get("/tiket/<int:tiket_id>.pdf")
@require_role(*BACA)
def ekspor_pdf(tiket_id: int):
    """Laporan lengkap satu tiket: rincian, SLA, uraian, komentar, lampiran."""
    user = current_user()
    tiket = service.ambil(db_session, user, tiket_id)
    komentar = service.daftar_komentar(db_session, user, tiket_id)
    lampiran = service.daftar_lampiran(db_session, user, tiket_id)
    orang = admin_service.penulis_komentar(
        db_session,
        [k.user_id for k in komentar]
        + [tiket.assigned_to_user_id, tiket.opened_by_user_id],
    )

    def nama(user_id):
        return orang[user_id].full_name if user_id in orang else None

    satu = {
        "tiket": tiket,
        "kategori": service.ambil_kategori(db_session, tiket.category_id),
        "pelanggan": (
            customer_service.ambil_pelanggan(db_session, user, tiket.customer_id)
            if tiket.customer_id else None
        ),
        "langganan": (
            subscription_service.ambil_langganan(db_session, user, tiket.subscription_id)
            if tiket.subscription_id else None
        ),
        "pembuka": nama(tiket.opened_by_user_id),
        "petugas": nama(tiket.assigned_to_user_id),
        "komentar": [(k, orang.get(k.user_id)) for k in komentar],
        "evidence": service.evidence_per_langkah(lampiran),
        "lampiran": [b for b in lampiran if b.comment_id is None],
        "sla": service.terlambat(tiket),
    }
    return _kirim_pdf_tiket(
        f"{tiket.number.replace('/', '-')}.pdf",
        judul=f"Laporan Tiket {tiket.number}",
        subjudul=tiket.title,
        ringkas=False,
        baris=[satu],
    )


@bp.get("/tiket.pdf")
@require_role(*BACA)
def ekspor_daftar_pdf():
    """Laporan daftar tiket sesuai filter yang sedang aktif di layar."""
    from app.modules.tickets.models import STATUS_TUTUP

    user = current_user()
    filter_aktif = _filter_tiket()
    hasil = service.daftar_untuk_ekspor(db_session, user, **filter_aktif)[: service.BATAS_PDF]
    pelanggan = service.pelanggan_tiket(db_session, [t.customer_id for t, _ in hasil])
    baris = [
        {"tiket": tiket, "kategori": kategori,
         "pelanggan": pelanggan.get(tiket.customer_id), "sla": service.terlambat(tiket)}
        for tiket, kategori in hasil
    ]
    saring = [
        f"{nama}: {nilai}" for nama, nilai in (
            ("cari", filter_aktif.get("q")),
            ("status", LABEL_STATUS.get(filter_aktif.get("status"))),
            ("prioritas", LABEL_PRIORITAS.get(filter_aktif.get("prioritas"))),
        ) if nilai
    ]
    return _kirim_pdf_tiket(
        "laporan-tiket.pdf",
        judul="Laporan Ticketing",
        subjudul=("Disaring — " + ", ".join(saring)) if saring else "Semua tiket",
        ringkas=True,
        baris=baris,
        hitung={
            "terbuka": sum(1 for s in baris if s["tiket"].status not in STATUS_TUTUP),
            "kritis": sum(1 for s in baris if s["tiket"].priority == "kritis"),
            "telat": sum(
                1 for s in baris if s["sla"]["respons_lewat"] or s["sla"]["selesai_lewat"]
            ),
        },
    )


@bp.get("/tiket.csv")
@require_role(*BACA)
def ekspor_daftar():
    """Daftar tiket sesuai filter yang sedang aktif di layar."""
    from flask import Response

    baris = service.daftar_untuk_ekspor(db_session, current_user(), **_filter_tiket())

    # Nama berkas mengatakan kalau isinya terpotong. Berkas yang tampak utuh
    # padahal kehilangan segalanya setelah baris ke-20.000 adalah kegagalan
    # yang tidak pernah ketahuan — persis yang dijaga docstring `_query_daftar`.
    terpotong = len(baris) >= service.BATAS_EKSPOR
    nama = f"tiket-terpotong-{service.BATAS_EKSPOR}.csv" if terpotong else "tiket.csv"

    return Response(
        service.csv_daftar_tiket(baris),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nama}"'},
    )


@bp.route("/tiket/<int:tiket_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def ubah(tiket_id: int):
    user = current_user()
    tiket = service.ambil(db_session, user, tiket_id)
    form = TiketForm(obj=tiket)
    _isi_pilihan(form, user)

    if form.validate_on_submit():
        try:
            service.ubah(db_session, user, tiket_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Tiket disimpan.", "sukses")
            return redirect(url_for("tickets.detail", tiket_id=tiket_id))

    return render_template("tickets/form.html", form=form, tiket=tiket)


@bp.post("/tiket/<int:tiket_id>/status")
@require_role(*TULIS)
def ubah_status(tiket_id: int):
    user = current_user()
    form = StatusForm()
    # Pilihan divalidasi service; di sini daftarnya dibiarkan terbuka supaya
    # pesan galatnya datang dari aturan transisi, bukan dari "Pilihan tidak sah".
    form.status.choices = [(s, LABEL_STATUS[s]) for s in LABEL_STATUS]

    if form.validate_on_submit():
        try:
            service.ubah_status(
                db_session, user, tiket_id, form.status.data, form.resolution.data
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Status tiket diperbarui.", "sukses")
    else:
        flash("Permintaan tidak sah. Coba lagi dari halaman tiket.", "bahaya")

    return redirect(url_for("tickets.detail", tiket_id=tiket_id))


@bp.post("/tiket/<int:tiket_id>/komentar")
@require_role(*TULIS)
def komentar(tiket_id: int):
    """Menambah satu langkah penanganan beserta lampiran evidence-nya.

    Langkah dan evidence-nya disimpan dalam satu transaksi: foto yang ditolak
    membatalkan langkahnya juga, supaya tidak ada langkah "lihat foto
    terlampir" yang fotonya tidak ada.
    """
    # Beberapa foto ponsel sekaligus melewati batas unggah umum 8 MB.
    request.max_content_length = 40 * 1024 * 1024
    form = KomentarForm()
    tujuan = redirect(url_for("tickets.detail", tiket_id=tiket_id) + "#penanganan")
    if not form.validate_on_submit():
        for pesan in form.body.errors:
            flash(pesan, "bahaya")
        return tujuan

    berkas = [b for b in request.files.getlist("evidence") if b and b.filename]
    if len(berkas) > service.BATAS_EVIDENCE:
        flash(f"Maksimal {service.BATAS_EVIDENCE} lampiran per langkah.", "bahaya")
        return tujuan
    try:
        langkah = service.tambah_komentar(
            db_session, current_user(), tiket_id, form.body.data,
            is_internal=form.is_internal.data,
        )
        for satu in berkas:
            service.unggah_lampiran(
                db_session, current_user(), tiket_id, satu.stream, satu.filename,
                current_app.config["UPLOAD_DIR"], comment_id=langkah.id,
            )
    except (GalatDomain, FileError) as galat:
        db_session.rollback()
        flash(f"Penanganan tidak disimpan. {galat}", "bahaya")
        return tujuan
    db_session.commit()
    flash("Langkah penanganan ditambahkan.", "sukses")
    return tujuan


@bp.post("/tiket/<int:tiket_id>/lampiran")
@require_role(*TULIS)
def lampiran_unggah(tiket_id: int):
    form = LampiranTiketForm()
    if form.validate_on_submit():
        try:
            service.unggah_lampiran(
                db_session,
                current_user(),
                tiket_id,
                form.berkas.data.stream,
                form.berkas.data.filename,
                current_app.config["UPLOAD_DIR"],
            )
        except (GalatDomain, FileError) as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Lampiran diunggah.", "sukses")
    else:
        for pesan in form.berkas.errors:
            flash(pesan, "bahaya")
    return redirect(url_for("tickets.detail", tiket_id=tiket_id))


@bp.get("/tiket/lampiran/<int:lampiran_id>/lihat")
@require_role(*BACA)
def lampiran_lihat(lampiran_id: int):
    """Menampilkan foto evidence di halaman. Hanya gambar; selain itu diunduh."""
    from app.core.files import sajikan_sebaris

    lampiran = service.ambil_lampiran(db_session, current_user(), lampiran_id)
    if lampiran.mime not in ("image/png", "image/jpeg"):
        return redirect(url_for("tickets.lampiran_unduh", lampiran_id=lampiran_id))
    return sajikan_sebaris(
        lampiran.path, lampiran.original_name, lampiran.mime,
        current_app.config["UPLOAD_DIR"],
    )


@bp.get("/tiket/layanan-customer/<int:customer_id>")
@require_role(*BACA)
def layanan_customer(customer_id: int):
    """Layanan milik satu customer, untuk mengisi pilihan di formulir tiket
    begitu customernya dipilih."""
    from flask import jsonify

    baris = subscription_service.daftar_langganan(db_session, current_user(), customer_id)
    return jsonify(
        [
            {"id": langganan.id, "teks": f"{langganan.service_no or '—'} — {paket.name}"}
            for langganan, paket, _kategori in baris
        ]
    )


@bp.get("/tiket/lampiran/<int:lampiran_id>/unduh")
@require_role(*BACA)
def lampiran_unduh(lampiran_id: int):
    lampiran = service.ambil_lampiran(db_session, current_user(), lampiran_id)
    return sajikan(
        lampiran.path,
        lampiran.original_name,
        lampiran.mime,
        current_app.config["UPLOAD_DIR"],
    )


def _rentang_laporan():
    """Rentang tanggal laporan; bawaannya bulan berjalan.

    `akhir` diperlakukan eksklusif di service, jadi tanggal akhir yang dipilih
    pengguna ikut terhitung penuh — tanpa ini tiket yang dibuka pukul 10 pagi
    di tanggal akhir hilang dari laporan.
    """
    from datetime import date, timedelta

    mulai = request.args.get("mulai", type=date.fromisoformat) or waktu.awal_bulan()
    akhir = request.args.get("akhir", type=date.fromisoformat) or waktu.hari_ini()
    return mulai, akhir, akhir + timedelta(days=1)


@bp.get("/tiket/laporan")
@require_role(*BACA)
def laporan():
    mulai, akhir, batas = _rentang_laporan()
    return render_template(
        "tickets/laporan.html",
        baris=service.laporan_sla(db_session, current_user(), mulai, batas),
        mulai=mulai,
        akhir=akhir,
    )


@bp.get("/tiket/laporan.csv")
@require_role(*BACA)
def laporan_csv():
    from flask import Response

    mulai, _akhir, batas = _rentang_laporan()
    isi = service.csv_sla(
        service.laporan_sla(db_session, current_user(), mulai, batas)
    )
    return Response(
        isi,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="sla-tiket.csv"'},
    )


# --- Kategori -------------------------------------------------------------


@bp.get("/tiket/kategori")
@require_role(*BACA)
def kategori_daftar():
    return render_template(
        "tickets/kategori_daftar.html",
        daftar=service.daftar_kategori(db_session),
        form_hapus=HapusTiketForm(),
        **_konteks_label(),
    )


@bp.route("/tiket/kategori/baru", methods=["GET", "POST"])
@require_role(*MASTER)
def kategori_baru():
    form = KategoriTiketForm()
    if form.validate_on_submit():
        service.tambah_kategori(db_session, current_user(), form.data)
        db_session.commit()
        flash("Kategori ditambahkan.", "sukses")
        return redirect(url_for("tickets.kategori_daftar"))
    return render_template("tickets/kategori_form.html", form=form, kategori=None)


@bp.route("/tiket/kategori/<int:kategori_id>/ubah", methods=["GET", "POST"])
@require_role(*MASTER)
def kategori_ubah(kategori_id: int):
    kategori = service.ambil_kategori(db_session, kategori_id)
    form = KategoriTiketForm(obj=kategori)
    if form.validate_on_submit():
        service.ubah_kategori(db_session, current_user(), kategori_id, form.data)
        db_session.commit()
        flash("Kategori disimpan.", "sukses")
        return redirect(url_for("tickets.kategori_daftar"))
    return render_template("tickets/kategori_form.html", form=form, kategori=kategori)


@bp.post("/tiket/kategori/<int:kategori_id>/hapus")
@require_role(*MASTER)
def kategori_hapus(kategori_id: int):
    if not HapusTiketForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("tickets.kategori_daftar"))
    try:
        service.hapus_kategori(db_session, current_user(), kategori_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash("Kategori dihapus.", "sukses")
    return redirect(url_for("tickets.kategori_daftar"))
