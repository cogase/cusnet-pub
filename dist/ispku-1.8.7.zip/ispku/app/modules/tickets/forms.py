"""Formulir modul tiket.

Pilihan cabang, kategori, pelanggan, dan petugas diisi rute — daftarnya
bergantung hak akses aktor, dan formulir tidak boleh melakukan query.
"""

from app.core.forms import FormDasar
from flask_wtf.file import FileAllowed, FileField, FileRequired
from wtforms import BooleanField, StringField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange, Optional

from app.modules.customers.forms import PilihanIndonesia
from app.modules.tickets.models import PRIORITAS, STATUS_TIKET

LABEL_PRIORITAS = {
    "rendah": "Rendah",
    "sedang": "Sedang",
    "tinggi": "Tinggi",
    "kritis": "Kritis",
}

LABEL_STATUS = {
    "baru": "Baru",
    "proses": "Diproses",
    "pending": "Menunggu Pihak Lain",
    "selesai": "Selesai",
    "ditutup": "Ditutup",
}

NADA_PRIORITAS = {
    "rendah": "netral",
    "sedang": "peringatan",
    "tinggi": "jingga",
    "kritis": "bahaya",
}

NADA_STATUS = {
    "baru": "ungu",
    "proses": "peringatan",
    "pending": "jingga",
    "selesai": "sukses",
    "ditutup": "netral",
}


class TiketForm(FormDasar):
    branch_id = PilihanIndonesia("Cabang", coerce=int)
    category_id = PilihanIndonesia("Kategori", coerce=int)
    priority = PilihanIndonesia(
        "Prioritas", choices=[(p, LABEL_PRIORITAS[p]) for p in PRIORITAS]
    )
    title = StringField(
        "Judul",
        validators=[DataRequired(message="Judul wajib diisi."), Length(max=200)],
    )
    description = TextAreaField(
        "Uraian",
        validators=[
            DataRequired(message="Uraian wajib diisi."),
            Length(max=5000),
        ],
    )
    # Pelanggan dan langganan opsional: gangguan backbone tidak menempel ke
    # siapa pun, dan tiket sering dibuka sebelum diketahui layanan mana yang
    # terdampak.
    customer_id = PilihanIndonesia("Customer", coerce=int, validators=[Optional()])
    subscription_id = PilihanIndonesia("Layanan", coerce=int, validators=[Optional()])
    assigned_to_user_id = PilihanIndonesia("Ditugaskan ke", coerce=int, validators=[Optional()])


class KomentarForm(FormDasar):
    """Satu langkah penanganan. Nama kelas dan tabelnya tetap "komentar";
    yang berubah hanya sebutannya di layar."""

    body = TextAreaField(
        "Langkah Penanganan",
        validators=[DataRequired(message="Penanganan tidak boleh kosong."), Length(max=5000)],
        render_kw={"placeholder": "Contoh: Cek OTDR dari POP, putus di 2,3 km. Tim menuju lokasi."},
    )
    # Bawaannya internal. Yang salah arah lebih murah daripada catatan teknis
    # yang tanpa sengaja terkirim ke pelanggan.
    is_internal = BooleanField("Catatan internal", default=True)


class StatusForm(FormDasar):
    status = PilihanIndonesia(
        "Status", choices=[(s, LABEL_STATUS[s]) for s in STATUS_TIKET]
    )
    resolution = TextAreaField("Penyelesaian", validators=[Optional(), Length(max=5000)])


class LampiranTiketForm(FormDasar):
    berkas = FileField(
        "Berkas",
        validators=[
            FileRequired(message="Pilih berkas dulu."),
            FileAllowed(["png", "jpg", "jpeg", "pdf"], "Hanya JPG, PNG, dan PDF."),
        ],
    )


class KategoriTiketForm(FormDasar):
    code = StringField(
        "Kode",
        validators=[DataRequired(message="Kode wajib diisi."), Length(max=20)],
    )
    name = StringField(
        "Nama Kategori",
        validators=[DataRequired(message="Nama wajib diisi."), Length(max=120)],
    )
    default_priority = PilihanIndonesia(
        "Prioritas Bawaan", choices=[(p, LABEL_PRIORITAS[p]) for p in PRIORITAS]
    )
    sla_response_hours = PilihanIndonesia(
        "SLA Respons",
        coerce=int,
        choices=[(1, "1 jam"), (2, "2 jam"), (4, "4 jam"), (8, "8 jam"), (24, "24 jam")],
        validators=[NumberRange(min=1)],
    )
    sla_resolve_hours = PilihanIndonesia(
        "SLA Penyelesaian",
        coerce=int,
        choices=[
            (4, "4 jam"), (8, "8 jam"), (24, "1 hari"), (48, "2 hari"),
            (72, "3 hari"), (120, "5 hari"), (168, "7 hari"),
        ],
        validators=[NumberRange(min=1)],
    )
    is_active = BooleanField("Aktif", default=True)


class HapusTiketForm(FormDasar):
    """Formulir kosong; ada hanya untuk token CSRF."""
