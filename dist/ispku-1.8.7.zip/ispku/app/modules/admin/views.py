from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.pagination import per_halaman_dari
from app.core.rbac import is_cross_branch, require_role
from app.modules.admin import service
from app.modules.admin.forms import CabangForm, UserForm
from app.modules.customers.forms import HapusForm

bp = Blueprint("admin", __name__)


@bp.get("/cabang")
@require_role("superadmin", "admin_cabang", "billing", "teknis", "viewer")
def cabang_daftar():
    halaman = service.daftar_cabang(
        db_session,
        current_user(),
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "admin/cabang_daftar.html", halaman=halaman, form_hapus=HapusForm()
    )


# Membuat dan menghapus cabang adalah tindakan lintas cabang: peran yang
# terikat satu cabang tidak akan pernah bisa membuka cabang yang baru ia buat,
# dan tidak bisa menghapus cabangnya sendiri selama akunnya masih di sana.
@bp.route("/cabang/baru", methods=["GET", "POST"])
@require_role("superadmin")
def cabang_baru():
    form = CabangForm()
    if form.validate_on_submit():
        try:
            service.buat_cabang(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.cabang_daftar"))
    return render_template("admin/cabang_form.html", form=form, judul="Tambah Cabang")


@bp.route("/cabang/<int:branch_id>/ubah", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang", "billing")
def cabang_ubah(branch_id: int):
    cabang = service.ambil_cabang(db_session, current_user(), branch_id)
    form = CabangForm(obj=cabang)
    if form.validate_on_submit():
        try:
            service.ubah_cabang(db_session, current_user(), branch_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.cabang_daftar"))
    return render_template("admin/cabang_form.html", form=form, judul="Ubah Cabang")


@bp.post("/cabang/<int:branch_id>/hapus")
@require_role("superadmin")
def cabang_hapus(branch_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman cabang.", "bahaya")
        return redirect(url_for("admin.cabang_daftar"))
    try:
        service.hapus_cabang(db_session, current_user(), branch_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash("Cabang dihapus.", "sukses")
    return redirect(url_for("admin.cabang_daftar"))


@bp.get("/pengaturan/user")
@require_role("superadmin", "admin_cabang", "billing", "teknis", "viewer")
def user_daftar():
    halaman = service.daftar_user_dengan_cabang(
        db_session,
        current_user(),
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template("admin/user_daftar.html", halaman=halaman)


@bp.get("/pengaturan/audit")
@require_role("superadmin", "admin_cabang", "billing", "teknis", "viewer")
def audit_daftar():
    """Audit log, hanya-baca; isinya disaring per peran di service."""
    from datetime import date

    def _tanggal(nama):
        teks = (request.args.get(nama) or "").strip()
        try:
            return date.fromisoformat(teks) if teks else None
        except ValueError:
            return None

    filter_ = {
        "actor_user_id": request.args.get("actor_user_id", type=int),
        "action": (request.args.get("action") or "").strip(),
        "entity_type": (request.args.get("entity_type") or "").strip(),
        "dari": _tanggal("dari"),
        "sampai": _tanggal("sampai"),
    }
    halaman = service.daftar_audit(
        db_session,
        current_user(),
        filter_,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "admin/audit_daftar.html",
        halaman=halaman,
        filter=filter_,
        pilihan=service.pilihan_audit(db_session, current_user()),
    )


@bp.route("/pengaturan/user/baru", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang")
def user_baru():
    form = UserForm()
    form.branch_id.choices = _pilihan_cabang()
    form.role.choices = _pilihan_peran()
    if form.validate_on_submit():
        data = _data_user(form)
        try:
            service.buat_user(db_session, current_user(), data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.user_daftar"))
    return render_template("admin/user_form.html", form=form, judul="Tambah User")


@bp.route("/pengaturan/user/<int:user_id>/ubah", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang")
def user_ubah(user_id: int):
    target = service.ambil_user(db_session, current_user(), user_id)
    form = UserForm(obj=target)
    form.branch_id.choices = _pilihan_cabang()
    form.role.choices = _pilihan_peran()
    if form.validate_on_submit():
        data = _data_user(form)
        try:
            service.ubah_user(db_session, current_user(), user_id, data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.user_daftar"))
    return render_template("admin/user_form.html", form=form, judul="Ubah User")


def _data_user(form) -> dict:
    data = dict(form.data)
    if data.get("branch_id") in (0, None, ""):
        data["branch_id"] = None
    return data


def _pilihan_cabang():
    cabang = service.semua_cabang(db_session, current_user())
    pilihan = [(c.id, f"{c.code} — {c.name}") for c in cabang]
    if is_cross_branch(current_user()):
        pilihan.insert(0, (0, "— Tanpa cabang (lintas cabang) —"))
    return pilihan


def _pilihan_peran():
    return [(r, r) for r in service.peran_dapat_diberikan(current_user())]


# --- Profil dan notifikasi milik pengguna sendiri -----------------------------

SEMUA_PERAN = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")


@bp.route("/profil", methods=["GET", "POST"])
@require_role(*SEMUA_PERAN)
def profil():
    """Profil sendiri: data diri dan sandi. Dua formulir, satu halaman."""
    from app.core.errors import GalatDomain
    from app.modules.admin.forms import ProfilForm, SandiForm

    user = current_user()
    form_profil = ProfilForm(obj=user, prefix="p")
    form_sandi = SandiForm(prefix="s")
    cabang = service.nama_cabang(db_session, user.branch_id)

    if request.method == "POST":
        bagian = request.form.get("bagian")
        try:
            if bagian == "profil" and form_profil.validate():
                service.ubah_profil(
                    db_session, user,
                    {"full_name": form_profil.full_name.data, "email": form_profil.email.data},
                )
                db_session.commit()
                flash("Profil disimpan.", "sukses")
                return redirect(url_for("admin.profil"))
            if bagian == "sandi" and form_sandi.validate():
                service.ubah_sandi_sendiri(
                    db_session, user, form_sandi.sandi_lama.data, form_sandi.sandi_baru.data
                )
                db_session.commit()
                flash("Sandi diganti.", "sukses")
                return redirect(url_for("admin.profil"))
        except GalatDomain as galat:
            db_session.rollback()
            form = form_profil if bagian == "profil" else form_sandi
            getattr(form, galat.field).errors.append(str(galat))

    return render_template(
        "admin/profil.html", form_profil=form_profil, form_sandi=form_sandi, cabang=cabang
    )


@bp.get("/notifikasi")
@require_role(*SEMUA_PERAN)
def notifikasi():
    """Isi lonceng di topbar, diambil skrip setelah halaman tampil."""
    from flask import jsonify

    from app.modules.admin import notifikasi as modul

    rangkuman = modul.rangkum(db_session, current_user())
    response = jsonify(
        jumlah=rangkuman["jumlah_baru"],
        html=render_template("admin/_notifikasi.html", **rangkuman),
    )
    response.headers["Cache-Control"] = "no-store, max-age=0"
    return response


@bp.post("/notifikasi/dibaca")
@require_role(*SEMUA_PERAN)
def notifikasi_dibaca():
    from flask import jsonify

    from app.modules.admin import notifikasi as modul

    if not HapusForm().validate_on_submit():
        return jsonify(error="Permintaan tidak sah."), 400
    modul.tandai_dibaca(db_session, current_user())
    db_session.commit()
    return jsonify(ok=True)
