from app.core.forms import FormDasar
from wtforms import BooleanField, PasswordField, SelectField, StringField
from wtforms.validators import DataRequired, Email, Length, Optional

from app.modules.admin.models import ROLES


class CabangForm(FormDasar):
    code = StringField(
        "Kode Cabang",
        validators=[DataRequired(message="Kode cabang wajib diisi."), Length(max=8)],
    )
    name = StringField(
        "Nama Cabang",
        validators=[DataRequired(message="Nama cabang wajib diisi."), Length(max=120)],
    )
    address = StringField("Alamat", validators=[Optional(), Length(max=500)])
    phone = StringField("Telepon", validators=[Optional(), Length(max=40)])
    is_active = BooleanField("Aktif", default=True)


class UserForm(FormDasar):
    username = StringField(
        "Username",
        validators=[DataRequired(message="Username wajib diisi."), Length(max=60)],
    )
    email = StringField(
        "Email",
        validators=[
            DataRequired(message="Email wajib diisi."),
            Email(message="Format email tidak sah."),
        ],
    )
    full_name = StringField(
        "Nama Lengkap",
        validators=[DataRequired(message="Nama lengkap wajib diisi.")],
    )
    role = SelectField("Peran", choices=[(r, r) for r in ROLES])
    branch_id = SelectField("Cabang", coerce=int, validators=[Optional()])
    password = PasswordField("Password", validators=[Optional(), Length(min=8)])
    is_active = BooleanField("Aktif", default=True)


class ProfilForm(FormDasar):
    """Data diri yang boleh disunting pemilik akunnya sendiri."""

    full_name = StringField(
        "Nama Lengkap",
        validators=[DataRequired(message="Nama lengkap wajib diisi."), Length(max=120)],
    )
    email = StringField(
        "Email",
        validators=[
            DataRequired(message="Email wajib diisi."),
            Email(message="Format email tidak sah."),
            Length(max=160),
        ],
    )


class SandiForm(FormDasar):
    sandi_lama = PasswordField(
        "Sandi Lama", validators=[DataRequired(message="Isi sandi lama Anda.")]
    )
    sandi_baru = PasswordField(
        "Sandi Baru",
        validators=[
            DataRequired(message="Isi sandi baru."),
            Length(min=8, max=128, message="Sandi baru minimal 8 karakter."),
        ],
    )
    konfirmasi = PasswordField(
        "Ulangi Sandi Baru", validators=[DataRequired(message="Ulangi sandi baru.")]
    )

    def validate_konfirmasi(self, field):
        from wtforms.validators import ValidationError

        if field.data != self.sandi_baru.data:
            raise ValidationError("Kedua sandi baru tidak sama.")
