from sqlalchemy import func, select

from app.core import audit
from app.core.auth import hash_password
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.pagination import Page, paginate, paginate_rows
from app.core.rbac import AccessDenied, _branch_of, assert_branch_access, is_cross_branch, scoped
from app.modules.admin.models import ROLES, Branch, User

KOLOM_CABANG = ("code", "name", "address", "phone", "is_active")
KOLOM_USER = (
    "username",
    "email",
    "full_name",
    "role",
    "branch_id",
    "is_active",
)

PERAN_DAPAT_DIBERIKAN: dict[str, tuple[str, ...]] = {
    "superadmin": ROLES,
    "admin_cabang": ("admin_cabang", "billing", "teknis", "viewer"),
}


class NilaiSudahDipakai(GalatDomain):
    """Nilai unik yang diminta sudah dipakai baris lain."""


def peran_dapat_diberikan(aktor) -> tuple[str, ...]:
    """Peran yang boleh diberikan aktor kepada user lain.

    Hanya superadmin yang boleh mencetak superadmin baru. Tanpa batas ini,
    admin cabang dapat mengangkat dirinya sendiri menjadi lintas cabang.
    """
    return PERAN_DAPAT_DIBERIKAN.get(aktor.role, ())


def _pastikan_peran_boleh(aktor, peran: str | None) -> None:
    if peran is None:
        return
    if peran not in peran_dapat_diberikan(aktor):
        raise AccessDenied(
            f"Anda tidak berhak memberikan peran '{peran}'."
        )


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def _saring_audit(query, user):
    """Membatasi audit log ke yang pantas dilihat `user`.

    Baris audit tidak menyimpan `branch_id`, jadi cabangnya diambil dari
    aktornya: peran yang terikat cabang hanya melihat tindakan rekan
    secabangnya (tindakan sistem dan cabang lain tidak ikut). Peran tanpa
    akses billing juga tidak melihat entitas yang memuat nominal.
    """
    from app.core import rbac
    from app.modules.admin.models import AuditLog

    if not is_cross_branch(user):
        query = query.where(User.branch_id == _branch_of(user))
    if user.role in rbac.PERAN_TANPA_KEUANGAN:
        query = query.where(
            AuditLog.entity_type.notin_(rbac.ENTITAS_AUDIT_KEUANGAN)
        )
    return query


def daftar_audit(
    sesi, user, filter_: dict | None = None, page: int = 1, per_page: int = 25
) -> Page:
    """Audit log, terbaru lebih dulu, beserta nama aktornya.

    Semua peran boleh membaca, tetapi hanya sebatas `_saring_audit`.
    """
    from app.modules.admin.models import AuditLog

    filter_ = filter_ or {}
    query = (
        select(AuditLog, User)
        .join(User, AuditLog.actor_user_id == User.id, isouter=True)
        .order_by(AuditLog.created_at.desc(), AuditLog.id.desc())
    )
    query = _saring_audit(query, user)

    if filter_.get("actor_user_id"):
        query = query.where(AuditLog.actor_user_id == filter_["actor_user_id"])
    if filter_.get("action"):
        query = query.where(AuditLog.action == filter_["action"])
    if filter_.get("entity_type"):
        query = query.where(AuditLog.entity_type == filter_["entity_type"])
    if filter_.get("dari"):
        query = query.where(AuditLog.created_at >= filter_["dari"])
    if filter_.get("sampai"):
        # Batas atas inklusif: pengguna yang mengetik tanggal hari ini
        # bermaksud "sampai akhir hari ini", bukan "sampai jam 00:00".
        from datetime import timedelta

        query = query.where(
            AuditLog.created_at < filter_["sampai"] + timedelta(days=1)
        )

    from app.core.pagination import paginate_rows

    return paginate_rows(sesi, query, page, per_page)


def pilihan_audit(sesi, user) -> dict:
    """Nilai yang benar-benar ada di audit log, untuk isi kotak filter.

    Diambil dari data, bukan dari daftar tetap: aksi dan jenis entitas
    bertambah setiap modul baru, dan daftar tetap akan ketinggalan diam-diam.
    """
    from app.modules.admin.models import AuditLog

    def _terlihat(kolom):
        return _saring_audit(
            select(kolom)
            .select_from(AuditLog)
            .join(User, AuditLog.actor_user_id == User.id, isouter=True),
            user,
        ).distinct()

    aksi = sesi.execute(
        _terlihat(AuditLog.action).order_by(AuditLog.action)
    ).scalars().all()
    entitas = sesi.execute(
        _terlihat(AuditLog.entity_type).order_by(AuditLog.entity_type)
    ).scalars().all()
    aktor = sesi.execute(
        select(User)
        .where(User.id.in_(_terlihat(AuditLog.actor_user_id)))
        .order_by(User.username)
    ).scalars().all()
    return {"aksi": list(aksi), "entitas": list(entitas), "aktor": list(aktor)}


def penulis_komentar(sesi, user_ids) -> dict:
    """Peta id user ke barisnya, untuk kolom penulis di ekspor dan daftar.

    Satu query untuk seluruh id sekaligus; memanggil `sesi.get` per komentar
    berarti satu query per baris pada tiket yang riwayatnya panjang.
    """
    bersih = {satu for satu in (user_ids or []) if satu}
    if not bersih:
        return {}
    baris = sesi.execute(select(User).where(User.id.in_(bersih))).scalars().all()
    return {satu.id: satu for satu in baris}


def _query_cabang(user):
    query = select(Branch).order_by(Branch.code)
    if not is_cross_branch(user):
        query = query.where(Branch.id == _branch_of(user))
    return query


def daftar_cabang(sesi, user, page: int = 1, per_page: int = 10) -> Page:
    return paginate(sesi, _query_cabang(user), page, per_page)


def semua_cabang(sesi, user) -> list[Branch]:
    """Seluruh cabang yang boleh dilihat `user`, tanpa halaman. Untuk dropdown."""
    return list(sesi.execute(_query_cabang(user)).scalars().all())


def ambil_cabang(sesi, user, branch_id: int) -> Branch:
    cabang = sesi.get(Branch, branch_id)
    if cabang is None:
        raise TidakDitemukan("Cabang tidak ditemukan.")
    assert_branch_access(user, cabang.id)
    return cabang


def buat_cabang(sesi, user, data: dict) -> Branch:
    bentrok = sesi.execute(
        select(Branch).where(Branch.code == data.get("code"))
    ).scalars().first()
    if bentrok is not None:
        raise NilaiSudahDipakai("code", f"Kode cabang '{data.get('code')}' sudah dipakai.")

    cabang = Branch(**{k: data.get(k) for k in KOLOM_CABANG if k in data})
    sesi.add(cabang)
    sesi.flush()
    audit.record(
        sesi, "create", "branch", cabang.id,
        after=_potret(cabang, KOLOM_CABANG), aktor=user,
    )
    return cabang


def ubah_cabang(sesi, user, branch_id: int, data: dict) -> Branch:
    cabang = ambil_cabang(sesi, user, branch_id)

    if "code" in data:
        bentrok = sesi.execute(
            select(Branch).where(Branch.code == data["code"], Branch.id != branch_id)
        ).scalars().first()
        if bentrok is not None:
            raise NilaiSudahDipakai("code", f"Kode cabang '{data['code']}' sudah dipakai.")

    sebelum = _potret(cabang, KOLOM_CABANG)

    for nama in KOLOM_CABANG:
        if nama in data:
            setattr(cabang, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "branch", cabang.id,
        before=sebelum, after=_potret(cabang, KOLOM_CABANG),
        aktor=user,
    )
    return cabang


class CabangMasihDipakai(GalatDomain):
    """Cabang masih memiliki akun, pelanggan, transaksi, atau inventaris."""


def hapus_cabang(sesi, user, branch_id: int) -> int:
    """Menghapus cabang kosong saja; data operasional tidak dihapus berantai."""
    cabang = ambil_cabang(sesi, user, branch_id)
    from app.modules.billing.models import Invoice
    from app.modules.customers.models import Customer
    from app.modules.inventory.models import Device, DevicePort, IpBlock, Site, Vlan
    from app.modules.tickets.models import Ticket, TicketAttachment

    pemakai = (
        ("akun pengguna", User),
        ("customer", Customer),
        ("invoice", Invoice),
        ("tiket", Ticket),
        ("lampiran tiket", TicketAttachment),
        ("site", Site),
        ("perangkat", Device),
        ("port", DevicePort),
        ("VLAN", Vlan),
        ("blok IP", IpBlock),
    )
    jumlah = {
        nama: sesi.execute(
            select(func.count(model.id)).where(model.branch_id == branch_id)
        ).scalar_one()
        for nama, model in pemakai
    }
    terpakai = [(nama, hitung) for nama, hitung in jumlah.items() if hitung]
    if terpakai:
        ringkasan = ", ".join(f"{hitung} {nama}" for nama, hitung in terpakai)
        raise CabangMasihDipakai(
            "branch_id",
            f"Cabang masih digunakan oleh {ringkasan}. Pindahkan atau hapus data terkait terlebih dahulu.",
        )

    sebelum = _potret(cabang, KOLOM_CABANG)
    sesi.delete(cabang)
    sesi.flush()
    audit.record(
        sesi, "delete", "branch", branch_id, before=sebelum, aktor=user
    )
    return branch_id


def daftar_user(sesi, user, page: int = 1, per_page: int = 10) -> Page:
    """Baris `User`. Dipakai pemilih petugas tiket dan pemilih sales.

    Bentuknya sengaja TIDAK diubah jadi `(User, Branch)` demi halaman Daftar
    User: tiga pemanggil lain memperlakukan `.items` sebagai `User`, dan
    mengubah bentuk kembalian di sini mematahkan ketiganya diam-diam — baru
    ketahuan saat dropdown petugas kosong di layar.
    """
    query = scoped(select(User).order_by(User.username), user, User)
    return paginate(sesi, query, page, per_page)


def daftar_user_dengan_cabang(
    sesi, user, page: int = 1, per_page: int = 10
) -> Page:
    """Baris `(User, Branch | None)` untuk halaman Daftar User.

    Cabang ikut diambil di sini supaya halaman bisa menyebut namanya.
    Merender `branch_id` mentah — angka `3` — tidak memberi tahu siapa pun
    cabang mana, dan mengambilnya per baris di templat berarti satu query
    tambahan untuk tiap user.
    """
    query = scoped(
        select(User, Branch)
        .outerjoin(Branch, Branch.id == User.branch_id)
        .order_by(User.username),
        user,
        User,
    )
    return paginate_rows(sesi, query, page, per_page)


def semua_user(sesi, user) -> list[User]:
    """Seluruh user yang boleh dilihat `user`, tanpa halaman.

    Untuk mengisi dropdown petugas dan sales. Dulu diambil lewat
    `daftar_user(per_page=200)`, yang memotong diam-diam: nama ke-201 hilang
    tanpa pesan, dan operator menyimpulkan akunnya belum dibuat.
    `app_user` adalah tabel staf — jumlahnya dibatasi kenyataan, bukan
    transaksi.
    """
    return list(
        sesi.execute(
            scoped(select(User).order_by(User.username), user, User)
        ).scalars().all()
    )


def ambil_user(sesi, aktor, user_id: int) -> User:
    target = sesi.get(User, user_id)
    if target is None:
        raise TidakDitemukan("User tidak ditemukan.")
    assert_branch_access(aktor, target.branch_id)
    return target


def buat_user(sesi, aktor, data: dict) -> User:
    _pastikan_peran_boleh(aktor, data.get("role"))
    if not is_cross_branch(aktor):
        assert_branch_access(aktor, data.get("branch_id"))

    bentrok_username = sesi.execute(
        select(User).where(User.username == data.get("username"))
    ).scalars().first()
    if bentrok_username is not None:
        raise NilaiSudahDipakai(
            "username", f"Username '{data.get('username')}' sudah dipakai."
        )

    bentrok_email = sesi.execute(
        select(User).where(User.email == data.get("email"))
    ).scalars().first()
    if bentrok_email is not None:
        raise NilaiSudahDipakai("email", f"Email '{data.get('email')}' sudah dipakai.")

    target = User(
        **{k: data.get(k) for k in KOLOM_USER if k in data},
        password_hash=hash_password(data["password"]),
    )
    sesi.add(target)
    sesi.flush()

    audit.record(
        sesi, "create", "user", target.id,
        after=_potret(target, KOLOM_USER), aktor=aktor,
    )
    return target


def ubah_user(sesi, aktor, user_id: int, data: dict) -> User:
    target = ambil_user(sesi, aktor, user_id)
    if target.role not in peran_dapat_diberikan(aktor):
        raise AccessDenied(
            f"Anda tidak berhak menyunting akun berperan '{target.role}'."
        )
    _pastikan_peran_boleh(aktor, data.get("role"))
    if "branch_id" in data and not is_cross_branch(aktor):
        assert_branch_access(aktor, data["branch_id"])

    if "username" in data:
        bentrok_username = sesi.execute(
            select(User).where(User.username == data["username"], User.id != target.id)
        ).scalars().first()
        if bentrok_username is not None:
            raise NilaiSudahDipakai(
                "username", f"Username '{data['username']}' sudah dipakai."
            )

    if "email" in data:
        bentrok_email = sesi.execute(
            select(User).where(User.email == data["email"], User.id != target.id)
        ).scalars().first()
        if bentrok_email is not None:
            raise NilaiSudahDipakai("email", f"Email '{data['email']}' sudah dipakai.")

    sebelum = _potret(target, KOLOM_USER)

    for nama in KOLOM_USER:
        if nama in data:
            setattr(target, nama, data[nama])
    if data.get("password"):
        target.password_hash = hash_password(data["password"])
    sesi.flush()

    sesudah = _potret(target, KOLOM_USER)
    if data.get("password"):
        sebelum["password_hash"] = "hash-lama"
        sesudah["password_hash"] = "hash-baru"

    audit.record(
        sesi, "update", "user", target.id,
        before=sebelum, after=sesudah,
        aktor=aktor,
    )
    return target


# --- Profil sendiri ---------------------------------------------------------


class SandiSalah(GalatDomain):
    """Sandi lama tidak cocok."""


def ubah_profil(sesi, user, data: dict) -> User:
    """Pengguna menyunting nama dan email miliknya sendiri.

    Peran, cabang, dan username tidak ikut: ketiganya menentukan apa yang
    boleh dilihat akun ini, dan itu keputusan admin.
    """
    nama = (data.get("full_name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    if not nama:
        raise NilaiSudahDipakai("full_name", "Nama lengkap wajib diisi.")
    bentrok = sesi.execute(
        select(User).where(func.lower(User.email) == email, User.id != user.id)
    ).scalars().first()
    if bentrok is not None:
        raise NilaiSudahDipakai("email", f"Email '{email}' sudah dipakai.")

    sebelum = {"full_name": user.full_name, "email": user.email}
    user.full_name = nama
    user.email = email
    sesi.flush()
    audit.record(
        sesi, "update", "user", user.id,
        before=sebelum, after={"full_name": user.full_name, "email": user.email},
        aktor=user,
    )
    return user


def ubah_sandi_sendiri(sesi, user, sandi_lama: str, sandi_baru: str) -> None:
    """Mengganti sandi setelah membuktikan sandi lamanya."""
    from app.core.auth import verify_password

    if not verify_password(sandi_lama or "", user.password_hash):
        raise SandiSalah("sandi_lama", "Sandi lama tidak cocok.")
    if len(sandi_baru or "") < 8:
        raise SandiSalah("sandi_baru", "Sandi baru minimal 8 karakter.")
    user.password_hash = hash_password(sandi_baru)
    sesi.flush()
    audit.record(
        sesi, "update", "user", user.id,
        before={"password_hash": "hash-lama"}, after={"password_hash": "hash-baru"},
        aktor=user,
    )


def nama_cabang(sesi, branch_id: int | None) -> str | None:
    if branch_id is None:
        return None
    cabang = sesi.get(Branch, branch_id)
    return cabang.name if cabang else None
