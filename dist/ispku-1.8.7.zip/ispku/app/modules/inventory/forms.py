"""Formulir inventaris jaringan.

Pilihan cabang dan site diisi rute — daftarnya bergantung hak akses aktor.
"""

from app.core.forms import FormDasar
from wtforms import BooleanField, IntegerField, StringField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange, Optional

from app.modules.customers.forms import PilihanIndonesia
from app.modules.inventory.models import (
    JENIS_BLOK_IP,
    JENIS_PERANGKAT,
    JENIS_PORT,
    JENIS_SITE,
    JENIS_VLAN,
    STATUS_PERANGKAT,
    STATUS_PORT,
)

LABEL_JENIS_SITE = {
    "pop": "POP",
    "datacenter": "Data Center",
    "tower": "Tower",
    "kantor": "Kantor",
    "lainnya": "Lainnya",
}

LABEL_JENIS_PERANGKAT = {
    "router": "Router",
    "switch": "Switch",
    "olt": "OLT",
    "onu": "ONU / ONT",
    "radio": "Radio",
    "server": "Server",
    "lainnya": "Lainnya",
}

LABEL_STATUS_PERANGKAT = {
    "aktif": "Aktif",
    "cadangan": "Cadangan",
    "rusak": "Rusak",
    "pensiun": "Pensiun",
}

NADA_STATUS_PERANGKAT = {
    "aktif": "sukses",
    "cadangan": "netral",
    "rusak": "bahaya",
    "pensiun": "netral",
}

LABEL_JENIS_PORT = {
    "access": "Access",
    "trunk": "Trunk",
    "uplink": "Uplink",
    "manajemen": "Manajemen",
}

LABEL_STATUS_PORT = {
    "bebas": "Bebas",
    "terpakai": "Terpakai",
    "rusak": "Rusak",
    "dicadangkan": "Dicadangkan",
}

NADA_STATUS_PORT = {
    "bebas": "sukses",
    "terpakai": "ungu",
    "rusak": "bahaya",
    "dicadangkan": "peringatan",
}

LABEL_JENIS_VLAN = {
    "pelanggan": "Pelanggan",
    "transit": "Transit",
    "manajemen": "Manajemen",
    "lainnya": "Lainnya",
}

LABEL_JENIS_BLOK = {"publik": "Publik", "privat": "Privat"}


class SiteForm(FormDasar):
    code = StringField(
        "Kode Site",
        validators=[DataRequired(message="Kode wajib diisi."), Length(max=20)],
    )
    name = StringField(
        "Nama Site",
        validators=[DataRequired(message="Nama wajib diisi."), Length(max=120)],
    )
    branch_id = PilihanIndonesia("Cabang", coerce=int)
    kind = PilihanIndonesia(
        "Jenis", choices=[(k, LABEL_JENIS_SITE[k]) for k in JENIS_SITE]
    )
    address = TextAreaField("Alamat", validators=[Optional(), Length(max=500)])
    # Koordinat sebagai teks lalu diubah ke Decimal di rute: `FloatField`
    # menyeret nilainya lewat float, dan titik yang bergeser beberapa meter
    # karena pembulatan biner adalah titik yang salah di peta.
    lat = StringField("Lintang", validators=[Optional(), Length(max=20)])
    lng = StringField("Bujur", validators=[Optional(), Length(max=20)])
    is_active = BooleanField("Aktif", default=True)
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=1000)])


class PerangkatForm(FormDasar):
    site_id = PilihanIndonesia("Site", coerce=int)
    name = StringField(
        "Nama Perangkat",
        validators=[DataRequired(message="Nama wajib diisi."), Length(max=120)],
    )
    kind = PilihanIndonesia(
        "Jenis", choices=[(k, LABEL_JENIS_PERANGKAT[k]) for k in JENIS_PERANGKAT]
    )
    brand = StringField("Merek", validators=[Optional(), Length(max=80)])
    model = StringField("Model", validators=[Optional(), Length(max=80)])
    mgmt_address = StringField(
        "Alamat Manajemen", validators=[Optional(), Length(max=120)]
    )
    serial_number = StringField("Nomor Seri", validators=[Optional(), Length(max=80)])
    status = PilihanIndonesia(
        "Status", choices=[(s, LABEL_STATUS_PERANGKAT[s]) for s in STATUS_PERANGKAT]
    )
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=1000)])


class PortForm(FormDasar):
    name = StringField(
        "Nama Port",
        validators=[DataRequired(message="Nama port wajib diisi."), Length(max=60)],
    )
    kind = PilihanIndonesia(
        "Jenis", choices=[(k, LABEL_JENIS_PORT[k]) for k in JENIS_PORT]
    )
    speed_mbps = IntegerField(
        "Kecepatan (Mbps)",
        validators=[Optional(), NumberRange(min=0, max=1_000_000)],
    )
    status = PilihanIndonesia(
        "Status", choices=[(s, LABEL_STATUS_PORT[s]) for s in STATUS_PORT]
    )
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=500)])


class AlokasiPortForm(FormDasar):
    subscription_id = PilihanIndonesia("Langganan", coerce=int)


class VlanForm(FormDasar):
    vlan_id = IntegerField(
        "Nomor VLAN",
        validators=[
            DataRequired(message="Nomor VLAN wajib diisi."),
            NumberRange(min=1, max=4094, message="Nomor VLAN harus antara 1 dan 4094."),
        ],
    )
    name = StringField(
        "Nama",
        validators=[DataRequired(message="Nama wajib diisi."), Length(max=120)],
    )
    branch_id = PilihanIndonesia("Cabang", coerce=int)
    site_id = PilihanIndonesia("Site", coerce=int, validators=[Optional()])
    kind = PilihanIndonesia(
        "Jenis", choices=[(k, LABEL_JENIS_VLAN[k]) for k in JENIS_VLAN]
    )
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=500)])


class BlokIpForm(FormDasar):
    cidr = StringField(
        "Blok (CIDR)",
        validators=[DataRequired(message="Blok IP wajib diisi."), Length(max=60)],
    )
    kind = PilihanIndonesia(
        "Jenis", choices=[(k, LABEL_JENIS_BLOK[k]) for k in JENIS_BLOK_IP]
    )
    branch_id = PilihanIndonesia("Cabang", coerce=int)
    site_id = PilihanIndonesia("Site", coerce=int, validators=[Optional()])
    gateway = StringField("Gateway", validators=[Optional(), Length(max=60)])
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=500)])


class HapusInventarisForm(FormDasar):
    """Formulir kosong; ada hanya untuk token CSRF."""
