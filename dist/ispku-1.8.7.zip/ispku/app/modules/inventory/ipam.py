"""IPAM sederhana: mencocokkan alamat IP langganan dengan blok IP terdaftar.

Alamat IP pelanggan hidup di satu tempat saja — kolom `subscription.ip_address`
yang diisi orang yang mendata layanannya. Modul ini **tidak** menyalinnya ke
tabel alokasi tersendiri: dua salinan alamat yang sama pasti berbeda pada
suatu hari, dan yang di layar Network akan bercerita lain daripada yang di
halaman pelanggan.

Yang dikerjakan di sini justru sebaliknya: membaca alamat itu apa adanya,
mencocokkannya ke blok, dan menghitung apa yang terpakai dan apa yang bebas.
"""

import ipaddress

from sqlalchemy import select

from app.core.errors import GalatDomain

# Blok besar tidak dibentangkan seluruh alamatnya. /16 berisi 65 ribu alamat,
# dan merendernya sebagai daftar adalah satu halaman yang tidak pernah selesai
# dimuat.
BATAS_BENTANG = 1024


class IpTidakSah(GalatDomain):
    """Alamat IP salah bentuk atau sudah dipakai langganan lain."""


def urai_alamat(teks: str):
    """`10.0.0.5` atau `10.0.0.5/30` menjadi objek alamat.

    Prefix diterima karena itulah bentuk yang biasa ditulis teknisi di lapangan
    untuk titik pelanggan; yang disimpan tetap teks aslinya.
    """
    bersih = (teks or "").strip()
    if not bersih:
        return None
    try:
        return ipaddress.ip_address(bersih.split("/", 1)[0])
    except ValueError as galat:
        raise IpTidakSah(
            "ip_address",
            f"'{bersih}' bukan alamat IP yang sah. Contoh: 103.10.10.5 "
            "atau 103.10.10.5/30.",
        ) from galat


def urai_blok(cidr: str):
    try:
        return ipaddress.ip_network((cidr or "").strip(), strict=False)
    except ValueError:
        return None


def di_dalam(alamat, cidr: str) -> bool:
    jaringan = urai_blok(cidr)
    return bool(jaringan and alamat is not None and alamat in jaringan)


def pastikan_ip_bebas(sesi, teks: str, kecuali_id: int | None = None) -> None:
    """Menolak alamat yang sudah dipakai langganan lain.

    Perbandingannya lewat objek alamat, bukan teks: `10.0.0.5` dan
    `10.0.0.5/30` adalah alamat yang sama, dan membandingkannya sebagai string
    akan meloloskan tabrakan yang paling sering terjadi di lapangan.
    """
    from sqlalchemy import or_

    from app.modules.customers.subscriptions import Subscription

    alamat = urai_alamat(teks)
    if alamat is None:
        return

    # Disaring di basis data lebih dulu. Menarik SELURUH langganan ber-IP ke
    # memori lalu menguraikannya satu per satu berarti satu pemindaian penuh
    # per baris yang disimpan — dan impor 1.000 pelanggan menjadi 1.000
    # pemindaian penuh. Yang dibandingkan tetap objek alamat, karena
    # `10.0.0.5` dan `10.0.0.5/30` adalah alamat yang sama; SQL hanya
    # mempersempit kandidatnya.
    query = select(Subscription).where(
        or_(
            Subscription.ip_address == str(alamat),
            Subscription.ip_address.like(f"{alamat}/%"),
            Subscription.ip_address.like(f" %{alamat}%"),
        )
    )
    if kecuali_id is not None:
        query = query.where(Subscription.id != kecuali_id)

    for langganan in sesi.execute(query).scalars().all():
        try:
            lain = urai_alamat(langganan.ip_address)
        except IpTidakSah:
            # Data lama yang tidak terurai bukan alasan menolak input baru.
            continue
        if lain == alamat:
            # Nomor layanannya sengaja TIDAK disebut: keunikan alamat berlaku
            # global, tetapi admin cabang tidak boleh tahu nomor layanan
            # cabang lain hanya karena kebetulan mengetik alamat yang sama.
            raise IpTidakSah(
                "ip_address",
                f"Alamat {alamat} sudah dipakai layanan lain. Satu alamat "
                "hanya boleh dipakai satu layanan.",
            )


def _langganan_ber_ip(sesi, user):
    """Seluruh langganan yang punya alamat IP, dalam jangkauan cabang `user`."""
    from app.core import rbac
    from app.modules.customers.models import Customer
    from app.modules.customers.subscriptions import Subscription

    query = (
        select(Subscription, Customer)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.ip_address.isnot(None))
        .where(Subscription.ip_address != "")
    )
    return sesi.execute(rbac.scoped(query, user, Customer)).all()


def alokasi_blok(sesi, user, blok) -> dict:
    """Isi satu blok: siapa memakai alamat mana, dan berapa yang tersisa.

    Alamat jaringan, broadcast, dan gateway dikeluarkan dari hitungan bebas —
    ketiganya tidak pernah bisa diberikan ke pelanggan, dan memasukkannya
    membuat angka "sisa" terlalu optimistis.
    """
    jaringan = urai_blok(blok.cidr)
    if jaringan is None:
        return {
            "jaringan": None, "total": 0, "terpakai": [], "jumlah_terpakai": 0,
            "jumlah_bebas": 0, "persen": 0, "bebas_berikutnya": [],
        }

    terpakai = []
    dipakai_alamat = set()
    for langganan, pelanggan in _langganan_ber_ip(sesi, user):
        try:
            alamat = urai_alamat(langganan.ip_address)
        except IpTidakSah:
            continue
        if alamat is None or alamat not in jaringan:
            continue
        terpakai.append(
            {"alamat": alamat, "langganan": langganan, "pelanggan": pelanggan}
        )
        dipakai_alamat.add(alamat)

    terpakai.sort(key=lambda satu: satu["alamat"])

    dipesan = set()
    if jaringan.num_addresses > 2:
        dipesan.update({jaringan.network_address, jaringan.broadcast_address})
    if blok.gateway:
        try:
            gw = urai_alamat(blok.gateway)
            if gw is not None and gw in jaringan:
                dipesan.add(gw)
        except IpTidakSah:
            pass

    total_dapat_dipakai = max(jaringan.num_addresses - len(dipesan), 0)
    jumlah_bebas = max(total_dapat_dipakai - len(dipakai_alamat), 0)

    bebas_berikutnya = []
    if jaringan.num_addresses <= BATAS_BENTANG:
        for alamat in jaringan:
            if alamat in dipesan or alamat in dipakai_alamat:
                continue
            bebas_berikutnya.append(alamat)
            if len(bebas_berikutnya) >= 10:
                break

    persen = round(len(dipakai_alamat) / total_dapat_dipakai * 100) if total_dapat_dipakai else 0
    return {
        "jaringan": jaringan,
        "total": total_dapat_dipakai,
        "terpakai": terpakai,
        "jumlah_terpakai": len(dipakai_alamat),
        "jumlah_bebas": jumlah_bebas,
        "persen": persen,
        "dipesan": sorted(dipesan),
        "bebas_berikutnya": bebas_berikutnya,
        "terlalu_besar_untuk_dibentang": jaringan.num_addresses > BATAS_BENTANG,
    }


def ringkasan_blok(sesi, user, blok_blok) -> dict[int, dict]:
    """Angka terpakai/bebas untuk sederet blok sekaligus.

    Langganan dibaca **sekali** untuk seluruh blok. Memanggil `alokasi_blok`
    per baris berarti satu query penuh per blok di halaman daftar.
    """
    baris = []
    for langganan, pelanggan in _langganan_ber_ip(sesi, user):
        try:
            alamat = urai_alamat(langganan.ip_address)
        except IpTidakSah:
            continue
        if alamat is not None:
            baris.append((alamat, langganan, pelanggan))

    hasil = {}
    for blok in blok_blok:
        jaringan = urai_blok(blok.cidr)
        if jaringan is None:
            hasil[blok.id] = {"total": 0, "terpakai": 0, "bebas": 0, "persen": 0}
            continue

        dipesan = set()
        if jaringan.num_addresses > 2:
            dipesan.update({jaringan.network_address, jaringan.broadcast_address})
        if blok.gateway:
            try:
                gw = urai_alamat(blok.gateway)
                if gw is not None and gw in jaringan:
                    dipesan.add(gw)
            except IpTidakSah:
                pass

        dipakai = {alamat for alamat, _l, _p in baris if alamat in jaringan}
        total = max(jaringan.num_addresses - len(dipesan), 0)
        hasil[blok.id] = {
            "total": total,
            "terpakai": len(dipakai),
            "bebas": max(total - len(dipakai), 0),
            "persen": round(len(dipakai) / total * 100) if total else 0,
        }
    return hasil


BATAS_DI_LUAR = 50


def di_luar_blok(sesi, user, batas: int = BATAS_DI_LUAR) -> list[dict]:
    """Alamat pelanggan yang tidak masuk blok terdaftar mana pun.

    Tidak ditolak saat disimpan — ISP yang belum sempat mendaftarkan bloknya
    tetap harus bisa mendata pelanggan. Yang dilakukan: ditampilkan di sini,
    supaya blok yang belum terdaftar ketahuan alih-alih hilang diam-diam.

    Dibatasi `batas` baris. Pemasangan yang belum mendaftarkan satu blok pun
    akan memasukkan SELURUH langganannya ke daftar ini, dan halaman berisi
    dua puluh ribu baris bukan peringatan — itu halaman yang tidak terbuka.
    Pemanggil memberi tahu sisanya lewat `len()` dibanding `batas`.
    """
    from app.core import rbac
    from app.modules.inventory.models import IpBlock

    blok_blok = sesi.execute(rbac.scoped(select(IpBlock), user, IpBlock)).scalars().all()
    jaringan_jaringan = [j for j in (urai_blok(b.cidr) for b in blok_blok) if j]

    hasil = []
    for langganan, pelanggan in _langganan_ber_ip(sesi, user):
        try:
            alamat = urai_alamat(langganan.ip_address)
        except IpTidakSah:
            hasil.append(
                {"teks": langganan.ip_address, "langganan": langganan,
                 "pelanggan": pelanggan, "alasan": "bukan alamat IP yang sah"}
            )
            continue
        if alamat is None:
            continue
        if not any(alamat in jaringan for jaringan in jaringan_jaringan):
            hasil.append(
                {"teks": langganan.ip_address, "langganan": langganan,
                 "pelanggan": pelanggan, "alasan": "di luar blok terdaftar"}
            )
        # Satu lebih banyak dari batas: pemanggil memakainya untuk tahu bahwa
        # daftarnya terpotong, tanpa harus menghitung seluruhnya.
        if len(hasil) > batas:
            break
    return hasil
