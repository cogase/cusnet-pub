"""Peta sebaran koordinat, digambar sendiri.

**Tanpa peta dasar.** Server pelanggan sering tanpa akses internet keluar
(risiko yang sudah dicatat di spesifikasi §14), jadi peta yang menarik ubin
dari OpenStreetMap atau Google akan kosong justru di tempat ia dipakai. Yang
digambar di sini hubungan **relatif** antar-titik: mana yang berdekatan, mana
yang jauh sendiri. Bukan jalan, bukan sungai, bukan batas wilayah.

Proyeksinya sengaja sederhana (equirectangular dengan koreksi kosinus lintang)
dan hanya sahih untuk sebaran sempit — satu kota, satu kabupaten. Untuk
sebaran selebar Indonesia bentuknya akan meleset, dan itu ditulis apa adanya
di halamannya.
"""

import math

LEBAR = 720
TINGGI = 420
SISIP = 28

# Jarak minimum yang dianggap "sebaran", dalam derajat. Di bawah ini seluruh
# titik praktis bertumpuk, dan membentangkannya memenuhi kanvas membuat jarak
# tiga meter tampak seperti tiga kilometer.
RENTANG_MINIMUM = 0.002


def rakit_svg(titik: list[dict]) -> dict:
    """Menghitung koordinat layar untuk tiap titik.

    Mengembalikan dict siap render; templatnya yang menggambar SVG.
    """
    if not titik:
        return {"kosong": True, "lebar": LEBAR, "tinggi": TINGGI, "titik": []}

    lat = [t["lat"] for t in titik]
    lng = [t["lng"] for t in titik]
    lat_min, lat_maks = min(lat), max(lat)
    lng_min, lng_maks = min(lng), max(lng)

    # Koreksi kosinus lintang: satu derajat bujur lebih pendek daripada satu
    # derajat lintang begitu menjauh dari khatulistiwa. Tanpa ini sebaran di
    # Jakarta tampak melar ke samping.
    lat_tengah = (lat_min + lat_maks) / 2
    skala_bujur = max(math.cos(math.radians(lat_tengah)), 0.01)

    rentang_lat = max(lat_maks - lat_min, RENTANG_MINIMUM)
    rentang_lng = max((lng_maks - lng_min) * skala_bujur, RENTANG_MINIMUM)

    dalam_lebar = LEBAR - 2 * SISIP
    dalam_tinggi = TINGGI - 2 * SISIP

    # Satu skala untuk kedua sumbu supaya bentuknya tidak terdistorsi; sisanya
    # jadi ruang kosong yang dipusatkan.
    skala = min(dalam_lebar / rentang_lng, dalam_tinggi / rentang_lat)
    geser_x = (dalam_lebar - rentang_lng * skala) / 2
    geser_y = (dalam_tinggi - rentang_lat * skala) / 2

    hasil = []
    for baris in titik:
        x = SISIP + geser_x + ((baris["lng"] - lng_min) * skala_bujur) * skala
        # Lintang naik ke utara, sumbu Y layar naik ke bawah.
        y = SISIP + geser_y + (lat_maks - baris["lat"]) * skala
        hasil.append(baris | {"x": round(x, 2), "y": round(y, 2)})

    return {
        "kosong": False,
        "lebar": LEBAR,
        "tinggi": TINGGI,
        "titik": hasil,
        "jumlah_site": sum(1 for t in titik if t["jenis"] == "site"),
        "jumlah_pelanggan": sum(1 for t in titik if t["jenis"] == "pelanggan"),
        # Dipakai halaman untuk mengatakan seberapa lebar sebarannya, supaya
        # pembacanya tahu skalanya sendiri.
        "rentang_lat": round(lat_maks - lat_min, 5),
        "rentang_lng": round(lng_maks - lng_min, 5),
    }
