"""Manifest, service worker, dan halaman luring.

Tidak punya `service.py` karena tidak menyentuh basis data sama sekali.

`sw.js` **harus** dilayani dari akar, bukan dari `/static/`. Cakupan sebuah
service worker dibatasi oleh path berkasnya; dari `/static/sw.js` ia hanya
akan mengendalikan permintaan di bawah `/static/`, jadi halaman aplikasinya
tidak pernah tersentuh.
"""

from flask import Blueprint, current_app, make_response, render_template

bp = Blueprint("pwa", __name__)


def _tanpa_simpan(isi: str, tipe: str):
    respons = make_response(isi)
    respons.headers["Content-Type"] = tipe
    # Peramban yang menyimpan sw.js lama tidak akan pernah tahu ada versi baru.
    respons.headers["Cache-Control"] = "no-cache"
    return respons


@bp.get("/manifest.webmanifest")
def manifest():
    return _tanpa_simpan(
        render_template("pwa/manifest.json"),
        "application/manifest+json",
    )


@bp.get("/sw.js")
def service_worker():
    return _tanpa_simpan(
        render_template("pwa/sw.js", app_version=current_app.config["APP_VERSION"]),
        "application/javascript",
    )


@bp.get("/luring")
def luring():
    return render_template("pwa/luring.html")
