"""Satu titik impor seluruh modul model.

Model hanya terdaftar di `Base.metadata` sebagai efek samping impor. Modul ini
menjadi satu-satunya tempat daftar itu dipelihara, supaya kehadiran tabel tidak
bergantung pada kebetulan urutan impor.
"""

import app.modules.admin.models  # noqa: F401
import app.modules.billing.models  # noqa: F401
import app.modules.customers.models  # noqa: F401
import app.modules.customers.subscriptions  # noqa: F401
import app.modules.services.models  # noqa: F401
import app.modules.inventory.models  # noqa: F401
import app.modules.settings.models  # noqa: F401  BillingSetting, AppBranding
import app.modules.tickets.models  # noqa: F401
