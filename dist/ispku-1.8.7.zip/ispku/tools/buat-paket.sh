#!/bin/sh
# Menaikkan versi lalu membungkus ISPKU jadi satu berkas zip untuk dipasang
# di server lain.
#
#   tools/buat-paket.sh            naikkan angka terakhir (1.8.3 -> 1.8.4)
#   tools/buat-paket.sh minor      1.8.3 -> 1.9.0
#   tools/buat-paket.sh major      1.8.3 -> 2.0.0
#   tools/buat-paket.sh 2.1.0      pakai versi ini persis
#   tools/buat-paket.sh --tetap    bungkus ulang versi sekarang, tanpa menaikkan
#
# Versi baru ditulis ke VERSI_APLIKASI di app/core/config.py, lalu di-commit
# ("chore: rilis <versi>"). Paketnya dibuat dari commit itu, BUKAN dari berkas
# yang sedang diedit — paket yang dikirim harus bisa ditelusuri ke satu
# commit. Karena itu perubahan lain harus di-commit lebih dulu. Yang tidak
# ikut (uji, catatan pengembangan, gambar mockup) diatur di .gitattributes.
#
# Hasilnya dist/ispku-<versi>.zip beserta berkas .sha256-nya. Di dalam zip
# semuanya berada di folder `ispku/`, jadi di server cukup:
#   unzip ispku-<versi>.zip -d /opt      ->  /opt/ispku
#
# Menerbitkannya ke repositori publik: tools/push-paket.sh
set -eu

# Jangan dijalankan dengan sudo: commit rilis dan berkas di dist/ menjadi milik root dan tidak bisa disentuh akun Anda lagi.
if [ "$(id -u)" = "0" ] && [ -n "${SUDO_USER:-}" ]; then
    echo "Jangan jalankan script ini dengan sudo." >&2
    echo "Dengan sudo, commit rilis dan berkas di dist/ menjadi milik root dan tidak bisa disentuh akun Anda lagi." >&2
    echo "Jalankan sebagai ${SUDO_USER}: tools/buat-paket.sh" >&2
    exit 1
fi

cd "$(dirname "$0")/.."

MODE=${1:-patch}

versi_sekarang() {
    sed -n 's/^VERSI_APLIKASI = "\(.*\)"$/\1/p' app/core/config.py | head -n 1
}

LAMA=$(versi_sekarang)
case "$LAMA" in
    [0-9]*.[0-9]*.[0-9]*) ;;
    *) echo "VERSI_APLIKASI di app/core/config.py bukan bentuk X.Y.Z: '${LAMA}'." >&2; exit 1 ;;
esac

MAJOR=${LAMA%%.*}
SISA=${LAMA#*.}
MINOR=${SISA%%.*}
PATCH=${SISA#*.}
case "$MAJOR$MINOR$PATCH" in
    *[!0-9]*) echo "VERSI_APLIKASI di app/core/config.py bukan bentuk X.Y.Z: '${LAMA}'." >&2; exit 1 ;;
esac

case "$MODE" in
    patch) VERSI="${MAJOR}.${MINOR}.$((PATCH + 1))" ;;
    minor) VERSI="${MAJOR}.$((MINOR + 1)).0" ;;
    major) VERSI="$((MAJOR + 1)).0.0" ;;
    --tetap) VERSI=$LAMA ;;
    [0-9]*.[0-9]*.[0-9]*)
        case "$MODE" in
            *[!0-9.]*) echo "Versi tidak sah: '${MODE}'." >&2; exit 1 ;;
        esac
        VERSI=$MODE
        ;;
    *)
        echo "Pemakaian: tools/buat-paket.sh [patch|minor|major|X.Y.Z|--tetap]" >&2
        exit 1
        ;;
esac

if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
    echo "Ada perubahan yang belum di-commit. Paket dibuat dari commit, jadi" >&2
    echo "perubahan itu tidak akan ikut. Commit dulu, lalu jalankan lagi:" >&2
    git status --short --untracked-files=no >&2
    exit 1
fi

if [ "$VERSI" != "$LAMA" ]; then
    if [ -e "dist/ispku-${VERSI}.zip" ]; then
        echo "dist/ispku-${VERSI}.zip sudah ada. Pilih versi lain." >&2
        exit 1
    fi
    sed -i "s/^VERSI_APLIKASI = \".*\"$/VERSI_APLIKASI = \"${VERSI}\"/" app/core/config.py
    if [ "$(versi_sekarang)" != "$VERSI" ]; then
        git checkout -- app/core/config.py
        echo "VERSI_APLIKASI di app/core/config.py tidak ditemukan; tidak ada yang diubah." >&2
        exit 1
    fi
    git add -- app/core/config.py
    git commit -q -m "chore: rilis ${VERSI}"
    echo "Versi   : ${LAMA} -> ${VERSI}"
else
    echo "Versi   : ${VERSI} (tidak dinaikkan)"
fi

mkdir -p dist
NAMA="ispku-${VERSI}.zip"
git archive --format=zip --prefix=ispku/ -o "dist/${NAMA}" HEAD
(cd dist && sha256sum "$NAMA" > "${NAMA}.sha256")

echo "Paket   : dist/${NAMA} ($(du -h "dist/${NAMA}" | cut -f1))"
echo "Commit  : $(git rev-parse --short HEAD)"
echo "SHA256  : $(cut -d' ' -f1 "dist/${NAMA}.sha256")"
echo "Terbitkan dengan: tools/push-paket.sh"
