#!/bin/sh
# Menerbitkan paket yang sudah dibuat `tools/buat-paket.sh` ke repositori
# publik agar server pelanggan dapat menarik paket dengan `git pull`.
#
#   tools/buat-paket.sh        (menaikkan versi, menghasilkan dist/ispku-X.zip)
#   tools/push-paket.sh        (mengirim zip itu ke cogase/cusnet-pub)
#
# Script ini TIDAK membuat paket baru: yang dikirim adalah zip versi sekarang
# (VERSI_APLIKASI di app/core/config.py) yang sudah ada di dist/. Versi lain bisa
# dipilih lewat argumen: tools/push-paket.sh 1.8.3
#
# Repo, branch, dan identitas commit dapat ditimpa tanpa mengubah script:
#   CUSNET_PUB_REPO=git@github.com:cogase/cusnet-pub.git \
#   CUSNET_PUB_BRANCH=main \
#   CUSNET_PUB_NAME=cogase \
#   CUSNET_PUB_EMAIL=cogase.njabrut@gmail.com tools/push-paket.sh
set -eu

# Jangan dijalankan dengan sudo: perintah kirim memakai kunci SSH milik root, bukan milik akun Anda, dan GitHub menolaknya (Permission denied (publickey)).
if [ "$(id -u)" = "0" ] && [ -n "${SUDO_USER:-}" ]; then
    echo "Jangan jalankan script ini dengan sudo." >&2
    echo "Dengan sudo, perintah kirim memakai kunci SSH milik root, bukan milik akun Anda, dan GitHub menolaknya (Permission denied (publickey))." >&2
    echo "Jalankan sebagai ${SUDO_USER}: tools/push-paket.sh" >&2
    exit 1
fi

AKAR=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$AKAR"

REPO=${CUSNET_PUB_REPO:-git@github.com:cogase/cusnet-pub.git}
BRANCH=${CUSNET_PUB_BRANCH:-main}
# Commit di repo publik selalu atas nama cogase, siapa pun yang menjalankan
# script ini. Alamatnya harus persis alamat yang terdaftar di akun GitHub
# itu: selisih satu huruf saja membuat commit tidak tertaut ke akunnya.
PUBLISHER_NAME=${CUSNET_PUB_NAME:-cogase}
PUBLISHER_EMAIL=${CUSNET_PUB_EMAIL:-cogase.njabrut@gmail.com}

VERSI=${1:-$(sed -n 's/^VERSI_APLIKASI = "\(.*\)"$/\1/p' app/core/config.py | head -n 1)}
[ -n "$VERSI" ] || { echo "VERSI_APLIKASI tidak ditemukan di app/core/config.py." >&2; exit 1; }

PAKET="ispku-${VERSI}.zip"
SUM="${PAKET}.sha256"
ZIP="dist/${PAKET}"

if [ ! -f "$ZIP" ] || [ ! -f "dist/$SUM" ]; then
    echo "dist/${PAKET} atau checksum-nya belum ada." >&2
    echo "Buat dulu dengan: tools/buat-paket.sh" >&2
    exit 1
fi

if ! (cd dist && sha256sum -c "$SUM" >/dev/null 2>&1); then
    echo "Checksum dist/${PAKET} tidak cocok dengan dist/${SUM}." >&2
    echo "Buat ulang dengan: tools/buat-paket.sh --tetap" >&2
    exit 1
fi

if ! command -v unzip >/dev/null 2>&1; then
    echo "Perintah unzip diperlukan untuk memeriksa isi paket." >&2
    exit 1
fi

TMP=$(mktemp -d "${TMPDIR:-/tmp}/cusnet-pub.XXXXXX")
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

unzip -tq "$ZIP" >/dev/null
if unzip -Z1 "$ZIP" | awk '
    /(^|\/)\.env$/ ||
    /(^|\/)[^/]+\.(key|pem|p12|pfx)$/ ||
    /(^|\/)(id_rsa|id_ed25519)$/ { print; found = 1 }
    END { exit !found }
' > "$TMP/private-files"; then
    echo "Paket berisi berkas rahasia; tidak diterbitkan:" >&2
    sed 's/^/  /' "$TMP/private-files" >&2
    exit 1
fi

git clone -q "$REPO" "$TMP/repo"
if git -C "$TMP/repo" ls-remote --exit-code --heads origin "$BRANCH" >/dev/null 2>&1; then
    if git -C "$TMP/repo" show-ref --verify --quiet "refs/heads/$BRANCH"; then
        git -C "$TMP/repo" switch -q "$BRANCH"
    else
        git -C "$TMP/repo" switch -q -c "$BRANCH" --track "origin/$BRANCH"
    fi
else
    git -C "$TMP/repo" switch -q --orphan "$BRANCH"
fi

mkdir -p "$TMP/repo/dist"
if [ -e "$TMP/repo/dist/$PAKET" ]; then
    if cmp -s "$ZIP" "$TMP/repo/dist/$PAKET" &&
       cmp -s "dist/$SUM" "$TMP/repo/dist/$SUM"; then
        echo "Paket ${VERSI} sudah diterbitkan dan isinya sama."
        exit 0
    fi
    echo "Paket versi ${VERSI} sudah terbit dengan isi berbeda." >&2
    echo "Buat versi baru dengan: tools/buat-paket.sh" >&2
    exit 1
fi

cp "$ZIP" "$TMP/repo/dist/$PAKET"
cp "dist/$SUM" "$TMP/repo/dist/$SUM"
git -C "$TMP/repo" add -- "dist/$PAKET" "dist/$SUM"
# Lewat variabel lingkungan, bukan `-c user.name`: GIT_AUTHOR_* yang sudah
# terpasang di shell mengalahkan konfigurasi dan diam-diam mengganti nama.
GIT_AUTHOR_NAME="$PUBLISHER_NAME" GIT_AUTHOR_EMAIL="$PUBLISHER_EMAIL" \
GIT_COMMITTER_NAME="$PUBLISHER_NAME" GIT_COMMITTER_EMAIL="$PUBLISHER_EMAIL" \
    git -C "$TMP/repo" -c commit.gpgsign=false \
    commit -q -m "Publish ISPKU ${VERSI}"
git -C "$TMP/repo" push -q origin "HEAD:refs/heads/$BRANCH"

echo "Diterbitkan : ${REPO} (${BRANCH})"
echo "Kontributor : ${PUBLISHER_NAME} <${PUBLISHER_EMAIL}>"
echo "Paket       : dist/${PAKET}"
echo "Checksum    : dist/${SUM}"
