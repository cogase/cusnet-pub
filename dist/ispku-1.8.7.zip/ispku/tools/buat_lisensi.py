#!/usr/bin/env python3
"""Menerbitkan kunci lisensi ISPKU. Dijalankan penjual, bukan pembeli.

Kunci privat penerbit **tidak** ada di repositori ini dan tidak boleh
ditaruh di sini. Simpan di luar repo, dengan hak akses 600.

Membuat pasangan kunci baru (sekali seumur produk):

    python3 tools/buat_lisensi.py --buat-kunci ~/.cusnet-penerbit.key

Perintah itu mencetak kunci publiknya; salin ke `KUNCI_PUBLIK_BAWAAN` di
`app/core/lisensi.py`, atau ke `LICENSE_PUBLIC_KEY` di `.env` pemasangan.

Menerbitkan lisensi:

    python3 tools/buat_lisensi.py \\
        --kunci ~/.cusnet-penerbit.key \\
        --pelanggan "PT Contoh Nusantara" \\
        --edisi enterprise \\
        --batas-pelanggan 2000 \\
        --kedaluwarsa 2027-08-31 \\
        --catatan "Perpanjangan tahun kedua"
"""

import argparse
import base64
import json
import pathlib
import sys
from datetime import date

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from app.core.lisensi import rakit_muatan  # noqa: E402


def buat_kunci(tujuan: str) -> None:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    berkas = pathlib.Path(tujuan).expanduser()
    if berkas.exists():
        raise SystemExit(
            f"{berkas} sudah ada. Menimpanya berarti seluruh lisensi yang "
            "sudah diterbitkan tidak bisa diverifikasi lagi."
        )

    privat = Ed25519PrivateKey.generate()
    berkas.write_bytes(
        privat.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    berkas.chmod(0o600)

    publik = privat.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    print(f"Kunci privat disimpan di {berkas} (mode 600). Jangan pernah dibagikan.")
    print("Kunci publik untuk ditanam di aplikasi:")
    print(base64.b64encode(publik).decode())


def terbitkan(args) -> None:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    mentah = pathlib.Path(args.kunci).expanduser().read_bytes()
    privat = Ed25519PrivateKey.from_private_bytes(mentah)

    data = {
        "pelanggan": args.pelanggan,
        "edisi": args.edisi,
        "batas_pelanggan": args.batas_pelanggan,
        "diterbitkan": (args.diterbitkan or date.today().isoformat()),
        "kedaluwarsa": args.kedaluwarsa,
        "catatan": args.catatan,
    }
    tanda_tangan = privat.sign(rakit_muatan(data))
    amplop = {
        "data": data,
        "ttd": base64.b64encode(tanda_tangan).decode(),
    }
    kunci = base64.b64encode(
        json.dumps(amplop, sort_keys=True, separators=(",", ":")).encode()
    ).decode()

    # Dipotong 64 karakter per baris supaya bisa disalin dari email tanpa
    # terpotong sembarangan; pembacanya membuang seluruh spasi lebih dulu.
    for awal in range(0, len(kunci), 64):
        print(kunci[awal:awal + 64])


def main() -> None:
    urai = argparse.ArgumentParser(description=__doc__)
    urai.add_argument("--buat-kunci", metavar="BERKAS")
    urai.add_argument("--kunci", metavar="BERKAS")
    urai.add_argument("--pelanggan")
    urai.add_argument("--edisi", default="standar")
    urai.add_argument("--batas-pelanggan", type=int, default=None)
    urai.add_argument("--diterbitkan", default=None)
    urai.add_argument("--kedaluwarsa", default=None)
    urai.add_argument("--catatan", default=None)
    args = urai.parse_args()

    if args.buat_kunci:
        buat_kunci(args.buat_kunci)
        return

    if not args.kunci or not args.pelanggan:
        raise SystemExit("--kunci dan --pelanggan wajib diisi saat menerbitkan.")
    terbitkan(args)


if __name__ == "__main__":
    main()
