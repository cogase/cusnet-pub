"""Membuat ikon PNG aplikasi dari bentuk yang sama dengan `app/static/img/logo.svg`.

Dijalankan sekali; hasilnya dikomit. Skripnya ikut dikomit supaya ikonnya bisa
dibuat ulang saat merek diganti per ISP (roadmap M5) — cukup mengubah warna di
`WARNA` lalu menjalankan ulang:

    python3 tools/buat_ikon.py

Tanpa pustaka luar. Pillow dan cairosvg sengaja tidak dipakai: keduanya tidak
ada di mesin pengembangan ini, dan menambah dependensi berarti satu jalur
kegagalan baru saat pemasangan di server pelanggan. PNG ditulis langsung dengan
`zlib` dan `struct` dari pustaka standar.

Tepi dihaluskan dengan supersampling: digambar tiga kali lipat lalu dirata-rata
turun. Tidak ada rasterizer sungguhan di sini, jadi setiap bentuk digambar
dengan rentang-per-baris, bukan per piksel.
"""

from __future__ import annotations

import math
import pathlib
import struct
import zlib

KELUARAN = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "img"

# Warna diambil apa adanya dari logo.svg.
WARNA = {
    "cincin": (0x1D, 0x4E, 0xD8),
    "isi": (0x25, 0x63, 0xEB),
    "putih": (0xFF, 0xFF, 0xFF),
}

SUPERSAMPLE = 3

# Bentuk logo dalam koordinat viewBox 32×32 milik logo.svg.
LINGKARAN_LUAR = (16.0, 16.0, 16.0, "cincin")
LINGKARAN_DALAM = (16.0, 16.0, 11.0, "isi")
TITIK = (12.0, 20.0, 2.2, "putih")
# path M11 20 a7 7 0 0 1 10 -9 — busur radius 7, sapuan positif, bukan busur besar.
BUSUR = {
    "awal": (11.0, 20.0),
    "akhir": (21.0, 11.0),
    "radius": 7.0,
    "tebal": 2.5,
    "busur_besar": False,
    "sapuan": True,
}


class Kanvas:
    """Bidang RGBA sederhana. Piksel disimpan sebagai satu bytearray datar."""

    def __init__(self, sisi: int) -> None:
        self.sisi = sisi
        self.piksel = bytearray(sisi * sisi * 4)

    def _baris(self, y: int, x0: int, x1: int, warna: tuple[int, int, int]) -> None:
        """Menimpa rentang [x0, x1) di baris y dengan warna buram."""
        if y < 0 or y >= self.sisi:
            return
        x0 = max(0, x0)
        x1 = min(self.sisi, x1)
        if x1 <= x0:
            return
        awal = (y * self.sisi + x0) * 4
        self.piksel[awal : awal + (x1 - x0) * 4] = bytes((*warna, 255)) * (x1 - x0)

    def isi_persegi(self, warna: tuple[int, int, int]) -> None:
        self.piksel[:] = bytes((*warna, 255)) * (self.sisi * self.sisi)

    def isi_lingkaran(self, cx: float, cy: float, r: float, warna) -> None:
        atas = max(0, int(math.floor(cy - r)))
        bawah = min(self.sisi - 1, int(math.ceil(cy + r)))
        for y in range(atas, bawah + 1):
            dy = (y + 0.5) - cy
            sisa = r * r - dy * dy
            if sisa <= 0:
                continue
            lebar = math.sqrt(sisa)
            self._baris(y, int(round(cx - lebar)), int(round(cx + lebar)), warna)


def _pusat_busur(awal, akhir, r, busur_besar, sapuan):
    """Parametrisasi titik-ujung ke titik-pusat menurut spesifikasi SVG (rx = ry, tanpa rotasi)."""
    (x1, y1), (x2, y2) = awal, akhir
    x_aksen = (x1 - x2) / 2
    y_aksen = (y1 - y2) / 2
    penyebut = r * r * y_aksen * y_aksen + r * r * x_aksen * x_aksen
    pembilang = r * r * r * r - penyebut
    faktor = math.sqrt(max(0.0, pembilang / penyebut))
    if busur_besar == sapuan:
        faktor = -faktor
    cx_aksen = faktor * (r * y_aksen / r)
    cy_aksen = faktor * (-r * x_aksen / r)
    cx = cx_aksen + (x1 + x2) / 2
    cy = cy_aksen + (y1 + y2) / 2

    sudut1 = math.atan2(y1 - cy, x1 - cx)
    sudut2 = math.atan2(y2 - cy, x2 - cx)
    delta = sudut2 - sudut1
    if sapuan and delta < 0:
        delta += 2 * math.pi
    if not sapuan and delta > 0:
        delta -= 2 * math.pi
    return cx, cy, sudut1, delta


def gambar_logo(kanvas: Kanvas, skala: float, geser_x: float, geser_y: float) -> None:
    """Menggambar keempat bentuk logo. `skala` = piksel per satuan viewBox."""

    def petakan(x, y):
        return x * skala + geser_x, y * skala + geser_y

    for cx, cy, r, kunci in (LINGKARAN_LUAR, LINGKARAN_DALAM):
        px, py = petakan(cx, cy)
        kanvas.isi_lingkaran(px, py, r * skala, WARNA[kunci])

    cx, cy, sudut_awal, delta = _pusat_busur(
        BUSUR["awal"], BUSUR["akhir"], BUSUR["radius"],
        BUSUR["busur_besar"], BUSUR["sapuan"],
    )
    # Busur digambar sebagai deretan cakram yang saling menindih; ujungnya jadi
    # bulat dengan sendirinya, sama seperti stroke-linecap="round" di SVG.
    jari_pena = BUSUR["tebal"] / 2 * skala
    panjang = abs(delta) * BUSUR["radius"] * skala
    cacah = max(64, int(panjang / max(1.0, jari_pena / 2)))
    for i in range(cacah + 1):
        sudut = sudut_awal + delta * (i / cacah)
        px, py = petakan(
            cx + BUSUR["radius"] * math.cos(sudut),
            cy + BUSUR["radius"] * math.sin(sudut),
        )
        kanvas.isi_lingkaran(px, py, jari_pena, WARNA["putih"])

    tx, ty, tr, kunci = TITIK
    px, py = petakan(tx, ty)
    kanvas.isi_lingkaran(px, py, tr * skala, WARNA[kunci])


def turunkan(kanvas: Kanvas, faktor: int) -> Kanvas:
    """Merata-rata blok faktor×faktor menjadi satu piksel."""
    sisi = kanvas.sisi // faktor
    hasil = Kanvas(sisi)
    sumber = kanvas.piksel
    lebar_sumber = kanvas.sisi
    jumlah_sel = faktor * faktor
    for y in range(sisi):
        for x in range(sisi):
            r = g = b = a = 0
            for dy in range(faktor):
                baris = ((y * faktor + dy) * lebar_sumber + x * faktor) * 4
                for dx in range(faktor):
                    p = baris + dx * 4
                    alfa = sumber[p + 3]
                    # Warna dirata-rata berbobot alfa supaya piksel transparan
                    # tidak menarik tepi lambang ke arah hitam.
                    r += sumber[p] * alfa
                    g += sumber[p + 1] * alfa
                    b += sumber[p + 2] * alfa
                    a += alfa
            tujuan = (y * sisi + x) * 4
            if a:
                hasil.piksel[tujuan] = r // a
                hasil.piksel[tujuan + 1] = g // a
                hasil.piksel[tujuan + 2] = b // a
            hasil.piksel[tujuan + 3] = a // jumlah_sel
    return hasil


def tulis_png(kanvas: Kanvas, tujuan: pathlib.Path) -> None:
    sisi = kanvas.sisi
    mentah = bytearray()
    for y in range(sisi):
        mentah.append(0)  # tipe filter 0 (None) untuk setiap baris
        awal = y * sisi * 4
        mentah += kanvas.piksel[awal : awal + sisi * 4]

    def potongan(tipe: bytes, isi: bytes) -> bytes:
        return (
            struct.pack(">I", len(isi))
            + tipe
            + isi
            + struct.pack(">I", zlib.crc32(tipe + isi) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", sisi, sisi, 8, 6, 0, 0, 0)
    tujuan.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + potongan(b"IHDR", ihdr)
        + potongan(b"IDAT", zlib.compress(bytes(mentah), 9))
        + potongan(b"IEND", b"")
    )


def buat(nama: str, sisi: int, *, latar: bool, sisipan: float) -> None:
    """`sisipan` = bagian sisi yang ditempati lambang (1.0 = penuh)."""
    besar = Kanvas(sisi * SUPERSAMPLE)
    if latar:
        besar.isi_persegi(WARNA["cincin"])
    bidang = sisi * SUPERSAMPLE * sisipan
    skala = bidang / 32
    geser = (sisi * SUPERSAMPLE - bidang) / 2
    gambar_logo(besar, skala, geser, geser)
    tulis_png(turunkan(besar, SUPERSAMPLE), KELUARAN / nama)
    print(f"{nama} ({sisi}×{sisi})")


def main() -> None:
    KELUARAN.mkdir(parents=True, exist_ok=True)
    # Ikon biasa: lambang penuh, latar tembus pandang.
    buat("ikon-192.png", 192, latar=False, sisipan=1.0)
    buat("ikon-512.png", 512, latar=False, sisipan=1.0)
    # Maskable: Android memotong jadi bentuk apa pun, jadi lambang mengecil ke
    # 60% di tengah bidang berlatar penuh — zona aman spesifikasi maskable.
    buat("ikon-maskable-512.png", 512, latar=True, sisipan=0.6)
    # iOS tidak menghormati transparansi pada apple-touch-icon; latar hitam
    # akan muncul kalau dibiarkan tembus pandang.
    buat("ikon-180.png", 180, latar=True, sisipan=0.78)


if __name__ == "__main__":
    main()
