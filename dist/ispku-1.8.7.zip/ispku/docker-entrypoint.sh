#!/bin/sh
set -e

echo "Menjalankan migrasi basis data..."
alembic upgrade head

echo "Menjalankan aplikasi..."
exec "$@"
