"""Aturan tiket: penomoran, SLA, perpindahan status, komentar, lampiran.

Kontrak yang mengikat modul lain:

| Fungsi | Kontrak |
|---|---|
| `buat` | Satu-satunya tempat nomor tiket diberikan dan tenggat SLA dibekukan |
| `ubah_status` | Satu-satunya tempat `status`, `resolved_at`, dan `closed_at` berubah |
| `tambah_komentar` | Satu-satunya tempat `first_response_at` terisi |

Seluruh query melewati `rbac.scoped` lewat `Ticket.branch_id`.
"""

from datetime import datetime, timedelta
import logging
from pathlib import Path
from zoneinfo import ZoneInfo

from flask import current_app
from sqlalchemy import func, or_, select

from app.core import audit, rbac, waktu
from app.core.errors import GalatDomain, TidakDitemukan
from app.core import files
from app.core.numbering import next_value, render_pattern
from app.core.pagination import Page, paginate
from app.modules.tickets.models import (
    PRIORITAS,
    STATUS_TIKET,
    STATUS_TUTUP,
    Ticket,
    TicketAttachment,
    TicketCategory,
    TicketComment,
)

POLA_NOMOR_BAWAAN = "TKT/{YYYY}/{MM}/{seq:04d}"
_log = logging.getLogger(__name__)

KOLOM_TIKET = (
    "title",
    "description",
    "priority",
    "status",
    "category_id",
    "customer_id",
    "subscription_id",
    "assigned_to_user_id",
    "branch_id",
)

KOLOM_KATEGORI = (
    "code",
    "name",
    "default_priority",
    "sla_response_hours",
    "sla_resolve_hours",
    "is_active",
)

# Perpindahan status yang diizinkan. Ditulis sebagai peta, bukan rangkaian
# `if`, supaya aturan yang berlaku bisa dibaca sekali pandang — dan supaya
# menambah status berarti menyunting satu tempat.
#
# `ditutup` tidak punya jalan keluar: tiket yang perlu dibuka lagi dibuat
# sebagai tiket baru yang merujuk yang lama. Membuka kembali tiket yang sudah
# ditutup membuat angka SLA bulan lalu berubah setelah dilaporkan.
TRANSISI = {
    "baru": ("proses", "pending", "selesai", "ditutup"),
    "proses": ("pending", "selesai", "ditutup"),
    "pending": ("proses", "selesai", "ditutup"),
    "selesai": ("ditutup", "proses"),
    "ditutup": (),
}


class StatusTidakSah(GalatDomain):
    """Perpindahan status yang tidak diizinkan."""


class PrioritasTidakSah(GalatDomain):
    """Prioritas di luar daftar."""


class ResolusiWajib(GalatDomain):
    """Menutup tiket tanpa menuliskan penyelesaiannya."""


class KategoriDipakai(GalatDomain):
    """Kategori masih dipakai tiket."""


def _sekarang() -> datetime:
    """Waktu sekarang berzona aplikasi.

    Postgres berjalan di UTC; menyimpan waktu tanpa zona membuat tenggat SLA
    meleset tujuh jam dan tiket tampak terlambat sejak dibuat.
    """
    return waktu.sekarang()


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


# --- Kategori -------------------------------------------------------------


def daftar_kategori(sesi, hanya_aktif: bool = False) -> list[TicketCategory]:
    query = select(TicketCategory).order_by(TicketCategory.name)
    if hanya_aktif:
        query = query.where(TicketCategory.is_active.is_(True))
    return list(sesi.execute(query).scalars().all())


def ambil_kategori(sesi, kategori_id: int) -> TicketCategory:
    kategori = sesi.get(TicketCategory, kategori_id)
    if kategori is None:
        raise TidakDitemukan("Kategori tiket tidak ditemukan.")
    return kategori


def tambah_kategori(sesi, aktor, data: dict) -> TicketCategory:
    kategori = TicketCategory(**{k: data[k] for k in KOLOM_KATEGORI if k in data})
    sesi.add(kategori)
    sesi.flush()
    audit.record(
        sesi, "create", "ticket_category", kategori.id,
        after=_potret(kategori, KOLOM_KATEGORI), aktor=aktor,
    )
    return kategori


def ubah_kategori(sesi, aktor, kategori_id: int, data: dict) -> TicketCategory:
    kategori = ambil_kategori(sesi, kategori_id)
    sebelum = _potret(kategori, KOLOM_KATEGORI)
    for nama in KOLOM_KATEGORI:
        if nama in data:
            setattr(kategori, nama, data[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "ticket_category", kategori.id,
        before=sebelum, after=_potret(kategori, KOLOM_KATEGORI), aktor=aktor,
    )
    return kategori


def hapus_kategori(sesi, aktor, kategori_id: int) -> int:
    """Menghapus kategori yang belum pernah dipakai.

    Kategori yang sudah menempel di tiket tidak boleh hilang: tiket lama akan
    kehilangan artinya dan laporan gangguan per kategori jadi bolong. Yang
    dipakai untuk menghentikan pemakaian adalah `is_active`.
    """
    kategori = ambil_kategori(sesi, kategori_id)
    terpakai = sesi.execute(
        select(func.count(Ticket.id)).where(Ticket.category_id == kategori_id)
    ).scalar_one()
    if terpakai:
        raise KategoriDipakai(
            "code",
            f"Kategori ini dipakai {terpakai} tiket. Nonaktifkan saja, jangan dihapus.",
        )

    sebelum = _potret(kategori, KOLOM_KATEGORI)
    sesi.delete(kategori)
    sesi.flush()
    audit.record(
        sesi, "delete", "ticket_category", kategori_id, before=sebelum, aktor=aktor
    )
    return kategori_id


# --- Tiket ----------------------------------------------------------------


def buat_nomor(sesi, saat: datetime, pola: str = POLA_NOMOR_BAWAAN) -> str:
    seq = next_value(sesi, f"ticket:{saat.year:04d}-{saat.month:02d}")
    return render_pattern(
        pola, YYYY=f"{saat.year:04d}", MM=f"{saat.month:02d}", seq=seq
    )


def buat(sesi, aktor, data: dict, sekarang: datetime | None = None) -> Ticket:
    """Membuka tiket baru.

    Tenggat SLA dihitung sekali di sini dari kategori dan dibekukan di tiket.
    Menghitungnya saat dibaca berarti mengubah janji layanan akan mengubah
    tenggat tiket yang sudah berjalan — termasuk tiket yang sudah dilaporkan
    terlambat.
    """
    saat = sekarang or _sekarang()
    kategori = ambil_kategori(sesi, data["category_id"])

    prioritas = data.get("priority") or kategori.default_priority
    if prioritas not in PRIORITAS:
        raise PrioritasTidakSah("priority", f"Prioritas '{prioritas}' tidak dikenal.")

    tiket = Ticket(
        number=buat_nomor(sesi, saat),
        branch_id=data["branch_id"],
        customer_id=data.get("customer_id") or None,
        subscription_id=data.get("subscription_id") or None,
        category_id=kategori.id,
        title=data["title"],
        description=data["description"],
        priority=prioritas,
        status="baru",
        assigned_to_user_id=data.get("assigned_to_user_id") or None,
        opened_by_user_id=aktor.id if aktor else None,
        opened_at=saat,
        response_due_at=saat + timedelta(hours=kategori.sla_response_hours),
        resolve_due_at=saat + timedelta(hours=kategori.sla_resolve_hours),
    )
    rbac.assert_branch_access(aktor, tiket.branch_id)
    sesi.add(tiket)
    sesi.flush()

    audit.record(
        sesi, "create", "ticket", tiket.id,
        after=_potret(tiket, KOLOM_TIKET), aktor=aktor,
    )
    return tiket


def ambil(sesi, user, tiket_id: int) -> Ticket:
    tiket = sesi.get(Ticket, tiket_id)
    if tiket is None:
        raise TidakDitemukan("Tiket tidak ditemukan.")
    rbac.assert_branch_access(user, tiket.branch_id)
    return tiket


def hapus(sesi, aktor, tiket_id: int) -> int:
    """Hapus tiket beserta komentar dan lampirannya."""
    tiket = ambil(sesi, aktor, tiket_id)
    lampiran = list(
        sesi.execute(
            select(TicketAttachment).where(TicketAttachment.ticket_id == tiket.id)
        ).scalars()
    )
    audit.record(
        sesi, "delete", "ticket", tiket.id,
        before=_potret(tiket, KOLOM_TIKET), aktor=aktor,
    )
    sesi.delete(tiket)
    sesi.flush()

    for berkas in lampiran:
        try:
            files._di_dalam(berkas.path, current_app.config["UPLOAD_DIR"]).unlink(
                missing_ok=True
            )
        except files.PathDiluarUploadDir:
            _log.warning(
                "Lampiran tiket berada di luar direktori unggahan, tidak dihapus: %s",
                berkas.path,
            )
        except OSError:
            _log.exception("Lampiran tiket gagal dihapus: %s", berkas.path)

    return tiket.id


def ubah(sesi, aktor, tiket_id: int, data: dict) -> Ticket:
    """Menyunting isi tiket. Status **tidak** diubah lewat sini."""
    tiket = ambil(sesi, aktor, tiket_id)

    if data.get("priority") and data["priority"] not in PRIORITAS:
        raise PrioritasTidakSah("priority", f"Prioritas '{data['priority']}' tidak dikenal.")

    sebelum = _potret(tiket, KOLOM_TIKET)
    for nama in ("title", "description", "priority", "category_id",
                 "customer_id", "subscription_id", "assigned_to_user_id"):
        if nama in data:
            nilai = data[nama]
            if nama.endswith("_id") and not nilai:
                nilai = None
            setattr(tiket, nama, nilai)
    sesi.flush()

    audit.record(
        sesi, "update", "ticket", tiket.id,
        before=sebelum, after=_potret(tiket, KOLOM_TIKET), aktor=aktor,
    )
    return tiket


def ubah_status(
    sesi, aktor, tiket_id: int, status_baru: str,
    resolusi: str | None = None, sekarang: datetime | None = None,
) -> Ticket:
    """Memindahkan status tiket menurut peta `TRANSISI`.

    Satu-satunya tempat `status`, `resolved_at`, dan `closed_at` berubah.
    """
    tiket = ambil(sesi, aktor, tiket_id)
    saat = sekarang or _sekarang()

    if status_baru not in STATUS_TIKET:
        raise StatusTidakSah("status", f"Status '{status_baru}' tidak dikenal.")
    if status_baru == tiket.status:
        return tiket
    if status_baru not in TRANSISI[tiket.status]:
        raise StatusTidakSah(
            "status",
            f"Tiket berstatus '{tiket.status}' tidak bisa dipindahkan ke '{status_baru}'.",
        )

    if status_baru in STATUS_TUTUP and not (resolusi or tiket.resolution):
        raise ResolusiWajib(
            "resolution",
            "Tuliskan penyelesaiannya sebelum tiket ditutup — tiket tanpa "
            "penyelesaian tidak berguna saat gangguan yang sama terulang.",
        )

    sebelum = _potret(tiket, KOLOM_TIKET) | {"resolution": tiket.resolution}
    tiket.status = status_baru
    if resolusi:
        tiket.resolution = resolusi
    if status_baru == "selesai" and tiket.resolved_at is None:
        tiket.resolved_at = saat
    if status_baru == "ditutup":
        tiket.closed_at = saat
        # Ditutup langsung tanpa lewat `selesai` tetap dihitung sebagai
        # terselesaikan pada saat itu; tanpa ini SLA penyelesaiannya kosong.
        if tiket.resolved_at is None:
            tiket.resolved_at = saat
    sesi.flush()

    audit.record(
        sesi, "update", "ticket", tiket.id,
        before=sebelum,
        after=_potret(tiket, KOLOM_TIKET) | {"resolution": tiket.resolution},
        aktor=aktor,
    )
    return tiket


# --- Komentar dan lampiran ------------------------------------------------


def daftar_komentar(sesi, user, tiket_id: int, termasuk_internal: bool = True) -> list:
    ambil(sesi, user, tiket_id)
    query = (
        select(TicketComment)
        .where(TicketComment.ticket_id == tiket_id)
        .order_by(TicketComment.id)
    )
    if not termasuk_internal:
        query = query.where(TicketComment.is_internal.is_(False))
    return list(sesi.execute(query).scalars().all())


def tambah_komentar(
    sesi, aktor, tiket_id: int, body: str, is_internal: bool = True,
    sekarang: datetime | None = None,
) -> TicketComment:
    """Menambah komentar.

    Komentar **untuk pelanggan** yang pertama menandai `first_response_at` —
    itulah yang dijanjikan SLA respons. Catatan internal tidak menghentikan
    jam respons: pelanggan tidak pernah melihatnya.
    """
    tiket = ambil(sesi, aktor, tiket_id)
    saat = sekarang or _sekarang()

    komentar = TicketComment(
        ticket_id=tiket.id,
        user_id=aktor.id if aktor else None,
        body=body,
        is_internal=is_internal,
    )
    sesi.add(komentar)

    if not is_internal and tiket.first_response_at is None:
        tiket.first_response_at = saat

    sesi.flush()
    audit.record(
        sesi, "create", "ticket_comment", komentar.id,
        after={"ticket_id": tiket.id, "is_internal": is_internal},
        aktor=aktor,
    )
    return komentar


def daftar_lampiran(sesi, user, tiket_id: int) -> list[TicketAttachment]:
    ambil(sesi, user, tiket_id)
    return list(
        sesi.execute(
            select(TicketAttachment)
            .where(TicketAttachment.ticket_id == tiket_id)
            .order_by(TicketAttachment.id)
        ).scalars().all()
    )


def unggah_lampiran(
    sesi, aktor, tiket_id: int, stream, nama_asli: str, upload_dir: str
) -> TicketAttachment:
    from app.core import files

    tiket = ambil(sesi, aktor, tiket_id)
    tersimpan = files.simpan(stream, nama_asli, upload_dir)

    lampiran = TicketAttachment(
        ticket_id=tiket.id,
        branch_id=tiket.branch_id,
        original_name=tersimpan.original_name,
        path=tersimpan.path,
        size=tersimpan.size,
        mime=tersimpan.mime,
        uploaded_by_user_id=aktor.id if aktor else None,
    )
    sesi.add(lampiran)
    sesi.flush()
    audit.record(
        sesi, "create", "ticket_attachment", lampiran.id,
        after={"ticket_id": tiket.id, "original_name": lampiran.original_name},
        aktor=aktor,
    )
    return lampiran


def ambil_lampiran(sesi, user, lampiran_id: int) -> TicketAttachment:
    lampiran = sesi.get(TicketAttachment, lampiran_id)
    if lampiran is None:
        raise TidakDitemukan("Lampiran tidak ditemukan.")
    rbac.assert_branch_access(user, lampiran.branch_id)
    return lampiran


# --- Daftar, SLA, dan riwayat ---------------------------------------------


def terlambat(tiket: Ticket, sekarang: datetime | None = None) -> dict:
    """Keadaan SLA satu tiket.

    Dihitung, tidak disimpan: menyimpan "terlambat" berarti ada baris yang
    harus disegarkan penjadwal, dan tiket yang tidak pernah dibuka akan
    berbohong.
    """
    saat = sekarang or _sekarang()
    respons_lewat = bool(
        tiket.response_due_at
        and (tiket.first_response_at or saat) > tiket.response_due_at
    )
    selesai_lewat = bool(
        tiket.resolve_due_at and (tiket.resolved_at or saat) > tiket.resolve_due_at
    )
    return {
        "respons_lewat": respons_lewat,
        "selesai_lewat": selesai_lewat,
        "lewat": respons_lewat or selesai_lewat,
    }


def _query_daftar(
    user, q: str | None = None, status: str | None = None,
    prioritas: str | None = None, category_id: int | None = None,
    assigned_to: int | None = None, customer_id: int | None = None,
):
    """Query daftar tiket beserta seluruh filternya.

    Dipakai halaman daftar dan ekspor. Query kedua yang ditulis khusus untuk
    ekspor akan menyaring lain dari layarnya pada suatu hari — dan itu salah
    tanpa memberitahu siapa pun.
    """
    query = select(Ticket)

    if status:
        query = query.where(Ticket.status == status)
    if prioritas:
        query = query.where(Ticket.priority == prioritas)
    if category_id:
        query = query.where(Ticket.category_id == category_id)
    if assigned_to:
        query = query.where(Ticket.assigned_to_user_id == assigned_to)
    if customer_id:
        query = query.where(Ticket.customer_id == customer_id)
    if q:
        pola = f"%{q}%"
        query = query.where(
            or_(Ticket.number.ilike(pola), Ticket.title.ilike(pola))
        )

    return rbac.scoped(query, user, Ticket).order_by(Ticket.id.desc())


def daftar(sesi, user, page: int = 1, per_page: int = 25, **filter) -> Page:
    return paginate(sesi, _query_daftar(user, **filter), page=page, per_page=per_page)


def ringkasan(sesi, user) -> dict:
    """Angka kartu di halaman Ticketing."""
    per_status = dict(
        sesi.execute(
            rbac.scoped(
                select(Ticket.status, func.count(Ticket.id)).group_by(Ticket.status),
                user,
                Ticket,
            )
        ).all()
    )
    terbuka = sum(
        jumlah for status, jumlah in per_status.items() if status not in STATUS_TUTUP
    )
    kritis = sesi.execute(
        rbac.scoped(
            select(func.count(Ticket.id)).where(
                Ticket.priority == "kritis", Ticket.status.notin_(STATUS_TUTUP)
            ),
            user,
            Ticket,
        )
    ).scalar_one()

    saat = _sekarang()
    lewat = sesi.execute(
        rbac.scoped(
            select(func.count(Ticket.id)).where(
                Ticket.status.notin_(STATUS_TUTUP),
                Ticket.resolve_due_at.is_not(None),
                Ticket.resolve_due_at < saat,
            ),
            user,
            Ticket,
        )
    ).scalar_one()

    return {
        "per_status": per_status,
        "total": sum(per_status.values()),
        "terbuka": terbuka,
        "kritis": kritis,
        "lewat_sla": lewat,
    }


def laporan_sla(sesi, user, awal, akhir, sekarang: datetime | None = None) -> list[dict]:
    """Kepatuhan SLA per kategori untuk tiket yang **dibuka** dalam rentang.

    Dikelompokkan menurut tanggal dibuka, bukan tanggal selesai: pertanyaan
    yang dijawab adalah "dari tiket yang masuk bulan ini, berapa yang kami
    tangani sesuai janji". Mengelompokkan menurut tanggal selesai membuat
    tiket yang menunggak berpindah ke bulan berikutnya dan bulan yang buruk
    tampak baik.

    Tiket yang belum dijawab dan tenggatnya sudah lewat dihitung **terlambat**,
    bukan diabaikan — kalau tidak, kategori yang seluruh tiketnya terbengkalai
    akan memperlihatkan kepatuhan 100%.
    """
    # `sekarang` bisa disuntik: tanpa itu laporan tidak bisa diuji, karena
    # keterlambatan tiket yang belum selesai selalu diukur terhadap jam nyata.
    saat = sekarang or _sekarang()
    query = (
        select(Ticket, TicketCategory)
        .join(TicketCategory, Ticket.category_id == TicketCategory.id)
        .where(Ticket.opened_at >= awal, Ticket.opened_at < akhir)
    )
    query = rbac.scoped(query, user, Ticket)

    per_kategori: dict[int, dict] = {}
    for tiket, kategori in sesi.execute(query).all():
        baris = per_kategori.setdefault(
            kategori.id,
            {
                "kategori": kategori,
                "dibuka": 0,
                "selesai": 0,
                "respons_tepat": 0,
                "selesai_tepat": 0,
                "jam_penyelesaian": [],
            },
        )
        baris["dibuka"] += 1

        keadaan = terlambat(tiket, sekarang=saat)
        if not keadaan["respons_lewat"]:
            baris["respons_tepat"] += 1
        if tiket.resolved_at:
            baris["selesai"] += 1
            if not keadaan["selesai_lewat"]:
                baris["selesai_tepat"] += 1
            baris["jam_penyelesaian"].append(
                (tiket.resolved_at - tiket.opened_at).total_seconds() / 3600
            )

    hasil = []
    for baris in per_kategori.values():
        jam = baris.pop("jam_penyelesaian")
        hasil.append(
            baris
            | {
                "persen_respons": round(baris["respons_tepat"] * 100 / baris["dibuka"], 1),
                "persen_selesai": round(
                    baris["selesai_tepat"] * 100 / baris["dibuka"], 1
                ),
                # Rata-rata hanya dari yang benar-benar selesai; memasukkan
                # yang belum selesai sebagai nol membuat angkanya membaik
                # justru saat tiket menumpuk.
                "rata_jam": round(sum(jam) / len(jam), 1) if jam else None,
            }
        )
    return sorted(hasil, key=lambda b: b["kategori"].name)


def csv_sla(baris: list[dict]) -> str:
    """Ekspor laporan SLA. Angkanya sama persis dengan yang tampil di layar."""
    from app.core import csv_aman
    import io

    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(
        [
            "Kategori",
            "Dibuka",
            "Selesai",
            "Respons Tepat Waktu",
            "Persen Respons",
            "Selesai Tepat Waktu",
            "Persen Selesai",
            "Rata-rata Jam Penyelesaian",
        ]
    )
    for b in baris:
        tulis.writerow(
            [
                b["kategori"].name,
                b["dibuka"],
                b["selesai"],
                b["respons_tepat"],
                b["persen_respons"],
                b["selesai_tepat"],
                b["persen_selesai"],
                b["rata_jam"] if b["rata_jam"] is not None else "",
            ]
        )
    return keluaran.getvalue()


def _waktu(nilai) -> str:
    return nilai.strftime("%Y-%m-%d %H:%M") if nilai else ""


def csv_tiket(tiket: Ticket, kategori, komentar, pelanggan, langganan, sla: dict) -> str:
    """Satu tiket beserta riwayat komentarnya, sebagai satu berkas.

    Bentuknya dua blok dalam satu berkas — kepala tiket lalu daftar komentar —
    bukan dua berkas terpisah. Yang membukanya biasanya melampirkannya ke
    email atau tiket vendor, dan dua lampiran untuk satu gangguan justru
    memisahkan hal yang harus dibaca bersama.

    Komentar internal ikut. Rutenya berpenjaga peran yang sama dengan halaman
    detail, dan halaman itu pun menampilkan komentar internal — berkas yang
    diam-diam menyembunyikan sebagian riwayat lebih berbahaya daripada berkas
    yang lengkap, karena pembacanya mengira sudah melihat semuanya.
    """
    from app.core import csv_aman
    import io

    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)

    tulis.writerow(["Tiket", tiket.number])
    tulis.writerow(["Judul", tiket.title])
    tulis.writerow(["Kategori", kategori.name if kategori else ""])
    tulis.writerow(["Prioritas", tiket.priority])
    tulis.writerow(["Status", tiket.status])
    tulis.writerow(["Pelanggan", f"{pelanggan.cid} — {pelanggan.name}" if pelanggan else ""])
    tulis.writerow(["Nomor Layanan", langganan.service_no if langganan else ""])
    tulis.writerow(["Dibuka", _waktu(tiket.opened_at)])
    tulis.writerow(["Tenggat Respons", _waktu(tiket.response_due_at)])
    tulis.writerow(["Respons Pertama", _waktu(tiket.first_response_at)])
    tulis.writerow(["Tenggat Selesai", _waktu(tiket.resolve_due_at)])
    tulis.writerow(["Selesai", _waktu(tiket.resolved_at)])
    tulis.writerow(["Ditutup", _waktu(tiket.closed_at)])
    tulis.writerow(["Respons Terlambat", "ya" if sla.get("respons_lewat") else "tidak"])
    tulis.writerow(["Penyelesaian Terlambat", "ya" if sla.get("selesai_lewat") else "tidak"])
    tulis.writerow(["Deskripsi", tiket.description])
    tulis.writerow(["Resolusi", tiket.resolution or ""])

    tulis.writerow([])
    tulis.writerow(["Waktu", "Penulis", "Internal", "Komentar"])
    for baris in komentar:
        satu, penulis = baris if isinstance(baris, tuple) else (baris, None)
        tulis.writerow(
            [
                _waktu(satu.created_at),
                (penulis.full_name if penulis else "") or "",
                "ya" if satu.is_internal else "tidak",
                satu.body,
            ]
        )
    return keluaran.getvalue()


def csv_daftar_tiket(baris) -> str:
    """Daftar tiket sesuai filter yang sedang aktif."""
    from app.core import csv_aman
    import io

    keluaran = io.StringIO()
    tulis = csv_aman.penulis(keluaran)
    tulis.writerow(
        ["Nomor", "Judul", "Kategori", "Prioritas", "Status", "Dibuka",
         "Tenggat Selesai", "Selesai"]
    )
    for tiket, kategori in baris:
        tulis.writerow(
            [
                tiket.number,
                tiket.title,
                kategori.name if kategori else "",
                tiket.priority,
                tiket.status,
                _waktu(tiket.opened_at),
                _waktu(tiket.resolve_due_at),
                _waktu(tiket.resolved_at),
            ]
        )
    return keluaran.getvalue()


# Satu permintaan yang menarik seluruh tabel ke memori lalu merangkainya jadi
# satu string adalah cara termudah menjatuhkan worker. Pemanggil wajib
# memberi tahu pemakainya kalau batas ini kena — berkas yang tampak utuh
# padahal terpotong lebih berbahaya daripada berkas yang jelas terpotong.
BATAS_EKSPOR = 20_000


def daftar_untuk_ekspor(sesi, user, **filter):
    """Baris (tiket, kategori) untuk ekspor, memakai filter halaman daftar."""
    query = (
        _query_daftar(user, **filter)
        .join(TicketCategory, Ticket.category_id == TicketCategory.id)
        .add_columns(TicketCategory)
        .limit(BATAS_EKSPOR)
    )
    return sesi.execute(query).all()


def riwayat_layanan(sesi, user, subscription_id: int, limit: int = 20) -> list[Ticket]:
    """Riwayat gangguan satu langganan, terbaru dulu.

    Dipakai halaman detail langganan. Inilah yang menjawab "layanan ini sering
    bermasalah atau tidak" tanpa harus menyisir daftar tiket.
    """
    query = (
        select(Ticket)
        .where(Ticket.subscription_id == subscription_id)
        .order_by(Ticket.id.desc())
        .limit(limit)
    )
    return list(sesi.execute(rbac.scoped(query, user, Ticket)).scalars().all())
