from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.pagination import per_halaman_dari
from app.core.rbac import is_cross_branch, require_role
from app.modules.admin import service
from app.modules.admin.forms import CabangForm, UserForm
from app.modules.customers.forms import HapusForm

bp = Blueprint("admin", __name__)


@bp.get("/cabang")
@require_role("superadmin", "admin_cabang", "billing", "teknis", "viewer")
def cabang_daftar():
    halaman = service.daftar_cabang(
        db_session,
        current_user(),
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "admin/cabang_daftar.html", halaman=halaman, form_hapus=HapusForm()
    )


@bp.route("/cabang/baru", methods=["GET", "POST"])
@require_role("superadmin")
def cabang_baru():
    form = CabangForm()
    if form.validate_on_submit():
        try:
            service.buat_cabang(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.cabang_daftar"))
    return render_template("admin/cabang_form.html", form=form, judul="Tambah Cabang")


@bp.route("/cabang/<int:branch_id>/ubah", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang")
def cabang_ubah(branch_id: int):
    cabang = service.ambil_cabang(db_session, current_user(), branch_id)
    form = CabangForm(obj=cabang)
    if form.validate_on_submit():
        try:
            service.ubah_cabang(db_session, current_user(), branch_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.cabang_daftar"))
    return render_template("admin/cabang_form.html", form=form, judul="Ubah Cabang")


@bp.post("/cabang/<int:branch_id>/hapus")
@require_role("superadmin")
def cabang_hapus(branch_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman cabang.", "bahaya")
        return redirect(url_for("admin.cabang_daftar"))
    try:
        service.hapus_cabang(db_session, current_user(), branch_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash("Cabang dihapus.", "sukses")
    return redirect(url_for("admin.cabang_daftar"))


@bp.get("/pengaturan/user")
@require_role("superadmin", "admin_cabang")
def user_daftar():
    halaman = service.daftar_user_dengan_cabang(
        db_session,
        current_user(),
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template("admin/user_daftar.html", halaman=halaman)


@bp.get("/pengaturan/audit")
@require_role("superadmin")
def audit_daftar():
    """Audit log seluruh sistem.

    Superadmin saja. Baris audit tidak menyimpan `branch_id` sama sekali, jadi
    tidak ada cara jujur menyaringnya per cabang — dan menampilkan apa adanya
    ke admin cabang berarti membocorkan gerak-gerik cabang lain lewat pintu
    belakang.
    """
    from datetime import date

    def _tanggal(nama):
        teks = (request.args.get(nama) or "").strip()
        try:
            return date.fromisoformat(teks) if teks else None
        except ValueError:
            return None

    filter_ = {
        "actor_user_id": request.args.get("actor_user_id", type=int),
        "action": (request.args.get("action") or "").strip(),
        "entity_type": (request.args.get("entity_type") or "").strip(),
        "dari": _tanggal("dari"),
        "sampai": _tanggal("sampai"),
    }
    halaman = service.daftar_audit(
        db_session,
        filter_,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "admin/audit_daftar.html",
        halaman=halaman,
        filter=filter_,
        pilihan=service.pilihan_audit(db_session),
    )


@bp.route("/pengaturan/user/baru", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang")
def user_baru():
    form = UserForm()
    form.branch_id.choices = _pilihan_cabang()
    form.role.choices = _pilihan_peran()
    if form.validate_on_submit():
        data = _data_user(form)
        try:
            service.buat_user(db_session, current_user(), data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.user_daftar"))
    return render_template("admin/user_form.html", form=form, judul="Tambah User")


@bp.route("/pengaturan/user/<int:user_id>/ubah", methods=["GET", "POST"])
@require_role("superadmin", "admin_cabang")
def user_ubah(user_id: int):
    target = service.ambil_user(db_session, current_user(), user_id)
    form = UserForm(obj=target)
    form.branch_id.choices = _pilihan_cabang()
    form.role.choices = _pilihan_peran()
    if form.validate_on_submit():
        data = _data_user(form)
        try:
            service.ubah_user(db_session, current_user(), user_id, data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("admin.user_daftar"))
    return render_template("admin/user_form.html", form=form, judul="Ubah User")


def _data_user(form) -> dict:
    data = dict(form.data)
    if data.get("branch_id") in (0, None, ""):
        data["branch_id"] = None
    return data


def _pilihan_cabang():
    cabang = service.semua_cabang(db_session, current_user())
    pilihan = [(c.id, f"{c.code} — {c.name}") for c in cabang]
    if is_cross_branch(current_user()):
        pilihan.insert(0, (0, "— Tanpa cabang (lintas cabang) —"))
    return pilihan


def _pilihan_peran():
    return [(r, r) for r in service.peran_dapat_diberikan(current_user())]
