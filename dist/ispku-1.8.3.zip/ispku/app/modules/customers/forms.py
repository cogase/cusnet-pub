from app.core.forms import FormDasar
from flask_wtf.file import FileAllowed, FileField, FileRequired
from wtforms import (
    BooleanField,
    DateField,
    IntegerField,
    SelectField,
    StringField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    InputRequired,
    Length,
    NumberRange,
    Optional,
    ValidationError,
)

from app.modules.customers.models import (
    JENIS_DOKUMEN,
    MODE_INVOICE,
    PERAN_KONTAK,
    STATUS_PELANGGAN,
    SUMBER_PELANGGAN,
    TIER_PELANGGAN,
    TIPE_PELANGGAN,
    TIPE_PEMBAYARAN,
)
from app.modules.customers.subscriptions import (
    JENIS_DISKON,
    JENIS_INTERNET,
    STATUS_LANGGANAN,
)
from app.modules.services.forms import DesimalIndonesia, DesimalOpsional

LABEL_TIPE_PELANGGAN = {
    "corporate": "Corporate",
    "sme": "SME",
    "personal": "Personal",
}
LABEL_TIER = {"regular": "Regular", "premium": "Premium"}
LABEL_SUMBER = {
    "referral": "Referral",
    "marketing": "Marketing",
    "walk_in": "Walk In",
    "tender": "Tender",
    "lainnya": "Lainnya",
}
LABEL_STATUS = {
    "pending": "Pending",
    "active": "Active",
    "suspend": "Suspend",
    "terminasi": "Terminasi",
}
LABEL_MODE_INVOICE = {"gabungan": "Gabungan", "terpisah": "Terpisah"}
LABEL_TIPE_PEMBAYARAN = {"postpaid": "Postpaid", "prepaid": "Prepaid"}
LABEL_PERAN_KONTAK = {
    "pic_utama": "PIC Utama",
    "billing": "Billing",
    "teknis": "Teknis",
}
LABEL_JENIS_DOKUMEN = {
    "ktp": "KTP",
    "npwp": "NPWP",
    "kontrak": "Kontrak",
    "bast": "BAST",
    "lainnya": "Lainnya",
}

NADA_STATUS_PELANGGAN = {
    "active": "sukses",
    "suspend": "jingga",
    "pending": "ungu",
    "terminasi": "bahaya",
}


class PilihanIndonesia(SelectField):
    """`SelectField` dengan pesan pilihan tidak sah berbahasa Indonesia.

    Bawaan WTForms melempar "Not a valid choice." Pesan ini muncul pada
    permintaan yang mengirim nilai di luar daftar — mis. staf cabang yang
    memaksa `branch_id` cabang lain, yang daftar pilihannya memang tidak
    pernah memuat cabang itu. Penjagaan hak aksesnya sendiri tetap ada di
    `service.buat_pelanggan` lewat `rbac.assert_branch_access`.
    """

    def pre_validate(self, form):
        try:
            super().pre_validate(form)
        except ValueError as galat:
            # Harus `ValidationError`: WTForms hanya menangkap kelas itu di
            # `Field.validate`. `ValueError` polos menembus keluar dan menjadi
            # 500, bukan pesan galat di sebelah kolomnya.
            raise ValidationError("Pilihan tidak sah.") from galat


class KategoriPelangganForm(FormDasar):
    name = StringField(
        "Nama Kategori",
        validators=[DataRequired(message="Nama kategori wajib diisi."), Length(max=80)],
    )
    is_active = BooleanField("Aktif", default=True)


class PelangganForm(FormDasar):
    # Identitas
    name = StringField(
        "Nama Customer",
        validators=[
            DataRequired(message="Nama customer wajib diisi."),
            Length(max=160),
        ],
    )
    alias = StringField("Alias", validators=[Optional(), Length(max=80)])
    cid = StringField("CID", validators=[Optional(), Length(max=40)])
    branch_id = PilihanIndonesia("Cabang", coerce=int)
    customer_type = PilihanIndonesia(
        "Tipe Customer", choices=[(t, LABEL_TIPE_PELANGGAN[t]) for t in TIPE_PELANGGAN]
    )
    tier = PilihanIndonesia("Tier", choices=[(t, LABEL_TIER[t]) for t in TIER_PELANGGAN])
    category_id = PilihanIndonesia("Kategori", coerce=int)
    source = PilihanIndonesia(
        "Sumber",
        choices=[("", "—")] + [(s, LABEL_SUMBER[s]) for s in SUMBER_PELANGGAN],
    )
    sales_user_id = PilihanIndonesia("Sales", coerce=int)

    # Alamat
    install_address = TextAreaField(
        "Alamat Instalasi", validators=[Optional(), Length(max=500)]
    )
    install_lat = StringField("Latitude", validators=[Optional(), Length(max=20)])
    install_lng = StringField("Longitude", validators=[Optional(), Length(max=20)])
    billing_same_as_install = BooleanField(
        "Alamat penagihan sama dengan alamat instalasi", default=True
    )
    billing_address = TextAreaField(
        "Alamat Penagihan", validators=[Optional(), Length(max=500)]
    )

    # Identitas pajak
    ktp_number = StringField("Nomor KTP", validators=[Optional(), Length(max=32)])
    npwp_number = StringField("NPWP", validators=[Optional(), Length(max=32)])

    # Status
    status = PilihanIndonesia(
        "Status", choices=[(s, LABEL_STATUS[s]) for s in STATUS_PELANGGAN]
    )
    status_note = TextAreaField(
        "Catatan Status", validators=[Optional(), Length(max=2000)]
    )
    joined_at = DateField("Tanggal Bergabung", validators=[Optional()])

    # Billing
    invoice_mode = PilihanIndonesia(
        "Mode Invoice", choices=[(m, LABEL_MODE_INVOICE[m]) for m in MODE_INVOICE]
    )
    payment_type = PilihanIndonesia(
        "Tipe Pembayaran",
        choices=[(t, LABEL_TIPE_PEMBAYARAN[t]) for t in TIPE_PEMBAYARAN],
    )
    credit_limit = DesimalOpsional(
        "Kredit Limit", places=2, use_locale=False, validators=[Optional()]
    )
    ppn_exempt = BooleanField("Bebas PPN")
    payment_term_days = IntegerField(
        "Termin Bayar (hari)",
        validators=[
            Optional(),
            NumberRange(min=0, max=365, message="Termin bayar harus antara 0 dan 365 hari."),
        ],
    )


class KontakForm(FormDasar):
    name = StringField(
        "Nama",
        validators=[DataRequired(message="Nama kontak wajib diisi."), Length(max=120)],
    )
    job_title = StringField("Jabatan", validators=[Optional(), Length(max=120)])
    role = PilihanIndonesia(
        "Peran", choices=[(p, LABEL_PERAN_KONTAK[p]) for p in PERAN_KONTAK]
    )
    phone = StringField("Telepon", validators=[Optional(), Length(max=40)])
    email = StringField(
        "Email",
        validators=[
            Optional(),
            Email(message="Format email tidak sah."),
            Length(max=160),
        ],
    )
    is_primary = BooleanField("Jadikan PIC utama")


class DokumenForm(FormDasar):
    doc_type = PilihanIndonesia(
        "Jenis Dokumen", choices=[(j, LABEL_JENIS_DOKUMEN[j]) for j in JENIS_DOKUMEN]
    )
    berkas = FileField(
        "Berkas",
        validators=[
            FileRequired(message="Pilih berkas yang akan diunggah."),
            # Pemeriksaan ekstensi hanya kenyamanan. Penjagaan sungguhannya
            # tetap `files.deteksi_mime`, yang membaca angka ajaib isi berkas.
            FileAllowed(
                ["jpg", "jpeg", "png", "pdf"],
                message="Hanya JPG, PNG, dan PDF yang diterima.",
            ),
        ],
    )


LABEL_STATUS_LANGGANAN = {
    "pending": "Pending",
    "active": "Active",
    "suspend": "Suspend",
    "terminasi": "Terminasi",
}
LABEL_JENIS_INTERNET = {"dedicated": "Dedicated", "broadband": "Broadband"}
LABEL_JENIS_DISKON = {"persen": "Persen (%)", "nominal": "Nominal (Rp)"}


class LanggananForm(FormDasar):
    plan_id = PilihanIndonesia("Paket Layanan", coerce=int)
    site_name = StringField("Site", validators=[Optional(), Length(max=120)])
    status = PilihanIndonesia(
        "Status", choices=[(s, LABEL_STATUS_LANGGANAN[s]) for s in STATUS_LANGGANAN]
    )
    started_at = DateField("Tanggal Mulai", validators=[Optional()])
    activated_at = DateField("Tanggal Aktivasi", validators=[Optional()])
    terminated_at = DateField("Tanggal Berhenti", validators=[Optional()])

    ip_address = StringField(
        "IP Address", validators=[Optional(), Length(max=60)]
    )
    vlan = StringField("VLAN", validators=[Optional(), Length(max=20)])
    interface = StringField("Interface", validators=[Optional(), Length(max=60)])
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=2000)])

    # Blok nominal: hanya dirender dan diterima untuk peran yang berhak.
    price_override = DesimalOpsional(
        "Harga Khusus", places=2, use_locale=False, validators=[Optional()]
    )
    discount_kind = PilihanIndonesia(
        "Jenis Diskon",
        choices=[("", "—")] + [(j, LABEL_JENIS_DISKON[j]) for j in JENIS_DISKON],
    )
    discount_value = DesimalOpsional(
        "Nilai Diskon", places=2, use_locale=False, validators=[Optional()]
    )


class InternetForm(FormDasar):
    capacity_mbps = IntegerField(
        "Kapasitas (Mbps)", validators=[Optional(), NumberRange(min=0, max=1000000)]
    )
    internet_kind = PilihanIndonesia(
        "Jenis", choices=[(j, LABEL_JENIS_INTERNET[j]) for j in JENIS_INTERNET]
    )
    vendor_id = PilihanIndonesia("Vendor", coerce=int)
    odp_name = StringField("Lokasi ODP / OLT", validators=[Optional(), Length(max=120)])
    odp_lat = StringField("Latitude ODP", validators=[Optional(), Length(max=20)])
    odp_lng = StringField("Longitude ODP", validators=[Optional(), Length(max=20)])


class P2PForm(FormDasar):
    capacity_mbps = IntegerField(
        "Kapasitas (Mbps)", validators=[Optional(), NumberRange(min=0, max=1000000)]
    )
    vendor_id = PilihanIndonesia("Vendor", coerce=int)


class TerminasiForm(FormDasar):
    site_name = StringField(
        "Nama Site",
        validators=[DataRequired(message="Nama site wajib diisi."), Length(max=120)],
    )
    address = TextAreaField("Alamat", validators=[Optional(), Length(max=500)])
    lat = StringField("Latitude", validators=[Optional(), Length(max=20)])
    lng = StringField("Longitude", validators=[Optional(), Length(max=20)])
    vlan = StringField("VLAN", validators=[Optional(), Length(max=20)])
    interface = StringField("Interface / Perangkat", validators=[Optional(), Length(max=60)])


class HopForm(FormDasar):
    vendor_id = PilihanIndonesia("Vendor Provider", coerce=int)
    label = StringField(
        "Label Hop", validators=[Optional(), Length(max=120)],
        render_kw={"placeholder": "Contoh: Transit Jakarta – Surabaya"},
    )
    circuit_id = StringField(
        "Vendor Circuit ID", validators=[Optional(), Length(max=80)],
        render_kw={"placeholder": "Contoh: CID-JKT-SBY-00123"},
    )
    vendor_phone = StringField(
        "No. Telp Vendor", validators=[Optional(), Length(max=40)],
        render_kw={"placeholder": "Contoh: 021-5551234 (NOC 24 jam)"},
    )
    vlan = StringField(
        "VLAN Vendor", validators=[Optional(), Length(max=20)],
        render_kw={"placeholder": "Contoh: 313"},
    )
    physical_note = TextAreaField(
        "Keterangan Fisik / Jalur Kabel",
        validators=[Optional(), Length(max=1000)],
        render_kw={
            "placeholder": "Contoh: FO 24 core via tiang PLN Jl. Sudirman, "
            "tube biru core 3, masuk ODC-JKT-07"
        },
    )
    note = StringField(
        "Catatan", validators=[Optional(), Length(max=200)],
        render_kw={"placeholder": "Contoh: kontrak berakhir Desember 2027"},
    )


class AddonForm(FormDasar):
    description = StringField(
        "Deskripsi",
        validators=[DataRequired(message="Deskripsi wajib diisi."), Length(max=160)],
    )
    qty = IntegerField(
        "Jumlah",
        default=1,
        validators=[
            InputRequired(message="Jumlah wajib diisi."),
            NumberRange(min=1, message="Jumlah minimal 1."),
        ],
    )
    unit_price = DesimalIndonesia(
        "Harga Satuan",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Harga satuan wajib diisi."),
            NumberRange(min=0, message="Harga satuan tidak boleh negatif."),
        ],
    )
    is_active = BooleanField("Aktif", default=True)


class CicilanForm(FormDasar):
    description = StringField(
        "Deskripsi", default="Biaya Instalasi", validators=[Optional(), Length(max=160)]
    )
    total_amount = DesimalIndonesia(
        "Total Biaya",
        places=2,
        use_locale=False,
        validators=[
            InputRequired(message="Total biaya wajib diisi."),
            NumberRange(min=0, message="Total biaya tidak boleh negatif."),
        ],
    )
    terms = IntegerField(
        "Jumlah Termin",
        validators=[
            InputRequired(message="Jumlah termin wajib diisi."),
            NumberRange(min=1, max=120, message="Jumlah termin antara 1 dan 120."),
        ],
    )
    started_at = DateField("Mulai Ditagih", validators=[Optional()])


class HapusForm(FormDasar):
    """Formulir kosong untuk tombol hapus.

    Ada semata-mata supaya tombol hapus membawa token CSRF dan rutenya bisa
    memvalidasinya. Tanpa ini, `POST .../hapus` dari halaman mana pun di
    internet menghapus data pengguna yang sedang masuk.
    """


class CatatanForm(FormDasar):
    body = TextAreaField(
        "Catatan",
        validators=[
            DataRequired(message="Catatan tidak boleh kosong."),
            Length(max=4000),
        ],
    )
