"""Perakit topologi titik-ke-titik sebagai SVG.

Dirender di server, tanpa pustaka JavaScript: pemasangan pelanggan tidak
dijamin punya akses internet, dan seluruh aset harus ikut dalam berkas.

    [ Site A ]───( Vendor Transit X )───[ Site B ]
     VLAN 100                            VLAN 100
     ge-0/0/1                            xe-1/0/3
"""

from markupsafe import escape

LEBAR_KOTAK = 190
LEBAR_PENGHUBUNG = 90
TINGGI = 150
TINGGI_KOTAK = 78
JARAK_TEPI = 12


def _kotak(x: int, judul: str, baris: list[str], nada: str) -> str:
    """Satu kotak beserta baris keterangannya."""
    isi = [
        f'<rect x="{x}" y="26" width="{LEBAR_KOTAK}" height="{TINGGI_KOTAK}" rx="10" '
        f'fill="{nada}" stroke="#E5E9F0"/>',
        f'<text x="{x + LEBAR_KOTAK // 2}" y="52" text-anchor="middle" '
        f'class="topologi__judul">{escape(judul)}</text>',
    ]
    for nomor, teks in enumerate(baris):
        if not teks:
            continue
        isi.append(
            f'<text x="{x + LEBAR_KOTAK // 2}" y="{72 + nomor * 16}" '
            f'text-anchor="middle" class="topologi__ket">{escape(teks)}</text>'
        )
    return "".join(isi)


def _penghubung(x: int) -> str:
    tengah = 26 + TINGGI_KOTAK // 2
    return (
        f'<line x1="{x}" y1="{tengah}" x2="{x + LEBAR_PENGHUBUNG}" y2="{tengah}" '
        'stroke="#94A3B8" stroke-width="2"/>'
    )


def rakit_svg(terminasi: list, hop: list) -> str:
    """Merakit markup topologi.

    `viewBox` dihitung dari isi, bukan dari kanvas: `viewBox` seukuran kanvas
    membuat gambar menyusut drastis begitu hop-nya banyak, dan itu sudah
    pernah terjadi pada data produksi di proyek lain. Kanvasnya diberi lebar
    piksel supaya pembungkusnya bisa menggulir secara native.
    """
    if not terminasi:
        return '<p class="form__bantuan">Belum ada terminasi. Isi kedua ujungnya dulu.</p>'

    urut = sorted(terminasi, key=lambda t: t.side)
    simpul: list[tuple[str, list[str], str]] = []

    if urut:
        simpul.append(
            (
                urut[0].site_name,
                [
                    f"VLAN {urut[0].vlan}" if urut[0].vlan else "",
                    urut[0].interface or "",
                ],
                "#EFF6FF",
            )
        )
    for baris in sorted(hop, key=lambda h: h.urutan):
        simpul.append((baris.label or "Vendor transit", [baris.note or ""], "#FFEDD5"))
    if len(urut) > 1:
        simpul.append(
            (
                urut[1].site_name,
                [
                    f"VLAN {urut[1].vlan}" if urut[1].vlan else "",
                    urut[1].interface or "",
                ],
                "#EFF6FF",
            )
        )

    lebar = (
        JARAK_TEPI * 2
        + len(simpul) * LEBAR_KOTAK
        + max(len(simpul) - 1, 0) * LEBAR_PENGHUBUNG
    )

    bagian = []
    x = JARAK_TEPI
    for nomor, (judul, keterangan, nada) in enumerate(simpul):
        if nomor:
            bagian.append(_penghubung(x - LEBAR_PENGHUBUNG))
        bagian.append(_kotak(x, judul, keterangan, nada))
        x += LEBAR_KOTAK + LEBAR_PENGHUBUNG

    # Tanpa atribut `xmlns`: SVG sebaris di dalam HTML sudah mendapat namespace
    # dari parser peramban, sedangkan menuliskannya menaruh URL berskema http
    # di halaman — persis yang dilarang aturan tanpa CDN dan dipindai uji
    # penjaga, walau URL itu tidak pernah diambil dari jaringan.
    return (
        f'<svg class="topologi__gambar" width="{lebar}" height="{TINGGI}" '
        f'viewBox="0 0 {lebar} {TINGGI}" role="img" aria-label="Topologi layanan">'
        + "".join(bagian)
        + "</svg>"
    )
