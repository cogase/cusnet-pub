from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.pagination import per_halaman_dari
from app.core.rbac import require_role
from app.modules.customers import subscription_service
from app.modules.customers.forms import HapusForm
from app.modules.services import service
from app.modules.services.forms import (
    LABEL_BENTUK_FORMULIR,
    KategoriLayananForm,
    PaketLayananForm,
    VendorForm,
)

bp = Blueprint("services", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
TULIS = ("superadmin", "admin_cabang")

KOLOM_TABEL_LAYANAN = (
    {"kunci": "nama", "judul": "Nama Layanan", "wajib": True},
    {"kunci": "kategori", "judul": "Kategori"},
    {"kunci": "kapasitas", "judul": "Paket / Kapasitas"},
    {"kunci": "harga", "judul": "Harga"},
    {"kunci": "customer", "judul": "Customer Aktif"},
    {"kunci": "status", "judul": "Status"},
)
KUNCI_KOLOM_LAYANAN = tuple(k["kunci"] for k in KOLOM_TABEL_LAYANAN)


def _kolom_layanan_terpilih(diminta):
    """Validasi preferensi kolom; nama dan aksi tetap tersedia."""
    valid = {kunci for kunci in (diminta or ()) if kunci in KUNCI_KOLOM_LAYANAN}
    if not valid:
        return list(KUNCI_KOLOM_LAYANAN)
    valid.add("nama")
    return [kunci for kunci in KUNCI_KOLOM_LAYANAN if kunci in valid]


@bp.get("/vendor")
@require_role(*BACA)
def vendor_daftar():
    halaman = service.daftar_vendor(
        db_session,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "services/vendor_daftar.html", halaman=halaman, form_hapus=HapusForm()
    )


@bp.get("/vendor/<int:vendor_id>")
@require_role(*BACA)
def vendor_detail(vendor_id: int):
    vendor = service.ambil_vendor(db_session, vendor_id)
    langganan = subscription_service.daftar_langganan_vendor(
        db_session, current_user(), vendor_id
    )
    return render_template(
        "services/vendor_detail.html", vendor=vendor, langganan=langganan
    )


@bp.route("/vendor/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def vendor_baru():
    form = VendorForm()
    if form.validate_on_submit():
        try:
            service.buat_vendor(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.vendor_daftar"))
    return render_template(
        "services/vendor_form.html", form=form, judul="Tambah Vendor"
    )


@bp.route("/vendor/<int:vendor_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def vendor_ubah(vendor_id: int):
    vendor = service.ambil_vendor(db_session, vendor_id)
    form = VendorForm(obj=vendor)
    if form.validate_on_submit():
        try:
            service.ubah_vendor(db_session, current_user(), vendor_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.vendor_daftar"))
    return render_template("services/vendor_form.html", form=form, judul="Ubah Vendor")


@bp.post("/vendor/<int:vendor_id>/hapus")
@require_role(*TULIS)
def vendor_hapus(vendor_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman vendor.", "bahaya")
        return redirect(url_for("services.vendor_daftar"))
    service.hapus_vendor(db_session, current_user(), vendor_id)
    db_session.commit()
    flash("Vendor dihapus. Rujukan teknis yang ada tetap tersimpan.", "sukses")
    return redirect(url_for("services.vendor_daftar"))


def _filter_paket() -> dict:
    """Filter Daftar Layanan dari query string.

    Dipakai halaman daftar dan ekspor. Dua pembaca filter yang ditulis
    terpisah akan berbeda pada suatu hari, dan ekspor yang menyaring lain
    dari layarnya salah tanpa memberitahu siapa pun.
    """
    return {
        "kategori_id": request.args.get("kategori", type=int),
        "q": request.args.get("q") or None,
        "aktif": {"aktif": True, "nonaktif": False}.get(request.args.get("status")),
    }


@bp.get("/layanan/paket.csv")
@require_role(*BACA)
def paket_ekspor():
    """Daftar paket layanan sebagai CSV, mengikuti filter yang sedang aktif."""
    from flask import Response

    isi, terpotong = service.ekspor_paket(db_session, **_filter_paket())
    nama = (
        f"paket-terpotong-{service.BATAS_EKSPOR}.csv" if terpotong else "paket.csv"
    )
    return Response(
        isi,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nama}"'},
    )


@bp.get("/layanan")
@require_role(*BACA)
def layanan_daftar():
    user = current_user()
    kategori_id = request.args.get("kategori", type=int)
    status = request.args.get("status")
    q = request.args.get("q")
    tersimpan = (user.preferences or {}).get("service_list_columns")
    diminta = request.args.getlist("kolom") if "kolom" in request.args else tersimpan
    kolom = _kolom_layanan_terpilih(diminta)
    halaman = service.daftar_paket(
        db_session,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        **_filter_paket(),
    )
    # Panel Detail Layanan di kanan mengikuti baris yang dipilih. Tanpa
    # `?paket=`, yang ditampilkan baris pertama halaman ini — bukan baris
    # pertama seluruh katalog.
    paket_id = request.args.get("paket", type=int)
    terpilih = terpilih_kategori = None
    for paket, kategori in halaman.items:
        if terpilih is None or paket.id == paket_id:
            terpilih, terpilih_kategori = paket, kategori
        if paket.id == paket_id:
            break

    return render_template(
        "services/layanan_daftar.html",
        halaman=halaman,
        terpilih=terpilih,
        terpilih_kategori=terpilih_kategori,
        ringkasan=service.ringkasan_layanan(db_session),
        pelanggan_per_paket=subscription_service.jumlah_pelanggan_per_paket(
            db_session, user
        ),
        terpopuler=subscription_service.paket_terpopuler(db_session, user),
        kategori_aktif=kategori_id,
        status_aktif=status or "",
        q=q or "",
        kolom=kolom,
        kolom_tabel=KOLOM_TABEL_LAYANAN,
        form_hapus=HapusForm(),
    )


@bp.post("/layanan/kolom")
@require_role(*BACA)
def kolom_layanan_simpan():
    from urllib.parse import parse_qs, urlencode, urlsplit

    form = HapusForm()
    if not form.validate_on_submit():
        flash("Preferensi kolom tidak disimpan karena formulir tidak valid.", "bahaya")
        return redirect(url_for("services.layanan_daftar"))

    user = current_user()
    prefs = dict(user.preferences or {})
    prefs["service_list_columns"] = _kolom_layanan_terpilih(
        request.form.getlist("kolom")
    )
    user.preferences = prefs
    db_session.commit()

    tujuan = urlsplit(request.form.get("next", ""))
    params = parse_qs(tujuan.query)
    params.pop("kolom", None)
    boleh = {"q", "kategori", "status", "page", "paket"}
    query = urlencode(
        {k: v for k, v in params.items() if k in boleh}, doseq=True
    )
    return redirect("/layanan" + (f"?{query}" if query else ""))


@bp.get("/layanan/kategori")
@require_role(*BACA)
def kategori_daftar():
    halaman = service.daftar_kategori(
        db_session,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "services/kategori_daftar.html",
        halaman=halaman,
        label_bentuk_formulir=LABEL_BENTUK_FORMULIR,
        form_hapus=HapusForm(),
    )


@bp.route("/layanan/kategori/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def kategori_baru():
    form = KategoriLayananForm()
    if form.validate_on_submit():
        try:
            service.buat_kategori(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.kategori_daftar"))
    return render_template(
        "services/kategori_form.html", form=form, judul="Tambah Kategori Layanan"
    )


@bp.route("/layanan/kategori/<int:kategori_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def kategori_ubah(kategori_id: int):
    kategori = service.ambil_kategori(db_session, kategori_id)
    form = KategoriLayananForm(obj=kategori)
    if form.validate_on_submit():
        try:
            service.ubah_kategori(db_session, current_user(), kategori_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.kategori_daftar"))
    return render_template(
        "services/kategori_form.html", form=form, judul="Ubah Kategori Layanan"
    )


@bp.post("/layanan/kategori/<int:kategori_id>/hapus")
@require_role(*TULIS)
def kategori_hapus(kategori_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman kategori.", "bahaya")
        return redirect(url_for("services.kategori_daftar"))
    service.hapus_kategori(db_session, current_user(), kategori_id)
    db_session.commit()
    flash(
        "Kategori dan seluruh paket, layanan, invoice, pembayaran, serta tiket terkait dihapus.",
        "sukses",
    )
    return redirect(url_for("services.kategori_daftar"))


@bp.post("/layanan/paket/<int:paket_id>/hapus")
@require_role(*TULIS)
def paket_hapus(paket_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return redirect(url_for("services.layanan_daftar"))
    service.hapus_paket(db_session, current_user(), paket_id)
    db_session.commit()
    flash("Paket dan seluruh layanan serta transaksi terkait dihapus.", "sukses")
    return redirect(url_for("services.layanan_daftar"))


def _isi_pilihan_kategori(form: PaketLayananForm) -> None:
    kategori = service.semua_kategori(db_session)
    form.category_id.choices = [(k.id, k.name) for k in kategori]


@bp.route("/layanan/paket/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def paket_baru():
    form = PaketLayananForm()
    _isi_pilihan_kategori(form)
    if form.validate_on_submit():
        try:
            service.buat_paket(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.layanan_daftar"))
    return render_template(
        "services/paket_form.html", form=form, judul="Tambah Paket Layanan"
    )


@bp.route("/layanan/paket/<int:paket_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def paket_ubah(paket_id: int):
    paket = service.ambil_paket(db_session, paket_id)
    form = PaketLayananForm(obj=paket)
    _isi_pilihan_kategori(form)
    if form.validate_on_submit():
        try:
            service.ubah_paket(db_session, current_user(), paket_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("services.layanan_daftar"))
    return render_template(
        "services/paket_form.html", form=form, judul="Ubah Paket Layanan"
    )


@bp.post("/layanan/paket/<int:paket_id>/nonaktifkan")
@require_role(*TULIS)
def paket_nonaktifkan(paket_id: int):
    return _set_aktif_paket(paket_id, False)


@bp.post("/layanan/paket/<int:paket_id>/aktifkan")
@require_role(*TULIS)
def paket_aktifkan(paket_id: int):
    return _set_aktif_paket(paket_id, True)


def _set_aktif_paket(paket_id: int, aktif: bool):
    """POST, bukan GET: mengubah keadaan lewat tautan berarti prefetch
    peramban atau perayap bisa mematikan paket tanpa ada yang menekan apa pun.

    Paketnya diambil lebih dulu supaya paket yang tidak ada tetap menjawab
    404, bukan 302 yang seolah-olah berhasil.
    """
    service.ambil_paket(db_session, paket_id)
    kembali = redirect(request.referrer or url_for("services.layanan_daftar"))
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Layanan.", "bahaya")
        return kembali

    service.set_aktif_paket(db_session, current_user(), paket_id, aktif)
    db_session.commit()
    return kembali
