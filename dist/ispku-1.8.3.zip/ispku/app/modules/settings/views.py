from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app.core import waktu
from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.files import FileError, sajikan, simpan
from app.core.rbac import require_role
from app.modules.settings import service
from app.modules.settings.forms import (
    CadanganForm,
    EmailPengirimanForm,
    HapusRekeningForm,
    KopSuratForm,
    MerekForm,
    PemulihanForm,
    PengaturanBillingForm,
    RekeningForm,
)

bp = Blueprint("settings", __name__)

TULIS = ("superadmin", "admin_cabang", "billing")
BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
# Berkas cadangan berisi seluruh basis data — hash sandi, KTP, NPWP, dan
# seluruh cabang sekaligus. Ini bukan kemampuan yang boleh dipegang admin
# cabang, betapapun praktisnya.
SISTEM = ("superadmin",)


def _halaman_billing(form=None, form_kop=None, form_email=None, tab="penomoran"):
    """Merender halaman pengaturan dengan tab `tab` terbuka.

    Setelah POST yang gagal validasi, tab yang memuat galatnya harus terbuka
    sendiri — tab yang menutupi pesan galat sama saja dengan tidak
    menampilkannya.
    """
    setting = service.ambil_setting(db_session)
    return render_template(
        "settings/billing.html",
        tab_awal=tab,
        form=form or PengaturanBillingForm(obj=setting),
        form_kop=form_kop or KopSuratForm(obj=setting),
        # `obj=setting` sengaja tidak dipakai untuk formulir email: ia akan
        # mengisi `smtp_password` dengan sandi tersimpan dan mengirimkannya ke
        # peramban di setiap pemuatan halaman.
        form_email=form_email or EmailPengirimanForm(
            data={nama: getattr(setting, nama) for nama in service.KOLOM_EMAIL}
        ),
        setting=setting,
    )


@bp.route("/billing/pengaturan", methods=["GET", "POST"])
@require_role(*TULIS)
def billing():
    setting = service.ambil_setting(db_session)
    form = PengaturanBillingForm(obj=setting)
    if form.validate_on_submit():
        try:
            service.ubah_setting(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Pengaturan penomoran disimpan.", "sukses")
            return redirect(url_for("settings.billing"))
    return _halaman_billing(form=form)


@bp.post("/billing/pengaturan/kop")
@require_role(*TULIS)
def kop():
    form = KopSuratForm()
    if not form.validate_on_submit():
        for field in form:
            for pesan in field.errors:
                flash(f"{field.label.text}: {pesan}", "bahaya")
        return _halaman_billing(form_kop=form, tab="kop")

    berkas = {}
    try:
        for kolom, medan, hapus in (
            ("logo_path", form.logo, form.hapus_logo),
            ("signature_path", form.signature, form.hapus_signature),
        ):
            unggahan = medan.data
            if unggahan is not None and getattr(unggahan, "filename", ""):
                berkas[kolom] = simpan(
                    unggahan.stream,
                    unggahan.filename,
                    current_app.config["UPLOAD_DIR"],
                )
            elif hapus.data:
                berkas[kolom] = None
        service.ubah_kop(db_session, current_user(), form.data, berkas)
    except (GalatDomain, FileError) as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return _halaman_billing(form_kop=form, tab="kop")

    db_session.commit()
    flash("Kop surat disimpan.", "sukses")
    return redirect(url_for("settings.billing"))


@bp.post("/billing/pengaturan/email")
@require_role(*TULIS)
def email():
    form = EmailPengirimanForm()
    if not form.validate_on_submit():
        for field in form:
            for pesan in field.errors:
                flash(f"{field.label.text}: {pesan}", "bahaya")
        return _halaman_billing(form_email=form, tab="email")

    try:
        service.ubah_email(db_session, current_user(), form.data)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return _halaman_billing(form_email=form, tab="email")

    db_session.commit()
    flash("Pengaturan email disimpan.", "sukses")
    return redirect(url_for("settings.billing"))


@bp.get("/billing/pengaturan/berkas/<jenis>")
@require_role(*BACA)
def berkas_kop(jenis: str):
    """Melayani logo atau tanda tangan.

    Berkasnya tersimpan di direktori unggahan, bukan di `static/`, jadi
    halaman cetak memuatnya lewat rute ini. Tetap berpenjaga peran: kop surat
    memuat tanda tangan, dan itu bukan gambar publik.
    """
    from flask import abort

    setting = service.ambil_setting(db_session)
    path = {"logo": setting.logo_path, "tanda-tangan": setting.signature_path}.get(jenis)
    if not path:
        abort(404)

    import pathlib

    from app.core.files import mime_dari_path

    mime = mime_dari_path(path)
    return sajikan(path, f"{jenis}{pathlib.Path(path).suffix}", mime,
                   current_app.config["UPLOAD_DIR"])


# --- Lisensi --------------------------------------------------------------


def _kunci_publik():
    return current_app.config.get("LICENSE_PUBLIC_KEY") or None


@bp.get("/pengaturan/lisensi")
@require_role(*SISTEM)
def lisensi():
    from app.modules.settings import license_service

    keadaan = license_service.keadaan(db_session, _kunci_publik())
    db_session.commit()
    return render_template(
        "settings/lisensi.html", keadaan=keadaan, form=CadanganForm()
    )


@bp.post("/pengaturan/lisensi")
@require_role(*SISTEM)
def lisensi_pasang():
    from app.modules.settings import license_service

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Lisensi.", "bahaya")
        return redirect(url_for("settings.lisensi"))

    try:
        dipasang = license_service.pasang(
            db_session, current_user(), request.form.get("kunci") or "", _kunci_publik()
        )
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.lisensi"))

    db_session.commit()
    flash(f"Lisensi dipasang untuk {dipasang.pelanggan}.", "sukses")
    return redirect(url_for("settings.lisensi"))


@bp.post("/pengaturan/lisensi/lepas")
@require_role(*SISTEM)
def lisensi_lepas():
    from app.modules.settings import license_service

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Lisensi.", "bahaya")
        return redirect(url_for("settings.lisensi"))

    license_service.lepas(db_session, current_user())
    db_session.commit()
    flash("Kunci lisensi dilepas. Aplikasi tetap berjalan penuh.", "sukses")
    return redirect(url_for("settings.lisensi"))


# --- Data contoh ----------------------------------------------------------


@bp.get("/pengaturan/data-contoh")
@require_role(*SISTEM)
def demo():
    from app.modules.settings import demo as modul_demo

    keadaan = modul_demo.status(db_session)
    db_session.commit()
    return render_template(
        "settings/demo.html", keadaan=keadaan, form=CadanganForm()
    )


@bp.post("/pengaturan/data-contoh/pasang")
@require_role(*SISTEM)
def demo_pasang():
    from app.modules.settings import demo as modul_demo

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Data Contoh.", "bahaya")
        return redirect(url_for("settings.demo"))

    try:
        hitung = modul_demo.pasang(db_session, current_user())
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.demo"))

    db_session.commit()
    flash(
        "Data contoh dipasang: "
        + ", ".join(f"{jumlah} {nama}" for nama, jumlah in sorted(hitung.items())),
        "sukses",
    )
    return redirect(url_for("settings.demo"))


@bp.post("/pengaturan/data-contoh/hapus")
@require_role(*SISTEM)
def demo_hapus():
    """Membuang data contoh. Meminta kata konfirmasi diketik.

    Yang dihapus hanya baris yang tercatat di jejak data contoh, tetapi
    perintahnya tetap tidak bisa dibatalkan — dan pemasangan yang sudah
    dipakai sungguhan bisa saja punya tiket atau invoice yang menempel pada
    pelanggan contoh.
    """
    from app.modules.settings import demo as modul_demo

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Data Contoh.", "bahaya")
        return redirect(url_for("settings.demo"))

    if (request.form.get("konfirmasi") or "").strip() != "HAPUS":
        flash("Ketik HAPUS di kolom konfirmasi untuk melanjutkan.", "bahaya")
        return redirect(url_for("settings.demo"))

    try:
        dibuang = modul_demo.hapus(db_session, current_user())
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.demo"))

    db_session.commit()
    jumlah_dihapus = sum(
        jumlah for nama, jumlah in dibuang.items()
        if nama != "akun_pengguna_dilepas"
    )
    akun_dilepas = dibuang.get("akun_pengguna_dilepas", 0)
    pesan = f"Data contoh dihapus: {jumlah_dihapus} baris."
    if akun_dilepas:
        pesan += f" {akun_dilepas} akun pengguna dipertahankan tanpa cabang."
    flash(pesan, "sukses")
    return redirect(url_for("settings.demo"))


# --- Impor pelanggan dari CSV ---------------------------------------------

IMPOR = ("superadmin", "admin_cabang")


@bp.get("/pengaturan/impor")
@require_role(*IMPOR)
def impor():
    return _halaman_impor()


@bp.get("/pengaturan/impor/templat.csv")
@require_role(*IMPOR)
def impor_templat():
    from flask import Response

    from app.modules.customers import impor as modul_impor

    return Response(
        modul_impor.templat_csv(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="templat-customer.csv"'},
    )


def _halaman_impor(hasil=None, token=None, nama_berkas=None):
    from app.modules.customers import impor as modul_impor

    return render_template(
        "settings/impor.html",
        form=CadanganForm(),
        kolom=modul_impor.KOLOM,
        kolom_wajib=modul_impor.KOLOM_WAJIB,
        batas=modul_impor.BATAS_BARIS,
        hasil=hasil,
        token=token,
        nama_berkas=nama_berkas,
    )


@bp.post("/pengaturan/impor")
@require_role(*IMPOR)
def impor_periksa():
    """Membaca berkas lalu menampilkan pratinjaunya. Belum menulis apa pun."""
    from app.modules.customers import impor as modul_impor

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Impor.", "bahaya")
        return redirect(url_for("settings.impor"))

    unggahan = request.files.get("berkas")
    if unggahan is None or not getattr(unggahan, "filename", ""):
        flash("Pilih berkas CSV lebih dulu.", "bahaya")
        return redirect(url_for("settings.impor"))

    isi = unggahan.stream.read()
    try:
        hasil = modul_impor.periksa(db_session, current_user(), isi)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.impor"))

    token = modul_impor.simpan_sementara(isi, current_app.config["UPLOAD_DIR"])
    return _halaman_impor(
        hasil=hasil, token=token, nama_berkas=unggahan.filename
    )


@bp.post("/pengaturan/impor/terapkan")
@require_role(*IMPOR)
def impor_terapkan():
    """Menulis baris yang sah dari berkas yang barusan diperiksa.

    Berkasnya dibaca dan **diperiksa ulang** dari awal, bukan memakai hasil
    pemeriksaan yang dikirim balik peramban: apa pun yang datang dari
    peramban bisa disunting, dan daftar baris "sah" adalah daftar perintah
    tulis.
    """
    from app.modules.customers import impor as modul_impor

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Impor.", "bahaya")
        return redirect(url_for("settings.impor"))

    token = (request.form.get("token") or "").strip()
    upload_dir = current_app.config["UPLOAD_DIR"]
    try:
        isi = modul_impor.baca_sementara(upload_dir, token)
        hasil = modul_impor.periksa(db_session, current_user(), isi)
        dibuat = modul_impor.terapkan(db_session, current_user(), hasil)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.impor"))

    db_session.commit()
    modul_impor.buang_sementara(upload_dir, token)
    dilewati = len(hasil.bergalat)
    flash(
        f"{dibuat} pelanggan diimpor."
        + (f" {dilewati} baris dilewati karena bergalat." if dilewati else ""),
        "sukses",
    )
    return redirect(url_for("settings.impor"))


# --- Merek aplikasi -------------------------------------------------------


@bp.route("/pengaturan/merek", methods=["GET", "POST"])
@require_role(*SISTEM)
def merek():
    from app.modules.settings import branding

    baris = branding.ambil_merek(db_session)
    form = MerekForm(obj=baris)
    if form.validate_on_submit():
        berkas = {}
        try:
            for kolom, medan, hapus in (
                ("logo_path", form.logo, form.hapus_logo),
                ("favicon_path", form.favicon, form.hapus_favicon),
            ):
                unggahan = medan.data
                if unggahan is not None and getattr(unggahan, "filename", ""):
                    berkas[kolom] = simpan(
                        unggahan.stream,
                        unggahan.filename,
                        current_app.config["UPLOAD_DIR"],
                    )
                elif hapus.data:
                    berkas[kolom] = None
            branding.ubah_merek(db_session, current_user(), form.data, berkas)
        except (GalatDomain, FileError) as galat:
            db_session.rollback()
            medan = getattr(form, getattr(galat, "field", ""), None)
            if medan is not None:
                medan.errors.append(str(galat))
            else:
                flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Merek aplikasi disimpan.", "sukses")
            return redirect(url_for("settings.merek"))

    # Namanya `merek_tersimpan`, BUKAN `merek`. Context processor sudah
    # mengisi `merek` untuk seluruh templat, dan argumen render_template
    # menimpanya diam-diam: sidebar kehilangan namanya, judul tab kosong, dan
    # `--accent` menjadi nilai tak sah sehingga tombol utama jadi putih di
    # atas putih — terlihat hilang padahal masih bisa ditekan.
    return render_template(
        "settings/merek.html",
        form=form,
        merek_tersimpan=branding.ambil_merek(db_session),
    )


@bp.get("/merek/logo")
def merek_logo():
    """Logo aplikasi.

    **Sengaja publik**, tidak seperti `berkas_kop`. Logo ini tampil di halaman
    masuk, yang dibuka sebelum ada sesi; rute berpenjaga akan membuat halaman
    masuk selalu kehilangan logonya. Isinya memang merek perusahaan — yang
    juga tercetak di setiap invoice yang dikirim keluar.
    """
    import pathlib

    from flask import abort

    from app.core.files import mime_dari_path
    from app.modules.settings import branding

    baris = branding.ambil_merek(db_session)
    db_session.commit()
    if not baris.logo_path:
        abort(404)

    return sajikan(
        baris.logo_path,
        f"logo{pathlib.Path(baris.logo_path).suffix}",
        mime_dari_path(baris.logo_path),
        current_app.config["UPLOAD_DIR"],
    )


@bp.get("/merek/favicon")
def merek_favicon():
    """Favicon aplikasi yang dapat diakses sebelum login."""
    import pathlib

    from flask import abort

    from app.core.files import mime_dari_path, sajikan_sebaris
    from app.modules.settings import branding

    baris = branding.ambil_merek(db_session)
    db_session.commit()
    if not baris.favicon_path:
        abort(404)
    return sajikan_sebaris(
        baris.favicon_path,
        f"favicon{pathlib.Path(baris.favicon_path).suffix}",
        mime_dari_path(baris.favicon_path),
        current_app.config["UPLOAD_DIR"],
    )


# --- Sistem, cadangan, dan pemulihan --------------------------------------


def _halaman_sistem(form_pulih=None):
    from app.core import cadangan
    from app.modules.settings import sistem as info_sistem

    return render_template(
        "settings/sistem.html",
        info=info_sistem.info(db_session, current_app.config),
        cadangan_cadangan=cadangan.daftar(current_app.config["BACKUP_DIR"]),
        form_cadangan=CadanganForm(),
        form_pulih=form_pulih or PemulihanForm(),
    )


@bp.get("/pengaturan/sistem")
@require_role(*SISTEM)
def sistem():
    return _halaman_sistem()


@bp.post("/pengaturan/sistem/cadangan")
@require_role(*SISTEM)
def cadangan_buat():
    from datetime import datetime
    from zoneinfo import ZoneInfo

    from app.core import audit, cadangan

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Sistem.", "bahaya")
        return redirect(url_for("settings.sistem"))

    stempel = waktu.sekarang()
    try:
        berkas = cadangan.buat(
            current_app.config["DATABASE_URL"],
            current_app.config["BACKUP_DIR"],
            stempel,
        )
    except GalatDomain as galat:
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.sistem"))

    audit.record(
        db_session,
        "backup",
        "database",
        None,
        after={"berkas": berkas.name},
        aktor=current_user(),
    )
    db_session.commit()
    flash(f"Cadangan dibuat: {berkas.name}", "sukses")
    return redirect(url_for("settings.sistem"))


@bp.get("/pengaturan/sistem/cadangan/<nama>/unduh")
@require_role(*SISTEM)
def cadangan_unduh(nama: str):
    from app.core import audit, cadangan

    berkas = cadangan.path_aman(current_app.config["BACKUP_DIR"], nama)
    audit.record(
        db_session,
        "download",
        "database",
        None,
        after={"berkas": berkas.name},
        aktor=current_user(),
    )
    db_session.commit()
    return sajikan(
        str(berkas),
        berkas.name,
        "application/octet-stream",
        current_app.config["BACKUP_DIR"],
    )


@bp.post("/pengaturan/sistem/cadangan/<nama>/hapus")
@require_role(*SISTEM)
def cadangan_hapus(nama: str):
    from app.core import audit, cadangan

    if not CadanganForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman Sistem.", "bahaya")
        return redirect(url_for("settings.sistem"))

    cadangan.hapus(current_app.config["BACKUP_DIR"], nama)
    audit.record(
        db_session, "delete", "database", None, before={"berkas": nama},
        aktor=current_user(),
    )
    db_session.commit()
    flash(f"Cadangan {nama} dihapus.", "sukses")
    return redirect(url_for("settings.sistem"))


@bp.post("/pengaturan/sistem/pulihkan")
@require_role(*SISTEM)
def cadangan_pulihkan():
    from app.core import audit, cadangan

    form = PemulihanForm()
    if not form.validate_on_submit():
        for field in form:
            for pesan in field.errors:
                flash(pesan, "bahaya")
        return _halaman_sistem(form_pulih=form)

    berkas = cadangan.path_aman(current_app.config["BACKUP_DIR"], form.nama.data)

    # Dicatat dan di-commit **sebelum** pemulihan berjalan. Sesudahnya, audit
    # log yang berlaku adalah audit log milik cadangan, dan jejak bahwa
    # pemulihan pernah terjadi tidak akan ada di mana pun.
    audit.record(
        db_session,
        "restore",
        "database",
        None,
        after={"berkas": berkas.name},
        aktor=current_user(),
    )
    db_session.commit()

    try:
        cadangan.pulihkan(
            current_app.config["DATABASE_URL"],
            berkas,
            engine=current_app.extensions.get("db_engine"),
        )
    except GalatDomain as galat:
        flash(str(galat), "bahaya")
        return redirect(url_for("settings.sistem"))

    flash(
        f"Basis data dipulihkan dari {berkas.name}. "
        "Data yang ada sebelumnya sudah diganti.",
        "sukses",
    )
    return redirect(url_for("settings.sistem"))


# --- Rekening bank --------------------------------------------------------


@bp.get("/billing/rekening")
@require_role(*TULIS)
def rekening_daftar():
    return render_template(
        "settings/rekening_daftar.html",
        daftar=service.daftar_rekening(db_session),
        form_hapus=HapusRekeningForm(),
    )


@bp.route("/billing/rekening/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def rekening_baru():
    form = RekeningForm()
    if form.validate_on_submit():
        service.tambah_rekening(db_session, current_user(), form.data)
        db_session.commit()
        flash("Rekening ditambahkan.", "sukses")
        return redirect(url_for("settings.rekening_daftar"))
    return render_template("settings/rekening_form.html", form=form, rekening=None)


@bp.route("/billing/rekening/<int:rekening_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def rekening_ubah(rekening_id: int):
    rekening = service.ambil_rekening(db_session, rekening_id)
    form = RekeningForm(obj=rekening)
    if form.validate_on_submit():
        service.ubah_rekening(db_session, current_user(), rekening_id, form.data)
        db_session.commit()
        flash("Rekening disimpan.", "sukses")
        return redirect(url_for("settings.rekening_daftar"))
    return render_template("settings/rekening_form.html", form=form, rekening=rekening)


@bp.post("/billing/rekening/<int:rekening_id>/hapus")
@require_role(*TULIS)
def rekening_hapus(rekening_id: int):
    if not HapusRekeningForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman rekening.", "bahaya")
        return redirect(url_for("settings.rekening_daftar"))
    service.hapus_rekening(db_session, current_user(), rekening_id)
    db_session.commit()
    flash("Rekening dihapus.", "sukses")
    return redirect(url_for("settings.rekening_daftar"))
