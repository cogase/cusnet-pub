from flask import Blueprint, render_template

from app.core.auth import current_user
from app.core.db import db_session
from app.core.grafik import garis_ganda
from app.core.rbac import require_role
from app.modules.billing import reports
from app.modules.billing.forms import LABEL_STATUS_INVOICE, NADA_STATUS_INVOICE
from app.modules.dashboard import service
from app.modules.tickets import service as ticket_service

bp = Blueprint("dashboard", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")


@bp.get("/dashboard")
@require_role(*BACA)
def index():
    user = current_user()
    return render_template(
        "dashboard/index.html",
        ringkasan=service.ringkasan(db_session, user),
        uang=service.ringkasan_uang(db_session, user),
        invoice_terbaru=service.invoice_terbaru(db_session, user),
        invoice_tunggakan=service.invoice_tunggakan(db_session, user),
        ringkasan_tiket=ticket_service.ringkasan(db_session, user),
        tiket_operasional=service.tiket_operasional(db_session, user),
        pelanggan_teratas=service.pelanggan_teratas(db_session, user),
        tren=garis_ganda(
            reports.tren_pendapatan(db_session, user, bulan=12),
            [("tagihan", "Tagihan"), ("dibayar", "Dibayar")],
            kunci_label="bulan",
        ),
        aktivitas=service.aktivitas_terbaru(db_session, user),
        label_status=LABEL_STATUS_INVOICE,
        nada_status=NADA_STATUS_INVOICE,
    )
