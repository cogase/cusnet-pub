"""Agregat halaman Dashboard.

Seluruh angka melewati `rbac.scoped`: dashboard staf cabang hanya boleh
menghitung cabangnya sendiri. Persentase dihitung di sini, bukan di templat —
templat tidak boleh membagi, karena pembagi nol pada pemasangan baru berarti
halaman depan yang 500.
"""

from datetime import date, datetime
from zoneinfo import ZoneInfo

from flask import current_app
from sqlalchemy import case, func, or_, select

from app.core import rbac, waktu
from app.modules.admin.models import AuditLog
from app.modules.customers.models import STATUS_PELANGGAN, Customer
from app.modules.customers.subscriptions import Subscription

ENTITAS_PELANGGAN = ("customer", "customer_contact", "customer_document", "customer_note")
ENTITAS_GLOBAL = ("service_plan", "service_category", "vendor", "billing_setting", "branch")

LABEL_STATUS = {
    "active": "Aktif",
    "suspend": "Suspend",
    "terminasi": "Terminasi",
    "pending": "Pending",
}
NADA_STATUS = {
    "active": "sukses",
    "suspend": "jingga",
    "terminasi": "bahaya",
    "pending": "ungu",
}


def _persen(bagian: int, total: int) -> float:
    if not total:
        return 0.0
    return round(bagian * 100 / total, 1)


def _awal_bulan_lokal() -> date:
    """Tanggal 1 bulan berjalan menurut zona waktu aplikasi.

    Dulu dihitung sendiri di sini — tambalan lokal atas masalah yang ternyata
    ada di 26 tempat lain. Sekarang meminjam `app.core.waktu`, yang jadi
    satu-satunya jam aplikasi.
    """
    return waktu.awal_bulan()


def ringkasan(sesi, user) -> dict:
    per_status = dict(
        sesi.execute(
            rbac.scoped(
                select(Customer.status, func.count(Customer.id)).group_by(
                    Customer.status
                ),
                user,
                Customer,
            )
        ).all()
    )
    total_customer = sum(per_status.values())
    aktif = per_status.get("active", 0)

    total_langganan = sesi.execute(
        rbac.scoped(
            select(func.count())
            .select_from(Subscription)
            .join(Customer, Subscription.customer_id == Customer.id)
            .where(Subscription.status == "active"),
            user,
            Customer,
        )
    ).scalar_one()

    from app.modules.customers import subscription_service

    per_kategori = subscription_service.hitung_per_kategori(sesi, user)

    awal = _awal_bulan_lokal()
    baru = sesi.execute(
        rbac.scoped(
            select(func.count())
            .select_from(Customer)
            .where(Customer.joined_at >= awal),
            user,
            Customer,
        )
    ).scalar_one()
    terminasi_bulan_ini = sesi.execute(
        rbac.scoped(
            select(func.count())
            .select_from(Customer)
            .where(Customer.terminated_at >= awal),
            user,
            Customer,
        )
    ).scalar_one()

    return {
        "total_customer": total_customer,
        "customer_aktif": aktif,
        "persen_aktif": _persen(aktif, total_customer),
        "total_langganan": total_langganan,
        "per_status_customer": [
            {
                "status": status,
                "label": LABEL_STATUS.get(status, status),
                "nada": NADA_STATUS.get(status, "netral"),
                "jumlah": per_status.get(status, 0),
                "persen": _persen(per_status.get(status, 0), total_customer),
            }
            for status in STATUS_PELANGGAN
        ],
        "per_kategori_layanan": [
            {
                "kategori": baris["kategori"],
                "jumlah": baris["jumlah"],
                "persen": _persen(baris["jumlah"], total_langganan),
            }
            for baris in per_kategori
        ],
        "customer_baru_bulan_ini": baru,
        "customer_terminasi_bulan_ini": terminasi_bulan_ini,
    }


def ringkasan_uang(sesi, user) -> dict:
    """Angka billing di Dashboard.

    Sampai 0.6.0 kartu-kartu ini dirender nol dengan kalimat "Menunggu modul
    billing". Modulnya sudah ada sejak M2, jadi angkanya sekarang nyata.

    **Pendapatan Bulan Ini** dihitung dari `Payment.paid_at` — uang yang
    benar-benar masuk bulan ini, berapa pun periode tagihannya. Berbeda dari
    grafik tren di halaman Billing, yang mengelompokkan pembayaran menurut
    periode tagihan. Keduanya benar untuk pertanyaannya masing-masing; yang
    salah adalah memakai satu angka untuk menjawab dua pertanyaan.
    """
    from decimal import Decimal

    from app.core.money import to_money
    from app.modules.billing.models import Invoice, Payment

    awal = _awal_bulan_lokal()

    pendapatan = sesi.execute(
        rbac.scoped(
            select(func.coalesce(func.sum(Payment.amount), 0))
            .select_from(Payment)
            .join(Invoice, Payment.invoice_id == Invoice.id)
            .where(Invoice.status != "void", Payment.paid_at >= awal),
            user,
            Invoice,
        )
    ).scalar_one()

    tagihan, jumlah_invoice = sesi.execute(
        rbac.scoped(
            select(
                func.coalesce(func.sum(Invoice.total), 0), func.count(Invoice.id)
            ).where(Invoice.status.notin_(("void", "draft"))),
            user,
            Invoice,
        )
    ).one()

    dibayar = sesi.execute(
        rbac.scoped(
            select(func.coalesce(func.sum(Payment.amount), 0))
            .select_from(Payment)
            .join(Invoice, Payment.invoice_id == Invoice.id)
            .where(Invoice.status.notin_(("void", "draft"))),
            user,
            Invoice,
        )
    ).scalar_one()

    overdue = sesi.execute(
        rbac.scoped(
            select(func.count(Invoice.id)).where(Invoice.status == "overdue"),
            user,
            Invoice,
        )
    ).scalar_one()

    tagihan = to_money(tagihan)
    dibayar = to_money(dibayar)

    return {
        "pendapatan_bulan_ini": to_money(pendapatan),
        "outstanding": to_money(max(tagihan - dibayar, Decimal("0"))),
        "rata_rata_invoice": (
            to_money(tagihan / jumlah_invoice) if jumlah_invoice else Decimal("0.00")
        ),
        # Tingkat pembayaran = rupiah yang tertagih dibanding rupiah yang
        # ditagihkan, bukan jumlah invoice lunas dibanding total invoice.
        # Satu invoice besar yang belum dibayar lebih penting daripada
        # sepuluh invoice kecil yang lunas.
        "tingkat_pembayaran": (
            round(float(dibayar / tagihan) * 100, 1) if tagihan else 0.0
        ),
        "invoice_overdue": overdue,
    }


def invoice_terbaru(sesi, user, limit: int = 5) -> list:
    """Invoice terbit terbaru beserta pelanggannya."""
    from app.modules.billing.models import Invoice

    query = (
        select(Invoice, Customer)
        .join(Customer, Invoice.customer_id == Customer.id)
        .where(Invoice.status != "draft")
        .order_by(Invoice.id.desc())
        .limit(limit)
    )
    return list(sesi.execute(rbac.scoped(query, user, Invoice)).all())


def invoice_tunggakan(sesi, user, limit: int = 5) -> list:
    """Invoice overdue terdekat untuk antrian tindak lanjut operasional."""
    from app.modules.billing.models import Invoice

    query = (
        select(Invoice, Customer)
        .join(Customer, Invoice.customer_id == Customer.id)
        .where(Invoice.status == "overdue")
        .order_by(Invoice.due_at.asc(), Invoice.id.asc())
        .limit(limit)
    )
    return list(sesi.execute(rbac.scoped(query, user, Invoice)).all())


def tiket_operasional(sesi, user, limit: int = 5) -> list:
    """Tiket terbuka paling mendesak untuk ditampilkan pada dashboard."""
    from app.modules.tickets.models import STATUS_TUTUP, Ticket

    urutan_prioritas = case(
        (Ticket.priority == "kritis", 0),
        (Ticket.priority == "tinggi", 1),
        (Ticket.priority == "sedang", 2),
        else_=3,
    )
    query = (
        select(Ticket)
        .where(Ticket.status.notin_(STATUS_TUTUP))
        .order_by(
            urutan_prioritas,
            Ticket.resolve_due_at.is_(None),
            Ticket.resolve_due_at.asc(),
            Ticket.opened_at.asc(),
        )
        .limit(limit)
    )
    return list(sesi.execute(rbac.scoped(query, user, Ticket)).scalars().all())


def pelanggan_teratas(sesi, user, limit: int = 5) -> list[dict]:
    """Pelanggan dengan tagihan terbesar sepanjang masa.

    Diurutkan menurut nilai yang **ditagihkan**, bukan yang dibayar: peringkat
    yang berubah setiap kali ada yang menunggak membuat daftar ini tidak bisa
    dipakai memutuskan apa pun.
    """
    from app.core.money import to_money
    from app.modules.billing.models import Invoice

    query = (
        select(Customer, func.coalesce(func.sum(Invoice.total), 0).label("nilai"))
        .join(Invoice, Invoice.customer_id == Customer.id)
        .where(Invoice.status.notin_(("void", "draft")))
        .group_by(Customer.id)
        .order_by(func.coalesce(func.sum(Invoice.total), 0).desc())
        .limit(limit)
    )
    return [
        {"pelanggan": pelanggan, "nilai": to_money(nilai)}
        for pelanggan, nilai in sesi.execute(rbac.scoped(query, user, Invoice)).all()
    ]


def aktivitas_terbaru(sesi, user, limit: int = 8) -> list[AuditLog]:
    """Jejak audit terbaru yang boleh dilihat aktor.

    Staf cabang hanya melihat jejak pelanggan cabangnya sendiri ditambah jejak
    entitas yang memang global (katalog layanan, vendor, pengaturan). Entri
    pelanggan yang barisnya sudah dihapus tidak ikut tampil — idnya tidak lagi
    bisa dicocokkan ke cabang mana pun, dan menampilkannya berarti menebak.
    """
    query = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)

    if not rbac.is_cross_branch(user):
        id_pelanggan = sesi.execute(
            rbac.scoped(select(Customer.id), user, Customer)
        ).scalars().all()
        query = (
            select(AuditLog)
            .where(
                or_(
                    AuditLog.entity_type.in_(ENTITAS_GLOBAL),
                    (AuditLog.entity_type == "customer")
                    & AuditLog.entity_id.in_(id_pelanggan or [0]),
                )
            )
            .order_by(AuditLog.id.desc())
            .limit(limit)
        )

    return list(sesi.execute(query).scalars().all())
