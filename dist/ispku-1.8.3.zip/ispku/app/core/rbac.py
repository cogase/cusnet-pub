from functools import wraps

from flask import abort, redirect, url_for

from app.core.auth import current_user
from app.modules.admin.models import User

LINTAS_CABANG: frozenset[str] = frozenset({"superadmin"})


class _Sistem:
    """Aktor untuk pekerjaan terjadwal yang tidak dijalankan siapa pun.

    Perintah CLI seperti penerbitan batch dipanggil cron, bukan orang, jadi
    tidak ada user yang bisa diperiksa cabangnya. Sentinel ini melewati
    pemeriksaan cabang secara sadar dan bernama jelas — jauh lebih aman
    daripada membuat `None` berarti "boleh semua", karena `None` juga berarti
    "belum masuk" di jalur permintaan web.

    `id` sengaja `None`: audit log mencatatnya sebagai aksi tanpa aktor
    manusia, bukan atas nama akun siapa pun.
    """

    id = None
    role = "superadmin"
    branch_id = None
    full_name = "Sistem"


SISTEM = _Sistem()


class AccessDenied(PermissionError):
    """User tidak berhak mengakses data cabang tersebut."""


def has_role(user: User | None, *roles: str) -> bool:
    if user is None:
        return False
    return user.role in roles


def is_cross_branch(user: User) -> bool:
    return user.role in LINTAS_CABANG


def _branch_of(user: User) -> int:
    if user.branch_id is None:
        raise AccessDenied(
            "Akun ini tidak terikat cabang mana pun sehingga tidak bisa "
            "mengakses data. Hubungi administrator."
        )
    return user.branch_id


def scoped(query, user: User, model):
    if is_cross_branch(user):
        return query
    return query.where(model.branch_id == _branch_of(user))


def assert_branch_access(user: User, branch_id: int | None) -> None:
    if is_cross_branch(user):
        return
    if branch_id is None or branch_id != _branch_of(user):
        raise AccessDenied("Anda tidak berhak mengakses data cabang lain.")


def require_role(*roles: str):
    def dekorator(view):
        @wraps(view)
        def pembungkus(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("auth.login"))
            if not has_role(user, *roles):
                abort(403)
            return view(*args, **kwargs)

        return pembungkus

    return dekorator
