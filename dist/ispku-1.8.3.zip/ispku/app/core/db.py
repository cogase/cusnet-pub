from flask import Flask
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, scoped_session, sessionmaker


class Base(DeclarativeBase):
    pass


session_factory = sessionmaker(autoflush=False, expire_on_commit=False)
db_session = scoped_session(session_factory)


def create_db_engine(database_url: str, timezone_name: str):
    engine = create_engine(database_url, pool_pre_ping=True, future=True)

    @event.listens_for(engine, "connect")
    def _set_timezone(dbapi_connection, _record):
        with dbapi_connection.cursor() as cursor:
            cursor.execute(f"SET TIME ZONE '{timezone_name}'")

    return engine


def index_ekspresi(index) -> bool:
    """True bila index dibangun dari ekspresi, bukan dari kolom polos.

    Alembic tidak bisa membandingkan index ekspresi (mis.
    `lower(trim(name))`): yang dibaca dari basis data berupa teks mentah,
    sedangkan yang ada di model berupa objek fungsi SQLAlchemy, sehingga
    keduanya selalu tampak berbeda dan `--autogenerate` mengusulkan menghapus
    lalu membuat ulang index yang sama pada setiap revisi.

    Index semacam itu dikecualikan dari perbandingan, dan sebagai gantinya
    diuji langsung ke basis data (lihat
    `tests/test_services_vendor.py::test_index_menolak_nama_kembar_di_basis_data`).
    """
    from sqlalchemy import Column

    return any(not isinstance(bagian, Column) for bagian in index.expressions)


def init_db(app: Flask) -> None:
    from app.core.config import _valid_timezone

    engine = create_db_engine(
        app.config["DATABASE_URL"], _valid_timezone(app.config["APP_TIMEZONE"])
    )
    app.extensions["db_engine"] = engine
    session_factory.configure(bind=engine)

    @app.teardown_appcontext
    def _remove_session(_exception=None):
        db_session.remove()
