# ISPKU

Aplikasi pendataan pelanggan dan penerbitan invoice untuk ISP (dulu bernama
CUSNET CRM). Dipasang di server masing-masing ISP (on-premise): satu
instalasi melayani satu perusahaan.

## Yang sudah bisa dipakai

- Login, peran (`superadmin`, `admin_cabang`, `billing`, `teknis`, `viewer`),
  dan pembatasan data per cabang
- Master cabang, user, kategori customer, kategori layanan, vendor
- Katalog layanan: paket beserta harga dan tarif PPN-nya
- Pengaturan billing: pola CID, nomor layanan, dan nomor invoice
- **Customer**: daftar dengan filter dan statistik, formulir tambah/ubah, CID
  otomatis atau manual, halaman detail, kontak berperan (satu PIC utama),
  dokumen berpenjaga hak akses, catatan, timeline dari audit log, ekspor dan
  impor CSV
- **Layanan berlangganan**: nomor layanan turunan CID, detail teknis mengikuti
  bentuk formulir kategorinya (Internet, titik-ke-titik dengan dua terminasi
  dan hop transit, atau umum), Site layanan, dua terminasi dan hop transit
  untuk topologi semua jenis layanan, biaya tambahan, dan cicilan instalasi
- **Dashboard**: jumlah customer dan layanan, komposisi status dan kategori
  sebagai grafik donat, serta aktivitas terbaru
- **Billing**: penerbitan invoice per periode (halaman dan `flask billing-run`)
  dengan prorata, addon, cicilan, diskon, dan PPN; halaman Billing dan Detail
  Invoice; sunting draft, terbitkan, void beralasan, invoice pembetulan;
  PDF invoice dan kwitansi; kirim invoice dan pengingat tagihan lewat
  antrean email
- **Pembayaran**: pencatatan cicil sampai lunas beserta bukti unggah, status
  invoice dihitung dari pembayaran, dan pembatalan yang menghitung ulang
- **Laporan**: tunggakan beserta umur piutang, pendapatan per cabang, rekap
  periode, masing-masing dengan ekspor CSV
- **Kop surat dan rekening**: kop surat invoice beserta logo dan tanda tangan,
  pengaturan SMTP dan templat email, rekening bank yang tercetak di invoice
- **Ticketing**: tiket bernomor dengan kategori, prioritas, status, penugasan,
  dan SLA; komentar internal versus komentar untuk pelanggan; lampiran yang
  dapat dihapus bersama tiket;
  riwayat gangguan per nomor layanan; laporan SLA
- **Network Inventory**: site/POP beserta koordinat, perangkat, port dan
  alokasinya ke langganan, registry VLAN dan blok IP, IPAM sederhana, serta
  peta sebaran yang digambar sendiri tanpa menarik apa pun dari internet.
  VLAN yang dicatat di layanan otomatis muncul di registry dan ikut terhapus
  dari registry saat dihapus dari layanan
- **Operasi**: cadangan dan pemulihan basis data dari aplikasi, audit log,
  merek aplikasi per ISP termasuk favicon khusus, lisensi, data contoh
- **Tampilan**: bisa dipakai dari ponsel, bisa dipasang sebagai aplikasi
  (PWA), daftar Customer/Layanan/Ticketing/Network dengan filter yang dapat
  dibuka-tutup, dan pembaruan otomatis lintas pengguna tanpa memuat ulang
  manual. Formulir yang sedang diedit tidak akan ditimpa; aplikasi menampilkan
  pilihan pembaruan setelah ada perubahan baru.

## Kebutuhan sistem

- Linux dengan Docker dan plugin Docker Compose (panduan memakai Debian 12/13)
- 2 CPU, RAM 2 GB, disk 20 GB
- Tidak perlu Node.js maupun Redis. Akses internet hanya dibutuhkan saat
  memasang (mengunduh image dan paket)

## Memasang di server

**Pemula, mulai dari server kosong:** ikuti
[`docs/panduan-instal-debian.md`](docs/panduan-instal-debian.md) — dari
memasang Docker sampai bisa dibuka lewat `https://` dengan nginx dan
sertifikat Let's Encrypt.

Ringkasnya, di server yang sudah punya Docker:

```bash
./install.sh
```

Pemasang membuat `.env` dengan sandi acak, membangun image, menjalankan
`docker-compose.prod.yml`, menanyakan akun superadmin pertama, dan menanam
kategori layanan bawaan. Menjalankannya ulang sesudah berkas sumber
diperbarui adalah cara menaikkan versi — cadangan basis data dibuat lebih
dulu.

Detail teknis (seluruh variabel `.env`, cadangan dan pemulihan, jadwal cron,
lisensi) ada di [`docs/pemasangan.md`](docs/pemasangan.md). Templat nginx dan
cron siap salin ada di folder `deploy/`.

### Membuat paket zip

Untuk dikirim ke server yang tidak punya akses ke repositori ini:

```bash
tools/buat-paket.sh
```

Hasilnya `dist/ispku-<versi>.zip` (isinya folder `ispku/`) beserta
`.sha256`-nya, dibuat dari commit terakhir. Uji, catatan pengembangan, dan
gambar mockup tidak ikut (lihat `.gitattributes`).

Untuk menerbitkan paket ke repositori distribusi publik
[`cogase/cusnet-pub`](https://github.com/cogase/cusnet-pub), commit semua
perubahan terlebih dahulu lalu jalankan:

```bash
tools/push-paket.sh
```

Script hanya mengirim ZIP dan checksum ke folder `dist/` di repo distribusi.
Ia menolak pohon kerja yang belum bersih dan versi yang sama dengan isi
berbeda; naikkan `APP_VERSION` untuk setiap paket baru. Push memerlukan akses
GitHub lewat SSH. Di server pelanggan, clone repo tersebut sekali; untuk
pemasangan pertama di server pelanggan:

```bash
git clone https://github.com/cogase/cusnet-pub.git /opt/cusnet-pub
cd /opt/cusnet-pub/dist
PAKET=$(find . -maxdepth 1 -type f -name 'ispku-*.zip' -printf '%f\n' | sort -V | tail -n 1)
test -n "$PAKET" || { echo "Paket ISPKU belum ditemukan"; exit 1; }
sha256sum -c "$PAKET.sha256"
unzip -o "$PAKET" -d /opt
cd /opt/ispku
./install.sh
```

Untuk pembaruan berikutnya, mulai dari `cd /opt/cusnet-pub`, jalankan
`git pull --ff-only`, lalu ulangi langkah mulai dari `cd dist` di atas.
Perintah `git pull` hanya mengambil paket baru; ekstraksi dan `./install.sh`
tetap diperlukan untuk menerapkannya.

## Pengembangan

`docker-compose.yml` adalah berkas pengembangan: kode di-mount dari host,
sandi basis data tetap `cusnet:cusnet`, tanpa nyala ulang otomatis. Jangan
dipakai di server pelanggan.

```bash
cp .env.example .env
python3 -c "import secrets; print(secrets.token_urlsafe(64))"   # isi APP_SECRET_KEY
docker compose up -d
docker compose exec app flask seed-superadmin \
  --username admin --email admin@contoh.id \
  --password "kata-sandi-anda" --nama "Super Admin"
docker compose exec app flask seed-master
```

Buka `http://localhost:6060/masuk`. Hindari port 6000 dan 6665–6669 —
peramban menolaknya (`ERR_UNSAFE_PORT`) sehingga aplikasi tampak mati padahal
server melayani normal.

Gunicorn tidak memuat ulang kode: sesudah mengubah kode jalankan
`docker compose restart app`, dan sesudah mengubah `.env` jalankan
`docker compose up -d app` (`restart` tidak membaca ulang `.env`).

Penghapusan customer, layanan, kategori layanan, atau paket layanan bersifat
permanen dan dapat menghapus invoice, pembayaran, tiket, serta data turunannya.
Menghapus tiket juga menghapus komentar dan lampirannya. Email antrean dan PDF
yang terkait invoice ikut dihapus bersama invoice tersebut. Pastikan cadangan
basis data terbaru tersedia sebelum menghapus data. Invoice tidak dihapus
langsung agar jejak keuangan tetap utuh; gunakan pembatalan (void) beralasan.
Cabang dan akun dinonaktifkan alih-alih dihapus karena masih dapat dirujuk
transaksi dan log audit.

### Menjalankan uji

```bash
docker compose run --rm app pytest
```

Jangan menjalankan dua `pytest` bersamaan — keduanya berebut skema
`cusnet_test` dan puluhan uji gagal seolah kodenya rusak.

## Perintah operasional

Di server pelanggan tambahkan `-f docker-compose.prod.yml` setelah
`docker compose`. Semuanya lewat `exec` (bukan `run`), supaya promptnya
muncul dan perintahnya berjalan di kontainer yang sedang hidup.

| Keperluan | Perintah |
|---|---|
| Reset password akun (prompt tersembunyi) | `docker compose exec app flask reset-password --username admin` |
| Superadmin pertama | `docker compose exec app flask seed-superadmin ...` (menolak bila sudah ada; `--paksa` untuk tambahan) |
| Kategori layanan bawaan | `docker compose exec app flask seed-master` |
| Cadangan basis data | `docker compose exec app flask backup-db` |
| Kirim email antrean | `docker compose exec app flask mail-flush` |
| Pekerjaan harian billing | `docker compose exec app flask billing-harian` |

**Peringatan:** nilai `--password` pada `seed-superadmin` terlihat di
`ps aux` dan tersimpan di riwayat shell. Pakai hanya untuk pemasangan
pertama, lalu ganti passwordnya.

## Nama

Produk ini bernama **ISPKU** sejak 1.7.0. Nama lama CUSNET masih tersisa di
pengenal internal yang sengaja tidak diganti supaya pemasangan yang sudah ada
tidak terputus: nama basis data dan user PostgreSQL (`cusnet`), nama berkas
cadangan (`cusnet-*.dump`), dan nama repositori.

## Versi

Semver polos. Versi saat ini ada di `APP_VERSION` pada `.env.example`.
