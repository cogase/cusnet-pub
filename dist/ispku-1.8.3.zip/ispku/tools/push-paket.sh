#!/bin/sh
# Membuat paket dari commit terakhir dan menerbitkan dist/ ke repositori
# publik agar server pelanggan dapat menarik paket dengan `git pull`.
#
#   tools/push-paket.sh
#
# URL dan branch dapat ditimpa tanpa mengubah script:
#   CUSNET_PUB_REPO=git@github.com:cogase/cusnet-pub.git \
#   CUSNET_PUB_BRANCH=main tools/push-paket.sh
set -eu

AKAR=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$AKAR"

REPO=${CUSNET_PUB_REPO:-git@github.com:cogase/cusnet-pub.git}
BRANCH=${CUSNET_PUB_BRANCH:-main}

if [ -n "$(git status --porcelain --untracked-files=all)" ]; then
    echo "Pohon kerja belum bersih. Commit perubahan terlebih dahulu agar" >&2
    echo "paket yang diterbitkan berasal dari commit yang jelas." >&2
    exit 1
fi

tools/buat-paket.sh

VERSI=$(git show HEAD:.env.example | sed -n 's/^APP_VERSION=//p')
PAKET="ispku-${VERSI}.zip"
SUM="${PAKET}.sha256"
ZIP="dist/${PAKET}"

TMP=$(mktemp -d "${TMPDIR:-/tmp}/cusnet-pub.XXXXXX")
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

if ! command -v unzip >/dev/null 2>&1; then
    echo "Perintah unzip diperlukan untuk memeriksa isi paket." >&2
    exit 1
fi

unzip -tq "$ZIP" >/dev/null
if unzip -Z1 "$ZIP" | awk '
    /(^|\/)\.env$/ ||
    /(^|\/)[^/]+\.(key|pem|p12|pfx)$/ ||
    /(^|\/)(id_rsa|id_ed25519)$/ { print; found = 1 }
    END { exit !found }
' > "$TMP/private-files"; then
    echo "Paket berisi berkas rahasia; tidak diterbitkan:" >&2
    sed 's/^/  /' "$TMP/private-files" >&2
    exit 1
fi

git clone "$REPO" "$TMP/repo"
if git -C "$TMP/repo" ls-remote --exit-code --heads origin "$BRANCH" >/dev/null 2>&1; then
    if git -C "$TMP/repo" show-ref --verify --quiet "refs/heads/$BRANCH"; then
        git -C "$TMP/repo" switch "$BRANCH"
    else
        git -C "$TMP/repo" switch -c "$BRANCH" --track "origin/$BRANCH"
    fi
else
    git -C "$TMP/repo" switch --orphan "$BRANCH"
fi

mkdir -p "$TMP/repo/dist"
if [ -e "$TMP/repo/dist/$PAKET" ]; then
    if cmp -s "$ZIP" "$TMP/repo/dist/$PAKET" &&
       cmp -s "dist/$SUM" "$TMP/repo/dist/$SUM"; then
        echo "Paket ${VERSI} sudah diterbitkan dan isinya sama."
        exit 0
    fi
    echo "Paket versi ${VERSI} sudah ada dengan isi berbeda." >&2
    echo "Naikkan APP_VERSION sebelum menerbitkan paket baru." >&2
    exit 1
fi

cp "$ZIP" "$TMP/repo/dist/$PAKET"
cp "dist/$SUM" "$TMP/repo/dist/$SUM"
git -C "$TMP/repo" add -- "dist/$PAKET" "dist/$SUM"
git -C "$TMP/repo" -c user.name="CUSNET Release" \
    -c user.email="release@users.noreply.github.com" \
    commit -m "Publish ISPKU ${VERSI}"
git -C "$TMP/repo" push origin "HEAD:refs/heads/$BRANCH"

echo "Diterbitkan : ${REPO} (${BRANCH})"
echo "Paket       : dist/${PAKET}"
echo "Checksum    : dist/${SUM}"
