#!/bin/sh
# Membungkus ISPKU jadi satu berkas zip untuk dipasang di server lain.
#
#   tools/buat-paket.sh
#
# Hasilnya dist/ispku-<versi>.zip beserta berkas .sha256-nya. Isinya diambil
# dari commit terakhir (HEAD), BUKAN dari berkas yang sedang diedit — paket
# yang dikirim harus bisa ditelusuri ke satu commit. Yang tidak ikut
# (uji, catatan pengembangan, gambar mockup) diatur di .gitattributes.
#
# Di dalam zip semuanya berada di folder `ispku/`, jadi di server cukup:
#   unzip ispku-<versi>.zip -d /opt      ->  /opt/ispku
set -eu

cd "$(dirname "$0")/.."

VERSI=$(git show HEAD:.env.example | sed -n 's/^APP_VERSION=//p')
[ -n "$VERSI" ] || { echo "APP_VERSION tidak ditemukan di .env.example (HEAD)." >&2; exit 1; }

if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
    echo "PERINGATAN: ada perubahan yang belum di-commit. Paket dibuat dari" >&2
    echo "commit terakhir; perubahan itu TIDAK ikut masuk paket." >&2
fi

mkdir -p dist
NAMA="ispku-${VERSI}.zip"
git archive --format=zip --prefix=ispku/ -o "dist/${NAMA}" HEAD
(cd dist && sha256sum "$NAMA" > "${NAMA}.sha256")

echo "Paket   : dist/${NAMA} ($(du -h "dist/${NAMA}" | cut -f1))"
echo "Commit  : $(git rev-parse --short HEAD)"
echo "SHA256  : $(cut -d' ' -f1 "dist/${NAMA}.sha256")"
