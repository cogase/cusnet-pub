/* Tabel standar ISPKU.
 *
 * Setiap tabel daftar (`table.tabel` yang punya <thead>) otomatis mendapat:
 *   - lebar kolom yang bisa digeser, diingat per tabel;
 *   - menu Kolom untuk menampilkan/menyembunyikan kolom, diingat per tabel;
 *   - tombol Ekspor (CSV dari isi tabel) bila halamannya belum punya;
 *   - paginasi 20/50/100 di peramban bila tabelnya tidak dipaginasi server;
 *   - bila tabelnya ber-`data-entitas` dan barisnya ber-`data-id`:
 *     kotak centang, hapus massal, ubah massal, dan impor CSV lewat popup.
 *
 * Tidak ada yang perlu ditulis di templat selain dua atribut itu. Tabel yang
 * tidak boleh disentuh diberi `data-tabel="polos"`.
 *
 * Aksi massal memanggil /massal/<entitas>/…; hak aksesnya ditentukan server.
 */
(function () {
  "use strict";

  const PILIHAN_BARIS = [20, 50, 100];
  const meta = new Map();

  const simpan = {
    baca(kunci, bawaan) {
      try { return JSON.parse(localStorage.getItem(kunci)) ?? bawaan; } catch (e) { return bawaan; }
    },
    tulis(kunci, nilai) {
      try { localStorage.setItem(kunci, JSON.stringify(nilai)); } catch (e) { /* tidak diingat */ }
    }
  };

  function buat(tag, kelas, isi) {
    const unsur = document.createElement(tag);
    if (kelas) unsur.className = kelas;
    if (isi !== undefined) unsur.innerHTML = isi;
    return unsur;
  }

  function ikon(nama) { return '<i data-lucide="' + nama + '"></i>'; }

  function kunciTabel(tabel, nomor) {
    return "cusnet-tabel:" + location.pathname + ":" + (tabel.dataset.entitas || tabel.id || nomor);
  }

  function csrf() {
    const wadah = document.querySelector("[data-csrf]");
    return wadah ? wadah.dataset.csrf : "";
  }

  function beriTahu(teks) {
    const kotak = document.getElementById("live-update-notice");
    if (!kotak) return;
    kotak.textContent = teks;
    kotak.hidden = false;
    window.clearTimeout(beriTahu.jam);
    beriTahu.jam = window.setTimeout(() => { kotak.hidden = true; }, 6000);
  }

  function segarkan() {
    if (window.cusnetSegarkan) return window.cusnetSegarkan();
    location.reload();
    return Promise.resolve();
  }

  // --- Lebar kolom ----------------------------------------------------------
  function pasangLebar(tabel, kunci) {
    const lebar = simpan.baca(kunci + ":lebar", {});
    const kepala = Array.from(tabel.tHead.rows[0].cells);
    const adaSimpanan = Object.keys(lebar).length > 0;
    if (adaSimpanan) tabel.classList.add("tabel--lebar-tetap");
    kepala.forEach((th, i) => {
      const nama = th.dataset.kolom || String(i);
      if (lebar[nama]) th.style.width = lebar[nama] + "px";
      if (th.classList.contains("tabel__pilih") || th.querySelector(".tabel__geser")) return;
      const pegangan = buat("span", "tabel__geser");
      pegangan.setAttribute("aria-hidden", "true");
      th.append(pegangan);
      pegangan.addEventListener("pointerdown", (awal) => {
        awal.preventDefault();
        awal.stopPropagation();
        // Bekukan lebar semua kolom dulu supaya kolom lain tidak ikut
        // meloncat saat tata letak berpindah ke lebar tetap.
        if (!tabel.classList.contains("tabel--lebar-tetap")) {
          kepala.forEach((k) => { k.style.width = k.offsetWidth + "px"; });
          tabel.classList.add("tabel--lebar-tetap");
        }
        const mulaiX = awal.clientX;
        const mulaiLebar = th.offsetWidth;
        pegangan.setPointerCapture(awal.pointerId);
        document.body.classList.add("sedang-menggeser");
        const gerak = (e) => { th.style.width = Math.max(56, mulaiLebar + e.clientX - mulaiX) + "px"; };
        const lepas = () => {
          pegangan.removeEventListener("pointermove", gerak);
          document.body.classList.remove("sedang-menggeser");
          const hasil = {};
          kepala.forEach((k, n) => { hasil[k.dataset.kolom || String(n)] = k.offsetWidth; });
          simpan.tulis(kunci + ":lebar", hasil);
        };
        pegangan.addEventListener("pointermove", gerak);
        pegangan.addEventListener("pointerup", lepas, { once: true });
        pegangan.addEventListener("pointercancel", lepas, { once: true });
      });
    });
  }

  // --- Kolom tampil/sembunyi --------------------------------------------------
  function terapkanKolom(tabel, sembunyi) {
    const kepala = Array.from(tabel.tHead.rows[0].cells);
    kepala.forEach((th, i) => {
      const hilang = sembunyi.includes(th.textContent.trim());
      const pilih = 'tr > :nth-child(' + (i + 1) + ')';
      tabel.querySelectorAll(pilih).forEach((sel) => {
        if (sel.colSpan > 1) return;
        sel.classList.toggle("tabel__sel--sembunyi", hilang);
      });
    });
  }

  function menuKolom(tabel, kunci) {
    const sembunyi = simpan.baca(kunci + ":sembunyi", []);
    terapkanKolom(tabel, sembunyi);
    const bungkus = buat("details", "pemilih-kolom tabel-alat__kolom");
    bungkus.append(buat("summary", "tombol", ikon("columns-3") + " Kolom"));
    const panel = buat("div", "pemilih-kolom__panel");
    Array.from(tabel.tHead.rows[0].cells).forEach((th) => {
      const judul = th.textContent.trim();
      if (!judul || th.classList.contains("tabel__pilih") || /^aksi$/i.test(judul)) return;
      const baris = buat("label", "pemilih-kolom__baris");
      const kotak = buat("input");
      kotak.type = "checkbox";
      kotak.checked = !sembunyi.includes(judul);
      kotak.addEventListener("change", () => {
        const kini = simpan.baca(kunci + ":sembunyi", []).filter((j) => j !== judul);
        if (!kotak.checked) kini.push(judul);
        simpan.tulis(kunci + ":sembunyi", kini);
        terapkanKolom(tabel, kini);
      });
      baris.append(kotak, document.createTextNode(" " + judul));
      panel.append(baris);
    });
    bungkus.append(panel);
    return bungkus;
  }

  // --- Ekspor CSV dari isi tabel ----------------------------------------------
  function eksporCsv(tabel) {
    const baris = [];
    const ambil = (sel) => '"' + sel.innerText.replace(/\s+/g, " ").trim().replace(/"/g, '""') + '"';
    tabel.querySelectorAll("tr").forEach((tr) => {
      const sel = Array.from(tr.cells).filter((s) =>
        !s.classList.contains("tabel__pilih") && !s.classList.contains("tabel__sel--sembunyi") &&
        !s.querySelector(".tabel__aksi") && !/^aksi$/i.test(s.textContent.trim()) && s.colSpan === 1);
      if (sel.length) baris.push(sel.map(ambil).join(","));
    });
    const berkas = new Blob(["﻿" + baris.join("\r\n")], { type: "text/csv;charset=utf-8" });
    const tautan = buat("a");
    tautan.href = URL.createObjectURL(berkas);
    tautan.download = (tabel.dataset.entitas || document.title.split(" — ")[0] || "tabel").toLowerCase().replace(/\s+/g, "-") + ".csv";
    tautan.dataset.live = "off";
    document.body.append(tautan);
    tautan.click();
    tautan.remove();
    window.setTimeout(() => URL.revokeObjectURL(tautan.href), 1000);
  }

  // --- Paginasi di peramban ---------------------------------------------------
  function paginasiLokal(tabel, kunci, wadah) {
    const baris = Array.from(tabel.tBodies[0].rows).filter((tr) => !tr.querySelector("td[colspan]"));
    if (baris.length <= PILIHAN_BARIS[0]) return;
    let per = simpan.baca(kunci + ":per", PILIHAN_BARIS[0]);
    let halaman = 1;
    const kaki = buat("div", "paginasi paginasi--lokal");
    const info = buat("span", "paginasi__info");
    const daftar = buat("div", "paginasi__daftar");
    const pilih = buat("select");
    pilih.setAttribute("aria-label", "Jumlah baris per halaman");
    PILIHAN_BARIS.forEach((n) => { const o = buat("option", "", n + " / halaman"); o.value = n; pilih.append(o); });
    pilih.value = PILIHAN_BARIS.includes(per) ? per : PILIHAN_BARIS[0];
    const formulir = buat("div", "paginasi__per-halaman");
    formulir.append(pilih);
    kaki.append(info, daftar, formulir);
    wadah.after(kaki);

    function gambar() {
      per = Number(pilih.value);
      const akhir = Math.max(1, Math.ceil(baris.length / per));
      halaman = Math.min(halaman, akhir);
      baris.forEach((tr, i) => { tr.hidden = i < (halaman - 1) * per || i >= halaman * per; });
      info.textContent = "Menampilkan " + ((halaman - 1) * per + 1) + " - " + Math.min(halaman * per, baris.length) + " dari " + baris.length + " data";
      daftar.replaceChildren();
      const tombol = (teks, tujuan, mati, aktif) => {
        const t = buat("button", "paginasi__halaman" + (aktif ? " paginasi__halaman--aktif" : "") + (mati ? " paginasi__panah--mati" : ""), teks);
        t.type = "button";
        t.disabled = mati;
        t.addEventListener("click", () => { halaman = tujuan; gambar(); });
        daftar.append(t);
      };
      tombol("‹", halaman - 1, halaman === 1);
      for (let n = 1; n <= akhir; n++) {
        if (akhir > 7 && Math.abs(n - halaman) > 1 && n !== 1 && n !== akhir) {
          if (n === 2 || n === akhir - 1) daftar.append(buat("span", "paginasi__elipsis", "…"));
          continue;
        }
        tombol(String(n), n, false, n === halaman);
      }
      tombol("›", halaman + 1, halaman === akhir);
    }
    pilih.addEventListener("change", () => { simpan.tulis(kunci + ":per", Number(pilih.value)); halaman = 1; gambar(); });
    gambar();
  }

  // --- Aksi massal ------------------------------------------------------------
  async function ambilMeta(entitas) {
    if (meta.has(entitas)) return meta.get(entitas);
    const janji = fetch("/massal/" + entitas + "/meta", { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : null)).catch(() => null);
    meta.set(entitas, janji);
    return janji;
  }

  async function kirim(url, data) {
    data.append("csrf_token", csrf());
    const response = await fetch(url, { method: "POST", body: data, credentials: "same-origin", headers: { Accept: "application/json" } });
    let jawaban = null;
    try { jawaban = await response.json(); } catch (e) { /* bukan JSON */ }
    if (response.ok && jawaban && jawaban.ok) return jawaban;
    throw new Error((jawaban && jawaban.error) || (response.status === 403 ? "Anda tidak berhak melakukan ini." : "Gagal (HTTP " + response.status + ")."));
  }

  function dialog(judul, isiHtml) {
    const d = buat("dialog", "dialog");
    d.innerHTML =
      '<form method="dialog" class="dialog__isi" data-live="off">' +
      '<div class="dialog__kepala"><strong>' + judul + '</strong>' +
      '<button class="aksi-ikon" type="button" data-tutup aria-label="Tutup">' + ikon("x") + '</button></div>' +
      '<div class="dialog__badan">' + isiHtml + '</div>' +
      '<p class="form__galat" data-galat hidden></p>' +
      '<div class="dialog__aksi"><button class="tombol" type="button" data-tutup>Batal</button>' +
      '<button class="tombol tombol--utama" type="submit" data-kirim>Simpan</button></div></form>';
    document.body.append(d);
    d.addEventListener("close", () => d.remove());
    d.querySelectorAll("[data-tutup]").forEach((t) => t.addEventListener("click", () => d.close()));
    d.addEventListener("click", (e) => { if (e.target === d) d.close(); });
    if (window.lucide) window.lucide.createIcons();
    d.showModal();
    return d;
  }

  function jalankan(d, kerja) {
    const form = d.querySelector("form");
    const galat = d.querySelector("[data-galat]");
    const tombol = d.querySelector("[data-kirim]");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      galat.hidden = true;
      tombol.disabled = true;
      try {
        const jawaban = await kerja();
        d.close();
        beriTahu(jawaban.pesan || "Selesai.");
        await segarkan();
      } catch (e) {
        galat.textContent = e.message;
        galat.hidden = false;
      } finally {
        tombol.disabled = false;
      }
    });
  }

  function pasangPilih(tabel, info, bilah) {
    const entitas = tabel.dataset.entitas;
    const baris = Array.from(tabel.tBodies[0].rows).filter((tr) => tr.dataset.id);
    if (!baris.length) return;
    const kotakSemua = buat("input");
    kotakSemua.type = "checkbox";
    kotakSemua.setAttribute("aria-label", "Pilih semua baris");
    const th = buat("th", "tabel__pilih");
    th.append(kotakSemua);
    tabel.tHead.rows[0].prepend(th);
    Array.from(tabel.tBodies[0].rows).forEach((tr) => {
      if (!tr.dataset.id) {
        const sel = tr.querySelector("td[colspan]");
        if (sel) sel.colSpan += 1;
        return;
      }
      const td = buat("td", "tabel__pilih");
      const kotak = buat("input");
      kotak.type = "checkbox";
      kotak.value = tr.dataset.id;
      kotak.setAttribute("aria-label", "Pilih baris");
      td.append(kotak);
      td.addEventListener("click", (e) => e.stopPropagation());
      tr.prepend(td);
    });

    const terpilih = () => baris.filter((tr) => tr.querySelector(".tabel__pilih input").checked);
    const jumlah = buat("strong");
    const tombolUbah = buat("button", "tombol tombol--kecil", ikon("pencil") + " Ubah massal");
    const tombolHapus = buat("button", "tombol tombol--kecil tombol--bahaya", ikon("trash-2") + " Hapus");
    const tombolBatal = buat("button", "tombol tombol--kecil tombol--hantu", "Batal");
    [tombolUbah, tombolHapus, tombolBatal].forEach((t) => { t.type = "button"; });
    tombolUbah.hidden = !(info.medan && info.medan.length);
    tombolHapus.hidden = !info.hapus;
    bilah.append(jumlah, tombolUbah, tombolHapus, tombolBatal);

    function perbarui() {
      const dipilih = terpilih();
      baris.forEach((tr) => tr.classList.toggle("tabel__baris--dipilih", tr.querySelector(".tabel__pilih input").checked));
      bilah.hidden = dipilih.length === 0;
      jumlah.textContent = dipilih.length + " dipilih";
      const tampak = baris.filter((tr) => !tr.hidden);
      kotakSemua.checked = tampak.length > 0 && tampak.every((tr) => tr.querySelector(".tabel__pilih input").checked);
      kotakSemua.indeterminate = !kotakSemua.checked && dipilih.length > 0;
    }
    tabel.addEventListener("change", (e) => { if (e.target.closest(".tabel__pilih")) perbarui(); });
    kotakSemua.addEventListener("change", () => {
      baris.filter((tr) => !tr.hidden).forEach((tr) => { tr.querySelector(".tabel__pilih input").checked = kotakSemua.checked; });
      perbarui();
    });
    tombolBatal.addEventListener("click", () => {
      baris.forEach((tr) => { tr.querySelector(".tabel__pilih input").checked = false; });
      perbarui();
    });

    const dataIds = () => {
      const data = new FormData();
      terpilih().forEach((tr) => data.append("id", tr.dataset.id));
      return data;
    };

    tombolHapus.addEventListener("click", () => {
      const n = terpilih().length;
      const d = dialog("Hapus " + n + " " + info.label + "?",
        "<p>Data yang dihapus tidak bisa dikembalikan, termasuk data turunannya. " +
        "Bila satu saja tidak boleh dihapus, tidak ada yang dihapus.</p>" +
        '<label class="form__label" for="konfirmasi-hapus">Ketik HAPUS untuk melanjutkan</label>' +
        '<input class="form__isian" id="konfirmasi-hapus" autocomplete="off" required pattern="HAPUS">');
      const tombol = d.querySelector("[data-kirim]");
      tombol.textContent = "Hapus " + n + " baris";
      tombol.classList.replace("tombol--utama", "tombol--bahaya");
      jalankan(d, () => {
        if (d.querySelector("#konfirmasi-hapus").value !== "HAPUS") throw new Error("Ketik HAPUS (huruf besar) untuk melanjutkan.");
        return kirim("/massal/" + entitas + "/hapus", dataIds());
      });
    });

    tombolUbah.addEventListener("click", () => {
      const n = terpilih().length;
      const pilihanMedan = info.medan.map((m, i) => '<option value="' + i + '">' + m.label + "</option>").join("");
      const d = dialog("Ubah " + n + " " + info.label,
        '<label class="form__label" for="massal-medan">Yang diubah</label>' +
        '<select class="form__isian" id="massal-medan">' + pilihanMedan + "</select>" +
        '<label class="form__label" for="massal-nilai">Menjadi</label>' +
        '<select class="form__isian" id="massal-nilai"></select>');
      const medan = d.querySelector("#massal-medan");
      const nilai = d.querySelector("#massal-nilai");
      const isi = () => {
        nilai.innerHTML = info.medan[Number(medan.value)].pilihan
          .map((p) => '<option value="' + p[0] + '">' + p[1] + "</option>").join("");
      };
      medan.addEventListener("change", isi);
      isi();
      d.querySelector("[data-kirim]").textContent = "Ubah " + n + " baris";
      jalankan(d, () => {
        const data = dataIds();
        data.append("medan", info.medan[Number(medan.value)].nama);
        data.append("nilai", nilai.value);
        return kirim("/massal/" + entitas + "/ubah", data);
      });
    });
  }

  function tombolImpor(entitas, info) {
    const tombol = buat("button", "tombol", ikon("upload") + " Impor");
    tombol.type = "button";
    tombol.addEventListener("click", () => {
      const wajib = info.kolom.filter((k) => k.wajib).map((k) => "<code>" + k.nama + "</code>").join(", ");
      const d = dialog("Impor " + info.label,
        "<p>Unggah berkas CSV. Kolom wajib: " + (wajib || "—") + ". " +
        'Mulai dari <a href="/massal/' + entitas + '/templat.csv" data-live="off" download>templat ini</a> supaya nama kolomnya persis.</p>' +
        '<label class="form__label" for="impor-berkas">Berkas CSV</label>' +
        '<input class="form__isian" id="impor-berkas" type="file" accept=".csv,text/csv" required>' +
        '<p class="form__bantuan" data-bantuan-tetap>Bila satu baris gagal, tidak ada yang tersimpan.</p>');
      d.querySelector("[data-kirim]").textContent = "Impor";
      jalankan(d, () => {
        const berkas = d.querySelector("#impor-berkas").files[0];
        if (!berkas) throw new Error("Pilih berkas CSV dulu.");
        const data = new FormData();
        data.append("berkas", berkas);
        return kirim("/massal/" + entitas + "/impor", data);
      });
    });
    return tombol;
  }

  // --- Merakit satu tabel -----------------------------------------------------
  let hitung = 0;

  async function rakit(tabel) {
    if (tabel.dataset.tabelSiap || tabel.dataset.tabel === "polos") return;
    if (!tabel.tHead || !tabel.tHead.rows.length || !tabel.tBodies.length) return;
    if (tabel.classList.contains("tabel--rapat") || tabel.closest(".tabel--rapat, dialog")) return;
    tabel.dataset.tabelSiap = "1";
    const kunci = kunciTabel(tabel, ++hitung);
    const kartu = tabel.closest(".kartu, .db-panel") || tabel.parentElement;
    const bacaSaja = Boolean(tabel.closest(".isi--baca-saja"));

    // Pembungkus bergulir: kolom yang dilebarkan tidak melebarkan halaman.
    let bungkus = tabel.parentElement;
    if (!bungkus.classList.contains("tabel-bungkus")) {
      bungkus = buat("div", "tabel-bungkus");
      tabel.before(bungkus);
      bungkus.append(tabel);
    }

    const alat = buat("div", "tabel-alat");
    const kiri = buat("div", "tabel-alat__kiri");
    const bilah = buat("div", "tabel-alat__massal");
    bilah.hidden = true;
    alat.append(bilah, kiri);
    bungkus.before(alat);

    // Halaman yang sudah punya tombol Kolom/Ekspor sendiri (versi server,
    // mencakup semua baris) tidak diberi yang kedua.
    const halaman = document.getElementById("konten-utama") || document;
    if (!halaman.querySelector(".pemilih-kolom:not(.tabel-alat__kolom)")) kiri.append(menuKolom(tabel, kunci));
    const adaEkspor = Array.from(halaman.querySelectorAll("a[download], a[href*='.csv']")).some((a) => /ekspor/i.test(a.textContent));
    if (!adaEkspor) {
      const tombol = buat("button", "tombol", ikon("download") + " Ekspor");
      tombol.type = "button";
      tombol.addEventListener("click", () => eksporCsv(tabel));
      kiri.append(tombol);
    }

    const entitas = tabel.dataset.entitas;
    if (entitas && !bacaSaja) {
      const info = await ambilMeta(entitas);
      if (info && (info.hapus || (info.medan && info.medan.length))) pasangPilih(tabel, info, bilah);
      if (info && info.impor) kiri.append(tombolImpor(entitas, info));
    }
    if (tabel.dataset.imporUrl && !bacaSaja) {
      const tautan = buat("a", "tombol", ikon("upload") + " Impor");
      tautan.href = tabel.dataset.imporUrl;
      kiri.append(tautan);
    }

    pasangLebar(tabel, kunci);
    if (!kartu.querySelector(".paginasi")) paginasiLokal(tabel, kunci, bungkus);
    if (!kiri.children.length && bilah.hidden) alat.classList.add("tabel-alat--kosong");
    if (window.lucide) window.lucide.createIcons();
  }

  function rakitSemua() {
    document.querySelectorAll("#konten-utama table.tabel").forEach((tabel) => { rakit(tabel); });
  }

  document.addEventListener("DOMContentLoaded", rakitSemua);
  document.addEventListener("cusnet:isi-berubah", rakitSemua);
  document.addEventListener("htmx:afterSettle", rakitSemua);
  // Menu Kolom menutup saat diklik di luarnya.
  document.addEventListener("click", (event) => {
    document.querySelectorAll("details.tabel-alat__kolom[open]").forEach((d) => {
      if (!d.contains(event.target)) d.open = false;
    });
  });
})();
