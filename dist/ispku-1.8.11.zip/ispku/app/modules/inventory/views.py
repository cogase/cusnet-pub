"""Rute inventaris jaringan (menu Network).

Peran: `teknis` yang memelihara inventaris, jadi merekalah yang boleh menulis.
`billing` dan `viewer` hanya membaca — mereka perlu tahu port mana yang dipakai
pelanggan mana, tetapi tidak mengubahnya.
"""

from decimal import Decimal, InvalidOperation

from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.pagination import per_halaman_dari
from app.core.rbac import require_role
from app.modules.admin import service as admin_service
from app.modules.inventory import service
from app.modules.inventory.forms import (
    LABEL_JENIS_BLOK,
    LABEL_JENIS_PERANGKAT,
    LABEL_JENIS_PORT,
    LABEL_JENIS_SITE,
    LABEL_JENIS_VLAN,
    LABEL_STATUS_PERANGKAT,
    LABEL_STATUS_PORT,
    NADA_STATUS_PERANGKAT,
    NADA_STATUS_PORT,
    AlokasiPortForm,
    BlokIpForm,
    HapusInventarisForm,
    PerangkatForm,
    PortForm,
    SiteForm,
    VlanForm,
)

bp = Blueprint("inventory", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
TULIS = ("superadmin", "admin_cabang", "teknis")

KOSONG = (0, "—")


class _KoordinatTidakSah(GalatDomain):
    """Isian koordinat bukan angka desimal."""

    def __init__(self, field: str):
        super().__init__(field, "Koordinat harus berupa angka, contoh: -6.2088")


def _labels() -> dict:
    return {
        "label_jenis_site": LABEL_JENIS_SITE,
        "label_jenis_perangkat": LABEL_JENIS_PERANGKAT,
        "label_status_perangkat": LABEL_STATUS_PERANGKAT,
        "nada_status_perangkat": NADA_STATUS_PERANGKAT,
        "label_jenis_port": LABEL_JENIS_PORT,
        "label_status_port": LABEL_STATUS_PORT,
        "nada_status_port": NADA_STATUS_PORT,
        "label_jenis_vlan": LABEL_JENIS_VLAN,
        "label_jenis_blok": LABEL_JENIS_BLOK,
    }


def _pilihan_cabang(form) -> None:
    cabang = admin_service.semua_cabang(db_session, current_user())
    form.branch_id.choices = [(c.id, c.name) for c in cabang]


def _pilihan_site(form, wajib: bool = True) -> None:
    site = service.site_pilihan(db_session, current_user())
    pilihan = [(s.id, f"{s.code} — {s.name}") for s in site]
    form.site_id.choices = pilihan if wajib else [KOSONG] + pilihan


def _koordinat(data: dict) -> dict:
    """Mengubah isian koordinat jadi `Decimal`, bukan lewat `float`."""
    bersih = dict(data)
    for field in ("lat", "lng"):
        nilai = (bersih.get(field) or "").strip()
        if not nilai:
            bersih[field] = None
            continue
        try:
            bersih[field] = Decimal(nilai)
        except InvalidOperation as galat:
            raise _KoordinatTidakSah(field) from galat
    return bersih


@bp.get("/network")
@require_role(*BACA)
def ringkasan():
    return render_template(
        "inventory/ringkasan.html",
        ringkasan=service.ringkasan(db_session, current_user()),
        **_labels(),
    )


# --- Site -----------------------------------------------------------------


@bp.get("/network/site")
@require_role(*BACA)
def site_daftar():
    return render_template(
        "inventory/site_daftar.html",
        halaman=service.daftar_site(
            db_session,
            current_user(),
            page=request.args.get("page", 1, type=int),
            per_page=per_halaman_dari(request),
            q=request.args.get("q") or None,
        ),
        q=request.args.get("q") or "",
        form_hapus=HapusInventarisForm(),
        **_labels(),
    )


@bp.route("/network/site/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def site_baru():
    form = SiteForm()
    _pilihan_cabang(form)
    if form.validate_on_submit():
        try:
            service.tambah_site(db_session, current_user(), _koordinat(form.data))
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Site ditambahkan.", "sukses")
            return redirect(url_for("inventory.site_daftar"))
    return render_template("inventory/site_form.html", form=form, site=None)


@bp.route("/network/site/<int:site_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def site_ubah(site_id: int):
    site = service.ambil_site(db_session, current_user(), site_id)
    form = SiteForm(obj=site)
    _pilihan_cabang(form)
    if form.validate_on_submit():
        try:
            service.ubah_site(db_session, current_user(), site_id, _koordinat(form.data))
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Site disimpan.", "sukses")
            return redirect(url_for("inventory.site_daftar"))
    return render_template("inventory/site_form.html", form=form, site=site)


@bp.post("/network/site/<int:site_id>/hapus")
@require_role(*TULIS)
def site_hapus(site_id: int):
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("inventory.site_daftar"))
    try:
        service.hapus_site(db_session, current_user(), site_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash("Site dihapus.", "sukses")
    return redirect(url_for("inventory.site_daftar"))


# --- Perangkat ------------------------------------------------------------


@bp.get("/network/perangkat")
@require_role(*BACA)
def perangkat_daftar():
    user = current_user()
    filter_aktif = {
        "q": request.args.get("q") or None,
        "site_id": request.args.get("site", type=int),
        "status": request.args.get("status") or None,
        "kind": request.args.get("jenis") or None,
    }
    return render_template(
        "inventory/perangkat_daftar.html",
        halaman=service.daftar_perangkat(
            db_session,
            user,
            page=request.args.get("page", 1, type=int),
            per_page=per_halaman_dari(request),
            **filter_aktif,
        ),
        site_pilihan=service.site_pilihan(db_session, user),
        filter_aktif=filter_aktif,
        form_hapus=HapusInventarisForm(),
        **_labels(),
    )


@bp.route("/network/perangkat/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def perangkat_baru():
    form = PerangkatForm()
    _pilihan_site(form)
    if form.validate_on_submit():
        try:
            perangkat = service.tambah_perangkat(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Perangkat ditambahkan.", "sukses")
            return redirect(url_for("inventory.perangkat_detail", device_id=perangkat.id))
    return render_template("inventory/perangkat_form.html", form=form, perangkat=None)


@bp.get("/network/perangkat/<int:device_id>")
@require_role(*BACA)
def perangkat_detail(device_id: int):
    user = current_user()
    perangkat = service.ambil_perangkat(db_session, user, device_id)
    port = service.daftar_port(db_session, user, device_id)

    form_alokasi = AlokasiPortForm()
    # Langganan yang belum punya port. Menawarkan yang sudah terpakai berarti
    # tombol yang selalu ditolak.
    form_alokasi.subscription_id.choices = [
        # Site di tengah: satu customer bisa punya banyak layanan, jadi yang
        # membedakan baris-barisnya adalah site, bukan nama customernya.
        (
            langganan.id,
            f"{langganan.service_no or '—'} — {langganan.site_name or 'tanpa site'} — {pelanggan.name}",
        )
        for langganan, pelanggan in service.langganan_tanpa_port(db_session, user)
    ]

    return render_template(
        "inventory/perangkat_detail.html",
        perangkat=perangkat,
        site=service.ambil_site(db_session, user, perangkat.site_id),
        port=port,
        langganan_port={
            p.subscription_id: p for p in port if p.subscription_id is not None
        },
        form_port=PortForm(),
        form_alokasi=form_alokasi,
        form_hapus=HapusInventarisForm(),
        snmp=service.data_snmp(db_session, device_id),
        **_trafik_perangkat(device_id),
        **_labels(),
    )


def _trafik_perangkat(device_id: int) -> dict:
    from datetime import timedelta as _td

    from app.core import waktu
    from app.modules.inventory import trafik

    kunci = trafik.rentang_sah(request.args.get("rentang"))
    kini = waktu.sekarang()
    deret = trafik.deret_perangkat(db_session, device_id, kini, kunci)
    return {
        "rentang": kunci,
        "rentang_pilihan": [(k, v[0]) for k, v in trafik.RENTANG.items()],
        "grafik_trafik": trafik.svg(deret, kini - trafik.RENTANG[kunci][1], kini),
        "ringkas_trafik": trafik.ringkas(deret),
    }


@bp.get("/network/port/<int:port_id>/trafik")
@require_role(*BACA)
def port_trafik(port_id: int):
    """Grafik trafik satu port."""
    from app.core import waktu
    from app.modules.inventory import trafik

    user = current_user()
    port = service.ambil_port(db_session, user, port_id)
    perangkat = service.ambil_perangkat(db_session, user, port.device_id)
    kini = waktu.sekarang()
    grafik = []
    for kunci, (label, lama) in trafik.RENTANG.items():
        deret = trafik.deret_port(db_session, port_id, kini, kunci)
        grafik.append(
            {"label": label, "svg": trafik.svg(deret, kini - lama, kini), "ringkas": trafik.ringkas(deret)}
        )
    return render_template(
        "inventory/port_trafik.html", port=port, perangkat=perangkat, grafik=grafik
    )


@bp.post("/network/perangkat/<int:device_id>/snmp")
@require_role(*TULIS)
def perangkat_snmp(device_id: int):
    """Menarik identitas dan daftar port perangkat lewat SNMP."""
    from app.core import waktu
    from app.modules.inventory import snmp_tarik

    tujuan = redirect(url_for("inventory.perangkat_detail", device_id=device_id))
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman perangkat.", "bahaya")
        return tujuan
    try:
        hasil = snmp_tarik.tarik(db_session, current_user(), device_id, waktu.sekarang())
    except GalatDomain as galat:
        db_session.rollback()
        flash(f"SNMP gagal: {galat}", "bahaya")
        return tujuan
    db_session.commit()
    flash(
        f"SNMP: {hasil['antarmuka']} antarmuka ({hasil['dibuat']} port baru), "
        f"{hasil['alamat']} alamat IP ({hasil['blok_baru']} blok baru), "
        f"{hasil['vlan_baru']} VLAN baru, {hasil['bgp']} sesi BGP.",
        "sukses",
    )
    return tujuan


@bp.route("/network/perangkat/<int:device_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def perangkat_ubah(device_id: int):
    perangkat = service.ambil_perangkat(db_session, current_user(), device_id)
    form = PerangkatForm(obj=perangkat)
    _pilihan_site(form)
    if form.validate_on_submit():
        try:
            service.ubah_perangkat(db_session, current_user(), device_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Perangkat disimpan.", "sukses")
            return redirect(url_for("inventory.perangkat_detail", device_id=device_id))
    return render_template(
        "inventory/perangkat_form.html", form=form, perangkat=perangkat
    )


@bp.post("/network/perangkat/<int:device_id>/hapus")
@require_role(*TULIS)
def perangkat_hapus(device_id: int):
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("inventory.perangkat_daftar"))
    try:
        service.hapus_perangkat(db_session, current_user(), device_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("inventory.perangkat_detail", device_id=device_id))
    db_session.commit()
    flash("Perangkat dihapus.", "sukses")
    return redirect(url_for("inventory.perangkat_daftar"))


# --- Port -----------------------------------------------------------------


@bp.post("/network/perangkat/<int:device_id>/port")
@require_role(*TULIS)
def port_tambah(device_id: int):
    form = PortForm()
    if form.validate_on_submit():
        try:
            service.tambah_port(db_session, current_user(), device_id, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Port ditambahkan.", "sukses")
    else:
        for field in form:
            for pesan in field.errors:
                flash(f"{field.label.text}: {pesan}", "bahaya")
    return redirect(url_for("inventory.perangkat_detail", device_id=device_id))


@bp.post("/network/port/<int:port_id>/alokasi")
@require_role(*TULIS)
def port_alokasi(port_id: int):
    user = current_user()
    port = service.ambil_port(db_session, user, port_id)
    form = AlokasiPortForm()
    # Daftar pilihan dibiarkan terbuka: penolakan datang dari aturan alokasi,
    # yang pesannya menyebut langganan mana yang sudah memakai portnya.
    form.subscription_id.choices = [
        (langganan.id, langganan.service_no or str(langganan.id))
        for langganan, _pelanggan in service.langganan_tanpa_port(
            db_session, user, termasuk=port.subscription_id
        )
    ]

    if form.validate_on_submit():
        try:
            service.alokasi_port(db_session, user, port_id, form.subscription_id.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Port dialokasikan.", "sukses")
    else:
        flash("Pilih langganan yang sah dulu.", "bahaya")
    return redirect(url_for("inventory.perangkat_detail", device_id=port.device_id))


@bp.post("/network/port/<int:port_id>/bebaskan")
@require_role(*TULIS)
def port_bebaskan(port_id: int):
    user = current_user()
    port = service.ambil_port(db_session, user, port_id)
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan tidak sah.", "bahaya")
        return redirect(url_for("inventory.perangkat_detail", device_id=port.device_id))
    service.bebaskan_port(db_session, user, port_id)
    db_session.commit()
    flash("Alokasi port dibebaskan.", "sukses")
    return redirect(url_for("inventory.perangkat_detail", device_id=port.device_id))


@bp.post("/network/port/<int:port_id>/hapus")
@require_role(*TULIS)
def port_hapus(port_id: int):
    user = current_user()
    port = service.ambil_port(db_session, user, port_id)
    device_id = port.device_id
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("inventory.perangkat_detail", device_id=device_id))
    try:
        service.hapus_port(db_session, user, port_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash("Port dihapus.", "sukses")
    return redirect(url_for("inventory.perangkat_detail", device_id=device_id))


# --- VLAN dan blok IP -----------------------------------------------------


@bp.get("/network/vlan")
@require_role(*BACA)
def vlan_daftar():
    return render_template(
        "inventory/vlan_daftar.html",
        halaman=service.daftar_vlan(
            db_session,
            current_user(),
            page=request.args.get("page", 1, type=int),
            per_page=per_halaman_dari(request),
            q=request.args.get("q") or None,
        ),
        q=request.args.get("q") or "",
        form_hapus=HapusInventarisForm(),
        **_labels(),
    )


@bp.route("/network/vlan/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def vlan_baru():
    form = VlanForm()
    _pilihan_cabang(form)
    _pilihan_site(form, wajib=False)
    if form.validate_on_submit():
        data = dict(form.data)
        data["site_id"] = data.get("site_id") or None
        try:
            service.tambah_vlan(db_session, current_user(), data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("VLAN ditambahkan.", "sukses")
            return redirect(url_for("inventory.vlan_daftar"))
    return render_template("inventory/vlan_form.html", form=form, vlan=None)


@bp.route("/network/vlan/<int:vlan_row_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def vlan_ubah(vlan_row_id: int):
    baris = service.ambil_vlan(db_session, current_user(), vlan_row_id)
    form = VlanForm(obj=baris)
    _pilihan_cabang(form)
    _pilihan_site(form, wajib=False)
    if form.validate_on_submit():
        data = dict(form.data)
        data["site_id"] = data.get("site_id") or None
        try:
            service.ubah_vlan(db_session, current_user(), vlan_row_id, data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("VLAN disimpan.", "sukses")
            return redirect(url_for("inventory.vlan_daftar"))
    return render_template("inventory/vlan_form.html", form=form, vlan=baris)


@bp.post("/network/vlan/<int:vlan_row_id>/hapus")
@require_role(*TULIS)
def vlan_hapus(vlan_row_id: int):
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("inventory.vlan_daftar"))
    service.hapus_vlan(db_session, current_user(), vlan_row_id)
    db_session.commit()
    flash("VLAN dihapus.", "sukses")
    return redirect(url_for("inventory.vlan_daftar"))


@bp.get("/network/ip")
@require_role(*BACA)
def blok_daftar():
    from app.modules.inventory import ipam

    user = current_user()
    halaman = service.daftar_blok(
        db_session,
        user,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        q=request.args.get("q") or None,
    )
    di_luar = ipam.di_luar_blok(db_session, user)
    return render_template(
        "inventory/blok_daftar.html",
        halaman=halaman,
        q=request.args.get("q") or "",
        form_hapus=HapusInventarisForm(),
        pemakaian=ipam.ringkasan_blok(db_session, user, halaman.items),
        di_luar=di_luar[: ipam.BATAS_DI_LUAR],
        di_luar_terpotong=len(di_luar) > ipam.BATAS_DI_LUAR,
        batas_di_luar=ipam.BATAS_DI_LUAR,
        **_labels(),
    )


@bp.get("/network/ip/<int:blok_id>")
@require_role(*BACA)
def blok_detail(blok_id: int):
    """Isi satu blok: alamat yang terpakai, oleh siapa, dan apa yang tersisa.

    Alamat tidak disalin ke tabel alokasi tersendiri — yang ditampilkan di
    sini dibaca langsung dari `subscription.ip_address` yang diisi di halaman
    layanan pelanggan. Dua salinan alamat yang sama pasti berbeda pada suatu
    hari, dan layar Network akan bercerita lain daripada halaman pelanggan.
    """
    from app.modules.inventory import ipam

    user = current_user()
    blok = service.ambil_blok(db_session, user, blok_id)
    return render_template(
        "inventory/blok_detail.html",
        blok=blok,
        isi=ipam.alokasi_blok(db_session, user, blok),
        form_hapus=HapusInventarisForm(),
        **_labels(),
    )


@bp.route("/network/ip/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def blok_baru():
    form = BlokIpForm()
    _pilihan_cabang(form)
    _pilihan_site(form, wajib=False)
    if form.validate_on_submit():
        data = dict(form.data)
        data["site_id"] = data.get("site_id") or None
        try:
            service.tambah_blok(db_session, current_user(), data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Blok IP ditambahkan.", "sukses")
            return redirect(url_for("inventory.blok_daftar"))
    return render_template("inventory/blok_form.html", form=form, blok=None)


@bp.route("/network/ip/<int:blok_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def blok_ubah(blok_id: int):
    baris = service.ambil_blok(db_session, current_user(), blok_id)
    form = BlokIpForm(obj=baris)
    _pilihan_cabang(form)
    _pilihan_site(form, wajib=False)
    if form.validate_on_submit():
        data = dict(form.data)
        data["site_id"] = data.get("site_id") or None
        try:
            service.ubah_blok(db_session, current_user(), blok_id, data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            flash("Blok IP disimpan.", "sukses")
            return redirect(url_for("inventory.blok_daftar"))
    return render_template("inventory/blok_form.html", form=form, blok=baris)


@bp.post("/network/ip/<int:blok_id>/hapus")
@require_role(*TULIS)
def blok_hapus(blok_id: int):
    if not HapusInventarisForm().validate_on_submit():
        flash("Permintaan hapus tidak sah.", "bahaya")
        return redirect(url_for("inventory.blok_daftar"))
    service.hapus_blok(db_session, current_user(), blok_id)
    db_session.commit()
    flash("Blok IP dihapus.", "sukses")
    return redirect(url_for("inventory.blok_daftar"))


# --- Peta -----------------------------------------------------------------


@bp.get("/network/peta")
@require_role(*BACA)
def peta():
    """Sebaran koordinat site dan pelanggan.

    Digambar sendiri sebagai SVG, tanpa peta dasar: server pelanggan sering
    tanpa akses internet keluar, dan peta yang menarik ubin dari luar akan
    kosong di sana. Yang ditampilkan hubungan relatif antar-titik, bukan jalan
    dan sungai.
    """
    from app.modules.inventory import peta as modul_peta

    return render_template(
        "inventory/peta.html",
        peta=modul_peta.rakit_svg(
            service.titik_peta(db_session, current_user())
        ),
    )
