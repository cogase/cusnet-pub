from datetime import date
from decimal import Decimal, InvalidOperation
from urllib.parse import parse_qs, urlencode, urlsplit

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.files import FileError, sajikan
from app.core.pagination import per_halaman_dari
from app.core.rbac import has_role, require_role
from app.modules.admin import service as admin_service
from app.modules.customers import service, subscription_service
from app.modules.customers import topology
from app.modules.tickets import service as ticket_service
from app.modules.tickets.forms import LABEL_STATUS as LABEL_STATUS_TIKET
from app.modules.tickets.forms import NADA_STATUS as NADA_STATUS_TIKET
from app.modules.customers.forms import (
    LABEL_JENIS_DOKUMEN,
    LABEL_STATUS_LANGGANAN,
    LABEL_PERAN_KONTAK,
    LABEL_SUMBER,
    LABEL_TIER,
    LABEL_TIPE_PELANGGAN,
    LABEL_TIPE_PEMBAYARAN,
    AddonForm,
    CatatanForm,
    CicilanForm,
    DokumenForm,
    HapusForm,
    HopForm,
    InternetForm,
    KategoriPelangganForm,
    KontakForm,
    LanggananForm,
    P2PForm,
    PelangganForm,
    TerminasiForm,
)
from app.modules.services import service as service_layanan

bp = Blueprint("customers", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
TULIS = ("superadmin", "admin_cabang", "billing")
# Teknisi hanya mengelola Network dan Ticketing; data customer hanya dibaca.
TULIS_PELANGGAN = ("superadmin", "admin_cabang", "billing")
# Nominal tetap dibatasi ke peran yang mengelola customer/billing. Dibuang
# dari data di rute, bukan sekadar disembunyikan di templat.
TULIS_NOMINAL = ("superadmin", "admin_cabang", "billing")
FIELD_NOMINAL_LANGGANAN = ("price_override", "discount_kind", "discount_value")
FIELD_NOMINAL_PELANGGAN = ("credit_limit", "payment_term_days")


def _boleh_nominal() -> bool:
    return has_role(current_user(), *TULIS_NOMINAL)


def _tanpa_nominal(data: dict, field: tuple[str, ...]) -> dict:
    """Membuang field nominal bila aktor tidak berhak menyentuhnya.

    Dibuang, bukan ditimpa `None`: menimpa berarti staf teknis yang menyunting
    alamat justru menghapus harga khusus yang disetel billing.
    """
    if _boleh_nominal():
        return data
    return {k: v for k, v in data.items() if k not in field}


@bp.get("/master/kategori-customer")
@require_role(*BACA)
def kategori_daftar():
    halaman = service.daftar_kategori_pelanggan(
        db_session,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
    )
    return render_template(
        "customers/kategori_daftar.html", halaman=halaman, form_hapus=HapusForm()
    )


@bp.route("/master/kategori-customer/baru", methods=["GET", "POST"])
@require_role(*TULIS)
def kategori_baru():
    form = KategoriPelangganForm()
    if form.validate_on_submit():
        try:
            service.buat_kategori_pelanggan(db_session, current_user(), form.data)
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("customers.kategori_daftar"))
    return render_template(
        "customers/kategori_form.html", form=form, judul="Tambah Kategori Customer"
    )


@bp.route("/master/kategori-customer/<int:kategori_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS)
def kategori_ubah(kategori_id: int):
    kategori = service.ambil_kategori_pelanggan(db_session, kategori_id)
    form = KategoriPelangganForm(obj=kategori)
    if form.validate_on_submit():
        try:
            service.ubah_kategori_pelanggan(
                db_session, current_user(), kategori_id, form.data
            )
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("customers.kategori_daftar"))
    return render_template(
        "customers/kategori_form.html", form=form, judul="Ubah Kategori Customer"
    )


@bp.post("/master/kategori-customer/<int:kategori_id>/hapus")
@require_role(*TULIS)
def kategori_hapus(kategori_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman kategori.", "bahaya")
        return redirect(url_for("customers.kategori_daftar"))
    service.hapus_kategori_pelanggan(db_session, current_user(), kategori_id)
    db_session.commit()
    flash("Kategori customer dihapus. Customer yang memakainya tidak dihapus.", "sukses")
    return redirect(url_for("customers.kategori_daftar"))


def _isi_pilihan(form: PelangganForm) -> None:
    """Mengisi pilihan cabang, kategori, dan sales.

    Cabang dibatasi ke yang boleh diakses aktor: staf cabang tidak boleh
    melihat — apalagi memilih — cabang orang lain di dropdown.
    """
    user = current_user()

    cabang = admin_service.semua_cabang(db_session, user)
    form.branch_id.choices = [(c.id, f"{c.code} — {c.name}") for c in cabang]

    kategori = service.semua_kategori_pelanggan(db_session)
    form.category_id.choices = [(0, "—")] + [(k.id, k.name) for k in kategori]

    sales = admin_service.semua_user(db_session, user)
    form.sales_user_id.choices = [(0, "—")] + [
        (u.id, u.full_name) for u in sales
    ]


class _KoordinatTidakSah(ValueError):
    """Isian koordinat bukan angka desimal."""

    def __init__(self, field: str):
        super().__init__("Koordinat harus berupa angka, contoh: -6.2088")
        self.field = field


def _data_bersih(form: PelangganForm) -> dict:
    """Menerjemahkan isian formulir menjadi argumen service.

    Dua hal ini urusan bentuk formulir, bukan aturan bisnis, jadi tidak
    dititipkan ke service: `0` sebagai penanda "tidak dipilih" pada
    SelectField, dan pencentangan "alamat penagihan sama".
    """
    data = dict(form.data)
    data.pop("csrf_token", None)

    for field in ("category_id", "sales_user_id"):
        if not data.get(field):
            data[field] = None
    if not data.get("source"):
        data["source"] = None

    if data.get("billing_same_as_install"):
        data["billing_address"] = data.get("install_address")

    for field in ("install_lat", "install_lng"):
        nilai = (data.get(field) or "").strip()
        if not nilai:
            data[field] = None
            continue
        try:
            data[field] = Decimal(nilai)
        except InvalidOperation as galat:
            raise _KoordinatTidakSah(field) from galat

    return _tanpa_nominal(data, FIELD_NOMINAL_PELANGGAN)


# Parameter URL yang membentuk "daftar yang sedang dibuka". Dipakai untuk
# merangkai ulang tautan Selanjutnya di halaman detail; padanan URL dari
# kunci-kunci yang dibaca `_filter_pelanggan`.
ARGS_FILTER_PELANGGAN = (
    "q", "status", "cabang", "kategori", "tipe", "layanan", "sejak", "sampai",
)


def _filter_pelanggan():
    """Filter daftar pelanggan dari query string.

    Dipakai halaman daftar dan ekspor. Dua pembaca filter yang ditulis
    terpisah akan berbeda pada suatu hari, dan ekspor yang menyaring lain
    dari layarnya salah tanpa memberitahu siapa pun.
    """
    return {
        "q": request.args.get("q") or None,
        "status": request.args.get("status") or None,
        "branch_id": request.args.get("cabang", type=int),
        "category_id": request.args.get("kategori", type=int),
        "customer_type": request.args.get("tipe") or None,
        "kategori_layanan_id": request.args.get("layanan", type=int),
        # Werkzeug menelan ValueError dari `type=`, jadi tanggal ngawur
        # menjadi None, bukan 500.
        "sejak": request.args.get("sejak", type=date.fromisoformat),
        "sampai": request.args.get("sampai", type=date.fromisoformat),
    }


@bp.get("/customer.csv")
@require_role(*BACA)
def pelanggan_ekspor():
    """Daftar pelanggan sebagai CSV, mengikuti filter dan kolom yang aktif."""
    from flask import Response

    from app.modules.customers import ekspor

    kolom = ekspor.kolom_terpilih(request.args.getlist("kolom"))
    isi, terpotong = service.ekspor_pelanggan(
        db_session, current_user(), kolom, **_filter_pelanggan()
    )
    nama = (
        f"customer-terpotong-{service.BATAS_EKSPOR}.csv"
        if terpotong
        else "customer.csv"
    )
    return Response(
        isi,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nama}"'},
    )


@bp.get("/customer")
@require_role(*BACA)
def pelanggan_daftar():
    from app.modules.customers import ekspor

    user = current_user()
    filter_aktif = _filter_pelanggan()
    tersimpan = (user.preferences or {}).get("customer_list_columns")
    diminta = request.args.getlist("kolom") if "kolom" in request.args else tersimpan
    kolom = ekspor.kolom_terpilih(diminta)
    halaman = service.daftar_pelanggan(
        db_session,
        user,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        **filter_aktif,
    )
    return render_template(
        "customers/pelanggan_daftar.html",
        halaman=halaman,
        ringkasan=service.ringkasan_pelanggan(db_session, user),
        kontak_utama=service.kontak_utama_untuk(
            db_session, [pelanggan.id for pelanggan, _ in halaman.items]
        ),
        cabang_pilihan=admin_service.semua_cabang(db_session, user),
        kategori_pilihan=service.semua_kategori_pelanggan(db_session),
        kategori_layanan_pilihan=service_layanan.semua_kategori(db_session),
        kategori_aktif=subscription_service.kategori_aktif_untuk(
            db_session, [pelanggan.id for pelanggan, _ in halaman.items]
        ),
        filter_aktif=filter_aktif,
        label_tipe=LABEL_TIPE_PELANGGAN,
        kolom=kolom,
        kolom_tabel=ekspor.KOLOM_TABEL,
        kolom_tambahan=ekspor.KOLOM_CSV_TAMBAHAN,
        form_kolom=HapusForm(),
    )


@bp.post("/customer/kolom")
@require_role(*BACA)
def kolom_pelanggan_simpan():
    from app.modules.customers import ekspor

    form = HapusForm()
    if not form.validate_on_submit():
        flash("Preferensi kolom tidak disimpan karena formulir tidak valid.", "bahaya")
        return redirect(url_for("customers.pelanggan_daftar"))

    user = current_user()
    prefs = dict(user.preferences or {})
    prefs["customer_list_columns"] = ekspor.kolom_terpilih(
        request.form.getlist("kolom")
    )
    user.preferences = prefs
    db_session.commit()

    tujuan = urlsplit(request.form.get("next", ""))
    params = parse_qs(tujuan.query)
    params.pop("kolom", None)
    boleh = {
        "q", "status", "cabang", "kategori", "tipe", "layanan",
        "sejak", "sampai", "page",
    }
    query = urlencode(
        {k: v for k, v in params.items() if k in boleh}, doseq=True
    )
    return redirect("/customer" + (f"?{query}" if query else ""))


@bp.route("/customer/<int:customer_id>/kontak/baru", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def kontak_baru(customer_id: int):
    pelanggan = service.ambil_pelanggan(db_session, current_user(), customer_id)
    form = KontakForm()
    if form.validate_on_submit():
        try:
            service.buat_kontak(
                db_session, current_user(), customer_id, _data_kontak(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(
                url_for("customers.pelanggan_detail", customer_id=customer_id)
            )
    return render_template(
        "customers/kontak_form.html",
        form=form,
        pelanggan=pelanggan,
        judul="Tambah Kontak",
    )


@bp.route("/customer/kontak/<int:kontak_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def kontak_ubah(kontak_id: int):
    kontak = service.ambil_kontak(db_session, current_user(), kontak_id)
    pelanggan = service.ambil_pelanggan(
        db_session, current_user(), kontak.customer_id
    )
    form = KontakForm(obj=kontak)
    if form.validate_on_submit():
        try:
            service.ubah_kontak(db_session, current_user(), kontak_id, _data_kontak(form))
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(
                url_for("customers.pelanggan_detail", customer_id=pelanggan.id)
            )
    return render_template(
        "customers/kontak_form.html",
        form=form,
        pelanggan=pelanggan,
        judul="Ubah Kontak",
    )


@bp.post("/customer/kontak/<int:kontak_id>/hapus")
@require_role(*TULIS_PELANGGAN)
def kontak_hapus(kontak_id: int):
    kontak = service.ambil_kontak(db_session, current_user(), kontak_id)
    customer_id = kontak.customer_id
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman customer.", "bahaya")
        return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))
    try:
        service.hapus_kontak(db_session, current_user(), kontak_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


def _data_kontak(form: KontakForm) -> dict:
    data = dict(form.data)
    data.pop("csrf_token", None)
    return data


@bp.post("/customer/<int:customer_id>/catatan/baru")
@require_role(*TULIS_PELANGGAN)
def catatan_baru(customer_id: int):
    form = CatatanForm()
    if form.validate_on_submit():
        try:
            service.buat_catatan(
                db_session, current_user(), customer_id, form.body.data
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        for pesan in form.body.errors:
            flash(pesan, "bahaya")
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


@bp.post("/customer/catatan/<int:catatan_id>/hapus")
@require_role(*TULIS_PELANGGAN)
def catatan_hapus(catatan_id: int):
    catatan = service.ambil_catatan(db_session, current_user(), catatan_id)
    customer_id = catatan.customer_id
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman customer.", "bahaya")
        return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))

    service.hapus_catatan(db_session, current_user(), catatan_id)
    db_session.commit()
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


@bp.post("/customer/<int:customer_id>/dokumen/unggah")
@require_role(*TULIS_PELANGGAN)
def dokumen_unggah(customer_id: int):
    form = DokumenForm()
    if form.validate_on_submit():
        try:
            service.unggah_dokumen(
                db_session,
                current_user(),
                customer_id,
                form.berkas.data.stream,
                form.berkas.data.filename,
                form.doc_type.data,
                current_app.config["UPLOAD_DIR"],
            )
        except (GalatDomain, FileError) as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        for pesan in form.berkas.errors + form.doc_type.errors:
            flash(pesan, "bahaya")
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


@bp.get("/customer/dokumen/<int:dokumen_id>/unduh")
@require_role(*BACA)
def dokumen_unduh(dokumen_id: int):
    dokumen = service.ambil_dokumen(db_session, current_user(), dokumen_id)
    return sajikan(
        dokumen.path,
        dokumen.original_name,
        dokumen.mime,
        current_app.config["UPLOAD_DIR"],
    )


@bp.post("/customer/dokumen/<int:dokumen_id>/hapus")
@require_role(*TULIS)
def dokumen_hapus(dokumen_id: int):
    dokumen = service.ambil_dokumen(db_session, current_user(), dokumen_id)
    customer_id = dokumen.customer_id
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman customer.", "bahaya")
        return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))

    service.hapus_dokumen(db_session, current_user(), dokumen_id)
    db_session.commit()
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


@bp.post("/customer/<int:customer_id>/hapus")
@require_role(*TULIS)
def pelanggan_hapus(customer_id: int):
    """Menghapus pelanggan beserta semua data terkait setelah konfirmasi CSRF."""
    service.ambil_pelanggan(db_session, current_user(), customer_id)

    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman customer.", "bahaya")
        return redirect(
            url_for("customers.pelanggan_detail", customer_id=customer_id)
        )

    try:
        service.hapus_pelanggan(db_session, current_user(), customer_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(
            url_for("customers.pelanggan_detail", customer_id=customer_id)
        )

    db_session.commit()
    flash("Customer dihapus.", "sukses")
    return redirect(url_for("customers.pelanggan_daftar"))


@bp.get("/customer/<int:customer_id>")
@require_role(*BACA)
def pelanggan_detail(customer_id: int):
    user = current_user()
    pelanggan = service.ambil_pelanggan(db_session, user, customer_id)
    tab = request.args.get("tab", "ringkasan")
    # Tombol "Selanjutnya" mengikuti daftar yang sedang dibuka, jadi filternya
    # ikut menempel di query string halaman ini. Tanpa itu "selanjutnya"
    # artinya menebak — dan itu sebabnya tombolnya mati sejak M1b.
    filter_aktif = _filter_pelanggan()
    langganan = subscription_service.daftar_langganan(
        db_session, user, customer_id
    )
    return render_template(
        "customers/pelanggan_detail.html",
        pelanggan=pelanggan,
        berikutnya_id=service.pelanggan_berikutnya(
            db_session, user, customer_id, **filter_aktif
        ),
        # Daftar putih, bukan `request.args` apa adanya. Dua sebabnya:
        # query string dikirim pengunjung, jadi `?customer_id=9` akan menjadi
        # argumen kembar di `url_for(...)` dan menjatuhkan halaman; dan nama
        # parameter URL (`cabang`, `kategori`) berbeda dari nama argumen
        # service, jadi menyusunnya ulang dari `filter_aktif` berarti dua
        # penerjemah yang harus dijaga tetap sama.
        args_filter={
            k: v for k, v in request.args.items() if k in ARGS_FILTER_PELANGGAN
        },
        cabang=admin_service.ambil_cabang(db_session, user, pelanggan.branch_id),
        kontak=service.daftar_kontak(db_session, user, customer_id),
        dokumen=service.daftar_dokumen(db_session, user, customer_id),
        catatan=service.daftar_catatan(db_session, user, customer_id),
        timeline=service.timeline_pelanggan(db_session, user, customer_id),
        langganan=langganan,
        langganan_aktif_terbaru=sorted(
            (baris for baris in langganan if baris[0].status == "active"),
            key=lambda baris: (baris[0].created_at, baris[0].id),
            reverse=True,
        )[:5],
        jumlah_layanan_aktif=subscription_service.jumlah_aktif_per_pelanggan(
            db_session, user, customer_id
        ),
        form_dokumen=DokumenForm(),
        form_hapus=HapusForm(),
        form_catatan=CatatanForm(),
        tab=tab,
        label_tipe=LABEL_TIPE_PELANGGAN,
        label_tier=LABEL_TIER,
        label_sumber=LABEL_SUMBER,
        label_tipe_pembayaran=LABEL_TIPE_PEMBAYARAN,
        label_peran_kontak=LABEL_PERAN_KONTAK,
        label_jenis_dokumen=LABEL_JENIS_DOKUMEN,
    )


@bp.route("/customer/baru", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def pelanggan_baru():
    form = PelangganForm()
    _isi_pilihan(form)
    if form.validate_on_submit():
        try:
            service.buat_pelanggan(db_session, current_user(), _data_bersih(form))
        except (GalatDomain, _KoordinatTidakSah) as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("customers.pelanggan_daftar"))
    return render_template(
        "customers/pelanggan_form.html",
        form=form,
        judul="Tambah Customer",
        boleh_nominal=_boleh_nominal(),
    )


@bp.route("/customer/<int:customer_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def pelanggan_ubah(customer_id: int):
    pelanggan = service.ambil_pelanggan(db_session, current_user(), customer_id)
    form = PelangganForm(obj=pelanggan)
    _isi_pilihan(form)
    if form.validate_on_submit():
        try:
            service.ubah_pelanggan(
                db_session, current_user(), customer_id, _data_bersih(form)
            )
        except (GalatDomain, _KoordinatTidakSah) as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(url_for("customers.pelanggan_daftar"))
    return render_template(
        "customers/pelanggan_form.html",
        form=form,
        judul="Edit Customer",
        pelanggan=pelanggan,
        boleh_nominal=_boleh_nominal(),
    )


def _pilihan_paket(form: LanggananForm, paket_terpakai: int | None = None) -> None:
    """Pilihan paket beserta kategorinya.

    Kategori ikut ditulis supaya pengguna tahu bentuk formulir teknis apa yang
    akan muncul setelah layanan tersimpan.

    Hanya paket aktif yang ditawarkan — itulah satu-satunya arti "Nonaktifkan"
    di Daftar Layanan. `paket_terpakai` adalah pengecualiannya: langganan yang
    sudah memakai paket nonaktif tetap boleh disunting, kalau tidak menyunting
    catatan teknisnya akan diam-diam memindahkannya ke paket lain — atau gagal
    validasi tanpa sebab yang terbaca di layar.
    """
    baris_paket = service_layanan.semua_paket(db_session, aktif=True)
    pilihan = [
        (paket.id, f"{kategori.name} — {paket.code} {paket.name}")
        for paket, kategori in baris_paket
    ]
    if paket_terpakai is not None and all(
        paket_id != paket_terpakai for paket_id, _ in pilihan
    ):
        paket, kategori = service_layanan.ambil_paket_dengan_kategori(
            db_session, paket_terpakai
        )
        pilihan.append(
            (
                paket.id,
                f"{kategori.name} — {paket.code} {paket.name} (nonaktif)",
            )
        )
    form.plan_id.choices = pilihan


def _pilihan_vendor(form) -> None:
    vendor = service_layanan.semua_vendor(db_session)
    form.vendor_id.choices = [(0, "— Infrastruktur sendiri —")] + [
        (vendor.id, vendor.name) for vendor in vendor
    ]


def _data_langganan(form: LanggananForm) -> dict:
    data = dict(form.data)
    data.pop("csrf_token", None)
    if not data.get("discount_kind"):
        data["discount_kind"] = None
    return _tanpa_nominal(data, FIELD_NOMINAL_LANGGANAN)


def _data_vendor(form) -> dict:
    data = dict(form.data)
    data.pop("csrf_token", None)
    if not data.get("vendor_id"):
        data["vendor_id"] = None
    return data


@bp.route("/customer/<int:customer_id>/layanan/baru", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def langganan_baru(customer_id: int):
    pelanggan = service.ambil_pelanggan(db_session, current_user(), customer_id)
    form = LanggananForm()
    _pilihan_paket(form)
    if form.validate_on_submit():
        try:
            langganan = subscription_service.buat_langganan(
                db_session, current_user(), customer_id, _data_langganan(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(
                url_for("customers.langganan_detail", langganan_id=langganan.id)
            )
    return render_template(
        "customers/langganan_form.html",
        form=form,
        pelanggan=pelanggan,
        judul="Tambah Layanan",
        boleh_nominal=_boleh_nominal(),
    )


@bp.route("/customer/layanan/<int:langganan_id>/ubah", methods=["GET", "POST"])
@require_role(*TULIS_PELANGGAN)
def langganan_ubah(langganan_id: int):
    langganan = subscription_service.ambil_langganan(
        db_session, current_user(), langganan_id
    )
    pelanggan = service.ambil_pelanggan(
        db_session, current_user(), langganan.customer_id
    )
    form = LanggananForm(obj=langganan)
    _pilihan_paket(form, paket_terpakai=langganan.plan_id)
    if form.validate_on_submit():
        try:
            subscription_service.ubah_langganan(
                db_session, current_user(), langganan_id, _data_langganan(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, galat.field).errors.append(str(galat))
        else:
            db_session.commit()
            return redirect(
                url_for("customers.langganan_detail", langganan_id=langganan_id)
            )
    return render_template(
        "customers/langganan_form.html",
        form=form,
        pelanggan=pelanggan,
        langganan=langganan,
        judul="Ubah Layanan",
        boleh_nominal=_boleh_nominal(),
    )


@bp.post("/customer/layanan/<int:langganan_id>/nomor")
@require_role(*TULIS_PELANGGAN)
def langganan_nomor(langganan_id: int):
    """Mengganti nomor layanan langsung dari halaman Detail Layanan."""
    tujuan = redirect(
        url_for("customers.langganan_detail", langganan_id=langganan_id)
    )
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return tujuan

    nomor = (request.form.get("service_no") or "").strip()
    if not nomor:
        flash("Nomor layanan tidak boleh kosong.", "bahaya")
        return tujuan

    try:
        langganan = subscription_service.ubah_langganan(
            db_session, current_user(), langganan_id, {"service_no": nomor}
        )
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return tujuan

    db_session.commit()
    flash(f"Nomor layanan diubah menjadi {langganan.service_no}.", "sukses")
    return tujuan


@bp.post("/customer/layanan/<int:langganan_id>/hapus")
@require_role(*TULIS)
def langganan_hapus(langganan_id: int):
    langganan = subscription_service.ambil_langganan(
        db_session, current_user(), langganan_id
    )
    customer_id = langganan.customer_id
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))

    try:
        subscription_service.hapus_langganan(db_session, current_user(), langganan_id)
    except GalatDomain as galat:
        # Penolakan "sudah pernah ditagih" adalah jawaban yang benar, bukan
        # kegagalan server. Tanpa ini yang sampai ke layar adalah
        # `IntegrityError` dari foreign key invoice, yaitu 500 tanpa
        # keterangan apa pun tentang apa yang harus dilakukan.
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(
            url_for("customers.langganan_detail", langganan_id=langganan_id)
        )

    db_session.commit()
    flash("Layanan dan seluruh data terkait dihapus.", "sukses")
    return redirect(url_for("customers.pelanggan_detail", customer_id=customer_id))


@bp.get("/customer/layanan/<int:langganan_id>")
@require_role(*BACA)
def langganan_detail(langganan_id: int):
    user = current_user()
    langganan = subscription_service.ambil_langganan(db_session, user, langganan_id)
    pelanggan = service.ambil_pelanggan(db_session, user, langganan.customer_id)
    bentuk = subscription_service.bentuk_formulir(db_session, langganan)
    paket, kategori = service_layanan.ambil_paket_dengan_kategori(
        db_session, langganan.plan_id
    )

    terminasi = subscription_service.daftar_terminasi(
        db_session, user, langganan_id
    )
    hop = subscription_service.daftar_hop(db_session, user, langganan_id)

    form_internet = InternetForm(
        obj=subscription_service.ambil_detail_internet(db_session, user, langganan_id)
    )
    form_p2p = P2PForm(
        obj=subscription_service.ambil_detail_p2p(db_session, user, langganan_id)
    )
    _pilihan_vendor(form_internet)
    _pilihan_vendor(form_p2p)
    form_hop = HopForm()
    _pilihan_vendor(form_hop)
    form_hop_ubah = {}
    for baris in hop:
        form_edit = HopForm(obj=baris, prefix=f"hop{baris.id}")
        _pilihan_vendor(form_edit)
        form_hop_ubah[baris.id] = form_edit

    cicilan = subscription_service.ambil_cicilan(db_session, user, langganan_id)

    return render_template(
        "customers/langganan_detail.html",
        langganan=langganan,
        pelanggan=pelanggan,
        paket=paket,
        kategori=kategori,
        bentuk=bentuk,
        harga=subscription_service.harga_efektif(langganan, paket),
        terminasi=terminasi,
        hop=hop,
        addon=subscription_service.daftar_addon(db_session, user, langganan_id),
        cicilan=cicilan,
        sisa_termin=subscription_service.sisa_termin(cicilan) if cicilan else 0,
        topologi=topology.rakit_svg(terminasi, hop),
        form_internet=form_internet,
        form_p2p=form_p2p,
        form_hop=form_hop,
        form_hop_ubah=form_hop_ubah,
        form_terminasi={
            sisi: TerminasiForm(
                obj=next((t for t in terminasi if t.side == sisi), None), prefix=f"t{sisi}"
            )
            for sisi in ("1", "2")
        },
        form_addon=AddonForm(),
        form_cicilan=CicilanForm(obj=cicilan),
        form_hapus=HapusForm(),
        boleh_nominal=_boleh_nominal(),
        label_status=LABEL_STATUS_LANGGANAN,
        # Riwayat gangguan layanan ini (M3). Inilah yang menjawab "layanan ini
        # sering bermasalah atau tidak" tanpa menyisir daftar tiket.
        riwayat_tiket=ticket_service.riwayat_layanan(db_session, user, langganan_id),
        label_status_tiket=LABEL_STATUS_TIKET,
        nada_status_tiket=NADA_STATUS_TIKET,
    )


@bp.post("/customer/layanan/<int:langganan_id>/internet")
@require_role(*TULIS_PELANGGAN)
def langganan_internet(langganan_id: int):
    form = InternetForm()
    _pilihan_vendor(form)
    if form.validate_on_submit():
        try:
            subscription_service.simpan_detail_internet(
                db_session, current_user(), langganan_id, _data_koordinat(form)
            )
        except (GalatDomain, _KoordinatTidakSah) as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/p2p")
@require_role(*TULIS_PELANGGAN)
def langganan_p2p(langganan_id: int):
    form = P2PForm()
    _pilihan_vendor(form)
    if form.validate_on_submit():
        try:
            subscription_service.simpan_detail_p2p(
                db_session, current_user(), langganan_id, _data_vendor(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/terminasi/<sisi>")
@require_role(*TULIS_PELANGGAN)
def terminasi_simpan(langganan_id: int, sisi: str):
    form = TerminasiForm(prefix=f"t{sisi}")
    if form.validate_on_submit():
        try:
            subscription_service.simpan_terminasi(
                db_session, current_user(), langganan_id, sisi, _data_koordinat(form)
            )
        except (GalatDomain, _KoordinatTidakSah) as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/hop/baru")
@require_role(*TULIS_PELANGGAN)
def hop_tambah(langganan_id: int):
    form = HopForm()
    _pilihan_vendor(form)
    if form.validate_on_submit():
        try:
            subscription_service.tambah_hop(
                db_session, current_user(), langganan_id, _data_vendor(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/hop/<int:hop_id>/ubah")
@require_role(*TULIS_PELANGGAN)
def hop_ubah(hop_id: int):
    langganan_id = subscription_service.langganan_id_hop(
        db_session, current_user(), hop_id
    )
    form = HopForm(prefix=f"hop{hop_id}")
    _pilihan_vendor(form)
    if form.validate_on_submit():
        try:
            subscription_service.ubah_hop(
                db_session, current_user(), hop_id, _data_vendor(form)
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Hop vendor/transit disimpan.", "sukses")
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/hop/<int:hop_id>/hapus")
@require_role(*TULIS_PELANGGAN)
def hop_hapus(hop_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return redirect(url_for("customers.pelanggan_daftar"))

    langganan_id = subscription_service.hapus_hop(db_session, current_user(), hop_id)
    db_session.commit()
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/addon/baru")
@require_role(*TULIS_NOMINAL)
def addon_tambah(langganan_id: int):
    form = AddonForm()
    if form.validate_on_submit():
        data = dict(form.data)
        data.pop("csrf_token", None)
        try:
            subscription_service.tambah_addon(
                db_session, current_user(), langganan_id, data
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/addon/<int:addon_id>/hapus")
@require_role(*TULIS_NOMINAL)
def addon_hapus(addon_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return redirect(url_for("customers.pelanggan_daftar"))

    langganan_id = subscription_service.hapus_addon(
        db_session, current_user(), addon_id
    )
    db_session.commit()
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/cicilan")
@require_role(*TULIS_NOMINAL)
def cicilan_simpan(langganan_id: int):
    form = CicilanForm()
    if form.validate_on_submit():
        data = dict(form.data)
        data.pop("csrf_token", None)
        try:
            subscription_service.simpan_cicilan(
                db_session, current_user(), langganan_id, data
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        _pesankan_galat(form)
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


@bp.post("/customer/layanan/<int:langganan_id>/cicilan/hapus")
@require_role(*TULIS_NOMINAL)
def cicilan_hapus(langganan_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman layanan.", "bahaya")
        return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))

    try:
        subscription_service.hapus_cicilan(db_session, current_user(), langganan_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
    return redirect(url_for("customers.langganan_detail", langganan_id=langganan_id))


def _pesankan_galat(form) -> None:
    """Menuang galat validasi formulir yang tidak punya halamannya sendiri.

    Formulir kecil di halaman detail dikirim lewat POST lalu dialihkan balik;
    tanpa ini, isian yang salah hilang tanpa pesan apa pun.
    """
    for field in form:
        for pesan in field.errors:
            flash(f"{field.label.text}: {pesan}", "bahaya")


def _data_koordinat(form) -> dict:
    """Seperti `_data_bersih`, tetapi untuk formulir yang hanya punya koordinat."""
    data = dict(form.data)
    data.pop("csrf_token", None)
    if "vendor_id" in data and not data.get("vendor_id"):
        data["vendor_id"] = None

    for field in ("lat", "lng", "odp_lat", "odp_lng"):
        if field not in data:
            continue
        nilai = (data.get(field) or "").strip()
        if not nilai:
            data[field] = None
            continue
        try:
            data[field] = Decimal(nilai)
        except InvalidOperation as galat:
            raise _KoordinatTidakSah(field) from galat

    return data
