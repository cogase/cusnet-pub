#!/bin/sh
set -e

# Portal pelanggan memakai basis data yang sama dan baru dinyalakan sesudah
# aplikasi utama; migrasinya cukup dijalankan sekali, oleh aplikasi utama.
if [ "${LEWATI_MIGRASI:-0}" != "1" ]; then
  echo "Menjalankan migrasi basis data..."
  alembic upgrade head
fi

echo "Menjalankan aplikasi..."
exec "$@"
