"""Titik masuk WSGI portal pelanggan: gunicorn wsgi_portal:app"""

from app import create_app

app = create_app(portal=True)
