"""peristiwa naik/turun link port untuk ketersediaan terukur

Revision ID: 0037
Revises: 0036
Create Date: 2026-10-22 10:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0037"
down_revision: Union[str, None] = "0036"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "port_link_event",
        sa.Column("id", sa.BigInteger(), primary_key=True),
        sa.Column("port_id", sa.Integer(), sa.ForeignKey("device_port.id", ondelete="CASCADE"), nullable=False),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("naik", sa.Boolean(), nullable=True),
    )
    op.create_index("ix_port_link_event_port_at", "port_link_event", ["port_id", "at"])
    # Port yang statusnya sudah diketahui sebelum tabel ini ada: dicatat
    # sebagai peristiwa awal, supaya pengukurannya mulai sekarang juga.
    op.execute(
        "INSERT INTO port_link_event (port_id, at, naik) "
        "SELECT id, now(), oper_status = 'naik' FROM device_port WHERE oper_status IS NOT NULL"
    )


def downgrade() -> None:
    op.drop_table("port_link_event")
