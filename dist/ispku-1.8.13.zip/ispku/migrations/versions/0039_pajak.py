"""pajak: PPh 23, bea meterai, nomor faktur pajak

Revision ID: 0039
Revises: 0038
Create Date: 2026-10-22 13:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0039"
down_revision: Union[str, None] = "0038"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    for kolom in ("pph23_withheld", "stamp_duty_billed", "tax_invoice_required"):
        op.add_column(
            "customer", sa.Column(kolom, sa.Boolean(), nullable=False, server_default=sa.text("false"))
        )
    op.add_column(
        "billing_setting",
        sa.Column("pph23_rate", sa.Numeric(5, 2), nullable=False, server_default=sa.text("2.00")),
    )
    op.add_column(
        "billing_setting",
        sa.Column("stamp_duty_amount", sa.Numeric(14, 2), nullable=False, server_default=sa.text("10000")),
    )
    op.add_column(
        "billing_setting",
        sa.Column("stamp_duty_threshold", sa.Numeric(14, 2), nullable=False, server_default=sa.text("5000000")),
    )
    op.add_column(
        "invoice", sa.Column("stamp_duty", sa.Numeric(14, 2), nullable=False, server_default=sa.text("0"))
    )
    op.add_column("invoice", sa.Column("tax_invoice_no", sa.String(40), nullable=True))
    op.drop_constraint("ck_payment_metode", "payment", type_="check")
    op.create_check_constraint(
        "ck_payment_metode", "payment", "method IN ('transfer', 'tunai', 'pph23')"
    )


def downgrade() -> None:
    op.drop_constraint("ck_payment_metode", "payment", type_="check")
    op.create_check_constraint("ck_payment_metode", "payment", "method IN ('transfer', 'tunai')")
    op.drop_column("invoice", "tax_invoice_no")
    op.drop_column("invoice", "stamp_duty")
    for kolom in ("stamp_duty_threshold", "stamp_duty_amount", "pph23_rate"):
        op.drop_column("billing_setting", kolom)
    for kolom in ("tax_invoice_required", "stamp_duty_billed", "pph23_withheld"):
        op.drop_column("customer", kolom)
