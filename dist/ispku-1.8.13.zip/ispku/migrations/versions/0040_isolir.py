"""isolir dan buka isolir (prototipe M8)

Revision ID: 0040
Revises: 0039
Create Date: 2026-10-22 15:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0040"
down_revision: Union[str, None] = "0039"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("billing_setting", sa.Column("isolir_mode", sa.String(10), nullable=False, server_default=sa.text("'kering'")))
    op.add_column("billing_setting", sa.Column("isolir_device_id", sa.Integer(), nullable=True))
    op.create_foreign_key("fk_billing_setting_isolir_device", "billing_setting", "device",
                          ["isolir_device_id"], ["id"], ondelete="SET NULL")
    op.add_column("billing_setting", sa.Column("isolir_list", sa.String(60), nullable=False, server_default=sa.text("'ISOLIR'")))
    op.add_column("billing_setting", sa.Column("isolir_hari", sa.Integer(), nullable=False, server_default=sa.text("7")))
    op.add_column("billing_setting", sa.Column("isolir_otomatis", sa.Boolean(), nullable=False, server_default=sa.text("false")))
    op.add_column("billing_setting", sa.Column("isolir_kredit_limit", sa.Boolean(), nullable=False, server_default=sa.text("false")))
    op.add_column("customer", sa.Column("isolir_exempt", sa.Boolean(), nullable=False, server_default=sa.text("false")))
    op.add_column("subscription", sa.Column("isolated_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("device", sa.Column("api_user", sa.String(60), nullable=True))
    op.add_column("device", sa.Column("api_password", sa.String(120), nullable=True))
    op.add_column("device", sa.Column("api_port", sa.Integer(), nullable=True))
    op.add_column("device", sa.Column("api_tls", sa.Boolean(), nullable=False, server_default=sa.text("false")))
    op.create_table(
        "isolir_event",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("subscription_id", sa.Integer(), sa.ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False),
        sa.Column("aksi", sa.String(10), nullable=False),
        sa.Column("sebab", sa.String(20), nullable=False),
        sa.Column("mode", sa.String(10), nullable=False),
        sa.Column("berhasil", sa.Boolean(), nullable=False),
        sa.Column("pesan", sa.Text(), nullable=True),
        sa.Column("actor_user_id", sa.Integer(), sa.ForeignKey("app_user.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("aksi IN ('isolir', 'buka')", name="ck_isolir_event_aksi"),
        sa.CheckConstraint("sebab IN ('manual', 'tunggakan', 'kredit_limit', 'lunas')", name="ck_isolir_event_sebab"),
        sa.CheckConstraint("mode IN ('kering', 'nyata')", name="ck_isolir_event_mode"),
    )
    op.create_index("ix_isolir_event_subscription", "isolir_event", ["subscription_id", "id"])


def downgrade() -> None:
    op.drop_table("isolir_event")
    for kolom in ("api_tls", "api_port", "api_password", "api_user"):
        op.drop_column("device", kolom)
    op.drop_column("subscription", "isolated_at")
    op.drop_column("customer", "isolir_exempt")
    op.drop_constraint("fk_billing_setting_isolir_device", "billing_setting", type_="foreignkey")
    for kolom in ("isolir_kredit_limit", "isolir_otomatis", "isolir_hari", "isolir_list",
                  "isolir_device_id", "isolir_mode"):
        op.drop_column("billing_setting", kolom)
