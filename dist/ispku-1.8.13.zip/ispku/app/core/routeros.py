"""Klien API RouterOS (MikroTik) yang kecil: login dan perintah kalimat.

Protokolnya sederhana — kata berawalan panjang, kalimat diakhiri kata kosong
— jadi ditulis sendiri di atas soket alih-alih menambah pustaka ke image.
Mendukung login gaya baru (RouterOS 6.43+, nama dan sandi dikirim langsung,
hanya aman di atas TLS atau jaringan tepercaya) dan gaya lama (tantangan MD5).
"""

import hashlib
import socket
import ssl


class GalatRouterOS(Exception):
    """Router menolak, tidak menjawab, atau jawabannya tidak bisa dibaca."""


def _panjang(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    if n < 0x4000:
        return (n | 0x8000).to_bytes(2, "big")
    if n < 0x200000:
        return (n | 0xC00000).to_bytes(3, "big")
    if n < 0x10000000:
        return (n | 0xE0000000).to_bytes(4, "big")
    return b"\xf0" + n.to_bytes(4, "big")


def sandi_kata(kata: str) -> bytes:
    isi = kata.encode()
    return _panjang(len(isi)) + isi


def sandi_kalimat(kata: list[str]) -> bytes:
    return b"".join(sandi_kata(k) for k in kata) + b"\x00"


class Klien:
    def __init__(self, host: str, user: str, sandi: str, port: int = 8728,
                 tls: bool = False, tenggat: float = 5.0):
        self.host, self.user, self.sandi = host, user, sandi
        self.port, self.tls, self.tenggat = port, tls, tenggat
        self._soket = None

    # ── soket ──────────────────────────────────────────────────────────────
    def __enter__(self):
        try:
            mentah = socket.create_connection((self.host, self.port), timeout=self.tenggat)
        except OSError as galat:
            raise GalatRouterOS(f"Tidak bisa menghubungi router {self.host}:{self.port}: {galat}.") from galat
        if self.tls:
            konteks = ssl.create_default_context()
            # Router biasanya memakai sertifikat buatan sendiri.
            konteks.check_hostname = False
            konteks.verify_mode = ssl.CERT_NONE
            mentah = konteks.wrap_socket(mentah, server_hostname=self.host)
        self._soket = mentah
        self._login()
        return self

    def __exit__(self, *_):
        if self._soket is not None:
            self._soket.close()

    def _baca(self, n: int) -> bytes:
        data = b""
        while len(data) < n:
            try:
                potong = self._soket.recv(n - len(data))
            except OSError as galat:
                raise GalatRouterOS(f"Koneksi ke router terputus: {galat}.") from galat
            if not potong:
                raise GalatRouterOS("Router menutup koneksi.")
            data += potong
        return data

    def _baca_kata(self) -> str:
        b = self._baca(1)[0]
        if b < 0x80:
            n = b
        elif b < 0xC0:
            n = ((b & 0x3F) << 8) | self._baca(1)[0]
        elif b < 0xE0:
            n = ((b & 0x1F) << 16) | int.from_bytes(self._baca(2), "big")
        elif b < 0xF0:
            n = ((b & 0x0F) << 24) | int.from_bytes(self._baca(3), "big")
        else:
            n = int.from_bytes(self._baca(4), "big")
        return self._baca(n).decode(errors="replace") if n else ""

    def _baca_kalimat(self) -> list[str]:
        kalimat = []
        while True:
            kata = self._baca_kata()
            if kata == "":
                return kalimat
            kalimat.append(kata)

    # ── perintah ───────────────────────────────────────────────────────────
    def perintah(self, kata: list[str]) -> list[dict]:
        """Mengirim satu perintah; mengembalikan isi baris `!re` sebagai dict."""
        try:
            self._soket.sendall(sandi_kalimat(kata))
        except OSError as galat:
            raise GalatRouterOS(f"Gagal mengirim perintah ke router: {galat}.") from galat
        hasil = []
        while True:
            kalimat = self._baca_kalimat()
            if not kalimat:
                continue
            jenis, atribut = kalimat[0], {}
            for kata_ in kalimat[1:]:
                if kata_.startswith("="):
                    kunci, _, nilai = kata_[1:].partition("=")
                    atribut[kunci] = nilai
            if jenis == "!re":
                hasil.append(atribut)
            elif jenis == "!done":
                if "ret" in atribut:
                    hasil.append({"ret": atribut["ret"]})
                return hasil
            elif jenis in ("!trap", "!fatal"):
                raise GalatRouterOS(f"Router menolak: {atribut.get('message', jenis)}.")

    def _login(self) -> None:
        jawaban = self.perintah(["/login", f"=name={self.user}", f"=password={self.sandi}"])
        tantangan = next((j["ret"] for j in jawaban if "ret" in j), None)
        if tantangan:
            # RouterOS sebelum 6.43: jawab tantangan MD5.
            md5 = hashlib.md5(b"\x00" + self.sandi.encode() + bytes.fromhex(tantangan)).hexdigest()
            self.perintah(["/login", f"=name={self.user}", f"=response=00{md5}"])
