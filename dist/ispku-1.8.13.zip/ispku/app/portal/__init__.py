"""Portal pelanggan (M9) — dipasang oleh `create_app(portal=True)`.

Jalan sebagai proses sendiri (`gunicorn wsgi_portal:app`), dengan cookie
sesi bernama lain, sehingga staf dan customer tidak pernah berbagi sesi dan
rute staf tidak pernah terbuka di alamat portal.
"""

from functools import wraps

from flask import Blueprint, abort, flash, g, redirect, render_template, request, session, url_for

from app.core.db import db_session
from app.core.errors import GalatDomain, TidakDitemukan

KUNCI_SESI = "portal_id"
bp = Blueprint("portal", __name__)
# Templat cetak billing memanggil url_for('settings.berkas_kop'). Di portal
# berkasnya dibaca langsung oleh pembuat PDF, jadi rute ini cukup ada
# namanya dan tidak menyajikan apa pun.
kop = Blueprint("settings", __name__)


@kop.get("/kop/<jenis>")
def berkas_kop(jenis):
    abort(404)


def _akun():
    from app.portal.models import PortalAccount

    if "akun" not in g:
        nomor = session.get(KUNCI_SESI)
        akun = db_session.get(PortalAccount, nomor) if nomor else None
        g.akun = akun if akun is not None and akun.is_active else None
    return g.akun


def perlu_masuk(view):
    @wraps(view)
    def bungkus(*args, **kwargs):
        akun = _akun()
        if akun is None:
            return redirect(url_for("portal.masuk", next=request.path))
        if akun.must_change_password and request.endpoint not in ("portal.akun", "portal.keluar"):
            flash("Ganti sandi sementara Anda lebih dulu.", "peringatan")
            return redirect(url_for("portal.akun"))
        return view(*args, **kwargs)

    return bungkus


def pasang(app) -> None:
    from app.core.keamanan import pasang_header
    from app.portal import views  # noqa: F401  mendaftarkan rute

    app.config["SESSION_COOKIE_NAME"] = "cusnet_portal"
    app.register_blueprint(bp)
    app.register_blueprint(kop)
    app.after_request(pasang_header)

    @app.context_processor
    def _konteks_portal():
        from flask_wtf.csrf import generate_csrf

        from app.modules.settings import branding

        try:
            merek = branding.konteks(branding.ambil_merek(db_session))
        except Exception:  # noqa: BLE001 — basis data belum siap
            merek = {"nama_penuh": "Portal Pelanggan", "warna": "#1f6feb"}
        return {"akun_portal": _akun(), "merek": merek, "token_csrf": generate_csrf}

    @app.errorhandler(TidakDitemukan)
    @app.errorhandler(404)
    def _tidak_ada(_galat):
        return render_template("portal/pesan.html", judul="Tidak ditemukan",
                               pesan="Halaman atau data yang Anda cari tidak ada."), 404

    @app.errorhandler(413)
    def _terlalu_besar(_galat):
        return render_template("portal/pesan.html", judul="Berkas terlalu besar",
                               pesan="Ukuran berkas paling besar 5 MB."), 413

    @app.errorhandler(500)
    def _galat(_galat):
        db_session.rollback()
        return render_template("portal/pesan.html", judul="Terjadi kesalahan",
                               pesan="Coba lagi beberapa saat lagi."), 500
