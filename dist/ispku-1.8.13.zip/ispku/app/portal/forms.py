from flask_wtf.file import FileAllowed, FileField
from wtforms import DateField, PasswordField, StringField, TextAreaField
from wtforms.validators import DataRequired, Length, Optional

from app.core.forms import FormDasar
from app.modules.billing.forms import DesimalIndonesia
from app.modules.customers.forms import PilihanIndonesia


class MasukForm(FormDasar):
    login = StringField("Email", validators=[DataRequired(message="Email wajib diisi."), Length(max=160)])
    sandi = PasswordField("Sandi", validators=[DataRequired(message="Sandi wajib diisi.")])


class SandiForm(FormDasar):
    lama = PasswordField("Sandi sekarang", validators=[DataRequired()])
    baru = PasswordField("Sandi baru", validators=[DataRequired(), Length(min=8, message="Paling sedikit 8 karakter.")])


class KonfirmasiForm(FormDasar):
    amount = DesimalIndonesia("Jumlah yang ditransfer", places=2, use_locale=False,
                              validators=[DataRequired(message="Jumlah wajib diisi.")])
    paid_at = DateField("Tanggal transfer", validators=[DataRequired(message="Tanggal wajib diisi.")])
    sender_name = StringField("Nama pengirim / rekening", validators=[Optional(), Length(max=120)])
    note = TextAreaField("Catatan", validators=[Optional(), Length(max=1000)])
    bukti = FileField("Bukti transfer", validators=[
        DataRequired(message="Lampirkan bukti transfer."),
        FileAllowed(["jpg", "jpeg", "png", "pdf"], message="Hanya JPG, PNG, dan PDF."),
    ])


class TiketForm(FormDasar):
    category_id = PilihanIndonesia("Jenis", coerce=int)
    subscription_id = PilihanIndonesia("Layanan", coerce=int, validators=[Optional()])
    title = StringField("Judul", validators=[DataRequired(message="Judul wajib diisi."), Length(max=200)])
    description = TextAreaField("Uraian", validators=[DataRequired(message="Uraian wajib diisi."), Length(max=5000)])


class BalasForm(FormDasar):
    body = TextAreaField("Balasan", validators=[DataRequired(message="Pesan tidak boleh kosong."), Length(max=5000)])
