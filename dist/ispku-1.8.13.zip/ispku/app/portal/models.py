"""Portal pelanggan (M9): kredensial TERPISAH dari akun staf.

Akun portal tidak pernah menumpang tabel `app_user`. Satu customer satu
akun; yang bisa dilihatnya selalu disaring `customer_id` akun itu.
"""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import Money, enum_check

STATUS_KONFIRMASI: tuple[str, ...] = ("menunggu", "diterima", "ditolak")


class PortalAccount(Base):
    __tablename__ = "portal_account"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customer.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    login: Mapped[str] = mapped_column(String(160), nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class PaymentConfirmation(Base):
    """Konfirmasi pembayaran dari portal, menunggu diperiksa staf billing.

    Bukan pembayaran: baru menjadi `payment` setelah staf menerimanya, karena
    bukti transfer bisa salah, ganda, atau palsu.
    """

    __tablename__ = "payment_confirmation"
    __table_args__ = (
        Index("ix_payment_confirmation_status", "status", "id"),
        enum_check("ck_payment_confirmation_status", "status", STATUS_KONFIRMASI),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("invoice.id", ondelete="CASCADE"), nullable=False)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customer.id", ondelete="CASCADE"), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Money, nullable=False)
    paid_at: Mapped[datetime] = mapped_column(Date, nullable=False)
    sender_name: Mapped[str | None] = mapped_column(String(120))
    note: Mapped[str | None] = mapped_column(Text)
    proof_path: Mapped[str] = mapped_column(String(500), nullable=False)
    proof_mime: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="menunggu")
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str | None] = mapped_column(Text)
    payment_id: Mapped[int | None] = mapped_column(ForeignKey("payment.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
