"""Aturan portal pelanggan. Setiap fungsi menerima `customer_id` akun yang
masuk dan TIDAK PERNAH mengembalikan data customer lain."""

import secrets
import string
from datetime import datetime, timezone

from sqlalchemy import func, select

from app.core import audit, files, keamanan, rbac
from app.core.auth import hash_password, verify_password
from app.core.errors import GalatDomain, TidakDitemukan
from app.modules.billing.models import Invoice, Payment
from app.modules.customers.models import Customer
from app.modules.customers.subscriptions import Subscription
from app.modules.services.models import ServicePlan
from app.modules.tickets.models import STATUS_TUTUP, Ticket, TicketCategory, TicketComment
from app.portal.models import PaymentConfirmation, PortalAccount

STATUS_TAGIHAN = ("issued", "partial", "overdue", "paid")
_HASH_SAMARAN = hash_password("bukan-sandi-siapa-pun")


# ── akun ────────────────────────────────────────────────────────────────────

def masuk(sesi, login: str, sandi: str, ip: str | None) -> PortalAccount | None:
    login = (login or "").strip().lower()
    if keamanan.terlalu_sering(sesi, ip):
        raise GalatDomain("login", "Terlalu banyak percobaan gagal. Coba lagi 15 menit lagi.")
    akun = sesi.execute(select(PortalAccount).where(PortalAccount.login == login)).scalar_one_or_none()
    if akun is None or not akun.is_active:
        verify_password(sandi or "", _HASH_SAMARAN)
        keamanan.catat_kegagalan(sesi, ip, f"portal:{login}")
        return None
    if not verify_password(sandi or "", akun.password_hash):
        keamanan.catat_kegagalan(sesi, ip, f"portal:{login}")
        return None
    keamanan.bersihkan_percobaan(sesi, ip)
    akun.last_login_at = datetime.now(timezone.utc)
    sesi.flush()
    return akun


def ganti_sandi(sesi, akun: PortalAccount, lama: str, baru: str) -> None:
    if not verify_password(lama or "", akun.password_hash):
        raise GalatDomain("lama", "Sandi lama salah.")
    if len(baru or "") < 8:
        raise GalatDomain("baru", "Sandi baru paling sedikit 8 karakter.")
    akun.password_hash = hash_password(baru)
    akun.must_change_password = False
    sesi.flush()


def sandi_acak() -> str:
    huruf = string.ascii_letters + string.digits
    return "".join(secrets.choice(huruf) for _ in range(12))


def akun_customer(sesi, customer_id: int) -> PortalAccount | None:
    return sesi.execute(
        select(PortalAccount).where(PortalAccount.customer_id == customer_id)
    ).scalar_one_or_none()


def buat_atau_reset(sesi, aktor, customer_id: int, login: str) -> tuple[PortalAccount, str]:
    """Membuat akun (atau mengganti sandinya) dan mengembalikan sandi sementara.

    Sandi sementara hanya ditampilkan sekali ke staf; customer wajib
    menggantinya saat pertama masuk.
    """
    login = (login or "").strip().lower()
    if "@" not in login or len(login) > 160:
        raise GalatDomain("login", "Login portal memakai alamat email yang sah.")
    bentrok = sesi.execute(
        select(PortalAccount).where(PortalAccount.login == login, PortalAccount.customer_id != customer_id)
    ).scalar_one_or_none()
    if bentrok is not None:
        raise GalatDomain("login", f"Email {login} sudah dipakai akun portal customer lain.")
    sandi = sandi_acak()
    akun = akun_customer(sesi, customer_id)
    if akun is None:
        akun = PortalAccount(customer_id=customer_id, login=login, password_hash=hash_password(sandi),
                             is_active=True, must_change_password=True)
        sesi.add(akun)
        aksi = "create"
    else:
        akun.login = login
        akun.password_hash = hash_password(sandi)
        akun.is_active = True
        akun.must_change_password = True
        aksi = "update"
    sesi.flush()
    audit.record(sesi, aksi, "portal_account", akun.id,
                 after={"customer_id": customer_id, "login": login, "sandi_direset": True}, aktor=aktor)
    return akun, sandi


def ubah_aktif(sesi, aktor, customer_id: int, aktif: bool) -> PortalAccount:
    akun = akun_customer(sesi, customer_id)
    if akun is None:
        raise TidakDitemukan("Customer ini belum punya akun portal.")
    akun.is_active = aktif
    sesi.flush()
    audit.record(sesi, "update", "portal_account", akun.id, after={"is_active": aktif}, aktor=aktor)
    return akun


# ── data customer ───────────────────────────────────────────────────────────

def pelanggan(sesi, customer_id: int) -> Customer:
    return sesi.get(Customer, customer_id)


def layanan(sesi, customer_id: int) -> list:
    return list(
        sesi.execute(
            select(Subscription, ServicePlan)
            .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
            .where(Subscription.customer_id == customer_id, Subscription.status != "terminasi")
            .order_by(Subscription.service_no)
        ).all()
    )


def _dibayar():
    return (
        select(Payment.invoice_id, func.coalesce(func.sum(Payment.amount), 0).label("dibayar"))
        .group_by(Payment.invoice_id).subquery()
    )


def tagihan(sesi, customer_id: int) -> list[dict]:
    dibayar = _dibayar()
    menunggu = set(
        sesi.execute(
            select(PaymentConfirmation.invoice_id).where(
                PaymentConfirmation.customer_id == customer_id, PaymentConfirmation.status == "menunggu"
            )
        ).scalars()
    )
    return [
        {"invoice": invoice, "sisa": invoice.total - sudah, "konfirmasi_menunggu": invoice.id in menunggu}
        for invoice, sudah in sesi.execute(
            select(Invoice, func.coalesce(dibayar.c.dibayar, 0))
            .outerjoin(dibayar, dibayar.c.invoice_id == Invoice.id)
            .where(Invoice.customer_id == customer_id, Invoice.status.in_(STATUS_TAGIHAN),
                   Invoice.number.is_not(None))
            .order_by(Invoice.period_start.desc(), Invoice.id.desc())
        ).all()
    ]


def invoice_milik(sesi, customer_id: int, invoice_id: int) -> Invoice:
    invoice = sesi.get(Invoice, invoice_id)
    if invoice is None or invoice.customer_id != customer_id or invoice.status not in STATUS_TAGIHAN:
        raise TidakDitemukan("Tagihan tidak ditemukan.")
    return invoice


def pembayaran_milik(sesi, customer_id: int, payment_id: int) -> Payment:
    bayar = sesi.get(Payment, payment_id)
    if bayar is None:
        raise TidakDitemukan("Pembayaran tidak ditemukan.")
    invoice_milik(sesi, customer_id, bayar.invoice_id)
    return bayar


def konfirmasi_bayar(sesi, customer_id: int, invoice_id: int, data: dict, berkas, nama_berkas, upload_dir):
    from app.core.money import to_money
    from app.modules.billing import payments

    invoice = invoice_milik(sesi, customer_id, invoice_id)
    jumlah = to_money(data.get("amount") or 0)
    if jumlah <= 0:
        raise GalatDomain("amount", "Jumlah harus lebih dari nol.")
    if jumlah > payments.sisa_tagihan(sesi, invoice):
        raise GalatDomain("amount", "Jumlah melebihi sisa tagihan.")
    if berkas is None:
        raise GalatDomain("bukti", "Lampirkan bukti transfer (JPG, PNG, atau PDF).")
    try:
        tersimpan = files.simpan(berkas, nama_berkas or "bukti", upload_dir)
    except files.FileError as galat:
        raise GalatDomain("bukti", str(galat)) from galat
    konfirmasi = PaymentConfirmation(
        invoice_id=invoice.id, customer_id=customer_id, amount=jumlah,
        paid_at=data.get("paid_at"), sender_name=(data.get("sender_name") or "").strip()[:120] or None,
        note=(data.get("note") or "").strip()[:1000] or None,
        proof_path=tersimpan.path, proof_mime=tersimpan.mime, status="menunggu",
    )
    sesi.add(konfirmasi)
    sesi.flush()
    return konfirmasi


# ── tiket ───────────────────────────────────────────────────────────────────

def tiket(sesi, customer_id: int) -> list[Ticket]:
    return list(
        sesi.execute(
            select(Ticket).where(Ticket.customer_id == customer_id).order_by(Ticket.id.desc()).limit(50)
        ).scalars()
    )


def tiket_milik(sesi, customer_id: int, tiket_id: int) -> Ticket:
    satu = sesi.get(Ticket, tiket_id)
    if satu is None or satu.customer_id != customer_id:
        raise TidakDitemukan("Tiket tidak ditemukan.")
    return satu


def komentar_publik(sesi, tiket_id: int) -> list[TicketComment]:
    """Hanya yang boleh dibaca customer: bukan catatan internal staf."""
    return list(
        sesi.execute(
            select(TicketComment)
            .where(TicketComment.ticket_id == tiket_id, TicketComment.is_internal.is_(False))
            .order_by(TicketComment.id)
        ).scalars()
    )


def kategori_tiket(sesi) -> list[TicketCategory]:
    return list(
        sesi.execute(
            select(TicketCategory).where(TicketCategory.is_active.is_(True)).order_by(TicketCategory.name)
        ).scalars()
    )


def buka_tiket(sesi, customer_id: int, data: dict) -> Ticket:
    from app.modules.tickets import service as ticket_service

    pemilik = pelanggan(sesi, customer_id)
    layanan_id = data.get("subscription_id") or None
    if layanan_id:
        langganan = sesi.get(Subscription, int(layanan_id))
        if langganan is None or langganan.customer_id != customer_id:
            raise GalatDomain("subscription_id", "Layanan tidak dikenal.")
    kategori = sesi.get(TicketCategory, int(data.get("category_id") or 0))
    if kategori is None or not kategori.is_active:
        raise GalatDomain("category_id", "Pilih jenis tiket.")
    judul = (data.get("title") or "").strip()
    uraian = (data.get("description") or "").strip()
    if not judul or not uraian:
        raise GalatDomain("title", "Judul dan uraian wajib diisi.")
    return ticket_service.buat(sesi, rbac.SISTEM, {
        "branch_id": pemilik.branch_id, "customer_id": customer_id,
        "subscription_id": int(layanan_id) if layanan_id else None,
        "category_id": kategori.id, "title": judul[:200], "description": uraian[:5000],
    })


def balas_tiket(sesi, customer_id: int, tiket_id: int, isi: str) -> TicketComment:
    from app.modules.tickets import service as ticket_service

    satu = tiket_milik(sesi, customer_id, tiket_id)
    if satu.status in STATUS_TUTUP:
        raise GalatDomain("body", "Tiket ini sudah ditutup. Buka tiket baru bila masih ada kendala.")
    isi = (isi or "").strip()
    if not isi:
        raise GalatDomain("body", "Pesan tidak boleh kosong.")
    return ticket_service.tambah_komentar(
        sesi, rbac.SISTEM, satu.id, isi[:5000], is_internal=False, dari_pelanggan=True
    )


# ── sisi staf: konfirmasi pembayaran ────────────────────────────────────────

def konfirmasi_menunggu(sesi, user) -> list:
    query = (
        select(PaymentConfirmation, Invoice, Customer)
        .join(Invoice, PaymentConfirmation.invoice_id == Invoice.id)
        .join(Customer, PaymentConfirmation.customer_id == Customer.id)
        .where(PaymentConfirmation.status == "menunggu")
        .order_by(PaymentConfirmation.id)
    )
    return list(sesi.execute(rbac.scoped(query, user, Invoice)).all())


def ambil_konfirmasi(sesi, user, konfirmasi_id: int) -> PaymentConfirmation:
    konfirmasi = sesi.get(PaymentConfirmation, konfirmasi_id)
    if konfirmasi is None:
        raise TidakDitemukan("Konfirmasi tidak ditemukan.")
    invoice = sesi.get(Invoice, konfirmasi.invoice_id)
    rbac.assert_branch_access(user, invoice.branch_id)
    return konfirmasi


def terima_konfirmasi(sesi, aktor, konfirmasi_id: int, bank_account_id=None) -> Payment:
    from app.modules.billing import payments

    konfirmasi = ambil_konfirmasi(sesi, aktor, konfirmasi_id)
    if konfirmasi.status != "menunggu":
        raise GalatDomain("status", "Konfirmasi ini sudah diperiksa.")
    bayar = payments.catat(sesi, aktor, konfirmasi.invoice_id, {
        "amount": konfirmasi.amount, "paid_at": konfirmasi.paid_at, "method": "transfer",
        "bank_account_id": bank_account_id, "reference": (konfirmasi.sender_name or "")[:120] or None,
        "note": "Dari konfirmasi portal pelanggan.",
    })
    bayar.proof_path = konfirmasi.proof_path
    konfirmasi.status = "diterima"
    konfirmasi.payment_id = bayar.id
    konfirmasi.reviewed_by_user_id = getattr(aktor, "id", None)
    konfirmasi.reviewed_at = datetime.now(timezone.utc)
    sesi.flush()
    return bayar


def tolak_konfirmasi(sesi, aktor, konfirmasi_id: int, alasan: str) -> PaymentConfirmation:
    konfirmasi = ambil_konfirmasi(sesi, aktor, konfirmasi_id)
    if konfirmasi.status != "menunggu":
        raise GalatDomain("status", "Konfirmasi ini sudah diperiksa.")
    alasan = (alasan or "").strip()
    if not alasan:
        raise GalatDomain("alasan", "Tulis alasan penolakan; customer akan melihatnya.")
    konfirmasi.status = "ditolak"
    konfirmasi.review_note = alasan[:1000]
    konfirmasi.reviewed_by_user_id = getattr(aktor, "id", None)
    konfirmasi.reviewed_at = datetime.now(timezone.utc)
    sesi.flush()
    audit.record(sesi, "update", "payment_confirmation", konfirmasi.id,
                 after={"status": "ditolak", "alasan": konfirmasi.review_note}, aktor=aktor)
    return konfirmasi


def riwayat_konfirmasi(sesi, customer_id: int) -> list[PaymentConfirmation]:
    return list(
        sesi.execute(
            select(PaymentConfirmation).where(PaymentConfirmation.customer_id == customer_id)
            .order_by(PaymentConfirmation.id.desc()).limit(20)
        ).scalars()
    )
