"""Pajak invoice (M7): bea meterai, PPh 23, nomor faktur pajak.

Keputusan yang dipegang (yosi, 22 Okt 2026):

- PPh 23 TIDAK mengurangi invoice. Customer badan (dedicated) memotong
  PPh 23 saat membayar; potongan itu dicatat sebagai pembayaran bermetode
  `pph23` dengan nomor bukti potong, sehingga invoice tetap lunas dan laporan
  tunggakan tidak penuh selisih 2%.
- Bea meterai dan nomor faktur pajak OPSIONAL per customer. Customer FTTH
  biasanya tidak memakai satu pun karena harganya sudah termasuk semuanya.
- Nilai bea meterai Rp 10.000, dikenakan bila total tagihan mencapai ambang
  (bawaan Rp 5.000.000, mengikuti UU 10/2020). Keduanya bisa diubah di
  Pengaturan Billing.
"""

from decimal import Decimal

from app.core.money import to_money

NOL = Decimal("0.00")


def bea_meterai(pelanggan, setelan, total_sebelum: Decimal) -> Decimal:
    """Bea meterai untuk satu invoice, atau nol."""
    if not getattr(pelanggan, "stamp_duty_billed", False):
        return NOL
    if to_money(total_sebelum) < to_money(setelan.stamp_duty_threshold):
        return NOL
    return to_money(setelan.stamp_duty_amount)


def dasar_pph23(invoice) -> Decimal:
    """Dasar pengenaan PPh 23: nilai jasa sebelum PPN dan bea meterai."""
    return to_money(invoice.total - invoice.ppn_amount - (invoice.stamp_duty or NOL))


def saran_pph23(invoice, setelan) -> Decimal:
    return to_money(dasar_pph23(invoice) * Decimal(setelan.pph23_rate) / Decimal(100))
