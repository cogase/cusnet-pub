"""Isolir dan buka isolir (M8).

Isolir di sini berarti: alamat IP layanan dimasukkan ke address-list router
(bawaannya `ISOLIR`), dan aturan firewall di router — yang dipasang operator
sendiri — memutus atau mengalihkan alamat di daftar itu. Aplikasi tidak
pernah mengubah aturan firewall; ia hanya menambah dan menghapus alamat.
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import enum_check

AKSI_ISOLIR: tuple[str, ...] = ("isolir", "buka")
SEBAB_ISOLIR: tuple[str, ...] = ("manual", "tunggakan", "kredit_limit", "lunas")
MODE_ISOLIR: tuple[str, ...] = ("kering", "nyata")


class IsolirEvent(Base):
    __tablename__ = "isolir_event"
    __table_args__ = (
        Index("ix_isolir_event_subscription", "subscription_id", "id"),
        enum_check("ck_isolir_event_aksi", "aksi", AKSI_ISOLIR),
        enum_check("ck_isolir_event_sebab", "sebab", SEBAB_ISOLIR),
        enum_check("ck_isolir_event_mode", "mode", MODE_ISOLIR),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False
    )
    aksi: Mapped[str] = mapped_column(String(10), nullable=False)
    sebab: Mapped[str] = mapped_column(String(20), nullable=False)
    mode: Mapped[str] = mapped_column(String(10), nullable=False)
    berhasil: Mapped[bool] = mapped_column(Boolean, nullable=False)
    pesan: Mapped[str | None] = mapped_column(Text)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
