"""Adaptor router untuk isolir. Antarmukanya sengaja sempit: isolir, buka, uji.

Tiap ISP memakai perangkat berbeda (MikroTik API, RADIUS CoA, ...). Yang perlu
ditambahkan untuk perangkat lain hanya kelas baru dengan tiga metode ini.
"""

import ipaddress

from app.core import routeros
from app.core.errors import GalatDomain


class GalatIsolir(GalatDomain):
    """Isolir/buka tidak bisa dijalankan."""


def alamat_layanan(ip: str | None) -> str:
    """Alamat IP layanan dalam bentuk yang diterima address-list router."""
    teks = (ip or "").strip()
    if not teks:
        raise GalatIsolir("ip_address", "Layanan ini belum punya IP, jadi tidak bisa diisolir lewat address-list.")
    try:
        jaringan = ipaddress.ip_network(teks, strict=False)
    except ValueError as galat:
        raise GalatIsolir("ip_address", f"IP layanan '{teks}' tidak sah.") from galat
    return str(jaringan.network_address) if jaringan.prefixlen == jaringan.max_prefixlen else str(jaringan)


class Kering:
    """Mode kering: tidak ada perintah ke router, hanya dicatat."""

    nama = "kering"

    def isolir(self, alamat: str, komentar: str) -> str:
        return f"Mode kering: {alamat} AKAN dimasukkan ke address-list (tidak ada perintah dikirim)."

    def buka(self, alamat: str) -> str:
        return f"Mode kering: {alamat} AKAN dikeluarkan dari address-list (tidak ada perintah dikirim)."

    def uji(self) -> str:
        return "Mode kering: tidak ada koneksi yang diuji."


class MikrotikApi:
    """Menambah/menghapus alamat di `/ip/firewall/address-list` lewat API RouterOS."""

    nama = "nyata"

    def __init__(self, perangkat, daftar: str, pabrik=routeros.Klien):
        if not perangkat.mgmt_address or not perangkat.api_user or not perangkat.api_password:
            raise GalatIsolir(
                "isolir_device_id",
                f"Router {perangkat.name} belum punya alamat manajemen, user API, dan sandi API.",
            )
        from app.modules.inventory import pantau

        self.host = pantau.host_dari(perangkat.mgmt_address)
        self.perangkat = perangkat
        self.daftar = daftar
        self.pabrik = pabrik

    def _klien(self):
        p = self.perangkat
        return self.pabrik(self.host, p.api_user, p.api_password,
                           port=p.api_port or (8729 if p.api_tls else 8728), tls=p.api_tls)

    def _cari(self, klien, alamat: str) -> list[str]:
        baris = klien.perintah([
            "/ip/firewall/address-list/print", f"?list={self.daftar}", f"?address={alamat}",
        ])
        return [b[".id"] for b in baris if ".id" in b]

    def isolir(self, alamat: str, komentar: str) -> str:
        try:
            with self._klien() as klien:
                if self._cari(klien, alamat):
                    return f"{alamat} sudah ada di address-list {self.daftar}."
                klien.perintah([
                    "/ip/firewall/address-list/add", f"=list={self.daftar}",
                    f"=address={alamat}", f"=comment={komentar[:120]}",
                ])
        except routeros.GalatRouterOS as galat:
            raise GalatIsolir("isolir_device_id", str(galat)) from galat
        return f"{alamat} dimasukkan ke address-list {self.daftar} di {self.perangkat.name}."

    def buka(self, alamat: str) -> str:
        try:
            with self._klien() as klien:
                ids = self._cari(klien, alamat)
                for nomor in ids:
                    klien.perintah(["/ip/firewall/address-list/remove", f"=.id={nomor}"])
        except routeros.GalatRouterOS as galat:
            raise GalatIsolir("isolir_device_id", str(galat)) from galat
        if not ids:
            return f"{alamat} memang tidak ada di address-list {self.daftar}."
        return f"{alamat} dikeluarkan dari address-list {self.daftar} di {self.perangkat.name}."

    def uji(self) -> str:
        try:
            with self._klien() as klien:
                identitas = klien.perintah(["/system/identity/print"])
        except routeros.GalatRouterOS as galat:
            raise GalatIsolir("isolir_device_id", str(galat)) from galat
        nama = identitas[0].get("name", "?") if identitas else "?"
        return f"Terhubung ke router '{nama}' ({self.perangkat.name}) lewat API."
