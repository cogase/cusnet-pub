"""Halaman isolir dan tombol isolir/buka di Detail Layanan."""

from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.core.rbac import require_role
from app.modules.customers.forms import HapusForm
from app.modules.isolir import service

bp = Blueprint("isolir", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "viewer")
TULIS = ("superadmin", "admin_cabang", "billing")
ATUR = ("superadmin", "admin_cabang")


@bp.get("/isolir")
@require_role(*BACA)
def halaman():
    user = current_user()
    return render_template(
        "isolir/halaman.html",
        setelan=service.pengaturan(db_session),
        kandidat=service.kandidat(db_session),
        riwayat=service.riwayat(db_session),
        routers=service.router_pilihan(db_session, user),
        label_sebab=service.LABEL_SEBAB,
        form=HapusForm(),
    )


@bp.post("/isolir/pengaturan")
@require_role(*ATUR)
def simpan_pengaturan():
    tujuan = redirect(url_for("isolir.halaman"))
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah.", "bahaya")
        return tujuan
    try:
        service.ubah_pengaturan(db_session, current_user(), request.form)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return tujuan
    db_session.commit()
    flash("Pengaturan isolir disimpan.", "sukses")
    return tujuan


@bp.post("/isolir/uji")
@require_role(*ATUR)
def uji():
    tujuan = redirect(url_for("isolir.halaman"))
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah.", "bahaya")
        return tujuan
    try:
        pesan = service.adaptor_untuk(db_session).uji()
    except GalatDomain as galat:
        flash(f"Uji koneksi gagal: {galat}", "bahaya")
        return tujuan
    flash(pesan, "sukses")
    return tujuan


@bp.post("/isolir/layanan/<int:langganan_id>/isolir")
@require_role(*TULIS)
def isolir_layanan(langganan_id: int):
    return _aksi_layanan(langganan_id, "isolir")


@bp.post("/isolir/layanan/<int:langganan_id>/buka")
@require_role(*TULIS)
def buka_layanan(langganan_id: int):
    return _aksi_layanan(langganan_id, "buka")


def _aksi_layanan(langganan_id: int, aksi: str):
    tujuan = redirect(url_for("customers.langganan_detail", langganan_id=langganan_id) + "#isolir")
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah.", "bahaya")
        return tujuan
    try:
        jalankan = service.isolir if aksi == "isolir" else service.buka
        peristiwa = jalankan(db_session, current_user(), langganan_id, "manual")
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return tujuan
    db_session.commit()
    flash(peristiwa.pesan or "Selesai.", "sukses" if peristiwa.berhasil else "bahaya")
    return tujuan
