"""Aturan isolir: siapa diisolir, kapan dibuka, dan jejaknya.

Pengaman yang dipegang (DEVPLAN M8 — satu bug memutus customer yang sudah
bayar):

- Mode KERING bawaan: perintah tidak dikirim, status layanan tidak diubah,
  hanya dicatat apa yang AKAN terjadi.
- Otomatis MATI bawaan. Selama mati, `flask isolir-otomatis` hanya melapor.
- Customer bertanda "kecualikan dari isolir" tidak pernah diisolir otomatis.
- Buka isolir tidak pernah menunggu: begitu sebabnya hilang (lunas, tunggakan
  di bawah kredit limit), ia dibuka pada jalan berikutnya.
- Layanan yang diisolir manual tidak dibuka otomatis — orang yang
  mengisolirnya yang memutuskan.
"""

from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, select

from app.core import audit, rbac, waktu
from app.core.errors import GalatDomain
from app.modules.billing.models import Invoice, Payment
from app.modules.customers.models import Customer
from app.modules.customers.subscriptions import Subscription
from app.modules.isolir import adaptor as modul_adaptor
from app.modules.isolir.models import IsolirEvent
from app.modules.settings import service as setting_service

STATUS_TERBUKA = ("issued", "partial", "overdue")
LABEL_SEBAB = {"manual": "Manual", "tunggakan": "Tunggakan", "kredit_limit": "Kredit limit",
               "lunas": "Lunas"}


def pengaturan(sesi):
    return setting_service.ambil_setting(sesi)


def adaptor_untuk(sesi, pabrik_routeros=None):
    setelan = pengaturan(sesi)
    if setelan.isolir_mode != "nyata":
        return modul_adaptor.Kering()
    if not setelan.isolir_device_id:
        raise modul_adaptor.GalatIsolir("isolir_device_id", "Mode nyata butuh router isolir. Pilih di halaman Isolir.")
    from app.modules.inventory.models import Device

    perangkat = sesi.get(Device, setelan.isolir_device_id)
    if perangkat is None:
        raise modul_adaptor.GalatIsolir("isolir_device_id", "Router isolir tidak ditemukan.")
    if pabrik_routeros is not None:
        return modul_adaptor.MikrotikApi(perangkat, setelan.isolir_list, pabrik=pabrik_routeros)
    return modul_adaptor.MikrotikApi(perangkat, setelan.isolir_list)


def _catat(sesi, aktor, langganan, aksi, sebab, mode, berhasil, pesan):
    peristiwa = IsolirEvent(
        subscription_id=langganan.id, aksi=aksi, sebab=sebab, mode=mode, berhasil=berhasil,
        pesan=pesan[:2000] if pesan else None, actor_user_id=getattr(aktor, "id", None),
    )
    sesi.add(peristiwa)
    sesi.flush()
    return peristiwa


def _jalankan(sesi, aktor, langganan, aksi: str, sebab: str, pabrik_routeros=None) -> IsolirEvent:
    setelan = pengaturan(sesi)
    mode = "nyata" if setelan.isolir_mode == "nyata" else "kering"
    try:
        alat = adaptor_untuk(sesi, pabrik_routeros)
        alamat = modul_adaptor.alamat_layanan(langganan.ip_address)
        pesan = (alat.isolir(alamat, f"CUSNET {langganan.service_no}") if aksi == "isolir"
                 else alat.buka(alamat))
    except GalatDomain as galat:
        return _catat(sesi, aktor, langganan, aksi, sebab, mode, False, str(galat))

    if mode == "nyata":
        sebelum = {"status": langganan.status, "isolated_at": langganan.isolated_at}
        if aksi == "isolir":
            langganan.status = "suspend"
            langganan.isolated_at = waktu.sekarang()
        else:
            langganan.status = "active"
            langganan.isolated_at = None
        sesi.flush()
        audit.record(
            sesi, "update", "subscription", langganan.id,
            before={"status": sebelum["status"]},
            after={"status": langganan.status, "isolir": aksi, "sebab": sebab}, aktor=aktor,
        )
    return _catat(sesi, aktor, langganan, aksi, sebab, mode, True, pesan)


def isolir(sesi, aktor, langganan_id: int, sebab: str = "manual", pabrik_routeros=None) -> IsolirEvent:
    from app.modules.customers import subscription_service

    langganan = subscription_service.ambil_langganan(sesi, aktor, langganan_id)
    if langganan.parent_id is not None:
        raise GalatDomain("subscription_id", "Isolir dilakukan pada layanan induknya, bukan per site.")
    if langganan.isolated_at is not None:
        raise GalatDomain("subscription_id", "Layanan ini sudah diisolir.")
    return _jalankan(sesi, aktor, langganan, "isolir", sebab, pabrik_routeros)


def buka(sesi, aktor, langganan_id: int, sebab: str = "manual", pabrik_routeros=None) -> IsolirEvent:
    from app.modules.customers import subscription_service

    langganan = subscription_service.ambil_langganan(sesi, aktor, langganan_id)
    if langganan.isolated_at is None and pengaturan(sesi).isolir_mode == "nyata":
        raise GalatDomain("subscription_id", "Layanan ini tidak sedang diisolir.")
    return _jalankan(sesi, aktor, langganan, "buka", sebab, pabrik_routeros)


def riwayat(sesi, langganan_id: int | None = None, batas: int = 50) -> list:
    query = (
        select(IsolirEvent, Subscription, Customer)
        .join(Subscription, IsolirEvent.subscription_id == Subscription.id)
        .join(Customer, Subscription.customer_id == Customer.id)
        .order_by(IsolirEvent.id.desc())
        .limit(batas)
    )
    if langganan_id is not None:
        query = query.where(IsolirEvent.subscription_id == langganan_id)
    return list(sesi.execute(query).all())


def _sebab_terakhir(sesi, langganan_id: int) -> str | None:
    return sesi.execute(
        select(IsolirEvent.sebab)
        .where(IsolirEvent.subscription_id == langganan_id, IsolirEvent.aksi == "isolir",
               IsolirEvent.berhasil.is_(True))
        .order_by(IsolirEvent.id.desc())
        .limit(1)
    ).scalar()


def _tunggakan(sesi, hari_ini, batas_hari: int) -> dict[int, dict]:
    """Per customer: sisa tagihan terbuka dan jatuh tempo tertua yang lewat batas."""
    dibayar = (
        select(Payment.invoice_id, func.coalesce(func.sum(Payment.amount), 0).label("dibayar"))
        .group_by(Payment.invoice_id).subquery()
    )
    hasil: dict[int, dict] = {}
    for invoice, sudah in sesi.execute(
        select(Invoice, func.coalesce(dibayar.c.dibayar, 0))
        .outerjoin(dibayar, dibayar.c.invoice_id == Invoice.id)
        .where(Invoice.status.in_(STATUS_TERBUKA))
    ).all():
        sisa = invoice.total - sudah
        if sisa <= 0:
            continue
        data = hasil.setdefault(invoice.customer_id, {"sisa": Decimal("0"), "lewat": []})
        data["sisa"] += sisa
        if invoice.due_at and invoice.due_at + timedelta(days=batas_hari) <= hari_ini:
            data["lewat"].append(invoice)
    return hasil


def kandidat(sesi, hari_ini=None) -> dict:
    """Layanan yang semestinya diisolir dan yang semestinya dibuka, hari ini."""
    hari_ini = hari_ini or waktu.hari_ini()
    setelan = pengaturan(sesi)
    tunggak = _tunggakan(sesi, hari_ini, setelan.isolir_hari)
    isolir_, buka_ = [], []
    for langganan, pelanggan in sesi.execute(
        select(Subscription, Customer)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.parent_id.is_(None), Subscription.status.in_(("active", "suspend")))
        .order_by(Customer.name, Subscription.service_no)
    ).all():
        data = tunggak.get(pelanggan.id)
        sebab = None
        alasan = ""
        if data and data["lewat"]:
            sebab = "tunggakan"
            tertua = min(i.due_at for i in data["lewat"])
            alasan = f"{len(data['lewat'])} invoice lewat jatuh tempo + {setelan.isolir_hari} hari (tertua {tertua:%d %b %Y})"
        elif (setelan.isolir_kredit_limit and data and pelanggan.credit_limit
              and data["sisa"] > pelanggan.credit_limit):
            sebab = "kredit_limit"
            alasan = f"Tunggakan {data['sisa']:,.0f} melewati kredit limit {pelanggan.credit_limit:,.0f}".replace(",", ".")

        if langganan.isolated_at is None:
            if sebab and langganan.status == "active":
                isolir_.append({"langganan": langganan, "pelanggan": pelanggan, "sebab": sebab,
                                "alasan": alasan, "dikecualikan": pelanggan.isolir_exempt})
        elif sebab is None and _sebab_terakhir(sesi, langganan.id) in ("tunggakan", "kredit_limit"):
            buka_.append({"langganan": langganan, "pelanggan": pelanggan, "sebab": "lunas",
                          "alasan": "Tidak ada lagi tunggakan yang menjadi sebab isolir."})
    return {"isolir": isolir_, "buka": buka_}


def jalankan_otomatis(sesi, hari_ini=None, pabrik_routeros=None) -> dict:
    """Pekerjaan terjadwal. Selama otomatis mati, hanya menghitung."""
    setelan = pengaturan(sesi)
    daftar = kandidat(sesi, hari_ini)
    hasil = {"aktif": setelan.isolir_otomatis, "mode": setelan.isolir_mode,
             "kandidat_isolir": len(daftar["isolir"]), "kandidat_buka": len(daftar["buka"]),
             "diisolir": 0, "dibuka": 0, "gagal": 0, "dikecualikan": 0}
    if not setelan.isolir_otomatis:
        return hasil
    # Buka lebih dulu: customer yang sudah bayar tidak boleh menunggu.
    for butir in daftar["buka"]:
        peristiwa = _jalankan(sesi, rbac.SISTEM, butir["langganan"], "buka", "lunas", pabrik_routeros)
        hasil["dibuka" if peristiwa.berhasil else "gagal"] += 1
    for butir in daftar["isolir"]:
        if butir["dikecualikan"]:
            hasil["dikecualikan"] += 1
            continue
        peristiwa = _jalankan(sesi, rbac.SISTEM, butir["langganan"], "isolir", butir["sebab"], pabrik_routeros)
        hasil["diisolir" if peristiwa.berhasil else "gagal"] += 1
    return hasil


def ubah_pengaturan(sesi, aktor, data: dict):
    setelan = pengaturan(sesi)
    mode = data.get("isolir_mode") or "kering"
    if mode not in ("kering", "nyata"):
        raise GalatDomain("isolir_mode", "Mode isolir tidak dikenal.")
    daftar = (data.get("isolir_list") or "ISOLIR").strip()
    if not daftar or len(daftar) > 60 or any(c.isspace() for c in daftar):
        raise GalatDomain("isolir_list", "Nama address-list wajib diisi, tanpa spasi, paling panjang 60 karakter.")
    try:
        hari = int(data.get("isolir_hari") or 7)
    except ValueError as galat:
        raise GalatDomain("isolir_hari", "Jumlah hari harus angka.") from galat
    if not 0 <= hari <= 365:
        raise GalatDomain("isolir_hari", "Jumlah hari harus antara 0 dan 365.")
    perangkat = data.get("isolir_device_id") or None
    if mode == "nyata" and not perangkat:
        raise GalatDomain("isolir_device_id", "Mode nyata butuh router isolir.")
    sebelum = {k: getattr(setelan, k) for k in ("isolir_mode", "isolir_device_id", "isolir_list",
                                                "isolir_hari", "isolir_otomatis", "isolir_kredit_limit")}
    setelan.isolir_mode = mode
    setelan.isolir_device_id = int(perangkat) if perangkat else None
    setelan.isolir_list = daftar
    setelan.isolir_hari = hari
    setelan.isolir_otomatis = bool(data.get("isolir_otomatis"))
    setelan.isolir_kredit_limit = bool(data.get("isolir_kredit_limit"))
    sesi.flush()
    audit.record(sesi, "update", "billing_setting", setelan.id, before=sebelum,
                 after={k: getattr(setelan, k) for k in sebelum}, aktor=aktor)
    return setelan


def router_pilihan(sesi, user) -> list:
    from app.modules.inventory.models import Device

    return list(
        sesi.execute(
            rbac.scoped(select(Device).where(Device.kind.in_(("router",))).order_by(Device.name), user, Device)
        ).scalars()
    ) or list(sesi.execute(rbac.scoped(select(Device).order_by(Device.name), user, Device)).scalars())
