"""Peringatan layanan yang mendekati kapasitasnya.

Dijalankan sekali sehari (`flask cek-kapasitas`). Untuk tiap port yang
dialokasikan ke layanan dan punya sampel trafik, dihitung persentil ke-95
pemakaian beberapa hari terakhir terhadap kapasitas yang DIJUAL (bukan
kecepatan port). Yang melewati ambang dikabarkan ke Telegram — sekali per
minggu per port, supaya tidak menjadi bising — sebagai bahan menawarkan
upgrade sebelum customer mengeluh.
"""

from datetime import timedelta

from sqlalchemy import select

from app.modules.customers.models import Customer
from app.modules.customers.subscriptions import Subscription, SubscriptionInternet, SubscriptionP2P
from app.modules.inventory import trafik
from app.modules.inventory.models import DevicePort, PortTraffic

AMBANG_BAWAAN = 80.0
HARI_BAWAAN = 3
JEDA_ULANG = timedelta(days=7)
# Paling sedikit sepertiga sampel 5 menit dari rentangnya: port yang baru
# dipantau beberapa jam belum cukup untuk dinilai.
PORSI_MINIMUM = 1 / 3


def _kapasitas(sesi, subscription_ids: list[int]) -> dict[int, int]:
    hasil: dict[int, int] = {}
    for model in (SubscriptionInternet, SubscriptionP2P):
        for sid, mbps in sesi.execute(
            select(model.subscription_id, model.capacity_mbps).where(
                model.subscription_id.in_(subscription_ids), model.capacity_mbps.is_not(None)
            )
        ).all():
            hasil[sid] = mbps
    return hasil


def periksa(sesi, sekarang, ambang: float = AMBANG_BAWAAN, hari: int = HARI_BAWAAN,
            pengirim=None) -> dict:
    from app.core import telegram
    from app.modules.settings import branding

    pengirim = pengirim or telegram.kirim
    baris = sesi.execute(
        select(DevicePort, Subscription, Customer)
        .join(Subscription, DevicePort.subscription_id == Subscription.id)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(DevicePort.last_counter_at.is_not(None))
    ).all()
    kapasitas = _kapasitas(sesi, [s.id for _p, s, _c in baris])
    awal = sekarang - timedelta(days=hari)
    perlu = hari * 24 * 12 * PORSI_MINIMUM
    hasil = {"diperiksa": 0, "melewati": [], "dikabari": 0}
    pengaturan = branding.pengaturan_kabar(sesi)

    for port, langganan, pelanggan in baris:
        batas = kapasitas.get(langganan.id) or port.speed_mbps
        if not batas:
            continue
        deret = [
            (saat, masuk, keluar)
            for saat, masuk, keluar in sesi.execute(
                select(PortTraffic.at, PortTraffic.in_bps, PortTraffic.out_bps).where(
                    PortTraffic.port_id == port.id, PortTraffic.at >= awal
                )
            ).all()
        ]
        if len(deret) < perlu:
            continue
        hasil["diperiksa"] += 1
        nilai = trafik.utilisasi(deret, batas)
        if nilai["p95"] < ambang:
            continue
        butir = {
            "layanan": langganan.service_no, "site": langganan.site_name,
            "customer": pelanggan.name, "p95": nilai["p95"], "rata": nilai["rata"],
            "kapasitas": batas, "subscription_id": langganan.id,
        }
        hasil["melewati"].append(butir)
        if port.capacity_warned_at and sekarang - port.capacity_warned_at < JEDA_ULANG:
            continue
        if pengaturan["telegram_siap"]:
            teks = (
                f"\U0001F4C8 KAPASITAS {butir['p95']}% (p95, {hari} hari)\n"
                f"{pelanggan.name} — {langganan.service_no}"
                f"{' · ' + langganan.site_name if langganan.site_name else ''}\n"
                f"Kapasitas {batas} Mbps, rata-rata {butir['rata']}%. Pertimbangkan upgrade."
            )
            berhasil, _ = pengirim(pengaturan["telegram_token"], pengaturan["telegram_chat_id"], teks)
            if berhasil:
                hasil["dikabari"] += 1
        port.capacity_warned_at = sekarang
    sesi.flush()
    return hasil
