"""Ketersediaan layanan yang TERUKUR dari status link port (SNMP).

Status di antara dua peristiwa dianggap tetap. Sebelum peristiwa pertama
statusnya tidak diketahui, dan waktu itu tidak dihitung — tidak sebagai
naik, tidak sebagai turun. Yang dilaporkan karenanya juga "terpantau berapa
lama": ketersediaan 100% dari dua jam pantauan bukan janji sebulan penuh.
"""

from sqlalchemy import select

from app.modules.inventory.models import DevicePort, PortLinkEvent


def port_layanan(sesi, subscription_ids: list[int]) -> dict[int, int]:
    """Peta id layanan ke id port yang dialokasikan kepadanya."""
    if not subscription_ids:
        return {}
    return dict(
        sesi.execute(
            select(DevicePort.subscription_id, DevicePort.id).where(
                DevicePort.subscription_id.in_(subscription_ids)
            )
        ).all()
    )


def ukur(sesi, port_ids: list[int], awal, akhir) -> dict[int, dict]:
    """`{port_id: {"terpantau": detik, "putus": detik, "kejadian": n}}` dalam `[awal, akhir)`."""
    hasil: dict[int, dict] = {}
    if not port_ids or akhir <= awal:
        return hasil
    peristiwa = sesi.execute(
        select(PortLinkEvent.port_id, PortLinkEvent.at, PortLinkEvent.naik)
        .where(PortLinkEvent.port_id.in_(port_ids), PortLinkEvent.at < akhir)
        .order_by(PortLinkEvent.port_id, PortLinkEvent.at, PortLinkEvent.id)
    ).all()
    per_port: dict[int, list] = {}
    for port_id, saat, naik in peristiwa:
        per_port.setdefault(port_id, []).append((saat, naik))
    for port_id, daftar in per_port.items():
        terpantau = putus = 0.0
        kejadian = 0
        for i, (saat, naik) in enumerate(daftar):
            mulai = max(saat, awal)
            selesai = daftar[i + 1][0] if i + 1 < len(daftar) else akhir
            selesai = min(selesai, akhir)
            if selesai <= mulai or naik is None:
                continue
            lama = (selesai - mulai).total_seconds()
            terpantau += lama
            if not naik:
                putus += lama
                kejadian += 1
        if terpantau > 0:
            hasil[port_id] = {"terpantau": terpantau, "putus": putus, "kejadian": kejadian}
    return hasil
