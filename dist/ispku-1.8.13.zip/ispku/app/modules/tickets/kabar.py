"""Kabar tiket ke luar aplikasi lewat email.

Lonceng di topbar hanya terlihat oleh orang yang sedang membuka aplikasi.
Modul ini mengantrekan email untuk tiga kejadian: tiket ditugaskan, tiket
kritis dibuka, dan tiket melewati tenggat SLA. Pengirimannya tetap dilakukan
`flask mail-flush`; di sini hanya mengantre.

Pengguna bisa mematikannya untuk dirinya sendiri di halaman Profil
(`preferences["notif_email"] = False`).
"""

from html import escape

from flask import current_app, has_app_context, has_request_context, url_for
from sqlalchemy import or_, select

from app.core import mail
from app.modules.admin.models import User
from app.modules.tickets.models import STATUS_TUTUP, Ticket

PERAN_JAGA = ("admin_cabang", "teknis")
LABEL_PRIORITAS = {"rendah": "Rendah", "sedang": "Sedang", "tinggi": "Tinggi", "kritis": "Kritis"}


def smtp_siap() -> bool:
    """Apakah SMTP sudah diisi.

    Selama belum, kabar tiket TIDAK diantrekan sama sekali. Antrean email
    tidak punya masa kedaluwarsa, jadi mengantre sekarang berarti begitu SMTP
    diisi berbulan-bulan kemudian, ratusan kabar tiket basi terkirim sekaligus.
    """
    if not has_app_context():
        return False
    config = current_app.extensions.get("config_object")
    if config is None:
        return False
    from app.core.db import db_session

    return mail.siap(db_session, config)


def mau_email(user: User) -> bool:
    return bool(user.is_active and user.email) and (user.preferences or {}).get(
        "notif_email", True
    )


def _penjaga(sesi, branch_id: int) -> list[User]:
    """Admin cabang dan teknisi cabang tiket, ditambah yang lintas cabang."""
    return list(
        sesi.execute(
            select(User).where(
                User.is_active.is_(True),
                User.role.in_(PERAN_JAGA),
                or_(User.branch_id == branch_id, User.branch_id.is_(None)),
            )
        ).scalars()
    )


def _penerima(sesi, tiket: Ticket, kecuali_id: int | None = None) -> list[User]:
    """Petugas tiket; kalau belum ditugaskan, seluruh penjaga cabangnya."""
    calon = []
    if tiket.assigned_to_user_id:
        petugas = sesi.get(User, tiket.assigned_to_user_id)
        if petugas is not None:
            calon.append(petugas)
    if not calon:
        calon = _penjaga(sesi, tiket.branch_id)
    return [u for u in calon if u.id != kecuali_id and mau_email(u)]


def _isi(tiket: Ticket, pembuka: str) -> str:
    tautan = ""
    if has_request_context():
        alamat = url_for("tickets.detail", tiket_id=tiket.id, _external=True)
        tautan = f'<p><a href="{escape(alamat)}">Buka tiket di aplikasi</a></p>'
    tenggat = (
        tiket.resolve_due_at.strftime("%d %b %Y %H:%M") if tiket.resolve_due_at else "-"
    )
    return (
        f"<p>{escape(pembuka)}</p>"
        "<table>"
        f"<tr><td>Nomor</td><td><strong>{escape(tiket.number)}</strong></td></tr>"
        f"<tr><td>Judul</td><td>{escape(tiket.title)}</td></tr>"
        f"<tr><td>Prioritas</td><td>{LABEL_PRIORITAS.get(tiket.priority, tiket.priority)}</td></tr>"
        f"<tr><td>Tenggat selesai</td><td>{tenggat}</td></tr>"
        "</table>"
        f"{tautan}"
        "<p style=\"color:#6b7280;font-size:12px\">Email ini bisa dimatikan di halaman Profil.</p>"
    )


def _telegram(sesi, teks: str, tenggat: float = 4.0) -> bool:
    """Kabar singkat ke grup Telegram, bila botnya diisi. Tidak pernah gagal keras."""
    from app.core import telegram
    from app.modules.settings import branding

    pengaturan = branding.pengaturan_kabar(sesi)
    if not pengaturan["telegram_siap"]:
        return False
    berhasil, _ = telegram.kirim(
        pengaturan["telegram_token"], pengaturan["telegram_chat_id"], teks, tenggat=tenggat
    )
    return berhasil


def _antre(sesi, penerima: list[User], subjek: str, isi: str) -> int:
    if not smtp_siap():
        return 0
    for user in penerima:
        mail.antre(sesi, user.email, subjek[:255], isi)
    if penerima:
        sesi.flush()
    return len(penerima)


def tiket_dibuka(sesi, tiket: Ticket, aktor=None) -> int:
    """Tiket baru: kabari petugasnya; tiket kritis mengabari seluruh penjaga."""
    kecuali = aktor.id if aktor is not None and getattr(aktor, "id", None) else None
    if tiket.priority == "kritis":
        _telegram(sesi, f"\U0001F6A8 TIKET KRITIS {tiket.number}\n{tiket.title}")
        penerima = {u.id: u for u in _penjaga(sesi, tiket.branch_id)}
        if tiket.assigned_to_user_id:
            petugas = sesi.get(User, tiket.assigned_to_user_id)
            if petugas is not None:
                penerima[petugas.id] = petugas
        daftar = [u for u in penerima.values() if u.id != kecuali and mau_email(u)]
        return _antre(
            sesi, daftar, f"[KRITIS] {tiket.number} — {tiket.title}",
            _isi(tiket, "Tiket prioritas kritis baru saja dibuka."),
        )
    if tiket.assigned_to_user_id:
        return ditugaskan(sesi, tiket, aktor)
    return 0


def ditugaskan(sesi, tiket: Ticket, aktor=None) -> int:
    petugas = sesi.get(User, tiket.assigned_to_user_id) if tiket.assigned_to_user_id else None
    kecuali = aktor.id if aktor is not None and getattr(aktor, "id", None) else None
    if petugas is None or petugas.id == kecuali or not mau_email(petugas):
        return 0
    return _antre(
        sesi, [petugas], f"Tiket {tiket.number} ditugaskan kepada Anda",
        _isi(tiket, "Sebuah tiket ditugaskan kepada Anda."),
    )


def lewat_sla(sesi, sekarang) -> dict:
    """Mengabari tiket terbuka yang tenggat selesainya sudah lewat.

    Sekali per tiket: `sla_notified_at` dicap begitu kabarnya diantre, jadi
    perintah ini aman dijalankan tiap beberapa menit.
    """
    tiket = list(
        sesi.execute(
            select(Ticket)
            .where(
                Ticket.status.notin_(STATUS_TUTUP),
                Ticket.resolve_due_at.is_not(None),
                Ticket.resolve_due_at < sekarang,
                Ticket.sla_notified_at.is_(None),
            )
            .order_by(Ticket.id)
            .with_for_update(skip_locked=True)
        ).scalars()
    )
    diantre = 0
    for satu in tiket:
        diantre += _antre(
            sesi, _penerima(sesi, satu), f"[LEWAT SLA] {satu.number} — {satu.title}",
            _isi(satu, "Tiket ini sudah melewati tenggat penyelesaian dan masih terbuka."),
        )
        _telegram(sesi, f"\u23F0 LEWAT SLA {satu.number}\n{satu.title}")
        satu.sla_notified_at = sekarang
    sesi.flush()
    return {"tiket": len(tiket), "email": diantre}


# ── Kabar ke customer yang terdampak gangguan massal ───────────────────────

PERAN_PENERIMA = ("pic_utama", "teknis")
JUDUL_KABAR = {"gangguan": "Pemberitahuan gangguan layanan", "pulih": "Layanan telah pulih"}


def pesan_bawaan(jenis: str, sumber: str) -> str:
    if jenis == "pulih":
        return (
            "Pelanggan yang terhormat,\n\n"
            f"Gangguan jaringan di {sumber} yang memengaruhi layanan Anda sudah teratasi, "
            "dan layanan Anda kembali normal. Bila masih ada kendala, balas email ini atau "
            "hubungi kami.\n\nTerima kasih atas kesabaran Anda."
        )
    return (
        "Pelanggan yang terhormat,\n\n"
        f"Saat ini terjadi gangguan jaringan di {sumber} yang memengaruhi layanan Anda. "
        "Tim teknis kami sedang menanganinya, dan kami akan mengabari kembali begitu "
        "layanan pulih.\n\nMohon maaf atas ketidaknyamanannya."
    )


def penerima_customer(sesi, customer_ids: list[int]) -> dict[int, list[str]]:
    """Alamat email kontak tiap customer: PIC utama dan teknis, lalu kontak lain bila tak ada."""
    from app.modules.customers.models import CustomerContact

    semua: dict[int, list] = {}
    for kontak in sesi.execute(
        select(CustomerContact)
        .where(CustomerContact.customer_id.in_(customer_ids or [0]), CustomerContact.email.is_not(None))
        .order_by(CustomerContact.is_primary.desc(), CustomerContact.id)
    ).scalars():
        if (kontak.email or "").strip():
            semua.setdefault(kontak.customer_id, []).append(kontak)
    hasil: dict[int, list[str]] = {}
    for customer_id, daftar in semua.items():
        terpilih = [k for k in daftar if k.role in PERAN_PENERIMA] or daftar
        alamat: list[str] = []
        for kontak in terpilih:
            email = kontak.email.strip().lower()
            if email not in alamat:
                alamat.append(email)
        hasil[customer_id] = alamat
    return hasil


def kabari_terdampak(sesi, aktor, tiket_id: int, jenis: str, pesan: str) -> dict:
    """Mengantrekan email ke customer yang layanannya terdampak satu tiket.

    Satu email per alamat, berisi pesan operator ditambah daftar layanan
    customer itu yang terdampak. Dicatat sebagai langkah penanganan internal
    di tiketnya, supaya kelihatan siapa sudah dikabari dan kapan.
    """
    from html import escape as _esc

    from app.core.errors import GalatDomain
    from app.modules.settings import service as setting_service
    from app.modules.tickets import service as ticket_service

    if jenis not in JUDUL_KABAR:
        raise GalatDomain("jenis", "Jenis kabar tidak dikenal.")
    pesan = (pesan or "").strip()
    if not pesan:
        raise GalatDomain("pesan", "Pesan tidak boleh kosong.")
    if not smtp_siap():
        raise GalatDomain("pesan", "SMTP belum diisi, jadi email tidak bisa dikirim. Lengkapi pengaturan SMTP lebih dulu.")

    tiket = ticket_service.ambil(sesi, aktor, tiket_id)
    terdampak = ticket_service.daftar_terdampak(sesi, aktor, tiket_id)
    if not terdampak:
        raise GalatDomain("pesan", "Tiket ini tidak mencatat layanan terdampak.")
    per_customer: dict[int, tuple] = {}
    for langganan, pelanggan in terdampak:
        per_customer.setdefault(pelanggan.id, (pelanggan, []))[1].append(langganan)
    alamat = penerima_customer(sesi, list(per_customer))
    perusahaan = setting_service.ambil_setting(sesi).company_name or "Kami"

    jumlah_email = 0
    tanpa_email = []
    for customer_id, (pelanggan, layanan) in per_customer.items():
        tujuan = alamat.get(customer_id) or []
        if not tujuan:
            tanpa_email.append(pelanggan.name)
            continue
        daftar = "".join(
            f"<li>{_esc(s.service_no)}{' — ' + _esc(s.site_name) if s.site_name else ''}</li>"
            for s in layanan
        )
        isi = (
            "".join(f"<p>{_esc(paragraf)}</p>" for paragraf in pesan.split("\n\n"))
            + f"<p>Layanan Anda yang terdampak:</p><ul>{daftar}</ul>"
            + f"<p style=\"color:#6b7280;font-size:12px\">{_esc(perusahaan)} · referensi {_esc(tiket.number)}</p>"
        )
        for email in tujuan:
            mail.antre(sesi, email, f"{JUDUL_KABAR[jenis]} — {pelanggan.name}"[:255], isi)
            jumlah_email += 1
    sesi.flush()

    catatan = (
        f"Kabar \"{JUDUL_KABAR[jenis].lower()}\" diantrekan ke {len(per_customer) - len(tanpa_email)} customer "
        f"({jumlah_email} alamat email)."
    )
    if tanpa_email:
        catatan += " Tanpa alamat email, perlu dihubungi manual: " + ", ".join(tanpa_email) + "."
    ticket_service.tambah_komentar(sesi, aktor, tiket.id, catatan, is_internal=True)
    return {"customer": len(per_customer) - len(tanpa_email), "email": jumlah_email, "tanpa_email": tanpa_email}
