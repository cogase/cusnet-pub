"""pengaturan tampilan dan fitur portal pelanggan

Revision ID: 0042
Revises: 0041
Create Date: 2026-10-22 19:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0042"
down_revision: Union[str, None] = "0041"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    benar = sa.text("true")
    op.create_table(
        "portal_setting",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("public_url", sa.String(200), nullable=True),
        sa.Column("title", sa.String(80), nullable=True),
        sa.Column("login_title", sa.String(120), nullable=True),
        sa.Column("login_text", sa.Text(), nullable=True),
        sa.Column("login_help", sa.Text(), nullable=True),
        sa.Column("welcome_text", sa.Text(), nullable=True),
        sa.Column("announcement", sa.Text(), nullable=True),
        sa.Column("announcement_level", sa.String(12), nullable=False, server_default="info"),
        sa.Column("contact_whatsapp", sa.String(30), nullable=True),
        sa.Column("contact_phone", sa.String(30), nullable=True),
        sa.Column("contact_email", sa.String(160), nullable=True),
        sa.Column("contact_hours", sa.String(120), nullable=True),
        sa.Column("accent_color", sa.String(7), nullable=True),
        sa.Column("logo_path", sa.String(500), nullable=True),
        sa.Column("show_logo", sa.Boolean(), nullable=False, server_default=benar),
        sa.Column("allow_tickets", sa.Boolean(), nullable=False, server_default=benar),
        sa.Column("allow_payment_proof", sa.Boolean(), nullable=False, server_default=benar),
        sa.Column("show_bank_accounts", sa.Boolean(), nullable=False, server_default=benar),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("id = 1", name="ck_portal_setting_satu_baris"),
        sa.CheckConstraint("announcement_level IN ('info', 'peringatan', 'bahaya')",
                           name="ck_portal_setting_tingkat"),
    )


def downgrade() -> None:
    op.drop_table("portal_setting")
