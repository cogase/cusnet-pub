"""Pengaturan tampilan dan fitur portal pelanggan.

Diubah staf dari Pengaturan → Portal Pelanggan; dibaca proses portal di
setiap halaman. Isian yang kosong mengikuti merek aplikasi atau teks bawaan
di `BAWAAN` — templat tidak menulis nilai bawaannya sendiri.
"""

import re

from sqlalchemy import func, select, text

from app.core import audit
from app.core.errors import GalatDomain
from app.portal.models import TINGKAT_PENGUMUMAN, PortalAccount, PortalSetting

ID = 1
_KUNCI = 918_273_647

BAWAAN = {
    "title": "Portal Pelanggan",
    "login_title": "Masuk Portal Pelanggan",
    "login_text": "Lihat tagihan, unduh invoice dan kwitansi, kirim bukti bayar, dan laporkan gangguan.",
    "login_help": "Belum punya akun atau lupa sandi? Hubungi tim kami; akun dibuatkan dari sisi kami.",
}

KOLOM_TEKS = {
    "public_url": 200, "title": 80, "login_title": 120, "login_text": 600, "login_help": 600,
    "welcome_text": 600, "announcement": 600, "contact_whatsapp": 30, "contact_phone": 30,
    "contact_email": 160, "contact_hours": 120, "accent_color": 7,
}
KOLOM_SAKELAR = ("show_logo", "allow_tickets", "allow_payment_proof", "show_bank_accounts")


def ambil(sesi) -> PortalSetting:
    """Baris pengaturan satu-satunya, dibuat bila belum ada."""
    baris = sesi.get(PortalSetting, ID)
    if baris is not None:
        return baris
    sesi.execute(text("SELECT pg_advisory_xact_lock(:kunci)"), {"kunci": _KUNCI})
    baris = sesi.get(PortalSetting, ID)
    if baris is None:
        baris = PortalSetting(id=ID, announcement_level="info", show_logo=True, allow_tickets=True,
                              allow_payment_proof=True, show_bank_accounts=True)
        sesi.add(baris)
        sesi.flush()
    return baris


def _potret(baris: PortalSetting) -> dict:
    kolom = tuple(KOLOM_TEKS) + KOLOM_SAKELAR + ("announcement_level", "logo_path")
    return {nama: getattr(baris, nama) for nama in kolom}


def ubah(sesi, aktor, data: dict, logo=False) -> PortalSetting:
    """Menyimpan pengaturan. `logo`: StoredFile baru, None = hapus, False = tetap."""
    from app.modules.settings.branding import periksa_warna

    baris = ambil(sesi)
    sebelum = _potret(baris)
    nilai = {}
    for kolom, panjang in KOLOM_TEKS.items():
        isi = (data.get(kolom) or "").strip() or None
        if isi is not None and len(isi) > panjang:
            raise GalatDomain(kolom, f"Paling panjang {panjang} karakter.")
        nilai[kolom] = isi

    if nilai["public_url"] and not re.fullmatch(r"https?://[^\s/]+(/\S*)?", nilai["public_url"]):
        raise GalatDomain("public_url", "Alamat portal harus diawali http:// atau https://.")
    if nilai["public_url"]:
        nilai["public_url"] = nilai["public_url"].rstrip("/")
    if nilai["accent_color"]:
        try:
            periksa_warna(nilai["accent_color"])
        except GalatDomain as galat:
            raise GalatDomain("accent_color", str(galat)) from None
    if nilai["contact_whatsapp"]:
        angka = nomor_wa(nilai["contact_whatsapp"])
        if not angka:
            raise GalatDomain("contact_whatsapp", "Nomor WhatsApp hanya berisi angka, mis. 0812xxxx atau 62812xxxx.")
    if nilai["contact_email"] and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", nilai["contact_email"]):
        raise GalatDomain("contact_email", "Alamat email tidak sah.")
    tingkat = data.get("announcement_level") or "info"
    if tingkat not in TINGKAT_PENGUMUMAN:
        raise GalatDomain("announcement_level", "Tingkat pengumuman tidak dikenal.")

    for kolom, isi in nilai.items():
        setattr(baris, kolom, isi)
    baris.announcement_level = tingkat
    for kolom in KOLOM_SAKELAR:
        setattr(baris, kolom, bool(data.get(kolom)))
    if logo is not False:
        baris.logo_path = logo.path if logo is not None else None
    sesi.flush()
    audit.record(sesi, "update", "portal_setting", baris.id, before=sebelum, after=_potret(baris), aktor=aktor)
    return baris


def nomor_wa(nomor: str | None) -> str | None:
    """'0812-3456 789' -> '628123456789'; None bila bukan nomor."""
    angka = re.sub(r"[\s().+-]", "", nomor or "")
    if not angka.isdigit() or not 8 <= len(angka) <= 16:
        return None
    return "62" + angka[1:] if angka.startswith("0") else angka


def alamat(sesi) -> str | None:
    baris = sesi.get(PortalSetting, ID)
    return baris.public_url if baris is not None else None


def ringkasan_akun(sesi) -> dict:
    jumlah = dict(sesi.execute(
        select(PortalAccount.is_active, func.count()).group_by(PortalAccount.is_active)
    ).all())
    pernah = sesi.execute(
        select(func.count()).select_from(PortalAccount).where(PortalAccount.last_login_at.is_not(None))
    ).scalar_one()
    return {"aktif": jumlah.get(True, 0), "nonaktif": jumlah.get(False, 0), "pernah_masuk": pernah}


def konteks(baris: PortalSetting | None, merek: dict) -> dict:
    """Bentuk yang dipakai templat portal; `merek` = `branding.konteks(...)`."""
    def isi(kolom):
        nilai = getattr(baris, kolom, None) if baris is not None else None
        return nilai or BAWAAN.get(kolom)

    def sakelar(kolom):
        return True if baris is None else bool(getattr(baris, kolom))

    kontak = []
    wa = nomor_wa(isi("contact_whatsapp"))
    if wa:
        kontak.append({"ikon": "message-circle", "label": f"WhatsApp {isi('contact_whatsapp')}",
                       "href": f"https://wa.me/{wa}"})
    if isi("contact_phone"):
        kontak.append({"ikon": "phone", "label": isi("contact_phone"),
                       "href": "tel:" + re.sub(r"[^\d+]", "", isi("contact_phone"))})
    if isi("contact_email"):
        kontak.append({"ikon": "mail", "label": isi("contact_email"), "href": "mailto:" + isi("contact_email")})

    punya_logo_sendiri = bool(baris is not None and baris.logo_path)
    return {
        "nama": merek.get("nama_penuh") or "Portal Pelanggan",
        "judul": isi("title"),
        "judul_masuk": isi("login_title"),
        "teks_masuk": isi("login_text"),
        "bantuan_masuk": isi("login_help"),
        "sapaan": isi("welcome_text"),
        "pengumuman": isi("announcement"),
        "pengumuman_tingkat": (baris.announcement_level if baris is not None else None) or "info",
        "kontak": kontak,
        "jam_layanan": isi("contact_hours"),
        "warna": isi("accent_color") or merek.get("warna") or "#2563EB",
        "logo": sakelar("show_logo") and (punya_logo_sendiri or bool(merek.get("punya_logo"))),
        "favicon": bool(merek.get("punya_favicon")),
        "tiket": sakelar("allow_tickets"),
        "bukti_bayar": sakelar("allow_payment_proof"),
        "rekening": sakelar("show_bank_accounts"),
        "alamat": isi("public_url"),
    }


def berkas_logo(sesi) -> str | None:
    """Jalur logo yang dipakai portal: logo portal, atau logo aplikasi."""
    from app.modules.settings.models import AppBranding

    baris = sesi.get(PortalSetting, ID)
    if baris is not None and baris.logo_path:
        return baris.logo_path
    merek = sesi.get(AppBranding, 1)
    return merek.logo_path if merek is not None else None


def berkas_favicon(sesi) -> str | None:
    from app.modules.settings.models import AppBranding

    merek = sesi.get(AppBranding, 1)
    return merek.favicon_path if merek is not None else None
