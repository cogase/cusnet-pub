"""Rute portal pelanggan."""

from flask import current_app, flash, redirect, render_template, request, session, url_for

from app.core import rbac
from app.core.db import db_session
from app.core.errors import GalatDomain
from app.portal import KUNCI_SESI, _akun, atur, bp, perlu_fitur, perlu_masuk
from app.portal import service
from app.portal.forms import BalasForm, KonfirmasiForm, MasukForm, SandiForm, TiketForm


def _cid() -> int:
    return _akun().customer_id


@bp.route("/masuk", methods=["GET", "POST"])
def masuk():
    form = MasukForm()
    if form.validate_on_submit():
        try:
            akun = service.masuk(db_session, form.login.data, form.sandi.data, request.remote_addr)
        except GalatDomain as galat:
            db_session.commit()
            flash(str(galat), "bahaya")
            return render_template("portal/masuk.html", form=form)
        db_session.commit()
        if akun is None:
            flash("Email atau sandi salah.", "bahaya")
        else:
            session.clear()
            session[KUNCI_SESI] = akun.id
            session.permanent = True
            tujuan = request.args.get("next") or ""
            return redirect(tujuan if tujuan.startswith("/") and not tujuan.startswith("//") else url_for("portal.beranda"))
    return render_template("portal/masuk.html", form=form)


@bp.get("/logo")
def logo():
    """Logo portal (atau logo aplikasi). Publik: tampil di halaman masuk."""
    return _sajikan_merek(service_pengaturan().berkas_logo(db_session), "logo")


@bp.get("/favicon")
def favicon():
    return _sajikan_merek(service_pengaturan().berkas_favicon(db_session), "favicon")


def service_pengaturan():
    from app.portal import pengaturan

    return pengaturan


def _sajikan_merek(jalur, nama):
    import pathlib

    from flask import abort

    from app.core.files import mime_dari_path, sajikan_sebaris

    db_session.commit()
    if not jalur:
        abort(404)
    return sajikan_sebaris(jalur, f"{nama}{pathlib.Path(jalur).suffix}", mime_dari_path(jalur),
                           current_app.config["UPLOAD_DIR"])


@bp.post("/keluar")
def keluar():
    session.clear()
    return redirect(url_for("portal.masuk"))


@bp.get("/")
@perlu_masuk
def beranda():
    cid = _cid()
    tagihan = service.tagihan(db_session, cid)
    return render_template(
        "portal/beranda.html",
        pelanggan=service.pelanggan(db_session, cid),
        layanan=service.layanan(db_session, cid),
        terbuka=[t for t in tagihan if t["sisa"] > 0],
        tiket=[t for t in service.tiket(db_session, cid) if t.status not in ("selesai", "ditutup")][:5]
        if atur()["tiket"] else [],
    )


@bp.get("/tagihan")
@perlu_masuk
def tagihan():
    cid = _cid()
    return render_template("portal/tagihan.html", tagihan=service.tagihan(db_session, cid),
                           konfirmasi=service.riwayat_konfirmasi(db_session, cid))


@bp.route("/tagihan/<int:invoice_id>", methods=["GET", "POST"])
@perlu_masuk
def tagihan_detail(invoice_id: int):
    from app.modules.billing import payments
    from app.modules.settings import service as setting_service

    cid = _cid()
    invoice = service.invoice_milik(db_session, cid, invoice_id)
    form = KonfirmasiForm()
    if atur()["bukti_bayar"] and form.validate_on_submit():
        berkas = form.bukti.data
        try:
            service.konfirmasi_bayar(
                db_session, cid, invoice.id, form.data, berkas.stream, berkas.filename,
                current_app.config["UPLOAD_DIR"],
            )
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Konfirmasi terkirim. Tim billing akan memeriksanya.", "sukses")
            return redirect(url_for("portal.tagihan_detail", invoice_id=invoice.id))
    return render_template(
        "portal/tagihan_detail.html", invoice=invoice, form=form,
        item=_item(invoice), pembayaran=payments.daftar(db_session, rbac.SISTEM, invoice.id),
        sisa=payments.sisa_tagihan(db_session, invoice),
        rekening=setting_service.daftar_rekening_aktif(db_session) if atur()["rekening"] else [],
    )


def _item(invoice):
    from app.modules.billing import service as billing_service

    return billing_service.daftar_item(db_session, rbac.SISTEM, invoice.id)


@bp.get("/tagihan/<int:invoice_id>.pdf")
@perlu_masuk
def tagihan_pdf(invoice_id: int):
    from app.modules.billing.views import _kirim_pdf, _konteks_detail

    invoice = service.invoice_milik(db_session, _cid(), invoice_id)
    konteks = _konteks_detail(rbac.SISTEM, invoice)
    html = render_template("billing/cetak.html", **konteks)
    return _kirim_pdf(html, konteks["setting"], f"{(invoice.number or 'invoice').replace('/', '-')}.pdf")


@bp.get("/kwitansi/<int:payment_id>.pdf")
@perlu_masuk
def kwitansi_pdf(payment_id: int):
    from app.modules.billing.views import _kirim_pdf, _konteks_kwitansi

    service.pembayaran_milik(db_session, _cid(), payment_id)
    konteks = _konteks_kwitansi(rbac.SISTEM, payment_id)
    html = render_template("billing/kwitansi.html", **konteks)
    return _kirim_pdf(html, konteks["setting"], f"kwitansi-{konteks['nomor_kwitansi']}.pdf")


@bp.get("/tiket")
@perlu_masuk
@perlu_fitur("tiket")
def tiket():
    return render_template("portal/tiket.html", tiket=service.tiket(db_session, _cid()))


@bp.route("/tiket/baru", methods=["GET", "POST"])
@perlu_masuk
@perlu_fitur("tiket")
def tiket_baru():
    cid = _cid()
    form = TiketForm()
    form.category_id.choices = [(k.id, k.name) for k in service.kategori_tiket(db_session)]
    form.subscription_id.choices = [(0, "— Tidak spesifik —")] + [
        (s.id, f"{s.service_no} — {s.site_name or p.name}") for s, p in service.layanan(db_session, cid)
    ]
    if form.validate_on_submit():
        try:
            baru = service.buka_tiket(db_session, cid, form.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash(f"Tiket {baru.number} dibuka. Kami akan segera menanganinya.", "sukses")
            return redirect(url_for("portal.tiket_detail", tiket_id=baru.id))
    return render_template("portal/tiket_baru.html", form=form)


@bp.route("/tiket/<int:tiket_id>", methods=["GET", "POST"])
@perlu_masuk
@perlu_fitur("tiket")
def tiket_detail(tiket_id: int):
    cid = _cid()
    satu = service.tiket_milik(db_session, cid, tiket_id)
    form = BalasForm()
    if form.validate_on_submit():
        try:
            service.balas_tiket(db_session, cid, satu.id, form.body.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            return redirect(url_for("portal.tiket_detail", tiket_id=satu.id))
    return render_template("portal/tiket_detail.html", tiket=satu, form=form,
                           komentar=service.komentar_publik(db_session, satu.id))


@bp.route("/akun", methods=["GET", "POST"])
def akun():
    akun_ = _akun()
    if akun_ is None:
        return redirect(url_for("portal.masuk"))
    form = SandiForm()
    if form.validate_on_submit():
        try:
            service.ganti_sandi(db_session, akun_, form.lama.data, form.baru.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Sandi diganti.", "sukses")
            return redirect(url_for("portal.beranda"))
    return render_template("portal/akun.html", form=form, pelanggan=service.pelanggan(db_session, akun_.customer_id))
