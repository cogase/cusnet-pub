from datetime import date

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app.core import waktu
from app.core.auth import current_user
from app.core.db import db_session
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.files import FileError, mime_dari_path, sajikan
from app.core.grafik import garis_ganda
from app.core.pagination import per_halaman_dari
from app.core.rbac import require_role
from app.modules.admin import service as admin_service
from app.modules.billing import payments, reports, service
from app.modules.billing.forms import (
    LABEL_STATUS_INVOICE,
    NADA_STATUS_INVOICE,
    AlasanForm,
    GenerateInvoiceForm,
    ItemManualForm,
    pilihan_periode,
)
from app.modules.customers.forms import HapusForm

bp = Blueprint("billing", __name__)

BACA = ("superadmin", "admin_cabang", "billing", "viewer")
BACA_LAPORAN = ("superadmin", "admin_cabang", "billing", "teknis", "viewer")
TULIS_BILLING = ("superadmin", "admin_cabang", "billing")
VOID = ("superadmin", "admin_cabang", "billing")


@bp.get("/billing/invoice.csv")
@require_role(*BACA)
def invoice_ekspor():
    """Daftar invoice sebagai CSV, mengikuti filter yang sedang aktif.

    Sengaja tidak memanggil `segarkan_status`: mengunduh berkas tidak boleh
    menyunting basis data. Status lewat-tempo dihitung di `ekspor.py`.
    """
    isi, terpotong = service.ekspor_invoice(
        db_session,
        current_user(),
        q=request.args.get("q") or None,
        status=request.args.get("status") or None,
    )
    nama = (
        f"invoice-terpotong-{service.BATAS_EKSPOR}.csv"
        if terpotong
        else "invoice.csv"
    )
    return _unduh_csv(isi, nama)


@bp.get("/billing")
@require_role(*BACA)
def daftar():
    user = current_user()
    halaman = service.daftar_invoice(
        db_session,
        user,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        q=request.args.get("q") or None,
        status=request.args.get("status") or None,
    )
    # TIDAK memanggil `segarkan_status`: permintaan baca tidak boleh menulis,
    # dan sejak `flask billing-harian` ada, yang menyimpan adalah pekerjaan
    # terjadwal. Yang dilihat di layar dihitung lewat `Invoice.status_efektif`.
    return render_template(
        "billing/daftar.html",
        halaman=halaman,
        ringkasan=service.ringkasan_billing(db_session, user),
        bayar=payments.ringkasan_pembayaran(db_session, user),
        status_aktif=request.args.get("status") or "",
        q=request.args.get("q") or "",
        label_status=LABEL_STATUS_INVOICE,
        nada_status=NADA_STATUS_INVOICE,
    )


@bp.route("/billing/generate", methods=["GET", "POST"])
@require_role(*TULIS_BILLING)
def generate():
    user = current_user()
    form = GenerateInvoiceForm()
    cabang = admin_service.semua_cabang(db_session, user)
    form.branch_id.choices = [(0, "— Semua cabang —")] + [
        (c.id, c.name) for c in cabang
    ]
    form.period.choices = pilihan_periode()
    if not form.period.data:
        # Bawaannya bulan berjalan, bukan yang teratas di daftar.
        form.period.data = waktu.hari_ini().strftime("%Y-%m")

    run = None
    if form.validate_on_submit():
        try:
            mulai, akhir = service.periode_bulan(form.period.data)
            run = service.jalankan_batch(
                db_session,
                user,
                mulai,
                akhir,
                branch_id=form.branch_id.data or None,
            )
        except GalatDomain as galat:
            db_session.rollback()
            getattr(form, "period").errors.append(str(galat))
        else:
            db_session.commit()
            flash(
                f"Periode {form.period.data}: {run.created_count} invoice terbit, "
                f"{run.failed_count} gagal.",
                "sukses",
            )

    return render_template("billing/generate.html", form=form, run=run)


@bp.get("/billing/dashboard")
@require_role(*BACA)
def dashboard():
    """Papan angka khusus billing.

    Submenu ini berlencana "Segera" sejak M0. Isinya dirakit dari laporan yang
    sudah ada — tren pendapatan, umur piutang, penunggak terbesar — bukan
    query baru: dua sumber untuk angka yang sama akan berbeda pada suatu hari,
    dan yang berbeda adalah uang.
    """
    from app.core import rbac
    from app.core.money import format_rupiah_singkat
    from app.modules.dashboard import service as dashboard_service

    user = current_user()
    hari_ini = waktu.hari_ini()
    bulan = 12 if request.args.get("bulan") == "12" else 6
    baris_tunggakan = reports.tunggakan(db_session, user, hari_ini)
    ringkasan = service.ringkasan_billing(db_session, user)
    umur = reports.ringkasan_umur(baris_tunggakan)
    nada_umur = {"0-30": "info", "31-60": "waspada", "61-90": "antrean", ">90": "kritis"}

    penunggak = sorted(
        baris_tunggakan, key=lambda satu: satu["sisa"], reverse=True
    )[:10]

    return render_template(
        "billing/dashboard.html",
        ringkasan=ringkasan,
        # Koordinat grafik dihitung di sini; templat hanya menggambar. Dulu
        # yang dikirim baris mentahnya, dan grafiknya tampil kosong.
        tren=garis_ganda(
            reports.tren_pendapatan(db_session, user, hari_ini, bulan=bulan),
            [("tagihan", "Tagihan"), ("dibayar", "Dibayar")],
            kunci_label="bulan",
        ),
        bulan=bulan,
        umur=umur,
        total_piutang=sum(umur.values()),
        rekap=reports.rekap_periode(db_session, user, hari_ini.replace(day=1)),
        penunggak=penunggak,
        jumlah_menunggak=len(baris_tunggakan),
        invoice_terbaru=dashboard_service.invoice_terbaru(db_session, user, limit=6),
        hari_ini=hari_ini,
        cakupan="Semua cabang" if rbac.is_cross_branch(user) else "Cabang Anda",
        label_status=LABEL_STATUS_INVOICE,
        nada_status=NADA_STATUS_INVOICE,
        ruas_status=[
            {
                "label": LABEL_STATUS_INVOICE.get(kunci, kunci),
                "jumlah": jumlah,
                "nada": NADA_STATUS_INVOICE.get(kunci, "netral"),
                "href": url_for("billing.daftar", status=kunci),
                "teks": None,
            }
            for kunci, jumlah in ringkasan["per_status"].items()
        ],
        ruas_umur=[
            {
                "label": f"{ember} hari",
                "jumlah": int(nilai),
                "nada": nada_umur.get(ember, "netral"),
                "href": url_for("billing.laporan"),
                "teks": format_rupiah_singkat(nilai),
            }
            for ember, nilai in umur.items()
        ],
    )


@bp.get("/billing/<int:invoice_id>")
@require_role(*BACA)
def detail(invoice_id: int):
    user = current_user()
    invoice = service.ambil_invoice(db_session, user, invoice_id)
    # Lihat catatan di `daftar`: halaman ini juga tidak lagi menulis.
    return render_template(
        "billing/detail.html",
        **_konteks_detail(user, invoice),
        tab=request.args.get("tab", "ringkasan"),
        form_alasan=AlasanForm(),
        form_item=ItemManualForm(),
        form_bayar=_form_bayar(),
        form_hapus=HapusForm(),
    )


@bp.get("/billing/<int:invoice_id>/cetak")
@require_role(*BACA)
def cetak(invoice_id: int):
    """Halaman cetak tanpa sidebar, untuk dialog cetak peramban.

    Templat yang sama dipakai `invoice_pdf`. Dua templat untuk satu dokumen
    pasti berbeda pada suatu hari, dan yang berbeda adalah tagihan pelanggan.
    """
    user = current_user()
    invoice = service.ambil_invoice(db_session, user, invoice_id)
    return render_template("billing/cetak.html", **_konteks_detail(user, invoice))


def _peta_berkas_kop(setting) -> dict:
    """Path URL logo dan tanda tangan ke berkasnya di disk.

    WeasyPrint tidak boleh mengambilnya lewat HTTP: rutenya berpenjaga peran,
    dan permintaan dari dalam proses tidak membawa cookie siapa pun — hasilnya
    PDF tanpa gambar, bukan galat. Lihat `app/core/pdf.py`.
    """
    from flask import url_for as _url_for

    peta = {}
    if setting.logo_path:
        peta[_url_for("settings.berkas_kop", jenis="logo")] = setting.logo_path
    if setting.signature_path:
        peta[_url_for("settings.berkas_kop", jenis="tanda-tangan")] = (
            setting.signature_path
        )
    return peta


def _kirim_pdf(html: str, setting, nama_berkas: str):
    from flask import Response

    from app.core import pdf

    isi = pdf.dari_html(
        html, _peta_berkas_kop(setting), current_app.static_folder
    )
    return Response(
        isi,
        mimetype="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{nama_berkas}"'},
    )


@bp.get("/billing/<int:invoice_id>/invoice.pdf")
@require_role(*BACA)
def invoice_pdf(invoice_id: int):
    """Invoice sebagai PDF, dari templat cetak yang sama."""
    user = current_user()
    invoice = service.ambil_invoice(db_session, user, invoice_id)
    konteks = _konteks_detail(user, invoice)
    html = render_template("billing/cetak.html", **konteks)
    nama = (invoice.number or f"draft-{invoice.id}").replace("/", "-")
    return _kirim_pdf(html, konteks["setting"], f"{nama}.pdf")


@bp.get("/billing/pembayaran/<int:payment_id>/kwitansi")
@require_role(*BACA)
def kwitansi(payment_id: int):
    user = current_user()
    return render_template("billing/kwitansi.html", **_konteks_kwitansi(user, payment_id))


@bp.get("/billing/pembayaran/<int:payment_id>/kwitansi.pdf")
@require_role(*BACA)
def kwitansi_pdf(payment_id: int):
    user = current_user()
    konteks = _konteks_kwitansi(user, payment_id)
    html = render_template("billing/kwitansi.html", **konteks)
    return _kirim_pdf(
        html, konteks["setting"], f"kwitansi-{konteks['nomor_kwitansi']}.pdf"
    )


def _konteks_kwitansi(user, payment_id: int) -> dict:
    from app.core.money import terbilang
    from app.modules.customers.service import ambil_pelanggan
    from app.modules.settings import service as setting_service

    pembayaran = payments.ambil(db_session, user, payment_id)
    invoice = service.ambil_invoice(db_session, user, pembayaran.invoice_id)
    return {
        "pembayaran": pembayaran,
        "invoice": invoice,
        "pelanggan": ambil_pelanggan(db_session, user, invoice.customer_id),
        "dibayar": payments.total_dibayar(db_session, invoice.id),
        "sisa": payments.sisa_tagihan(db_session, invoice),
        "setting": setting_service.ambil_setting(db_session),
        "terbilang": terbilang(pembayaran.amount),
        # Nomor kwitansi diturunkan dari nomor invoice dan id pembayaran, bukan
        # penghitung baru: satu invoice bisa dibayar beberapa kali, dan
        # nomornya harus bisa ditelusuri balik ke pembayaran mana.
        "nomor_kwitansi": (
            f"{(invoice.number or 'DRAFT-' + str(invoice.id)).replace('/', '-')}"
            f"-{pembayaran.id}"
        ),
    }


def _konteks_detail(user, invoice) -> dict:
    from app.modules.customers.service import ambil_pelanggan
    from app.modules.settings import service as setting_service

    return {
        "invoice": invoice,
        "pembayaran": payments.daftar(db_session, user, invoice.id),
        "dibayar": payments.total_dibayar(db_session, invoice.id),
        "sisa": payments.sisa_tagihan(db_session, invoice),
        "pelanggan": ambil_pelanggan(db_session, user, invoice.customer_id),
        "item": service.daftar_item(db_session, user, invoice.id),
        "setting": setting_service.ambil_setting(db_session),
        "rekening": setting_service.daftar_rekening_aktif(db_session),
        "timeline": service.timeline_invoice(db_session, user, invoice.id),
        "label_status": LABEL_STATUS_INVOICE,
        "nada_status": NADA_STATUS_INVOICE,
    }


@bp.post("/billing/<int:invoice_id>/terbitkan")
@require_role(*TULIS_BILLING)
def terbitkan(invoice_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman invoice.", "bahaya")
        return redirect(url_for("billing.detail", invoice_id=invoice_id))

    try:
        service.terbitkan(db_session, current_user(), invoice_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.post("/billing/<int:invoice_id>/void")
@require_role(*VOID)
def void(invoice_id: int):
    form = AlasanForm()
    if form.validate_on_submit():
        try:
            service.void(db_session, current_user(), invoice_id, form.alasan.data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        for pesan in form.alasan.errors:
            flash(pesan, "bahaya")
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.post("/billing/<int:invoice_id>/pembetulan")
@require_role(*TULIS_BILLING)
def pembetulan(invoice_id: int):
    form = AlasanForm()
    if not form.validate_on_submit():
        for pesan in form.alasan.errors:
            flash(pesan, "bahaya")
        return redirect(url_for("billing.detail", invoice_id=invoice_id))

    try:
        pengganti = service.buat_pembetulan(
            db_session, current_user(), invoice_id, form.alasan.data
        )
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("billing.detail", invoice_id=invoice_id))

    db_session.commit()
    return redirect(url_for("billing.detail", invoice_id=pengganti.id))


@bp.post("/billing/<int:invoice_id>/item/baru")
@require_role(*TULIS_BILLING)
def item_tambah(invoice_id: int):
    form = ItemManualForm()
    if form.validate_on_submit():
        data = dict(form.data)
        data.pop("csrf_token", None)
        try:
            service.tambah_item_manual(db_session, current_user(), invoice_id, data)
        except GalatDomain as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
    else:
        for field in form:
            for pesan in field.errors:
                flash(f"{field.label.text}: {pesan}", "bahaya")
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.post("/billing/item/<int:item_id>/hapus")
@require_role(*TULIS_BILLING)
def item_hapus(item_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan hapus tidak sah. Coba lagi dari halaman invoice.", "bahaya")
        return redirect(url_for("billing.daftar"))

    try:
        invoice_id = service.hapus_item(db_session, current_user(), item_id)
    except GalatDomain as galat:
        db_session.rollback()
        flash(str(galat), "bahaya")
        return redirect(url_for("billing.daftar"))

    db_session.commit()
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


def _simpan_pdf_invoice(invoice_id: int) -> str | None:
    """Menyiapkan lampiran PDF untuk email invoice.

    Berkasnya ditulis ke disk, bukan dibawa di memori: pengiriman terjadi
    belakangan lewat `flask mail-flush`, bahkan mungkin di proses lain.

    Gagal mencetak **tidak** membatalkan pengiriman — email tanpa lampiran
    masih memberi tahu pelanggan bahwa tagihannya terbit, dan itu lebih baik
    daripada tidak ada email sama sekali.
    """
    import pathlib

    from app.core import pdf

    try:
        user = current_user()
        invoice = service.ambil_invoice(db_session, user, invoice_id)
        konteks = _konteks_detail(user, invoice)
        isi = pdf.dari_html(
            render_template("billing/cetak.html", **konteks),
            _peta_berkas_kop(konteks["setting"]),
            current_app.static_folder,
        )

        # Penulisan berkas ikut di dalam penjaga. `UPLOAD_DIR` yang penuh atau
        # tidak bisa ditulisi melempar OSError, dan di luar blok ini galat itu
        # akan naik ke rute — yang hanya menangkap GalatDomain — sehingga
        # emailnya tidak pernah masuk antrean sama sekali. Persis kebalikan
        # dari yang dijanjikan docstring ini.
        folder = pathlib.Path(current_app.config["UPLOAD_DIR"]) / "invoice-pdf"
        folder.mkdir(parents=True, exist_ok=True)
        nama = (invoice.number or f"draft-{invoice.id}").replace("/", "-")
        berkas = folder / f"{nama}.pdf"
        berkas.write_bytes(isi)
    except Exception:  # noqa: BLE001
        current_app.logger.exception("Gagal menyiapkan PDF lampiran invoice")
        return None

    return str(berkas)


def _buang_lampiran(path: str | None) -> None:
    import pathlib

    if not path:
        return
    try:
        pathlib.Path(path).unlink(missing_ok=True)
    except OSError:
        current_app.logger.warning("Lampiran PDF gagal dibuang: %s", path)


@bp.post("/billing/<int:invoice_id>/kirim")
@require_role(*TULIS_BILLING)
def kirim_email(invoice_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman invoice.", "bahaya")
        return redirect(url_for("billing.detail", invoice_id=invoice_id))

    lampiran = _simpan_pdf_invoice(invoice_id)
    try:
        service.antre_email_invoice(
            db_session,
            current_user(),
            invoice_id,
            current_app.config["APP_VERSION"],
            lampiran_path=lampiran,
        )
    except GalatDomain as galat:
        db_session.rollback()
        # Berkas PDF sudah terlanjur ditulis sebelum antrean divalidasi;
        # kalau antreannya batal, berkasnya tidak boleh tertinggal selamanya —
        # `bersih-sementara` sengaja tidak menyentuh folder ini.
        _buang_lampiran(lampiran)
        flash(str(galat), "bahaya")
    else:
        db_session.commit()
        flash(
            "Invoice masuk antrean email"
            + (
                " beserta lampiran PDF."
                if lampiran
                # Dikatakan apa adanya. Operator yang mengira pelanggan
                # menerima PDF padahal tidak akan tahu belakangan, dari
                # pelanggannya.
                else ", tetapi lampiran PDF gagal dibuat dan tidak ikut."
            )
            + " Pengiriman dilakukan proses terpisah.",
            "sukses" if lampiran else "peringatan",
        )
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.post("/billing/<int:invoice_id>/bayar")
@require_role(*TULIS_BILLING)
def bayar(invoice_id: int):
    from app.modules.billing.forms import PembayaranForm

    form = PembayaranForm()
    form.bank_account_id.choices = [(0, "— Tanpa rekening —")] + [
        (bank.id, f"{bank.bank_name} {bank.account_number}")
        for bank in _rekening_pilihan()
    ]

    if form.validate_on_submit():
        data = dict(form.data)
        data.pop("csrf_token", None)
        berkas = data.pop("bukti", None)
        if not data.get("bank_account_id"):
            data["bank_account_id"] = None
        try:
            payments.catat(
                db_session,
                current_user(),
                invoice_id,
                data,
                berkas=berkas.stream if berkas else None,
                nama_berkas=berkas.filename if berkas else None,
                upload_dir=current_app.config["UPLOAD_DIR"],
            )
        except (GalatDomain, FileError) as galat:
            db_session.rollback()
            flash(str(galat), "bahaya")
        else:
            db_session.commit()
            flash("Pembayaran tercatat.", "sukses")
    else:
        for field in form:
            for pesan in field.errors:
                flash(f"{field.label.text}: {pesan}", "bahaya")

    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.post("/billing/pembayaran/<int:payment_id>/batal")
@require_role(*TULIS_BILLING)
def pembayaran_batal(payment_id: int):
    if not HapusForm().validate_on_submit():
        flash("Permintaan tidak sah. Coba lagi dari halaman invoice.", "bahaya")
        return redirect(url_for("billing.daftar"))

    invoice_id = payments.batalkan(db_session, current_user(), payment_id)
    db_session.commit()
    return redirect(url_for("billing.detail", invoice_id=invoice_id))


@bp.get("/billing/pembayaran/<int:payment_id>/bukti")
@require_role(*BACA)
def bukti(payment_id: int):
    pembayaran = payments.ambil(db_session, current_user(), payment_id)
    if not pembayaran.proof_path:
        raise TidakDitemukan("Pembayaran ini tidak punya bukti terunggah.")
    # Tipe berkas HARUS mengikuti yang diunggah. Sebelumnya rute ini selalu
    # mengaku PDF, jadi bukti transfer berformat JPG terunduh sebagai .pdf dan
    # tidak bisa dibuka sama sekali.
    import pathlib

    mime = mime_dari_path(pembayaran.proof_path)
    akhiran = pathlib.Path(pembayaran.proof_path).suffix or ".bin"
    return sajikan(
        pembayaran.proof_path,
        f"bukti-{payment_id}{akhiran}",
        mime,
        current_app.config["UPLOAD_DIR"],
    )


@bp.get("/pembayaran")
@require_role(*BACA)
def pembayaran_daftar():
    user = current_user()
    halaman = payments.daftar_semua(
        db_session,
        user,
        page=request.args.get("page", 1, type=int),
        per_page=per_halaman_dari(request),
        q=request.args.get("q") or None,
    )
    return render_template(
        "billing/pembayaran.html",
        halaman=halaman,
        ringkasan=payments.ringkasan_pembayaran(db_session, user),
        q=request.args.get("q") or "",
        label_status=LABEL_STATUS_INVOICE,
        nada_status=NADA_STATUS_INVOICE,
    )


@bp.route("/pembayaran/rekonsiliasi", methods=["GET", "POST"])
@require_role(*TULIS_BILLING)
def rekonsiliasi():
    """Mencocokkan mutasi bank (CSV) ke invoice terbuka, lalu mencatat yang dipilih."""
    from app.modules.billing import rekonsiliasi as modul
    from app.modules.settings import service as setting_service

    user = current_user()
    form = HapusForm()
    rekening = setting_service.daftar_rekening_aktif(db_session)
    rekening_id = request.form.get("bank_account_id", type=int) or None
    hasil = None
    ringkasan = None

    if request.method == "POST":
        if not form.validate():
            flash("Permintaan tidak sah. Muat ulang halaman lalu coba lagi.", "bahaya")
        elif request.form.get("aksi") == "catat":
            pilihan = modul.urai_pilihan(request.form)
            if not pilihan:
                flash("Belum ada baris yang dicentang.", "bahaya")
            else:
                ringkasan = modul.catat_terpilih(db_session, user, pilihan, rekening_id)
                db_session.commit()
                if ringkasan["dicatat"]:
                    flash(f"{len(ringkasan['dicatat'])} pembayaran dicatat.", "sukses")
        else:
            berkas = request.files.get("berkas")
            try:
                if berkas is None or not berkas.filename:
                    raise modul.BerkasMutasiTidakSah("berkas", "Pilih berkas CSV mutasi bank.")
                isi = berkas.read(5 * 1024 * 1024 + 1)
                if len(isi) > 5 * 1024 * 1024:
                    raise modul.BerkasMutasiTidakSah("berkas", "Berkas lebih besar dari 5 MB.")
                hasil = modul.cocokkan(db_session, user, modul.urai_csv(isi))
            except GalatDomain as galat:
                flash(str(galat), "bahaya")

    return render_template(
        "billing/rekonsiliasi.html",
        form=form,
        rekening=rekening,
        rekening_id=rekening_id,
        hasil=hasil,
        ringkasan=ringkasan,
    )


@bp.get("/laporan")
@require_role(*BACA_LAPORAN)
def laporan():
    from datetime import date as _date

    user = current_user()
    mulai = request.args.get("mulai", type=_date.fromisoformat) or waktu.awal_bulan()
    akhir = request.args.get("akhir", type=_date.fromisoformat) or waktu.hari_ini()

    baris_tunggakan = reports.tunggakan(db_session, user)
    return render_template(
        "billing/laporan.html",
        tunggakan=baris_tunggakan,
        umur=reports.ringkasan_umur(baris_tunggakan),
        pendapatan=reports.pendapatan_per_cabang(db_session, user, mulai, akhir),
        rekap=reports.rekap_periode(db_session, user, waktu.awal_bulan()),
        mulai=mulai,
        akhir=akhir,
    )


@bp.get("/laporan/tunggakan.csv")
@require_role(*BACA_LAPORAN)
def laporan_tunggakan_csv():
    isi = reports.csv_tunggakan(reports.tunggakan(db_session, current_user()))
    return _unduh_csv(isi, "tunggakan.csv")


@bp.get("/laporan/pendapatan.csv")
@require_role(*BACA_LAPORAN)
def laporan_pendapatan_csv():
    from datetime import date as _date

    mulai = request.args.get("mulai", type=_date.fromisoformat) or waktu.awal_bulan()
    akhir = request.args.get("akhir", type=_date.fromisoformat) or waktu.hari_ini()
    isi = reports.csv_pendapatan(
        reports.pendapatan_per_cabang(db_session, current_user(), mulai, akhir)
    )
    return _unduh_csv(isi, "pendapatan.csv")


def _unduh_csv(isi: str, nama: str):
    from flask import Response

    return Response(
        isi,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nama}"'},
    )


def _rekening_pilihan():
    from app.modules.settings import service as setting_service

    return setting_service.daftar_rekening_aktif(db_session)


def _form_bayar():
    from app.modules.billing.forms import PembayaranForm

    form = PembayaranForm()
    form.bank_account_id.choices = [(0, "— Tanpa rekening —")] + [
        (bank.id, f"{bank.bank_name} {bank.account_number}")
        for bank in _rekening_pilihan()
    ]
    return form
