"""Perhitungan isi invoice.

Seluruh fungsi di sini **murni**: tidak menyentuh sesi, tidak menulis apa pun,
dan bisa dipanggil berulang tanpa efek samping. Itu disengaja — angka uang
harus bisa diuji di batas bulan tanpa basis data, dan halaman pratinjau M2b
harus menampilkan angka yang persis sama dengan yang nanti diterbitkan.

Menaikkan `terms_billed` cicilan **bukan** tugas modul ini; itu terjadi saat
penerbitan (`billing/service.py:terbitkan`), supaya menghitung ulang tidak
menggeser cicilan pelanggan.
"""

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal

from app.core.money import apply_percent, prorate, to_money, total as jumlahkan
from app.modules.customers.subscription_service import harga_efektif, nominal_termin

NOL = Decimal("0.00")

_BULAN_SINGKAT = (
    "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
    "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
)


def _tanggal_id(nilai: date) -> str:
    return f"{nilai.day} {_BULAN_SINGKAT[nilai.month - 1]} {nilai.year}"


@dataclass(frozen=True)
class BarisItem:
    source: str
    description: str
    unit_price: Decimal
    amount: Decimal
    qty: int = 1
    discount: Decimal = NOL
    subdescription: str | None = None
    period_start: date | None = None
    period_end: date | None = None
    is_prorated: bool = False
    subscription_id: int | None = None


@dataclass(frozen=True)
class HasilInvoice:
    items: list[BarisItem] = field(default_factory=list)
    subtotal: Decimal = NOL
    discount_total: Decimal = NOL
    ppn_rate: Decimal = NOL
    ppn_amount: Decimal = NOL
    total: Decimal = NOL


def hari_dalam_periode(period_start: date, period_end: date) -> int:
    return (period_end - period_start).days + 1


def _mulai_efektif(langganan) -> date | None:
    """Tanggal langganan mulai ditagih.

    `activated_at` menang atas `started_at`: tanggal mulai adalah janji
    pemasangan, sedangkan aktivasi adalah saat layanan benar-benar menyala —
    dan pelanggan tidak boleh ditagih untuk hari sebelum layanannya hidup.
    """
    return langganan.activated_at or langganan.started_at


def hari_aktif(langganan, period_start: date, period_end: date) -> int:
    """Berapa hari langganan aktif di dalam periode ini.

    Nol berarti tidak ditagih sama sekali — mis. sudah berhenti sebelum
    periode dimulai, atau baru mulai setelah periode berakhir.
    """
    mulai = max(_mulai_efektif(langganan) or period_start, period_start)

    berhenti = period_end
    if langganan.status == "terminasi" and langganan.terminated_at is not None:
        berhenti = min(langganan.terminated_at, period_end)

    if mulai > berhenti:
        return 0
    return (berhenti - mulai).days + 1


def _diskon_baris(langganan, harga: Decimal) -> Decimal:
    """Nominal diskon untuk satu baris.

    Dijepit di harga: diskon yang melampaui harga sudah ditolak sejak M1c,
    tetapi data yang telanjur ada sebelum penjaga itu tidak boleh menghasilkan
    baris invoice negatif.
    """
    if not langganan.discount_kind or langganan.discount_value is None:
        return NOL

    if langganan.discount_kind == "persen":
        potongan = apply_percent(harga, langganan.discount_value)
    else:
        potongan = to_money(langganan.discount_value)

    return to_money(min(potongan, harga))


def baris_langganan(langganan, paket, period_start: date, period_end: date):
    """Baris biaya langganan, diprorata bila perlu.

    Mengembalikan `None` bila langganan tidak aktif sehari pun di periode ini.
    Langganan `suspend` tetap ditagih penuh — isolir karena tunggakan tidak
    menghapus kewajiban (spesifikasi §7).
    """
    hari = hari_aktif(langganan, period_start, period_end)
    if hari == 0:
        return None

    sehari_penuh = hari_dalam_periode(period_start, period_end)
    harga_bulanan = harga_efektif(langganan, paket)
    prorata = hari < sehari_penuh

    harga = (
        prorate(harga_bulanan, hari, sehari_penuh) if prorata else to_money(harga_bulanan)
    )
    potongan = _diskon_baris(langganan, harga)

    mulai = max(_mulai_efektif(langganan) or period_start, period_start)
    berhenti = period_end
    if langganan.status == "terminasi" and langganan.terminated_at is not None:
        berhenti = min(langganan.terminated_at, period_end)

    keterangan = f"{langganan.service_no}"
    if prorata:
        keterangan += f" · prorata {_tanggal_id(mulai)} – {_tanggal_id(berhenti)} ({hari} hari)"

    return BarisItem(
        source="langganan",
        description=paket.name,
        subdescription=keterangan,
        unit_price=harga,
        discount=potongan,
        amount=to_money(harga - potongan),
        period_start=mulai,
        period_end=berhenti,
        is_prorated=prorata,
        subscription_id=langganan.id,
    )


def baris_langganan_bersegmen(
    langganan, paket, period_start: date, period_end: date, perubahan: list
) -> list[BarisItem]:
    """Baris langganan untuk periode yang memuat perubahan harga/paket.

    `perubahan` adalah perubahan yang berlaku di tengah rentang aktif, urut
    tanggal. Rentang dipecah di tiap tanggal berlaku: potongan sebelum sebuah
    perubahan memakai tagihan lama yang dibekukan di perubahan itu, dan
    potongan terakhir memakai harga sekarang. Tiap potongan diprorata
    terhadap jumlah hari periode, sama seperti prorata mulai/berhenti.
    """
    utuh = baris_langganan(langganan, paket, period_start, period_end)
    if utuh is None or not perubahan:
        return [utuh] if utuh is not None else []

    sehari_penuh = hari_dalam_periode(period_start, period_end)
    mulai, berhenti = utuh.period_start, utuh.period_end
    baris: list[BarisItem] = []
    for satu in perubahan:
        akhir = satu.effective_date - timedelta(days=1)
        hari = (akhir - mulai).days + 1
        if hari > 0:
            nilai = prorate(satu.old_amount, hari, sehari_penuh)
            baris.append(
                BarisItem(
                    source="langganan",
                    description=paket.name,
                    subdescription=(
                        f"{langganan.service_no} · tarif sebelum perubahan · prorata "
                        f"{_tanggal_id(mulai)} – {_tanggal_id(akhir)} ({hari} hari)"
                    ),
                    unit_price=nilai,
                    amount=nilai,
                    period_start=mulai,
                    period_end=akhir,
                    is_prorated=True,
                    subscription_id=langganan.id,
                )
            )
        mulai = max(mulai, satu.effective_date)

    hari = (berhenti - mulai).days + 1
    harga = prorate(harga_efektif(langganan, paket), hari, sehari_penuh)
    potongan = _diskon_baris(langganan, harga)
    baris.append(
        BarisItem(
            source="langganan",
            description=paket.name,
            subdescription=(
                f"{langganan.service_no} · tarif baru · prorata "
                f"{_tanggal_id(mulai)} – {_tanggal_id(berhenti)} ({hari} hari)"
            ),
            unit_price=harga,
            discount=potongan,
            amount=to_money(harga - potongan),
            period_start=mulai,
            period_end=berhenti,
            is_prorated=True,
            subscription_id=langganan.id,
        )
    )
    return baris


def baris_addon(addon, period_start: date, period_end: date) -> BarisItem:
    """Biaya tambahan berulang. Tidak diprorata — nilainya per periode."""
    return BarisItem(
        source="addon",
        description=addon.description,
        qty=addon.qty,
        unit_price=to_money(addon.unit_price),
        amount=to_money(to_money(addon.unit_price) * addon.qty),
        period_start=period_start,
        period_end=period_end,
        subscription_id=addon.subscription_id,
    )


def baris_cicilan(cicilan, period_start: date, period_end: date):
    """Satu termin cicilan, atau `None` bila sudah lunas.

    Nominalnya lewat `nominal_termin`, sehingga termin terakhir menyerap
    selisih pembulatan dan penjumlahan seluruh termin persis sama dengan
    biaya yang disepakati.
    """
    if cicilan.terms_billed >= cicilan.terms:
        return None

    termin_ke = cicilan.terms_billed + 1
    nominal = nominal_termin(cicilan, termin_ke)

    return BarisItem(
        source="cicilan",
        description=f"{cicilan.description} (Amortisasi)",
        subdescription=f"cicilan bulan ke {termin_ke} dari {cicilan.terms}",
        unit_price=nominal,
        amount=nominal,
        period_start=period_start,
        period_end=period_end,
        subscription_id=cicilan.subscription_id,
    )


def rakit_invoice(
    baris: list[BarisItem], ppn_rate: Decimal, ppn_exempt: bool
) -> HasilInvoice:
    """Menjumlahkan baris menjadi angka invoice.

    Total adalah penjumlahan baris yang **sudah** dibulatkan, ditambah PPN
    yang dibulatkan sekali dari dasar pengenaannya (spesifikasi §7).
    """
    subtotal = jumlahkan(b.unit_price * b.qty for b in baris)
    diskon = jumlahkan(b.discount for b in baris)
    dasar = jumlahkan(b.amount for b in baris)

    tarif = NOL if ppn_exempt else to_money(ppn_rate)
    pajak = apply_percent(dasar, tarif) if tarif else NOL

    return HasilInvoice(
        items=list(baris),
        subtotal=subtotal,
        discount_total=diskon,
        ppn_rate=tarif,
        ppn_amount=pajak,
        total=to_money(dasar + pajak),
    )
