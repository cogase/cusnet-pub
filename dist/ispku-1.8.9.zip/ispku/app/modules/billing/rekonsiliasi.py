"""Rekonsiliasi pembayaran dari berkas mutasi bank (CSV).

Alurnya dua langkah dan tidak menyimpan apa pun di antaranya: berkas diurai
dan dicocokkan ke invoice terbuka, hasilnya ditampilkan, lalu operator
mencentang baris yang benar dan baru saat itulah pembayaran dicatat lewat
`payments.catat` — jadi semua penjaga pembayaran (sisa tagihan, status
invoice, hak akses cabang) tetap berlaku.

Bentuk CSV tiap bank berbeda, jadi pengurainya menebak dari judul kolom,
bukan dari nama bank: kolom tanggal, kolom keterangan, dan kolom nominal
(kredit terpisah, atau satu kolom jumlah berpenanda CR/DB).
"""

import csv
import io
import re
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from sqlalchemy import func, select

from app.core import rbac, waktu
from app.core.errors import GalatDomain
from app.core.money import to_money
from app.modules.billing import payments
from app.modules.billing.models import Invoice, Payment
from app.modules.customers.models import Customer

BATAS_BARIS = 2000
STATUS_TERBUKA = ("issued", "partial", "overdue")

_KOLOM = {
    "tanggal": ("tanggal", "tgl", "date", "posting", "waktu"),
    "keterangan": ("keterangan", "uraian", "deskripsi", "description", "remark", "berita", "detail"),
    "kredit": ("kredit", "credit", "masuk", "cr"),
    "debit": ("debit", "debet", "keluar", "db"),
    "jumlah": ("jumlah", "amount", "nominal", "mutasi"),
    "jenis": ("jenis", "type", "d/k", "dk", "db/cr"),
}
_BULAN = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "mei": 5, "may": 5, "jun": 6, "jul": 7,
    "agu": 8, "agt": 8, "aug": 8, "sep": 9, "okt": 10, "oct": 10, "nov": 11,
    "des": 12, "dec": 12,
}


class BerkasMutasiTidakSah(GalatDomain):
    """Berkas tidak bisa dibaca sebagai mutasi bank."""


@dataclass(frozen=True)
class BarisMutasi:
    nomor: int
    tanggal: date
    keterangan: str
    jumlah: Decimal


def _nominal(teks: str) -> Decimal | None:
    """Angka dari "1.500.000,00", "1,500,000.00", "Rp 1.500.000", atau "1500000"."""
    bersih = re.sub(r"[^\d,.\-]", "", teks or "")
    if not bersih or not re.search(r"\d", bersih):
        return None
    titik, koma = bersih.rfind("."), bersih.rfind(",")
    if titik >= 0 and koma >= 0:
        desimal = "." if titik > koma else ","
    elif koma >= 0:
        # Satu koma dengan 1-2 angka di belakangnya = desimal; selain itu ribuan.
        desimal = "," if bersih.count(",") == 1 and len(bersih) - koma - 1 in (1, 2) else None
    elif titik >= 0:
        desimal = "." if bersih.count(".") == 1 and len(bersih) - titik - 1 in (1, 2) else None
    else:
        desimal = None
    if desimal:
        utuh, pecahan = bersih.rsplit(desimal, 1)
        bersih = re.sub(r"[,.]", "", utuh) + "." + pecahan
    else:
        bersih = re.sub(r"[,.]", "", bersih)
    try:
        return to_money(Decimal(bersih))
    except (InvalidOperation, ValueError):
        return None


def _tanggal(teks: str, tahun_bawaan: int) -> date | None:
    teks = (teks or "").strip().strip("'\"")
    if not teks:
        return None
    teks = teks.split(" ")[0] if re.match(r"^\d{1,4}[/\-.]\d", teks) else teks
    cocok = re.match(r"^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$", teks)
    if cocok:
        tahun, bulan, hari = (int(x) for x in cocok.groups())
    else:
        cocok = re.match(r"^(\d{1,2})[/\-.](\d{1,2})(?:[/\-.](\d{2,4}))?$", teks)
        if cocok:
            hari, bulan = int(cocok.group(1)), int(cocok.group(2))
            tahun = int(cocok.group(3)) if cocok.group(3) else tahun_bawaan
            if tahun < 100:
                tahun += 2000
        else:
            cocok = re.match(r"^(\d{1,2})[\s\-]([A-Za-z]{3})[A-Za-z]*[\s\-](\d{2,4})", teks)
            if not cocok or cocok.group(2).lower() not in _BULAN:
                return None
            hari, bulan, tahun = int(cocok.group(1)), _BULAN[cocok.group(2).lower()], int(cocok.group(3))
            if tahun < 100:
                tahun += 2000
    try:
        return date(tahun, bulan, hari)
    except ValueError:
        return None


def _peta_kolom(judul: list[str]) -> dict[str, int]:
    peta: dict[str, int] = {}
    for indeks, nama in enumerate(judul):
        bersih = re.sub(r"[^a-z/]", "", (nama or "").lower())
        if not bersih:
            continue
        for kunci, calon in _KOLOM.items():
            if kunci in peta:
                continue
            if bersih in calon or any(bersih.startswith(c) for c in calon if len(c) > 2):
                peta[kunci] = indeks
                break
    return peta


def urai_csv(isi: bytes) -> list[BarisMutasi]:
    """Mengurai mutasi bank menjadi baris uang MASUK saja."""
    try:
        teks = isi.decode("utf-8-sig")
    except UnicodeDecodeError:
        teks = isi.decode("latin-1")
    if not teks.strip():
        raise BerkasMutasiTidakSah("berkas", "Berkas kosong.")
    contoh = teks[:4096]
    pemisah = max((";", ",", "\t", "|"), key=contoh.count)
    baris = [b for b in csv.reader(io.StringIO(teks), delimiter=pemisah) if any(s.strip() for s in b)]

    # Judul kolom tidak selalu di baris pertama: ekspor bank sering diawali
    # nama rekening dan periode.
    peta, mulai = {}, 0
    for indeks, satu in enumerate(baris[:30]):
        calon = _peta_kolom(satu)
        if "tanggal" in calon and ("kredit" in calon or "jumlah" in calon):
            peta, mulai = calon, indeks + 1
            break
    if not peta:
        raise BerkasMutasiTidakSah(
            "berkas",
            "Judul kolom tidak dikenali. Berkas harus punya kolom tanggal dan kolom "
            "kredit (atau jumlah), mis. Tanggal;Keterangan;Debit;Kredit.",
        )

    tahun = waktu.hari_ini().year
    hasil: list[BarisMutasi] = []
    for nomor, satu in enumerate(baris[mulai:], start=mulai + 1):
        def sel(kunci):
            indeks = peta.get(kunci)
            return satu[indeks].strip() if indeks is not None and indeks < len(satu) else ""

        tanggal = _tanggal(sel("tanggal"), tahun)
        if tanggal is None:
            continue
        if "kredit" in peta:
            jumlah = _nominal(sel("kredit"))
        else:
            mentah = sel("jumlah")
            penanda = (sel("jenis") + " " + mentah).upper()
            if re.search(r"\b(DB|DR|D)\b", penanda) or mentah.strip().startswith("-"):
                continue
            jumlah = _nominal(mentah)
        if jumlah is None or jumlah <= 0:
            continue
        hasil.append(BarisMutasi(nomor, tanggal, sel("keterangan")[:500], jumlah))
        if len(hasil) > BATAS_BARIS:
            raise BerkasMutasiTidakSah(
                "berkas", f"Berkas memuat lebih dari {BATAS_BARIS} baris uang masuk. Pecah per periode."
            )
    if not hasil:
        raise BerkasMutasiTidakSah("berkas", "Tidak ada baris uang masuk yang bisa dibaca dari berkas ini.")
    return hasil


def _rapat(teks: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (teks or "").upper())


def _invoice_terbuka(sesi, user) -> list[dict]:
    dibayar = (
        select(Payment.invoice_id, func.coalesce(func.sum(Payment.amount), 0).label("dibayar"))
        .group_by(Payment.invoice_id)
        .subquery()
    )
    query = (
        select(Invoice, Customer, func.coalesce(dibayar.c.dibayar, 0))
        .join(Customer, Invoice.customer_id == Customer.id)
        .outerjoin(dibayar, dibayar.c.invoice_id == Invoice.id)
        .where(Invoice.status.in_(STATUS_TERBUKA), Invoice.number.is_not(None))
        .order_by(Invoice.due_at, Invoice.id)
    )
    return [
        {"invoice": invoice, "pelanggan": pelanggan, "sisa": to_money(invoice.total - sudah)}
        for invoice, pelanggan, sudah in sesi.execute(rbac.scoped(query, user, Invoice)).all()
        if invoice.total - sudah > 0
    ]


def cocokkan(sesi, user, mutasi: list[BarisMutasi]) -> list[dict]:
    """Memasangkan tiap baris mutasi dengan invoice terbuka.

    `keadaan`: "nomor" (nomor invoice tertulis di keterangan), "nominal"
    (tepat satu invoice bersisa sama persis), "ambigu" (beberapa invoice
    bersisa sama — operator yang memilih), "tercatat" (pembayaran yang sama
    sudah ada), atau "tidak" (tidak ada yang cocok). Satu invoice tidak
    ditawarkan ke dua baris sekaligus.
    """
    terbuka = _invoice_terbuka(sesi, user)
    tercatat = {
        (paid_at, to_money(amount), (reference or "").strip())
        for paid_at, amount, reference in sesi.execute(
            select(Payment.paid_at, Payment.amount, Payment.reference).where(
                Payment.paid_at.in_({b.tanggal for b in mutasi})
            )
        ).all()
    }
    terpakai: set[int] = set()
    hasil = []
    for baris in mutasi:
        butir = {"baris": baris, "keadaan": "tidak", "calon": [], "pilihan": None}
        if (baris.tanggal, baris.jumlah, baris.keterangan[:120].strip()) in tercatat:
            butir["keadaan"] = "tercatat"
            hasil.append(butir)
            continue
        rapat = _rapat(baris.keterangan)
        bebas = [t for t in terbuka if t["invoice"].id not in terpakai]
        bernomor = [
            t for t in bebas
            if len(_rapat(t["invoice"].number)) >= 6 and _rapat(t["invoice"].number) in rapat
            and baris.jumlah <= t["sisa"]
        ]
        if len(bernomor) == 1:
            butir.update(keadaan="nomor", calon=bernomor, pilihan=bernomor[0])
        else:
            senilai = [t for t in bebas if t["sisa"] == baris.jumlah]
            # Nama customer di keterangan memecah seri antar invoice senilai.
            if len(senilai) > 1:
                bernama = [
                    t for t in senilai
                    if len(_rapat(t["pelanggan"].name)) >= 5 and _rapat(t["pelanggan"].name) in rapat
                ]
                if len(bernama) == 1:
                    senilai = bernama
            if len(senilai) == 1:
                butir.update(keadaan="nominal", calon=senilai, pilihan=senilai[0])
            elif senilai:
                butir.update(keadaan="ambigu", calon=senilai[:10])
        if butir["pilihan"]:
            terpakai.add(butir["pilihan"]["invoice"].id)
        hasil.append(butir)
    return hasil


def catat_terpilih(sesi, aktor, pilihan: list[dict], bank_account_id: int | None) -> dict:
    """Mencatat baris yang dicentang operator sebagai pembayaran transfer.

    Tiap baris dicatat sendiri: satu baris yang ditolak (mis. invoice sudah
    lunas oleh orang lain sementara layar ini terbuka) tidak membatalkan yang
    lain, dan alasannya dikembalikan untuk ditampilkan.
    """
    dicatat, ditolak = [], []
    for satu in pilihan:
        try:
            with sesi.begin_nested():
                pembayaran = payments.catat(
                    sesi, aktor, satu["invoice_id"],
                    {
                        "amount": satu["jumlah"],
                        "paid_at": satu["tanggal"],
                        "method": "transfer",
                        "bank_account_id": bank_account_id,
                        "reference": (satu.get("keterangan") or "")[:120].strip() or None,
                        "note": "Dicatat dari rekonsiliasi mutasi bank.",
                    },
                )
            dicatat.append(pembayaran)
        except GalatDomain as galat:
            ditolak.append({"baris": satu, "alasan": str(galat)})
    return {"dicatat": dicatat, "ditolak": ditolak}


def urai_pilihan(form) -> list[dict]:
    """Baris yang dicentang dari formulir hasil pencocokan."""
    pilihan = []
    for indeks in form.getlist("pilih"):
        try:
            pilihan.append(
                {
                    "invoice_id": int(form[f"invoice_{indeks}"]),
                    "jumlah": to_money(Decimal(form[f"jumlah_{indeks}"])),
                    "tanggal": datetime.strptime(form[f"tanggal_{indeks}"], "%Y-%m-%d").date(),
                    "keterangan": form.get(f"keterangan_{indeks}", ""),
                }
            )
        except (KeyError, ValueError, InvalidOperation):
            continue
    return pilihan
