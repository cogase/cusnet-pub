"""Tiket gangguan dan permintaan (spesifikasi §12, M3).

Tiket punya cabang sendiri (`branch_id`) alih-alih menurunkannya dari
pelanggan. Dua alasan: tiket boleh tidak punya pelanggan sama sekali (gangguan
backbone, permintaan internal), dan penyaringan cabang harus bisa dilakukan
tanpa join ke tabel pelanggan di setiap query.
"""

from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import TimestampMixin, enum_check

# Urutan penting: dipakai sebagai urutan tampil dan perbandingan "lebih
# mendesak" di beberapa tempat.
PRIORITAS: tuple[str, ...] = ("rendah", "sedang", "tinggi", "kritis")

# `pending` berarti menunggu pihak lain (pelanggan, vendor) — jamnya tetap
# berjalan untuk SLA penyelesaian, karena menghentikannya membuat tiket bisa
# diparkir selamanya tanpa pernah tampak terlambat.
STATUS_TIKET: tuple[str, ...] = ("baru", "proses", "pending", "selesai", "ditutup")

# Status yang dianggap sudah tidak dikerjakan lagi.
STATUS_TUTUP: tuple[str, ...] = ("selesai", "ditutup")


class TicketCategory(Base, TimestampMixin):
    """Kategori tiket beserta SLA-nya.

    SLA disimpan di kategori, bukan di tiket: mengubah janji layanan tidak
    boleh mengubah tenggat tiket yang sudah berjalan, jadi tenggatnya dihitung
    sekali saat tiket dibuat dan disimpan di tiketnya.
    """

    __tablename__ = "ticket_category"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(20), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    default_priority: Mapped[str] = mapped_column(
        String(20), nullable=False, default="sedang"
    )
    sla_response_hours: Mapped[int] = mapped_column(Integer, nullable=False, default=4)
    sla_resolve_hours: Mapped[int] = mapped_column(Integer, nullable=False, default=48)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class Ticket(Base, TimestampMixin):
    __tablename__ = "ticket"
    __table_args__ = (
        Index("ix_ticket_branch_status", "branch_id", "status"),
        Index(
            "ix_ticket_number_trgm",
            "number",
            postgresql_using="gin",
            postgresql_ops={"number": "gin_trgm_ops"},
        ),
        Index(
            "ix_ticket_title_trgm",
            "title",
            postgresql_using="gin",
            postgresql_ops={"title": "gin_trgm_ops"},
        ),
        Index("ix_ticket_customer", "customer_id"),
        Index("ix_ticket_subscription", "subscription_id"),
        enum_check("ck_ticket_status", "status", STATUS_TIKET),
        enum_check("ck_ticket_prioritas", "priority", PRIORITAS),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    number: Mapped[str] = mapped_column(String(40), nullable=False, unique=True)
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)

    # Pelanggan dan langganan opsional: gangguan backbone tidak menempel ke
    # siapa pun, dan tiket bisa dibuka sebelum diketahui layanan mana yang
    # terdampak.
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customer.id"))
    subscription_id: Mapped[int | None] = mapped_column(ForeignKey("subscription.id"))

    # Sumber gangguan di jaringan. Terisi berarti gangguan massal: semua
    # layanan yang lewat site/perangkat ini dicatat di `ticket_impact`.
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id", ondelete="SET NULL"))
    device_id: Mapped[int | None] = mapped_column(
        ForeignKey("device.id", ondelete="SET NULL")
    )

    category_id: Mapped[int] = mapped_column(
        ForeignKey("ticket_category.id"), nullable=False
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    priority: Mapped[str] = mapped_column(String(20), nullable=False, default="sedang")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="baru")

    assigned_to_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    opened_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))

    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    # Tenggat dibekukan saat tiket dibuat — lihat catatan di TicketCategory.
    response_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolve_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    first_response_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Kapan kabar "lewat SLA" diantrekan; kosong berarti belum pernah.
    sla_notified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Sebab penutupan ditulis bebas; dipakai laporan gangguan berulang.
    resolution: Mapped[str | None] = mapped_column(Text)


class TicketImpact(Base, TimestampMixin):
    """Layanan yang terdampak satu tiket gangguan massal.

    Dibekukan saat tiket dibuka: alokasi port yang berubah minggu depan tidak
    boleh mengubah daftar layanan yang terdampak gangguan hari ini.
    """

    __tablename__ = "ticket_impact"
    __table_args__ = (
        UniqueConstraint("ticket_id", "subscription_id", name="uq_ticket_impact"),
        Index("ix_ticket_impact_subscription", "subscription_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("ticket.id", ondelete="CASCADE"), nullable=False
    )
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False
    )


class TicketComment(Base, TimestampMixin):
    """Komentar tiket.

    `is_internal` memisahkan catatan teknis dari yang boleh dibaca pelanggan.
    Portal pelanggan belum ada, tetapi pemisahannya dibuat sejak sekarang:
    menambahkannya belakangan berarti menerka ulang mana dari ribuan komentar
    lama yang sebenarnya internal.
    """

    __tablename__ = "ticket_comment"
    __table_args__ = (Index("ix_ticket_comment_ticket", "ticket_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("ticket.id", ondelete="CASCADE"), nullable=False
    )
    user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
    body: Mapped[str] = mapped_column(Text, nullable=False)
    is_internal: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class TicketAttachment(Base, TimestampMixin):
    __tablename__ = "ticket_attachment"
    __table_args__ = (Index("ix_ticket_attachment_ticket", "ticket_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("ticket.id", ondelete="CASCADE"), nullable=False
    )
    # Cabang disalin ke lampiran supaya rute unduhan bisa memeriksa hak akses
    # tanpa join — pola yang sama dengan dokumen pelanggan.
    # Evidence satu langkah penanganan. Kosong = lampiran milik tiketnya.
    comment_id: Mapped[int | None] = mapped_column(
        ForeignKey("ticket_comment.id", ondelete="SET NULL"), index=True
    )
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    path: Mapped[str] = mapped_column(String(500), nullable=False)
    size: Mapped[int] = mapped_column(Integer, nullable=False)
    mime: Mapped[str] = mapped_column(String(100), nullable=False)
    uploaded_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_user.id"))
