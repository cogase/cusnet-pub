"""Kabar tiket ke luar aplikasi lewat email.

Lonceng di topbar hanya terlihat oleh orang yang sedang membuka aplikasi.
Modul ini mengantrekan email untuk tiga kejadian: tiket ditugaskan, tiket
kritis dibuka, dan tiket melewati tenggat SLA. Pengirimannya tetap dilakukan
`flask mail-flush`; di sini hanya mengantre.

Pengguna bisa mematikannya untuk dirinya sendiri di halaman Profil
(`preferences["notif_email"] = False`).
"""

from html import escape

from flask import current_app, has_app_context, has_request_context, url_for
from sqlalchemy import or_, select

from app.core import mail
from app.modules.admin.models import User
from app.modules.tickets.models import STATUS_TUTUP, Ticket

PERAN_JAGA = ("admin_cabang", "teknis")
LABEL_PRIORITAS = {"rendah": "Rendah", "sedang": "Sedang", "tinggi": "Tinggi", "kritis": "Kritis"}


def smtp_siap() -> bool:
    """Apakah SMTP sudah diisi.

    Selama belum, kabar tiket TIDAK diantrekan sama sekali. Antrean email
    tidak punya masa kedaluwarsa, jadi mengantre sekarang berarti begitu SMTP
    diisi berbulan-bulan kemudian, ratusan kabar tiket basi terkirim sekaligus.
    """
    if not has_app_context():
        return False
    config = current_app.extensions.get("config_object")
    return bool(config and config.SMTP_HOST and config.SMTP_FROM)


def mau_email(user: User) -> bool:
    return bool(user.is_active and user.email) and (user.preferences or {}).get(
        "notif_email", True
    )


def _penjaga(sesi, branch_id: int) -> list[User]:
    """Admin cabang dan teknisi cabang tiket, ditambah yang lintas cabang."""
    return list(
        sesi.execute(
            select(User).where(
                User.is_active.is_(True),
                User.role.in_(PERAN_JAGA),
                or_(User.branch_id == branch_id, User.branch_id.is_(None)),
            )
        ).scalars()
    )


def _penerima(sesi, tiket: Ticket, kecuali_id: int | None = None) -> list[User]:
    """Petugas tiket; kalau belum ditugaskan, seluruh penjaga cabangnya."""
    calon = []
    if tiket.assigned_to_user_id:
        petugas = sesi.get(User, tiket.assigned_to_user_id)
        if petugas is not None:
            calon.append(petugas)
    if not calon:
        calon = _penjaga(sesi, tiket.branch_id)
    return [u for u in calon if u.id != kecuali_id and mau_email(u)]


def _isi(tiket: Ticket, pembuka: str) -> str:
    tautan = ""
    if has_request_context():
        alamat = url_for("tickets.detail", tiket_id=tiket.id, _external=True)
        tautan = f'<p><a href="{escape(alamat)}">Buka tiket di aplikasi</a></p>'
    tenggat = (
        tiket.resolve_due_at.strftime("%d %b %Y %H:%M") if tiket.resolve_due_at else "-"
    )
    return (
        f"<p>{escape(pembuka)}</p>"
        "<table>"
        f"<tr><td>Nomor</td><td><strong>{escape(tiket.number)}</strong></td></tr>"
        f"<tr><td>Judul</td><td>{escape(tiket.title)}</td></tr>"
        f"<tr><td>Prioritas</td><td>{LABEL_PRIORITAS.get(tiket.priority, tiket.priority)}</td></tr>"
        f"<tr><td>Tenggat selesai</td><td>{tenggat}</td></tr>"
        "</table>"
        f"{tautan}"
        "<p style=\"color:#6b7280;font-size:12px\">Email ini bisa dimatikan di halaman Profil.</p>"
    )


def _antre(sesi, penerima: list[User], subjek: str, isi: str) -> int:
    if not smtp_siap():
        return 0
    for user in penerima:
        mail.antre(sesi, user.email, subjek[:255], isi)
    if penerima:
        sesi.flush()
    return len(penerima)


def tiket_dibuka(sesi, tiket: Ticket, aktor=None) -> int:
    """Tiket baru: kabari petugasnya; tiket kritis mengabari seluruh penjaga."""
    kecuali = aktor.id if aktor is not None and getattr(aktor, "id", None) else None
    if tiket.priority == "kritis":
        penerima = {u.id: u for u in _penjaga(sesi, tiket.branch_id)}
        if tiket.assigned_to_user_id:
            petugas = sesi.get(User, tiket.assigned_to_user_id)
            if petugas is not None:
                penerima[petugas.id] = petugas
        daftar = [u for u in penerima.values() if u.id != kecuali and mau_email(u)]
        return _antre(
            sesi, daftar, f"[KRITIS] {tiket.number} — {tiket.title}",
            _isi(tiket, "Tiket prioritas kritis baru saja dibuka."),
        )
    if tiket.assigned_to_user_id:
        return ditugaskan(sesi, tiket, aktor)
    return 0


def ditugaskan(sesi, tiket: Ticket, aktor=None) -> int:
    petugas = sesi.get(User, tiket.assigned_to_user_id) if tiket.assigned_to_user_id else None
    kecuali = aktor.id if aktor is not None and getattr(aktor, "id", None) else None
    if petugas is None or petugas.id == kecuali or not mau_email(petugas):
        return 0
    return _antre(
        sesi, [petugas], f"Tiket {tiket.number} ditugaskan kepada Anda",
        _isi(tiket, "Sebuah tiket ditugaskan kepada Anda."),
    )


def lewat_sla(sesi, sekarang) -> dict:
    """Mengabari tiket terbuka yang tenggat selesainya sudah lewat.

    Sekali per tiket: `sla_notified_at` dicap begitu kabarnya diantre, jadi
    perintah ini aman dijalankan tiap beberapa menit.
    """
    tiket = list(
        sesi.execute(
            select(Ticket)
            .where(
                Ticket.status.notin_(STATUS_TUTUP),
                Ticket.resolve_due_at.is_not(None),
                Ticket.resolve_due_at < sekarang,
                Ticket.sla_notified_at.is_(None),
            )
            .order_by(Ticket.id)
            .with_for_update(skip_locked=True)
        ).scalars()
    )
    diantre = 0
    for satu in tiket:
        diantre += _antre(
            sesi, _penerima(sesi, satu), f"[LEWAT SLA] {satu.number} — {satu.title}",
            _isi(satu, "Tiket ini sudah melewati tenggat penyelesaian dan masih terbuka."),
        )
        satu.sla_notified_at = sekarang
    sesi.flush()
    return {"tiket": len(tiket), "email": diantre}
