"""Aturan bisnis langganan beserta turunannya.

Terpisah dari `customers/service.py` supaya berkas pelanggan tidak tumbuh
menjadi dua subsistem sekaligus. Keduanya berbagi `ambil_pelanggan` sebagai
gerbang hak akses: `Subscription` tidak punya `branch_id` sendiri, jadi
kepemilikan cabangnya selalu dibaca lewat pelanggannya.
"""

import re
from datetime import date
from decimal import Decimal
from pathlib import Path

from sqlalchemy import delete, func, select, update

from app.core import audit, rbac, waktu
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.money import to_money
from app.core.pagination import Page, paginate_rows
from app.modules.customers.models import Customer
from app.modules.customers.service import NilaiSudahDipakai, ambil_pelanggan
from app.modules.customers.subscriptions import (
    JENIS_DISKON,
    JENIS_INTERNET,
    SISI_TERMINASI,
    STATUS_LANGGANAN,
    P2PTermination,
    SubscriptionPriceChange,
    P2PTransitHop,
    Subscription,
    SubscriptionAddon,
    SubscriptionInstallment,
    SubscriptionInternet,
    SubscriptionP2P,
)
from app.modules.services.models import ServiceCategory, ServicePlan, Vendor
from app.modules.settings import service as setting_service

# `service_no` sengaja tidak masuk daftar: ia tidak ikut disalin begitu saja
# dari formulir, melainkan lewat `_nomor_layanan_kustom` yang menegakkan
# keunikannya. Nomor tetap tidak pernah dipakai ulang — langganan yang
# diterminasi tetap memegang nomornya (spesifikasi §6).
KOLOM_LANGGANAN = (
    "plan_id",
    "site_name",
    "status",
    "started_at",
    "activated_at",
    "terminated_at",
    "price_override",
    "discount_kind",
    "discount_value",
    "ip_address",
    "vlan",
    "interface",
    "note",
)

KOLOM_AUDIT_LANGGANAN = ("service_no",) + KOLOM_LANGGANAN

HARGA_MAKS = Decimal("999999999999.99")


class NilaiTidakDikenal(GalatDomain):
    """Nilai enum atau rujukan di luar daftar yang tersedia."""


class NilaiTidakSah(GalatDomain):
    """Nilai numerik di luar batas yang masuk akal."""


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def harga_efektif(langganan, paket) -> Decimal:
    """Harga bulanan yang berlaku, sebelum diskon dan pajak.

    Fungsi murni supaya batch invoice M2 bisa memakainya ulang tanpa sesi.
    """
    if langganan.price_override is not None:
        return langganan.price_override
    return paket.price


def tagihan_bulanan(langganan, paket) -> Decimal:
    """Tagihan bulanan bersih: harga efektif dikurangi diskon langganan."""
    harga = to_money(harga_efektif(langganan, paket))
    if not langganan.discount_kind or langganan.discount_value is None:
        return harga
    if langganan.discount_kind == "persen":
        potongan = to_money(harga * Decimal(langganan.discount_value) / Decimal(100))
    else:
        potongan = to_money(langganan.discount_value)
    return to_money(harga - min(potongan, harga))


def riwayat_harga(sesi, user, langganan_id: int) -> list:
    """Perubahan tagihan satu langganan, terbaru dulu, beserta nama paketnya."""
    ambil_langganan(sesi, user, langganan_id)
    baris = sesi.execute(
        select(SubscriptionPriceChange)
        .where(SubscriptionPriceChange.subscription_id == langganan_id)
        .order_by(SubscriptionPriceChange.effective_date.desc(), SubscriptionPriceChange.id.desc())
    ).scalars().all()
    ids = {b.old_plan_id for b in baris} | {b.new_plan_id for b in baris}
    paket = {
        p.id: p
        for p in sesi.execute(select(ServicePlan).where(ServicePlan.id.in_(ids - {None}))).scalars()
    } if baris else {}
    return [
        {"baris": b, "paket_lama": paket.get(b.old_plan_id), "paket_baru": paket.get(b.new_plan_id)}
        for b in baris
    ]


def perubahan_harga_periode(sesi, langganan_id: int, mulai: date, berhenti: date) -> list:
    """Perubahan yang berlaku SESUDAH `mulai` sampai `berhenti`, urut tanggal.

    Perubahan tepat di `mulai` tidak memecah apa pun: seluruh rentang sudah
    memakai harga barunya.
    """
    return list(
        sesi.execute(
            select(SubscriptionPriceChange)
            .where(
                SubscriptionPriceChange.subscription_id == langganan_id,
                SubscriptionPriceChange.effective_date > mulai,
                SubscriptionPriceChange.effective_date <= berhenti,
            )
            .order_by(SubscriptionPriceChange.effective_date, SubscriptionPriceChange.id)
        ).scalars()
    )


def _ambil_paket(sesi, plan_id: int | None) -> ServicePlan:
    paket = sesi.get(ServicePlan, plan_id) if plan_id else None
    if paket is None:
        raise NilaiTidakDikenal("plan_id", "Paket layanan tidak ditemukan.")
    return paket


def _pastikan_status(data: dict) -> None:
    status = data.get("status")
    if status and status not in STATUS_LANGGANAN:
        raise NilaiTidakDikenal(
            "status", "Status harus salah satu dari: " + ", ".join(STATUS_LANGGANAN)
        )


def _bersihkan_nominal(data: dict, harga: Decimal) -> dict:
    """Memvalidasi harga khusus dan diskon terhadap harga yang benar-benar ditagih.

    Diskon nominal yang melampaui harga menghasilkan baris invoice negatif di
    M2. Ditolak di sini, bukan setelah invoicenya terbit.
    """
    bersih = dict(data)

    if bersih.get("price_override") is not None:
        bersih["price_override"] = to_money(bersih["price_override"])
        if bersih["price_override"] < 0:
            raise NilaiTidakSah("price_override", "Harga khusus tidak boleh negatif.")
        if bersih["price_override"] > HARGA_MAKS:
            raise NilaiTidakSah(
                "price_override",
                "Harga khusus terlalu besar. Maksimum Rp 999.999.999.999,99.",
            )
        harga = bersih["price_override"]

    jenis = bersih.get("discount_kind")
    nilai = bersih.get("discount_value")

    if jenis and jenis not in JENIS_DISKON:
        raise NilaiTidakDikenal(
            "discount_kind", "Jenis diskon harus salah satu dari: " + ", ".join(JENIS_DISKON)
        )
    if nilai is not None and not jenis:
        raise NilaiTidakSah(
            "discount_kind", "Pilih jenis diskon lebih dulu — persen atau nominal."
        )

    if nilai is not None:
        bersih["discount_value"] = to_money(nilai)
        if bersih["discount_value"] < 0:
            raise NilaiTidakSah("discount_value", "Diskon tidak boleh negatif.")
        if jenis == "persen" and bersih["discount_value"] > Decimal("100"):
            raise NilaiTidakSah("discount_value", "Diskon persen maksimum 100.")
        if jenis == "nominal" and bersih["discount_value"] > harga:
            raise NilaiTidakSah(
                "discount_value",
                "Diskon nominal tidak boleh melebihi harga layanan.",
            )

    return bersih


def _rapikan_tanggal_berhenti(langganan, data: dict, bersih: dict) -> None:
    """Menjaga `terminated_at` selalu sejalan dengan status.

    Prorata M2 memakai tanggal ini; langganan berstatus terminasi tanpa
    tanggal berhenti membuat periode terakhirnya tertagih penuh.
    """
    status_baru = bersih.get("status", langganan.status)

    if status_baru == "terminasi":
        if bersih.get("terminated_at") is None and langganan.terminated_at is None:
            bersih["terminated_at"] = waktu.hari_ini()
    elif langganan.terminated_at is not None or "terminated_at" in bersih:
        bersih["terminated_at"] = None


def _pastikan_ip(sesi, data: dict, kecuali_id: int | None = None) -> None:
    """Memeriksa alamat IP layanan sebelum disimpan.

    Ditegakkan di service, bukan hanya di formulir: impor CSV, CLI, dan uji
    menembus formulir sepenuhnya. Yang ditolak hanya dua hal — bentuk yang
    bukan alamat IP, dan alamat yang sudah dipakai layanan lain. Alamat di
    luar blok terdaftar TIDAK ditolak: ISP yang belum sempat mendaftarkan
    bloknya tetap harus bisa mendata pelanggannya, dan alamat semacam itu
    muncul sebagai daftar tersendiri di halaman Blok IP.
    """
    if "ip_address" not in data:
        return

    from app.modules.inventory import ipam

    ipam.urai_alamat(data.get("ip_address"))
    ipam.pastikan_ip_bebas(sesi, data.get("ip_address"), kecuali_id=kecuali_id)


POLA_NOMOR_LAYANAN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/\-]*$")
PANJANG_NOMOR_LAYANAN = 60


def _nomor_layanan_kustom(sesi, data: dict, kecuali_id: int | None = None) -> str | None:
    """Nomor layanan yang diketik operator, atau `None` bila dikosongkan.

    Kosong berarti "pakai yang otomatis" saat membuat dan "jangan diubah"
    saat menyunting. Keunikan diperiksa di sini supaya operator mendapat
    pesan yang bisa dibaca, bukan galat constraint dari basis data.
    """
    nomor = (data.get("service_no") or "").strip()
    if not nomor:
        return None
    # Galat diarahkan ke kolom yang benar-benar ada di formulir pemanggil.
    medan = "service_no_akhir" if data.get("service_no_akhir") else "service_no"
    if len(nomor) > PANJANG_NOMOR_LAYANAN:
        raise NilaiTidakDikenal(
            medan,
            f"Nomor layanan paling panjang {PANJANG_NOMOR_LAYANAN} karakter.",
        )
    if not POLA_NOMOR_LAYANAN.match(nomor):
        raise NilaiTidakDikenal(
            medan,
            "Nomor layanan hanya boleh berisi huruf, angka, titik, garis "
            "miring, garis bawah, dan tanda hubung, tanpa spasi.",
        )
    query = select(Subscription.id).where(Subscription.service_no == nomor)
    if kecuali_id is not None:
        query = query.where(Subscription.id != kecuali_id)
    if sesi.execute(query).first() is not None:
        raise NilaiSudahDipakai(
            medan, f"Nomor layanan '{nomor}' sudah dipakai layanan lain."
        )
    return nomor


POLA_AKHIR_NOMOR_LAYANAN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-]*$")


def awalan_nomor_layanan(sesi, customer_cid: str) -> tuple[str, str]:
    """`(awalan, akhiran)` nomor layanan pelanggan menurut pola pengaturan.

    Pola bawaan `{cid}-{seq:04d}` memberi awalan `<CID>-` tanpa akhiran.
    Awalan itu bukan milik operator: ia mengikuti CID pelanggan, dan CID
    mengikuti Pola CID di Pengaturan Billing. Yang boleh diketik hanya bagian
    yang ditempati `{seq}`.
    """
    from app.core.numbering import NumberingError, render_pattern

    pola = setting_service.ambil_setting(sesi).service_no_pattern or ""
    mulai = pola.find("{seq")
    tutup = pola.find("}", mulai) if mulai >= 0 else -1
    if mulai < 0 or tutup < 0:
        return f"{customer_cid}-", ""
    try:
        return (
            render_pattern(pola[:mulai], cid=customer_cid),
            render_pattern(pola[tutup + 1:], cid=customer_cid),
        )
    except NumberingError:
        return f"{customer_cid}-", ""


def akhir_nomor_layanan(sesi, customer_cid: str, nomor: str | None) -> str | None:
    """Bagian nomor layanan yang boleh disunting, atau `None`.

    `None` berarti nomornya tidak mengikuti awalan CID — data lama atau hasil
    impor — sehingga tidak ada "bagian belakang" yang bisa ditunjukkan.
    """
    awalan, akhiran = awalan_nomor_layanan(sesi, customer_cid)
    nomor = nomor or ""
    if not nomor.startswith(awalan) or not nomor.endswith(akhiran):
        return None
    tengah = nomor[len(awalan): len(nomor) - len(akhiran)]
    return tengah or None


def _terapkan_akhir_nomor(sesi, customer_cid: str, data: dict) -> dict:
    """Menerjemahkan `service_no_akhir` dari formulir menjadi `service_no` utuh."""
    akhir = (data.get("service_no_akhir") or "").strip()
    if not akhir:
        return data
    if not POLA_AKHIR_NOMOR_LAYANAN.match(akhir):
        raise NilaiTidakDikenal(
            "service_no_akhir",
            "Nomor layanan hanya boleh berisi huruf, angka, titik, garis "
            "bawah, dan tanda hubung, tanpa spasi.",
        )
    awalan, akhiran = awalan_nomor_layanan(sesi, customer_cid)
    return {**data, "service_no": f"{awalan}{akhir}{akhiran}"}


def _nomor_layanan_otomatis(sesi, customer_cid: str) -> str:
    """Nomor berikutnya dari pola, melewati yang sudah diambil nomor kustom.

    Sejak nomor boleh diketik sendiri, deret otomatis bisa menabrak nomor
    yang lebih dulu dipakai secara manual. Penghitungnya dimajukan sampai
    menemukan nomor bebas, alih-alih gagal di constraint unik.
    """
    for _ in range(1000):
        nomor = setting_service.buat_nomor_layanan(sesi, customer_cid)
        terpakai = sesi.execute(
            select(Subscription.id).where(Subscription.service_no == nomor)
        ).first()
        if terpakai is None:
            return nomor
    raise NilaiSudahDipakai(
        "service_no",
        "Nomor layanan otomatis tidak bisa dibuat. Isi nomor layanan secara manual.",
    )


def buat_langganan(sesi, aktor, customer_id: int, data: dict) -> Subscription:
    """Membuat langganan baru beserta nomor layanannya.

    Urutan advisory lock sama seperti `buat_pelanggan` dan tidak boleh dibalik
    (m1a-catatan-lanjutan.md §1.6): pengaturan lebih dulu — di dalam
    `setting_service.buat_nomor_layanan` — baru penghitung penomoran.
    """
    pelanggan = ambil_pelanggan(sesi, aktor, customer_id)
    paket = _ambil_paket(sesi, data.get("plan_id"))
    _pastikan_status(data)
    _pastikan_ip(sesi, data)
    bersih = _bersihkan_nominal(data, paket.price)
    data = _terapkan_akhir_nomor(sesi, pelanggan.cid, data)
    nomor = _nomor_layanan_kustom(sesi, data) or _nomor_layanan_otomatis(
        sesi, pelanggan.cid
    )

    langganan = Subscription(
        customer_id=pelanggan.id,
        service_no=nomor,
        **{k: bersih.get(k) for k in KOLOM_LANGGANAN if k in bersih},
    )
    if langganan.status == "terminasi" and langganan.terminated_at is None:
        langganan.terminated_at = waktu.hari_ini()

    sesi.add(langganan)
    sesi.flush()
    _sinkronkan_vlan_layanan(sesi, aktor, langganan)

    audit.record(
        sesi, "create", "subscription", langganan.id,
        after=_potret(langganan, KOLOM_AUDIT_LANGGANAN), aktor=aktor,
    )
    return langganan


def daftar_site(sesi, user, induk_id: int) -> list[Subscription]:
    """Site di bawah satu layanan induk, urut nomor."""
    ambil_langganan(sesi, user, induk_id)
    return list(
        sesi.execute(
            select(Subscription)
            .where(Subscription.parent_id == induk_id)
            .order_by(Subscription.service_no)
        ).scalars()
    )


def jumlah_site(sesi, induk_ids: list[int]) -> dict[int, int]:
    """Banyaknya site tiap layanan induk, satu query untuk satu halaman."""
    if not induk_ids:
        return {}
    return dict(
        sesi.execute(
            select(Subscription.parent_id, func.count())
            .where(Subscription.parent_id.in_(induk_ids))
            .group_by(Subscription.parent_id)
        ).all()
    )


def tambah_site(sesi, aktor, induk_id: int, data: dict) -> Subscription:
    """Menambah satu site di bawah layanan.

    Layanan menjadi induk begitu site pertamanya dibuat — tidak ada mode yang
    harus dipilih di awal, dan layanan satu site tidak berubah sama sekali.
    Site mewarisi paket induk (itulah yang menentukan bentuk formulir
    teknisnya) dan bernomor `<nomor induk>-NN`. Ia tidak membawa harga.
    """
    induk = ambil_langganan(sesi, aktor, induk_id)
    if induk.parent_id is not None:
        raise NilaiTidakSah("site_name", "Site tidak bisa punya site lagi di bawahnya.")
    nama = (data.get("site_name") or "").strip()
    if not nama:
        raise NilaiTidakSah("site_name", "Nama site wajib diisi.")
    if len(nama) > 120:
        raise NilaiTidakSah("site_name", "Nama site paling panjang 120 karakter.")

    terpakai = set(
        sesi.execute(
            select(Subscription.service_no).where(
                Subscription.service_no.like(f"{induk.service_no}-%")
            )
        ).scalars()
    )
    nomor = next(
        (
            calon
            for calon in (f"{induk.service_no}-{urut:02d}" for urut in range(1, 1000))
            if calon not in terpakai
        ),
        None,
    )
    if nomor is None or len(nomor) > PANJANG_NOMOR_LAYANAN:
        raise NilaiTidakSah(
            "site_name", "Nomor site tidak bisa dibuat karena nomor layanan induk terlalu panjang."
        )

    site = Subscription(
        customer_id=induk.customer_id,
        plan_id=induk.plan_id,
        parent_id=induk.id,
        service_no=nomor,
        site_name=nama,
        status=induk.status,
        started_at=induk.started_at,
        activated_at=induk.activated_at,
    )
    sesi.add(site)
    sesi.flush()
    audit.record(
        sesi, "create", "subscription", site.id,
        after={**_potret(site, KOLOM_AUDIT_LANGGANAN), "parent_id": induk.id}, aktor=aktor,
    )
    return site


def ambil_langganan(sesi, user, langganan_id: int) -> Subscription:
    langganan = sesi.get(Subscription, langganan_id)
    if langganan is None:
        raise TidakDitemukan("Layanan tidak ditemukan.")
    ambil_pelanggan(sesi, user, langganan.customer_id)
    return langganan


def ubah_langganan(sesi, aktor, langganan_id: int, data: dict) -> Subscription:
    langganan = ambil_langganan(sesi, aktor, langganan_id)
    _pastikan_status(data)
    _pastikan_ip(sesi, data, kecuali_id=langganan.id)

    paket = _ambil_paket(sesi, data.get("plan_id", langganan.plan_id))
    bersih = _bersihkan_nominal(data, harga_efektif(langganan, paket))
    _rapikan_tanggal_berhenti(langganan, data, bersih)
    if data.get("service_no_akhir"):
        pelanggan = ambil_pelanggan(sesi, aktor, langganan.customer_id)
        data = _terapkan_akhir_nomor(sesi, pelanggan.cid, data)
    nomor = _nomor_layanan_kustom(sesi, data, kecuali_id=langganan.id)

    sebelum = _potret(langganan, KOLOM_AUDIT_LANGGANAN)
    paket_lama = _ambil_paket(sesi, langganan.plan_id)
    tagihan_lama = tagihan_bulanan(langganan, paket_lama)
    for nama in KOLOM_LANGGANAN:
        if nama in bersih:
            setattr(langganan, nama, bersih[nama])
    if nomor is not None:
        langganan.service_no = nomor
    sesi.flush()
    _sinkronkan_vlan_layanan(sesi, aktor, langganan)

    # Upgrade/downgrade: tagihan bulanan berubah. Dicatat beserta tanggal
    # berlakunya supaya periode yang memuat perubahan ditagih prorata.
    # Site tidak ditagih, jadi tidak punya riwayat harga.
    tagihan_baru = tagihan_bulanan(langganan, paket)
    if langganan.parent_id is None and tagihan_baru != tagihan_lama:
        sesi.add(
            SubscriptionPriceChange(
                subscription_id=langganan.id,
                effective_date=data.get("price_effective_at") or waktu.hari_ini(),
                old_plan_id=paket_lama.id,
                new_plan_id=paket.id,
                old_amount=tagihan_lama,
                new_amount=tagihan_baru,
                changed_by_user_id=getattr(aktor, "id", None),
            )
        )
        sesi.flush()

    audit.record(
        sesi, "update", "subscription", langganan.id,
        before=sebelum, after=_potret(langganan, KOLOM_AUDIT_LANGGANAN),
        aktor=aktor,
    )
    return langganan


def _bebaskan_alokasi(sesi, langganan_id: int, aktor=None) -> None:
    """Melepas port, VLAN, dan blok IP sebelum langganannya hilang.

    Ketiganya bertaut lewat `ondelete="SET NULL"`, jadi basis data sudah
    melepas kuncinya sendiri. Yang tidak diketahui basis data adalah kolom
    `status` milik port: `SET NULL` meninggalkan port ber-`subscription_id`
    kosong tetapi tetap berstatus `"terpakai"` — port hantu yang selamanya
    tampak dipakai entah siapa. Statusnya harus dikembalikan di sini,
    sebagaimana `bebaskan_port` selalu mengubah keduanya.
    """
    from app.modules.inventory.models import DevicePort, IpBlock, Vlan

    for port in sesi.execute(
        select(DevicePort).where(DevicePort.subscription_id == langganan_id)
    ).scalars().all():
        port.subscription_id = None
        port.status = "bebas"

    for baris in sesi.execute(
        select(Vlan).where(Vlan.subscription_id == langganan_id)
    ).scalars().all():
        if baris.is_auto:
            audit.record(
                sesi, "delete", "vlan", baris.id,
                before={"vlan_id": baris.vlan_id, "subscription_id": langganan_id,
                        "is_auto": True},
                aktor=aktor,
            )
            sesi.delete(baris)
        else:
            baris.subscription_id = None

    for baris in sesi.execute(
        select(IpBlock).where(IpBlock.subscription_id == langganan_id)
    ).scalars().all():
        baris.subscription_id = None

    sesi.flush()


def hapus_langganan(sesi, aktor, langganan_id: int) -> int:
    """Hapus layanan beserta invoice, pembayaran, tiket, dan data turunannya."""
    langganan = ambil_langganan(sesi, aktor, langganan_id)
    customer_id = langganan.customer_id

    # Site ikut terhapus bersama induknya; tiket dan alokasi jaringannya
    # dibereskan satu per satu, bukan diserahkan ke CASCADE basis data.
    for site_id in sesi.execute(
        select(Subscription.id).where(Subscription.parent_id == langganan_id)
    ).scalars().all():
        hapus_langganan(sesi, aktor, site_id)

    _hapus_tiket(sesi, subscription_ids=[langganan_id])
    invoice_ids = _invoice_ids_langganan(sesi, [langganan_id])
    _hapus_invoice(sesi, invoice_ids)
    _bebaskan_alokasi(sesi, langganan_id, aktor)

    audit.record(
        sesi, "delete", "subscription", langganan.id,
        before=_potret(langganan, KOLOM_LANGGANAN), aktor=aktor,
    )
    sesi.delete(langganan)
    sesi.flush()
    return customer_id


def _hapus_tiket(sesi, *, customer_id: int | None = None,
                  subscription_ids: list[int] | None = None) -> None:
    """Hapus tiket terkait dan lampirannya sebelum menghapus pemiliknya."""
    from app.modules.tickets.models import Ticket, TicketAttachment

    kondisi = []
    if customer_id is not None:
        kondisi.append(Ticket.customer_id == customer_id)
    if subscription_ids:
        kondisi.append(Ticket.subscription_id.in_(subscription_ids))
    if not kondisi:
        return

    tiket_ids = list(
        sesi.execute(select(Ticket.id).where(*kondisi)).scalars().all()
    )
    if not tiket_ids:
        return
    lampiran = sesi.execute(
        select(TicketAttachment.path).where(TicketAttachment.ticket_id.in_(tiket_ids))
    ).scalars().all()
    _hapus_berkas(lampiran, "lampiran tiket")
    sesi.execute(delete(Ticket).where(Ticket.id.in_(tiket_ids)))


def _hapus_berkas(jalur: list[str], jenis: str) -> None:
    for nama in jalur:
        try:
            Path(nama).unlink(missing_ok=True)
        except OSError:
            _log.warning("Berkas %s gagal dibuang: %s", jenis, nama)


def _invoice_ids_langganan(sesi, langganan_ids: list[int]) -> list[int]:
    if not langganan_ids:
        return []
    from app.modules.billing.models import Invoice, InvoiceItem

    langsung = set(
        sesi.execute(
            select(Invoice.id).where(Invoice.subscription_id.in_(langganan_ids))
        ).scalars()
    )
    langsung.update(
        sesi.execute(
            select(InvoiceItem.invoice_id).where(
                InvoiceItem.subscription_id.in_(langganan_ids)
            )
        ).scalars()
    )
    return _invoice_koreksi_turunan(sesi, langsung)


def _invoice_koreksi_turunan(sesi, invoice_ids: set[int]) -> list[int]:
    """Tambahkan semua invoice pembetulan yang bergantung pada invoice asal."""
    from app.modules.billing.models import Invoice

    semua = set(invoice_ids)
    while semua:
        turunan = set(
            sesi.execute(
                select(Invoice.id).where(Invoice.corrects_invoice_id.in_(semua))
            ).scalars()
        ) - semua
        if not turunan:
            break
        semua.update(turunan)
    return sorted(semua)


def _hapus_invoice(sesi, invoice_ids: list[int]) -> None:
    """Hapus invoice dan data turunan DB; bersihkan bukti bayar dari disk."""
    if not invoice_ids:
        return
    from app.modules.admin.models import MailOutbox
    from app.modules.billing.models import Invoice, Payment

    berkas = sesi.execute(
        select(Payment.proof_path).where(
            Payment.invoice_id.in_(invoice_ids), Payment.proof_path.is_not(None)
        )
    ).scalars().all()
    lampiran_email = sesi.execute(
        select(MailOutbox.attachment_path).where(
            MailOutbox.invoice_id.in_(invoice_ids),
            MailOutbox.attachment_path.is_not(None),
        )
    ).scalars().all()
    _hapus_berkas(berkas, "bukti pembayaran")
    _hapus_berkas(lampiran_email, "lampiran email invoice")
    sesi.execute(
        update(Invoice)
        .where(Invoice.corrects_invoice_id.in_(invoice_ids))
        .values(corrects_invoice_id=None)
    )
    sesi.execute(delete(Invoice).where(Invoice.id.in_(invoice_ids)))


def hapus_invoice_pelanggan(sesi, customer_id: int) -> None:
    """Hapus invoice yang tidak terkait layanan, misalnya invoice manual."""
    from app.modules.billing.models import Invoice

    ids = set(
        sesi.execute(
            select(Invoice.id).where(Invoice.customer_id == customer_id)
        ).scalars()
    )
    _hapus_invoice(sesi, _invoice_koreksi_turunan(sesi, ids))


def hapus_data_pelanggan(sesi, aktor, customer_id: int) -> list[int]:
    """Hapus seluruh jejak transaksi dan layanan pelanggan."""
    from app.modules.customers.subscriptions import Subscription

    langganan = list(
        sesi.execute(
            select(Subscription).where(Subscription.customer_id == customer_id)
        ).scalars().all()
    )
    langganan_ids = [baris.id for baris in langganan]
    _hapus_tiket(sesi, customer_id=customer_id, subscription_ids=langganan_ids)
    for langganan_id in langganan_ids:
        _bebaskan_alokasi(sesi, langganan_id, aktor)
    _hapus_invoice(sesi, _invoice_ids_langganan(sesi, langganan_ids))
    hapus_invoice_pelanggan(sesi, customer_id)
    for baris in langganan:
        audit.record(
            sesi, "delete", "subscription", baris.id,
            before=_potret(baris, KOLOM_LANGGANAN), aktor=aktor,
        )
    return langganan_ids


class BentukTidakCocok(GalatDomain):
    """Detail teknis tidak sesuai bentuk formulir kategori paketnya."""


class CicilanSudahBerjalan(GalatDomain):
    """Cicilan yang sudah pernah ditagih tidak boleh diubah maupun dihapus."""


KOLOM_INTERNET = (
    "capacity_mbps",
    "internet_kind",
    "vendor_id",
    "odp_name",
    "odp_lat",
    "odp_lng",
)
KOLOM_P2P = ("capacity_mbps", "vendor_id")
KOLOM_TERMINASI = ("site_name", "address", "lat", "lng", "vlan", "interface")
KOLOM_HOP = (
    "urutan", "vendor_id", "label", "circuit_id", "vendor_phone", "vlan",
    "physical_note", "note",
)
KOLOM_ADDON = ("description", "qty", "unit_price", "is_active")
KOLOM_CICILAN = (
    "description",
    "total_amount",
    "terms",
    "term_amount",
    "terms_billed",
    "started_at",
)


def _sinkronkan_vlan_layanan(sesi, aktor, langganan: Subscription) -> None:
    """Menjaga registry VLAN yang diturunkan dari seluruh detail layanan."""
    from app.modules.customers.models import Customer
    from app.modules.inventory.models import Vlan

    nilai = {langganan.vlan} if langganan.vlan else set()
    nilai.update(
        sesi.execute(
            select(P2PTermination.vlan).where(
                P2PTermination.subscription_id == langganan.id,
                P2PTermination.vlan.is_not(None),
                P2PTermination.vlan != "",
            )
        ).scalars()
    )
    nilai.update(
        sesi.execute(
            select(P2PTransitHop.vlan).where(
                P2PTransitHop.subscription_id == langganan.id,
                P2PTransitHop.vlan.is_not(None),
                P2PTransitHop.vlan != "",
            )
        ).scalars()
    )

    nomor_vlan: set[int] = set()
    for teks in nilai:
        try:
            nomor = int(teks)
        except (TypeError, ValueError):
            raise NilaiTidakSah(
                "vlan", f"VLAN '{teks}' harus berupa nomor antara 1 dan 4094."
            ) from None
        if not 1 <= nomor <= 4094:
            raise NilaiTidakSah(
                "vlan", f"VLAN '{teks}' harus berupa nomor antara 1 dan 4094."
            )
        nomor_vlan.add(nomor)

    otomatis = list(
        sesi.execute(
            select(Vlan).where(
                Vlan.subscription_id == langganan.id, Vlan.is_auto.is_(True)
            )
        ).scalars()
    )
    menurut_nomor = {baris.vlan_id: baris for baris in otomatis}
    pelanggan = sesi.get(Customer, langganan.customer_id)

    for baris in otomatis:
        if baris.vlan_id not in nomor_vlan:
            audit.record(
                sesi, "delete", "vlan", baris.id,
                before={"vlan_id": baris.vlan_id, "subscription_id": langganan.id,
                        "is_auto": True},
                aktor=aktor,
            )
            sesi.delete(baris)

    sesi.flush()

    for nomor in nomor_vlan - set(menurut_nomor):
        baris = Vlan(
            vlan_id=nomor,
            name=f"Layanan {langganan.service_no}",
            branch_id=pelanggan.branch_id,
            kind="pelanggan",
            subscription_id=langganan.id,
            is_auto=True,
        )
        sesi.add(baris)
        sesi.flush()
        audit.record(
            sesi, "create", "vlan", baris.id,
            after={"vlan_id": baris.vlan_id, "name": baris.name,
                   "branch_id": baris.branch_id, "subscription_id": langganan.id,
                   "is_auto": True},
            aktor=aktor,
        )


def bentuk_formulir(sesi, langganan) -> str:
    """`form_kind` kategori paket langganan ini."""
    bentuk = sesi.execute(
        select(ServiceCategory.form_kind)
        .join(ServicePlan, ServicePlan.category_id == ServiceCategory.id)
        .where(ServicePlan.id == langganan.plan_id)
    ).scalar_one_or_none()
    if bentuk is None:
        raise TidakDitemukan("Kategori paket langganan tidak ditemukan.")
    return bentuk


def _pastikan_bentuk(sesi, langganan, diharapkan: str) -> None:
    bentuk = bentuk_formulir(sesi, langganan)
    if bentuk != diharapkan:
        raise BentukTidakCocok(
            "plan_id",
            f"Layanan ini berbentuk '{bentuk}', jadi detail '{diharapkan}' tidak "
            "berlaku untuknya. Pindahkan ke paket berkategori lain kalau memang "
            "salah pilih.",
        )


def _pastikan_vendor(sesi, vendor_id) -> None:
    if vendor_id is None:
        return
    if sesi.get(Vendor, vendor_id) is None:
        raise NilaiTidakDikenal("vendor_id", "Vendor tidak ditemukan.")


def simpan_detail_internet(sesi, aktor, langganan_id: int, data: dict):
    """Menyimpan detail Internet. Satu baris per langganan, jadi upsert."""
    langganan = ambil_langganan(sesi, aktor, langganan_id)
    _pastikan_bentuk(sesi, langganan, "internet")

    jenis = data.get("internet_kind")
    if jenis and jenis not in JENIS_INTERNET:
        raise NilaiTidakDikenal(
            "internet_kind",
            "Jenis internet harus salah satu dari: " + ", ".join(JENIS_INTERNET),
        )
    _pastikan_vendor(sesi, data.get("vendor_id"))

    detail = sesi.execute(
        select(SubscriptionInternet).where(
            SubscriptionInternet.subscription_id == langganan_id
        )
    ).scalars().first()
    aksi = "update" if detail is not None else "create"
    sebelum = _potret(detail, KOLOM_INTERNET) if detail is not None else None

    if detail is None:
        detail = SubscriptionInternet(subscription_id=langganan_id)
        sesi.add(detail)

    for nama in KOLOM_INTERNET:
        if nama in data:
            setattr(detail, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, aksi, "subscription_internet", detail.id,
        before=sebelum, after=_potret(detail, KOLOM_INTERNET), aktor=aktor,
    )
    return detail


def ambil_detail_internet(sesi, user, langganan_id: int):
    ambil_langganan(sesi, user, langganan_id)
    return sesi.execute(
        select(SubscriptionInternet).where(
            SubscriptionInternet.subscription_id == langganan_id
        )
    ).scalars().first()


def simpan_detail_p2p(sesi, aktor, langganan_id: int, data: dict):
    langganan = ambil_langganan(sesi, aktor, langganan_id)
    _pastikan_bentuk(sesi, langganan, "point_to_point")
    _pastikan_vendor(sesi, data.get("vendor_id"))

    detail = sesi.execute(
        select(SubscriptionP2P).where(SubscriptionP2P.subscription_id == langganan_id)
    ).scalars().first()
    aksi = "update" if detail is not None else "create"
    sebelum = _potret(detail, KOLOM_P2P) if detail is not None else None

    if detail is None:
        detail = SubscriptionP2P(subscription_id=langganan_id)
        sesi.add(detail)

    for nama in KOLOM_P2P:
        if nama in data:
            setattr(detail, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, aksi, "subscription_p2p", detail.id,
        before=sebelum, after=_potret(detail, KOLOM_P2P), aktor=aktor,
    )
    return detail


def ambil_detail_p2p(sesi, user, langganan_id: int):
    ambil_langganan(sesi, user, langganan_id)
    return sesi.execute(
        select(SubscriptionP2P).where(SubscriptionP2P.subscription_id == langganan_id)
    ).scalars().first()


def daftar_terminasi(sesi, user, langganan_id: int) -> list:
    ambil_langganan(sesi, user, langganan_id)
    return list(
        sesi.execute(
            select(P2PTermination)
            .where(P2PTermination.subscription_id == langganan_id)
            .order_by(P2PTermination.side)
        ).scalars().all()
    )


def simpan_terminasi(sesi, aktor, langganan_id: int, side: str, data: dict):
    langganan = ambil_langganan(sesi, aktor, langganan_id)

    if side not in SISI_TERMINASI:
        raise NilaiTidakDikenal(
            "side", "Sisi terminasi harus " + " atau ".join(SISI_TERMINASI) + "."
        )

    terminasi = sesi.execute(
        select(P2PTermination).where(
            P2PTermination.subscription_id == langganan_id,
            P2PTermination.side == side,
        )
    ).scalars().first()
    aksi = "update" if terminasi is not None else "create"
    sebelum = _potret(terminasi, KOLOM_TERMINASI) if terminasi is not None else None

    if terminasi is None:
        terminasi = P2PTermination(
            subscription_id=langganan_id, side=side, site_name=data.get("site_name") or "-"
        )
        sesi.add(terminasi)

    for nama in KOLOM_TERMINASI:
        if nama in data:
            setattr(terminasi, nama, data[nama])
    sesi.flush()
    _sinkronkan_vlan_layanan(sesi, aktor, langganan)

    audit.record(
        sesi, aksi, "p2p_termination", terminasi.id,
        before=sebelum, after=_potret(terminasi, KOLOM_TERMINASI), aktor=aktor,
    )
    return terminasi


def daftar_hop(sesi, user, langganan_id: int) -> list:
    ambil_langganan(sesi, user, langganan_id)
    return list(
        sesi.execute(
            select(P2PTransitHop)
            .where(P2PTransitHop.subscription_id == langganan_id)
            .order_by(P2PTransitHop.urutan, P2PTransitHop.id)
        ).scalars().all()
    )


def tambah_hop(sesi, aktor, langganan_id: int, data: dict):
    langganan = ambil_langganan(sesi, aktor, langganan_id)
    _pastikan_vendor(sesi, data.get("vendor_id"))

    terakhir = sesi.execute(
        select(func.max(P2PTransitHop.urutan)).where(
            P2PTransitHop.subscription_id == langganan_id
        )
    ).scalar()

    hop = P2PTransitHop(
        subscription_id=langganan_id,
        urutan=(terakhir or 0) + 1,
        **{k: data.get(k) for k in KOLOM_HOP if k in data and k != "urutan"},
    )
    sesi.add(hop)
    sesi.flush()
    _sinkronkan_vlan_layanan(sesi, aktor, langganan)

    audit.record(
        sesi, "create", "p2p_transit_hop", hop.id,
        after=_potret(hop, KOLOM_HOP), aktor=aktor,
    )
    return hop


def langganan_id_hop(sesi, user, hop_id: int) -> int:
    """Id langganan pemilik hop, setelah memastikan `user` boleh membukanya."""
    hop = sesi.get(P2PTransitHop, hop_id)
    if hop is None:
        raise TidakDitemukan("Hop transit tidak ditemukan.")
    ambil_langganan(sesi, user, hop.subscription_id)
    return hop.subscription_id


def ubah_hop(sesi, aktor, hop_id: int, data: dict):
    hop = sesi.get(P2PTransitHop, hop_id)
    if hop is None:
        raise TidakDitemukan("Hop transit tidak ditemukan.")
    ambil_langganan(sesi, aktor, hop.subscription_id)
    _pastikan_vendor(sesi, data.get("vendor_id"))

    sebelum = _potret(hop, KOLOM_HOP)
    for nama in KOLOM_HOP:
        if nama in data and nama != "urutan":
            setattr(hop, nama, data[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "p2p_transit_hop", hop.id,
        before=sebelum, after=_potret(hop, KOLOM_HOP), aktor=aktor,
    )
    return hop


def hapus_hop(sesi, aktor, hop_id: int) -> int:
    """Menghapus hop lalu merapatkan urutan sisanya.

    Urutan berlubang membuat topologi menggambar jarak yang tidak ada, dan
    membuat "hop ke-3" di layar tidak sama dengan hop ketiga di data.
    """
    hop = sesi.get(P2PTransitHop, hop_id)
    if hop is None:
        raise TidakDitemukan("Hop transit tidak ditemukan.")
    langganan_id = hop.subscription_id
    ambil_langganan(sesi, aktor, langganan_id)

    audit.record(
        sesi, "delete", "p2p_transit_hop", hop.id,
        before=_potret(hop, KOLOM_HOP), aktor=aktor,
    )
    sesi.delete(hop)
    sesi.flush()

    sisa = sesi.execute(
        select(P2PTransitHop)
        .where(P2PTransitHop.subscription_id == langganan_id)
        .order_by(P2PTransitHop.urutan, P2PTransitHop.id)
    ).scalars().all()
    for nomor, baris in enumerate(sisa, start=1):
        baris.urutan = nomor
    sesi.flush()
    _sinkronkan_vlan_layanan(sesi, aktor, ambil_langganan(sesi, aktor, langganan_id))

    return langganan_id


def daftar_addon(sesi, user, langganan_id: int) -> list:
    ambil_langganan(sesi, user, langganan_id)
    return list(
        sesi.execute(
            select(SubscriptionAddon)
            .where(SubscriptionAddon.subscription_id == langganan_id)
            .order_by(SubscriptionAddon.id)
        ).scalars().all()
    )


def _bersihkan_addon(data: dict) -> dict:
    bersih = dict(data)

    if "qty" in bersih and bersih["qty"] is not None:
        bersih["qty"] = int(bersih["qty"])
        if bersih["qty"] < 1:
            raise NilaiTidakSah("qty", "Jumlah minimal 1.")

    if bersih.get("unit_price") is not None:
        bersih["unit_price"] = to_money(bersih["unit_price"])
        if bersih["unit_price"] < 0:
            raise NilaiTidakSah("unit_price", "Harga satuan tidak boleh negatif.")
        if bersih["unit_price"] > HARGA_MAKS:
            raise NilaiTidakSah(
                "unit_price", "Harga satuan terlalu besar. Maksimum Rp 999.999.999.999,99."
            )

    return bersih


def tambah_addon(sesi, aktor, langganan_id: int, data: dict):
    ambil_langganan(sesi, aktor, langganan_id)
    bersih = _bersihkan_addon(data)

    addon = SubscriptionAddon(
        subscription_id=langganan_id,
        **{k: bersih.get(k) for k in KOLOM_ADDON if k in bersih},
    )
    sesi.add(addon)
    sesi.flush()

    audit.record(
        sesi, "create", "subscription_addon", addon.id,
        after=_potret(addon, KOLOM_ADDON), aktor=aktor,
    )
    return addon


def ubah_addon(sesi, aktor, addon_id: int, data: dict):
    addon = sesi.get(SubscriptionAddon, addon_id)
    if addon is None:
        raise TidakDitemukan("Biaya tambahan tidak ditemukan.")
    ambil_langganan(sesi, aktor, addon.subscription_id)
    bersih = _bersihkan_addon(data)

    sebelum = _potret(addon, KOLOM_ADDON)
    for nama in KOLOM_ADDON:
        if nama in bersih:
            setattr(addon, nama, bersih[nama])
    sesi.flush()

    audit.record(
        sesi, "update", "subscription_addon", addon.id,
        before=sebelum, after=_potret(addon, KOLOM_ADDON), aktor=aktor,
    )
    return addon


def hapus_addon(sesi, aktor, addon_id: int) -> int:
    addon = sesi.get(SubscriptionAddon, addon_id)
    if addon is None:
        raise TidakDitemukan("Biaya tambahan tidak ditemukan.")
    langganan_id = addon.subscription_id
    ambil_langganan(sesi, aktor, langganan_id)

    audit.record(
        sesi, "delete", "subscription_addon", addon.id,
        before=_potret(addon, KOLOM_ADDON), aktor=aktor,
    )
    sesi.delete(addon)
    sesi.flush()
    return langganan_id


def ambil_cicilan(sesi, user, langganan_id: int):
    ambil_langganan(sesi, user, langganan_id)
    return sesi.execute(
        select(SubscriptionInstallment).where(
            SubscriptionInstallment.subscription_id == langganan_id
        )
    ).scalars().first()


def sisa_termin(cicilan) -> int:
    return max(cicilan.terms - cicilan.terms_billed, 0)


def nominal_termin(cicilan, termin_ke: int) -> Decimal:
    """Nominal satu termin; termin terakhir menyerap selisih pembulatan.

    `total / terms` yang dibulatkan per termin hampir selalu meleset dari
    totalnya. Selisihnya ditaruh di termin terakhir supaya penjumlahan seluruh
    termin persis sama dengan biaya yang disepakati.
    """
    if termin_ke < cicilan.terms:
        return cicilan.term_amount
    return cicilan.total_amount - cicilan.term_amount * (cicilan.terms - 1)


def simpan_cicilan(sesi, aktor, langganan_id: int, data: dict):
    ambil_langganan(sesi, aktor, langganan_id)

    cicilan = ambil_cicilan(sesi, aktor, langganan_id)
    if cicilan is not None and cicilan.terms_billed > 0:
        raise CicilanSudahBerjalan(
            "total_amount",
            "Cicilan ini sudah pernah ditagih, jadi total dan jumlah terminnya "
            "tidak bisa diubah. Buat penyesuaian lewat invoice, bukan dengan "
            "mengubah rencana cicilannya.",
        )

    total = data.get("total_amount")
    if total is None:
        raise NilaiTidakSah("total_amount", "Total biaya wajib diisi.")
    total = to_money(total)
    if total < 0:
        raise NilaiTidakSah("total_amount", "Total biaya tidak boleh negatif.")
    if total > HARGA_MAKS:
        raise NilaiTidakSah(
            "total_amount", "Total biaya terlalu besar. Maksimum Rp 999.999.999.999,99."
        )

    terms = int(data.get("terms") or 0)
    if terms < 1:
        raise NilaiTidakSah("terms", "Jumlah termin minimal 1.")

    aksi = "update" if cicilan is not None else "create"
    sebelum = _potret(cicilan, KOLOM_CICILAN) if cicilan is not None else None

    if cicilan is None:
        cicilan = SubscriptionInstallment(
            subscription_id=langganan_id,
            total_amount=total,
            terms=terms,
            term_amount=to_money(total / terms),
        )
        sesi.add(cicilan)
    else:
        cicilan.total_amount = total
        cicilan.terms = terms
        cicilan.term_amount = to_money(total / terms)

    for nama in ("description", "started_at"):
        if data.get(nama) is not None:
            setattr(cicilan, nama, data[nama])
    sesi.flush()

    audit.record(
        sesi, aksi, "subscription_installment", cicilan.id,
        before=sebelum, after=_potret(cicilan, KOLOM_CICILAN), aktor=aktor,
    )
    return cicilan


def hapus_cicilan(sesi, aktor, langganan_id: int) -> None:
    cicilan = ambil_cicilan(sesi, aktor, langganan_id)
    if cicilan is None:
        raise TidakDitemukan("Cicilan tidak ditemukan.")
    if cicilan.terms_billed > 0:
        raise CicilanSudahBerjalan(
            "total_amount",
            "Cicilan ini sudah pernah ditagih dan tidak bisa dihapus. Invoice "
            "yang sudah terbit akan kehilangan rujukannya.",
        )

    audit.record(
        sesi, "delete", "subscription_installment", cicilan.id,
        before=_potret(cicilan, KOLOM_CICILAN), aktor=aktor,
    )
    sesi.delete(cicilan)
    sesi.flush()


def _query_langganan(user):
    """Query langganan beserta pelanggan, paket, dan kategorinya.

    `Subscription` tidak punya `branch_id`; scoping cabangnya lewat join ke
    `Customer`, jadi `rbac.scoped` diberi `Customer` — bukan `Subscription`.
    """
    query = (
        select(Subscription, Customer, ServicePlan, ServiceCategory)
        .join(Customer, Subscription.customer_id == Customer.id)
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .order_by(Subscription.id.desc())
    )
    return rbac.scoped(query, user, Customer)


def daftar_langganan_semua(
    sesi,
    user,
    page: int = 1,
    per_page: int = 10,
    customer_id: int | None = None,
    status: str | None = None,
    kategori_id: int | None = None,
) -> Page:
    query = _query_langganan(user)

    # Site tampil di Detail Layanan induknya, bukan sebagai baris sendiri.
    query = query.where(Subscription.parent_id.is_(None))
    if customer_id:
        query = query.where(Subscription.customer_id == customer_id)
    if status:
        query = query.where(Subscription.status == status)
    if kategori_id:
        query = query.where(ServicePlan.category_id == kategori_id)

    return paginate_rows(sesi, query, page, per_page)


def daftar_langganan(sesi, user, customer_id: int, dengan_site: bool = False) -> list:
    """Langganan satu pelanggan, sebagai baris `(langganan, paket, kategori)`.

    Site tidak ikut kecuali diminta: ia bukan layanan yang berdiri sendiri.
    """
    ambil_pelanggan(sesi, user, customer_id)
    query = (
        select(Subscription, ServicePlan, ServiceCategory)
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .where(Subscription.customer_id == customer_id)
        .order_by(Subscription.service_no if dengan_site else Subscription.id)
    )
    if not dengan_site:
        query = query.where(Subscription.parent_id.is_(None))
    return list(sesi.execute(query).all())


def pilihan_layanan(sesi, user, customer_id: int) -> list[tuple[int, str]]:
    """Layanan satu pelanggan sebagai `(id, "nomor — site")`.

    Site lebih mudah dikenali daripada nama paket saat memilih layanan yang
    bermasalah. Urutannya: nama site layanan, lalu kedua ujung sirkuit
    titik-ke-titik, dan baru nama paket bila keduanya kosong.
    """
    # Site ikut: tiket dibuka per site supaya kelihatan site mana yang
    # sering bermasalah.
    baris = daftar_langganan(sesi, user, customer_id, dengan_site=True)
    ids = [langganan.id for langganan, _paket, _kategori in baris]
    ujung: dict[int, list[str]] = {}
    if ids:
        for terminasi in sesi.execute(
            select(P2PTermination)
            .where(P2PTermination.subscription_id.in_(ids))
            .order_by(P2PTermination.subscription_id, P2PTermination.side)
        ).scalars():
            if terminasi.site_name:
                ujung.setdefault(terminasi.subscription_id, []).append(terminasi.site_name)
    hasil = []
    for langganan, paket, _kategori in baris:
        site = (langganan.site_name or "").strip() or " ↔ ".join(ujung.get(langganan.id, []))
        hasil.append((langganan.id, f"{langganan.service_no or '—'} — {site or paket.name}"))
    return hasil


def daftar_langganan_vendor(sesi, user, vendor_id: int) -> list:
    """Layanan dalam cakupan pengguna yang memakai vendor di salah satu sisi."""
    ids = set()
    for model in (SubscriptionInternet, SubscriptionP2P, P2PTransitHop):
        ids.update(
            sesi.execute(
                select(model.subscription_id).where(model.vendor_id == vendor_id)
            ).scalars()
        )
    if not ids:
        return []
    query = (
        select(Subscription, Customer, ServicePlan, ServiceCategory)
        .join(Customer, Subscription.customer_id == Customer.id)
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .where(Subscription.id.in_(ids))
        .order_by(Subscription.id.desc())
    )
    return list(sesi.execute(rbac.scoped(query, user, Customer)).all())


def jumlah_pelanggan_per_paket(sesi, user) -> dict[int, int]:
    """Berapa pelanggan berbeda yang punya langganan aktif di tiap paket.

    Dihitung `count(distinct customer_id)`: satu pelanggan dengan dua langganan
    pada paket yang sama tetap satu pelanggan.
    """
    query = (
        select(Subscription.plan_id, func.count(func.distinct(Subscription.customer_id)))
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.status == "active", Subscription.parent_id.is_(None))
        .group_by(Subscription.plan_id)
    )
    query = rbac.scoped(query, user, Customer)
    return {plan_id: jumlah for plan_id, jumlah in sesi.execute(query).all()}


def kategori_aktif_untuk(sesi, customer_ids: list[int]) -> dict[int, list]:
    """Kategori layanan aktif tiap pelanggan, satu query untuk seluruh halaman.

    Dipanggil sekali per halaman daftar. Membacanya per baris berarti satu
    query per pelanggan — pada daftar 1.248 pelanggan itu 1.248 query.
    """
    if not customer_ids:
        return {}

    baris = sesi.execute(
        select(Subscription.customer_id, ServiceCategory)
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .where(
            Subscription.customer_id.in_(customer_ids),
            Subscription.status == "active",
        )
        .order_by(ServiceCategory.sort_order)
    ).all()

    hasil: dict[int, list] = {}
    for customer_id, kategori in baris:
        daftar = hasil.setdefault(customer_id, [])
        if all(ada.id != kategori.id for ada in daftar):
            daftar.append(kategori)
    return hasil


def jumlah_aktif_per_pelanggan(sesi, user, customer_id: int) -> int:
    query = (
        select(func.count())
        .select_from(Subscription)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(
            Subscription.customer_id == customer_id,
            Subscription.status == "active",
            Subscription.parent_id.is_(None),
        )
    )
    return sesi.execute(rbac.scoped(query, user, Customer)).scalar_one()


def paket_terpopuler(sesi, user, limit: int = 5) -> list[dict]:
    """Paket dengan langganan aktif terbanyak, untuk panel Layanan Terpopuler."""
    query = (
        select(ServicePlan, ServiceCategory, func.count(Subscription.id))
        .join(Subscription, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.status == "active", Subscription.parent_id.is_(None))
        .group_by(ServicePlan.id, ServiceCategory.id)
        .order_by(func.count(Subscription.id).desc(), ServicePlan.name)
        .limit(limit)
    )
    query = rbac.scoped(query, user, Customer)
    return [
        {"paket": paket, "kategori": kategori, "jumlah": jumlah}
        for paket, kategori, jumlah in sesi.execute(query).all()
    ]


def hitung_per_kategori(sesi, user) -> list[dict]:
    """Jumlah langganan aktif per kategori layanan, terbanyak dulu."""
    query = (
        select(ServiceCategory, func.count(Subscription.id))
        .join(ServicePlan, Subscription.plan_id == ServicePlan.id)
        .join(ServiceCategory, ServicePlan.category_id == ServiceCategory.id)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.status == "active", Subscription.parent_id.is_(None))
        .group_by(ServiceCategory.id)
        .order_by(func.count(Subscription.id).desc())
    )
    query = rbac.scoped(query, user, Customer)
    return [
        {"kategori": kategori, "jumlah": jumlah}
        for kategori, jumlah in sesi.execute(query).all()
    ]
