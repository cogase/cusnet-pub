"""Notifikasi per pengguna.

Dua jenis isi, keduanya dihitung saat diminta — tidak ada tabel notifikasi:

1. **Perlu ditindaklanjuti**: keadaan yang menunggu tindakan (tiket kritis,
   invoice overdue, …). Bukan peristiwa, jadi tidak bisa "dibaca"; yang
   dicatat hanyalah jumlah terakhir yang sudah dilihat pengguna, supaya
   loncengnya menyala lagi begitu jumlahnya bertambah.
2. **Perubahan penting oleh pengguna lain** pada customer dan invoice,
   diambil dari audit log dan dibatasi seperti halaman Audit Log sendiri:
   peran bercabang hanya melihat tindakan rekan secabang, dan peran tanpa
   akses billing tidak melihat entri keuangan.

Yang sudah dibaca disimpan di `User.preferences`:
`notif_dibaca` (id audit terakhir) dan `notif_tindakan` (jumlah per kunci).
"""

from datetime import timedelta

from flask import url_for
from sqlalchemy import func, select

from app.core import rbac, waktu
from app.modules.admin.models import AuditLog, User

RENTANG_HARI = 14
BATAS_PERUBAHAN = 15

# Kolom yang perubahannya layak diberitahukan. Mengganti catatan atau alamat
# bukan urusan orang lain; mengganti status, harga, atau nomor layanan iya.
KOLOM_KRUSIAL = {
    "customer": {"status", "credit_limit", "payment_term_days", "branch_id", "name"},
    "subscription": {
        "status", "service_no", "plan_id", "price_override",
        "discount_kind", "discount_value", "terminated_at",
    },
    "invoice": {"status", "total", "due_at", "subtotal"},
    "payment": set(),
}
AKSI_SELALU = {"create": {"invoice", "payment", "customer"}, "delete": set(KOLOM_KRUSIAL),
               "void": {"invoice"}, "issue": {"invoice"}}
KATA_AKSI = {
    "create": "menambah", "update": "mengubah", "delete": "menghapus",
    "void": "membatalkan", "issue": "menerbitkan",
}
NAMA_ENTITAS = {
    "customer": "customer", "subscription": "layanan",
    "invoice": "invoice", "payment": "pembayaran",
}
NAMA_KOLOM = {
    "status": "status", "credit_limit": "kredit limit", "branch_id": "cabang",
    "payment_term_days": "termin bayar", "name": "nama", "service_no": "nomor layanan",
    "plan_id": "paket", "price_override": "harga khusus", "discount_kind": "jenis diskon",
    "discount_value": "nilai diskon", "terminated_at": "tanggal berhenti",
    "total": "total", "due_at": "jatuh tempo", "subtotal": "subtotal",
}
IKON = {"customer": "users", "subscription": "package", "invoice": "receipt", "payment": "wallet"}
NADA_AKSI = {"delete": "kritis", "void": "kritis", "create": "sehat", "issue": "info"}


def _penting(entri: AuditLog) -> bool:
    if entri.entity_type in AKSI_SELALU.get(entri.action, set()):
        return True
    if entri.action != "update":
        return False
    krusial = KOLOM_KRUSIAL.get(entri.entity_type, set())
    return bool(krusial & set(entri.changes or {}))


def _tautan(entri: AuditLog) -> str | None:
    """Tautan ke entitasnya; yang sudah dihapus tidak punya tujuan."""
    if entri.action == "delete" or not entri.entity_id:
        return None
    if entri.entity_type == "customer":
        return url_for("customers.pelanggan_detail", customer_id=entri.entity_id)
    if entri.entity_type == "subscription":
        return url_for("customers.langganan_detail", langganan_id=entri.entity_id)
    if entri.entity_type == "invoice":
        return url_for("billing.detail", invoice_id=entri.entity_id)
    if entri.entity_type == "payment":
        return url_for("billing.pembayaran_daftar")
    return None


def _kalimat(entri: AuditLog, aktor: User | None) -> str:
    siapa = aktor.full_name if aktor else "Sistem"
    kata = KATA_AKSI.get(entri.action, entri.action)
    apa = NAMA_ENTITAS.get(entri.entity_type, entri.entity_type)
    kalimat = f"{siapa} {kata} {apa}"
    if entri.action == "update":
        krusial = KOLOM_KRUSIAL.get(entri.entity_type, set())
        kolom = [NAMA_KOLOM.get(k, k) for k in (entri.changes or {}) if k in krusial]
        if kolom:
            kalimat += " (" + ", ".join(kolom[:3]) + ")"
    return kalimat


def perubahan(sesi, user) -> list[dict]:
    """Perubahan penting oleh pengguna lain, terbaru lebih dulu."""
    from app.modules.admin.service import _saring_audit

    entitas = set(KOLOM_KRUSIAL)
    if user.role in rbac.PERAN_TANPA_KEUANGAN:
        entitas -= rbac.ENTITAS_AUDIT_KEUANGAN
    sejak = waktu.sekarang() - timedelta(days=RENTANG_HARI)
    query = _saring_audit(
        select(AuditLog, User)
        .join(User, AuditLog.actor_user_id == User.id, isouter=True)
        .where(
            AuditLog.entity_type.in_(entitas),
            AuditLog.created_at >= sejak,
            AuditLog.actor_user_id.is_not(None),
            AuditLog.actor_user_id != user.id,
        )
        .order_by(AuditLog.id.desc())
        .limit(200),
        user,
    )
    dibaca = int((user.preferences or {}).get("notif_dibaca") or 0)
    hasil = []
    for entri, aktor in sesi.execute(query).all():
        if not _penting(entri):
            continue
        hasil.append(
            {
                "id": entri.id,
                "teks": _kalimat(entri, aktor),
                "rujukan": f"#{entri.entity_id}" if entri.entity_id else "",
                "waktu": entri.created_at,
                "href": _tautan(entri),
                "ikon": IKON.get(entri.entity_type, "activity"),
                "nada": NADA_AKSI.get(entri.action, "info"),
                "baru": entri.id > dibaca,
            }
        )
        if len(hasil) >= BATAS_PERUBAHAN:
            break
    return hasil


def tindakan(sesi, user) -> list[dict]:
    """Hal yang menunggu tindakan pengguna ini, sesuai perannya."""
    from app.modules.inventory import service as inventory_service
    from app.modules.tickets import service as ticket_service
    from app.modules.tickets.models import STATUS_TUTUP, Ticket

    butir = []

    def tambah(kunci, label, jumlah, nada, href):
        if jumlah:
            butir.append(
                {"kunci": kunci, "label": label, "jumlah": int(jumlah), "nada": nada, "href": href}
            )

    milik_saya = sesi.execute(
        rbac.scoped(
            select(func.count(Ticket.id)).where(
                Ticket.assigned_to_user_id == user.id, Ticket.status.notin_(STATUS_TUTUP)
            ),
            user,
            Ticket,
        )
    ).scalar_one()
    tambah("tiket_saya", "Tiket ditugaskan ke Anda", milik_saya, "antrean",
           url_for("tickets.daftar", petugas=user.id))

    tiket = ticket_service.ringkasan(sesi, user)
    tambah("tiket_kritis", "Tiket kritis masih terbuka", tiket["kritis"], "kritis",
           url_for("tickets.daftar", prioritas="kritis"))
    tambah("tiket_sla", "Tiket melewati SLA", tiket["lewat_sla"], "kritis",
           url_for("tickets.daftar"))

    if user.role not in rbac.PERAN_TANPA_KEUANGAN:
        from app.modules.billing import service as billing_service

        per_status = billing_service.ringkasan_billing(sesi, user)["per_status"]
        tambah("invoice_overdue", "Invoice lewat jatuh tempo", per_status.get("overdue", 0),
               "kritis", url_for("billing.daftar", status="overdue"))
        tambah("invoice_draf", "Invoice draf belum terbit", per_status.get("draft", 0),
               "antrean", url_for("billing.daftar", status="draft"))

    from app.modules.inventory import pantau

    tambah("perangkat_turun", "Perangkat tidak merespons", pantau.jumlah_turun(sesi, user),
           "kritis", url_for("inventory.perangkat_daftar"))

    jaringan = inventory_service.ringkasan(sesi, user)
    tambah("perangkat", "Perangkat bermasalah", jaringan["perangkat_bermasalah"], "waspada",
           url_for("inventory.perangkat_daftar", status="rusak"))

    dilihat = (user.preferences or {}).get("notif_tindakan") or {}
    for satu in butir:
        satu["baru"] = satu["jumlah"] > int(dilihat.get(satu["kunci"]) or 0)
    return butir


def rangkum(sesi, user) -> dict:
    daftar_tindakan = tindakan(sesi, user)
    daftar_perubahan = perubahan(sesi, user)
    return {
        "tindakan": daftar_tindakan,
        "perubahan": daftar_perubahan,
        "jumlah_baru": sum(1 for s in daftar_tindakan if s["baru"])
        + sum(1 for s in daftar_perubahan if s["baru"]),
    }


def tandai_dibaca(sesi, user) -> None:
    """Mencatat semua yang tampil sekarang sebagai sudah dibaca."""
    terakhir = sesi.execute(select(func.max(AuditLog.id))).scalar() or 0
    prefs = dict(user.preferences or {})
    prefs["notif_dibaca"] = int(terakhir)
    prefs["notif_tindakan"] = {s["kunci"]: s["jumlah"] for s in tindakan(sesi, user)}
    user.preferences = prefs
    sesi.flush()
