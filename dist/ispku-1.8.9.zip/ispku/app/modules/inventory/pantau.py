"""Pemantauan ringan: apakah perangkat masih terjangkau dari server ini.

Dijalankan `flask pantau-perangkat` lewat cron. Hanya perangkat yang
dicentang "Pantau" dan punya alamat manajemen yang diperiksa.

Cara memeriksa, berurutan: ICMP echo lewat soket datagram (tidak butuh
biner `ping` maupun hak root di kebanyakan kernel), lalu — kalau ICMP tidak
diizinkan — membuka koneksi TCP ke beberapa port manajemen umum. Koneksi
yang DITOLAK tetap berarti perangkatnya hidup; yang dihitung mati hanya
yang tidak menjawab sama sekali.

Satu kegagalan belum berarti turun: status baru berubah sesudah
`BATAS_GAGAL` pemeriksaan berturut-turut, supaya satu paket hilang tidak
membuka tiket.
"""

import logging
import os
import re
import socket
import struct
import time

from sqlalchemy import select

from app.core import rbac
from app.modules.inventory.models import Device

_log = logging.getLogger(__name__)

BATAS_GAGAL = 2
PORT_TCP = (22, 443, 80, 8291)
_POLA_HOST = re.compile(r"^(?:[a-z]+://)?\[?([^\]/]+?)\]?(?::\d+)?(?:/.*)?$", re.I)


def host_dari(alamat: str | None) -> str | None:
    """Nama host atau IP dari isian Alamat Manajemen yang bentuknya bebas."""
    alamat = (alamat or "").strip()
    if not alamat:
        return None
    # IPv6 polos memuat banyak titik dua; jangan dipotong sebagai port.
    if alamat.count(":") > 1 and "[" not in alamat and "//" not in alamat:
        return alamat
    cocok = _POLA_HOST.match(alamat)
    return cocok.group(1) if cocok else None


def _checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    jumlah = sum(struct.unpack(f"!{len(data) // 2}H", data))
    jumlah = (jumlah >> 16) + (jumlah & 0xFFFF)
    jumlah += jumlah >> 16
    return ~jumlah & 0xFFFF


def _icmp(ip: str, tenggat: float) -> bool | None:
    """True/False hasil echo; None bila ICMP tidak bisa dipakai di sini."""
    try:
        soket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_ICMP)
    except (PermissionError, OSError):
        return None
    try:
        soket.settimeout(tenggat)
        isi = struct.pack("!d", time.time())
        kepala = struct.pack("!BBHHH", 8, 0, 0, os.getpid() & 0xFFFF, 1)
        paket = struct.pack("!BBHHH", 8, 0, _checksum(kepala + isi), os.getpid() & 0xFFFF, 1) + isi
        soket.sendto(paket, (ip, 0))
        soket.recvfrom(1024)
        return True
    except socket.timeout:
        return False
    except OSError:
        return None
    finally:
        soket.close()


def _tcp(ip: str, tenggat: float) -> bool:
    for port in PORT_TCP:
        try:
            with socket.create_connection((ip, port), timeout=tenggat):
                return True
        except ConnectionRefusedError:
            return True
        except OSError:
            continue
    return False


def periksa(alamat: str, tenggat: float = 1.5) -> bool:
    """Apakah `alamat` menjawab. Tidak pernah melempar galat."""
    host = host_dari(alamat)
    if not host:
        return False
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        return False
    hasil = _icmp(ip, tenggat)
    if hasil:
        return True
    # ICMP sering diblokir sementara port manajemennya terbuka.
    return _tcp(ip, tenggat)


def _buka_tiket(sesi, perangkat: Device, sekarang) -> str | None:
    from app.modules.tickets import service as ticket_service
    from app.modules.tickets.models import STATUS_TUTUP, Ticket, TicketCategory

    sudah = sesi.execute(
        select(Ticket.id).where(
            Ticket.device_id == perangkat.id, Ticket.status.notin_(STATUS_TUTUP)
        )
    ).first()
    if sudah is not None:
        return None
    # Kategori dengan tenggat penyelesaian terpendek = yang paling mendesak.
    kategori = sesi.execute(
        select(TicketCategory)
        .where(TicketCategory.is_active.is_(True))
        .order_by(TicketCategory.sla_resolve_hours, TicketCategory.id)
    ).scalars().first()
    if kategori is None:
        return None
    tiket = ticket_service.buat(
        sesi, rbac.SISTEM,
        {
            "branch_id": perangkat.branch_id,
            "category_id": kategori.id,
            "priority": "kritis",
            "title": f"Perangkat {perangkat.name} tidak merespons",
            "description": (
                f"Pemantauan otomatis: {perangkat.name} ({perangkat.mgmt_address}) tidak "
                f"menjawab {BATAS_GAGAL} pemeriksaan berturut-turut. Tiket ini dibuka sistem."
            ),
            "device_id": perangkat.id,
        },
        sekarang=sekarang,
    )
    return tiket.number


def _catat_pulih(sesi, perangkat: Device, sekarang) -> None:
    from app.modules.tickets import service as ticket_service
    from app.modules.tickets.models import STATUS_TUTUP, Ticket

    for tiket in sesi.execute(
        select(Ticket).where(
            Ticket.device_id == perangkat.id,
            Ticket.status.notin_(STATUS_TUTUP),
            Ticket.opened_by_user_id.is_(None),
        )
    ).scalars():
        ticket_service.tambah_komentar(
            sesi, rbac.SISTEM, tiket.id,
            f"Pemantauan otomatis: {perangkat.name} kembali merespons. "
            "Tiket tidak ditutup otomatis; pastikan penyebabnya sebelum menutup.",
            sekarang=sekarang,
        )


def jalankan(sesi, sekarang, pemeriksa=periksa, buka_tiket: bool = True) -> dict:
    """Memeriksa semua perangkat yang dipantau dan memperbarui statusnya."""
    hasil = {"diperiksa": 0, "naik": 0, "turun": 0, "baru_turun": [], "pulih": [], "tiket": []}
    perangkat = sesi.execute(
        select(Device)
        .where(
            Device.monitor_enabled.is_(True),
            Device.mgmt_address.is_not(None),
            Device.mgmt_address != "",
        )
        .order_by(Device.id)
    ).scalars().all()

    for satu in perangkat:
        hidup = bool(pemeriksa(satu.mgmt_address))
        hasil["diperiksa"] += 1
        satu.monitor_checked_at = sekarang
        if hidup:
            hasil["naik"] += 1
            satu.monitor_fail_count = 0
            if satu.monitor_status != "naik":
                pulih = satu.monitor_status == "turun"
                satu.monitor_status = "naik"
                satu.monitor_changed_at = sekarang
                if pulih:
                    hasil["pulih"].append(satu.name)
                    _catat_pulih(sesi, satu, sekarang)
            continue

        satu.monitor_fail_count += 1
        if satu.monitor_fail_count >= BATAS_GAGAL and satu.monitor_status != "turun":
            satu.monitor_status = "turun"
            satu.monitor_changed_at = sekarang
            hasil["baru_turun"].append(satu.name)
            if buka_tiket:
                nomor = _buka_tiket(sesi, satu, sekarang)
                if nomor:
                    hasil["tiket"].append(nomor)
        if satu.monitor_status == "turun":
            hasil["turun"] += 1

    sesi.flush()
    return hasil


def jumlah_turun(sesi, user) -> int:
    from sqlalchemy import func

    return sesi.execute(
        rbac.scoped(
            select(func.count(Device.id)).where(
                Device.monitor_enabled.is_(True), Device.monitor_status == "turun"
            ),
            user,
            Device,
        )
    ).scalar_one()
