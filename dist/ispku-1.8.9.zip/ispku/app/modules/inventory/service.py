"""Aturan inventaris jaringan.

Kontrak yang mengikat modul lain:

| Fungsi | Kontrak |
|---|---|
| `alokasi_port` / `bebaskan_port` | Satu-satunya tempat `DevicePort.subscription_id` dan `status` berubah karena alokasi |
| `pindah_site` | Satu-satunya tempat perangkat berpindah site; ia ikut memperbarui `branch_id` port |
| `hapus_site` / `hapus_perangkat` | Menolak menghapus yang masih punya isi, bukan menghapus berantai |

Seluruh query melewati `rbac.scoped` lewat `branch_id` masing-masing tabel.
"""

import ipaddress

from sqlalchemy import String, func, or_, select

from app.core import audit, rbac
from app.core.errors import GalatDomain, TidakDitemukan
from app.core.pagination import paginate
from app.modules.inventory.models import (
    JENIS_BLOK_IP,
    JENIS_PERANGKAT,
    JENIS_PORT,
    JENIS_SITE,
    JENIS_VLAN,
    STATUS_PERANGKAT,
    STATUS_PORT,
    Device,
    DevicePort,
    IpBlock,
    Site,
    Vlan,
)

KOLOM_SITE = ("code", "name", "branch_id", "kind", "address", "lat", "lng",
              "is_active", "note")
KOLOM_PERANGKAT = ("site_id", "branch_id", "name", "kind", "brand", "model",
                   "mgmt_address", "serial_number", "status", "note", "monitor_enabled")
KOLOM_PORT = ("device_id", "branch_id", "name", "kind", "speed_mbps", "status",
              "subscription_id", "note")
KOLOM_VLAN = ("vlan_id", "name", "site_id", "branch_id", "kind",
              "subscription_id", "note")
KOLOM_BLOK = ("cidr", "kind", "site_id", "branch_id", "gateway",
              "subscription_id", "note")

# Status port yang berarti "tidak boleh dialokasikan". `bebas` satu-satunya
# yang boleh; `terpakai` ditolak dengan pesan yang menyebut langganannya.
STATUS_TIDAK_BOLEH_DIALOKASIKAN = ("rusak", "dicadangkan")


class NilaiTidakDikenal(GalatDomain):
    """Jenis atau status di luar daftar."""


class PortSudahTerpakai(GalatDomain):
    """Port sudah dialokasikan ke langganan lain."""


class PortTidakBisaDialokasikan(GalatDomain):
    """Port rusak atau sengaja dicadangkan."""


class MasihDipakai(GalatDomain):
    """Baris masih punya isi yang akan menggantung kalau dihapus."""


class CidrTidakSah(GalatDomain):
    """Blok IP bukan CIDR yang sah."""


class VlanDiLuarRentang(GalatDomain):
    """Nomor VLAN di luar 1–4094."""


def _potret(obj, kolom) -> dict:
    return {nama: getattr(obj, nama) for nama in kolom}


def _pastikan_pilihan(nilai, daftar, field, label) -> None:
    if nilai is not None and nilai not in daftar:
        raise NilaiTidakDikenal(
            field, f"{label} harus salah satu dari: " + ", ".join(daftar)
        )


# --- Site -----------------------------------------------------------------


def daftar_site(sesi, user, page: int = 1, per_page: int = 25, q: str | None = None):
    query = select(Site)
    if q:
        pola = f"%{q}%"
        query = query.where(or_(Site.code.ilike(pola), Site.name.ilike(pola)))
    query = rbac.scoped(query, user, Site).order_by(Site.code)
    return paginate(sesi, query, page=page, per_page=per_page)


def site_pilihan(sesi, user) -> list[Site]:
    query = rbac.scoped(select(Site), user, Site).order_by(Site.code)
    return list(sesi.execute(query).scalars().all())


def ambil_site(sesi, user, site_id: int) -> Site:
    site = sesi.get(Site, site_id)
    if site is None:
        raise TidakDitemukan("Site tidak ditemukan.")
    rbac.assert_branch_access(user, site.branch_id)
    return site


def tambah_site(sesi, aktor, data: dict) -> Site:
    _pastikan_pilihan(data.get("kind"), JENIS_SITE, "kind", "Jenis site")
    rbac.assert_branch_access(aktor, data["branch_id"])

    site = Site(**{k: data[k] for k in KOLOM_SITE if k in data})
    sesi.add(site)
    sesi.flush()
    audit.record(
        sesi, "create", "site", site.id, after=_potret(site, KOLOM_SITE), aktor=aktor
    )
    return site


def ubah_site(sesi, aktor, site_id: int, data: dict) -> Site:
    site = ambil_site(sesi, aktor, site_id)
    _pastikan_pilihan(data.get("kind"), JENIS_SITE, "kind", "Jenis site")
    if "branch_id" in data and data["branch_id"] != site.branch_id:
        rbac.assert_branch_access(aktor, data["branch_id"])

    sebelum = _potret(site, KOLOM_SITE)
    for nama in KOLOM_SITE:
        if nama in data:
            setattr(site, nama, data[nama])
    sesi.flush()

    # Cabang site berpindah berarti seluruh perangkat dan portnya ikut
    # berpindah; kalau tidak, salinan `branch_id` di bawahnya jadi bohong dan
    # staf cabang lama masih melihat perangkatnya.
    if sebelum["branch_id"] != site.branch_id:
        for perangkat in sesi.execute(
            select(Device).where(Device.site_id == site.id)
        ).scalars().all():
            perangkat.branch_id = site.branch_id
            for port in sesi.execute(
                select(DevicePort).where(DevicePort.device_id == perangkat.id)
            ).scalars().all():
                port.branch_id = site.branch_id
        sesi.flush()

    audit.record(
        sesi, "update", "site", site.id,
        before=sebelum, after=_potret(site, KOLOM_SITE), aktor=aktor,
    )
    return site


def hapus_site(sesi, aktor, site_id: int) -> int:
    """Menolak menghapus site yang masih punya perangkat.

    Menghapus berantai berarti port yang dialokasikan ke langganan pelanggan
    ikut lenyap tanpa ada yang tahu.
    """
    site = ambil_site(sesi, aktor, site_id)
    jumlah = sesi.execute(
        select(func.count(Device.id)).where(Device.site_id == site_id)
    ).scalar_one()
    if jumlah:
        raise MasihDipakai(
            "code", f"Site ini masih memuat {jumlah} perangkat. Pindahkan dulu."
        )

    sebelum = _potret(site, KOLOM_SITE)
    sesi.delete(site)
    sesi.flush()
    audit.record(sesi, "delete", "site", site_id, before=sebelum, aktor=aktor)
    return site_id


# --- Perangkat ------------------------------------------------------------


def daftar_perangkat(
    sesi, user, page: int = 1, per_page: int = 25, q: str | None = None,
    site_id: int | None = None, status: str | None = None, kind: str | None = None,
):
    query = select(Device)
    if q:
        pola = f"%{q}%"
        query = query.where(
            or_(
                Device.name.ilike(pola),
                Device.mgmt_address.ilike(pola),
                Device.serial_number.ilike(pola),
            )
        )
    if site_id:
        query = query.where(Device.site_id == site_id)
    if status:
        query = query.where(Device.status == status)
    if kind:
        query = query.where(Device.kind == kind)
    query = rbac.scoped(query, user, Device).order_by(Device.name)
    return paginate(sesi, query, page=page, per_page=per_page)


def ambil_perangkat(sesi, user, device_id: int) -> Device:
    perangkat = sesi.get(Device, device_id)
    if perangkat is None:
        raise TidakDitemukan("Perangkat tidak ditemukan.")
    rbac.assert_branch_access(user, perangkat.branch_id)
    return perangkat


def tambah_perangkat(sesi, aktor, data: dict) -> Device:
    _pastikan_pilihan(data.get("kind"), JENIS_PERANGKAT, "kind", "Jenis perangkat")
    _pastikan_pilihan(data.get("status"), STATUS_PERANGKAT, "status", "Status")

    site = ambil_site(sesi, aktor, data["site_id"])
    # `branch_id` selalu diturunkan dari site, tidak pernah dari formulir:
    # perangkat yang cabangnya berbeda dari sitenya adalah data yang salah,
    # bukan pilihan pengguna.
    perangkat = Device(
        **{k: data[k] for k in KOLOM_PERANGKAT if k in data and k != "branch_id"}
    )
    perangkat.branch_id = site.branch_id
    sesi.add(perangkat)
    sesi.flush()
    audit.record(
        sesi, "create", "device", perangkat.id,
        after=_potret(perangkat, KOLOM_PERANGKAT), aktor=aktor,
    )
    return perangkat


def ubah_perangkat(sesi, aktor, device_id: int, data: dict) -> Device:
    perangkat = ambil_perangkat(sesi, aktor, device_id)
    _pastikan_pilihan(data.get("kind"), JENIS_PERANGKAT, "kind", "Jenis perangkat")
    _pastikan_pilihan(data.get("status"), STATUS_PERANGKAT, "status", "Status")

    sebelum = _potret(perangkat, KOLOM_PERANGKAT)
    for nama in KOLOM_PERANGKAT:
        if nama in data and nama not in ("branch_id", "site_id"):
            setattr(perangkat, nama, data[nama])

    if data.get("site_id") and data["site_id"] != perangkat.site_id:
        pindah_site(sesi, aktor, perangkat, data["site_id"])

    sesi.flush()
    audit.record(
        sesi, "update", "device", perangkat.id,
        before=sebelum, after=_potret(perangkat, KOLOM_PERANGKAT), aktor=aktor,
    )
    return perangkat


def pindah_site(sesi, aktor, perangkat: Device, site_id: int) -> Device:
    """Memindahkan perangkat ke site lain berikut seluruh portnya.

    Satu-satunya tempat `Device.site_id` berubah. Port ikut dipindahkan
    cabangnya di sini — kalau tidak, salinan `branch_id` di port jadi bohong.
    """
    site = ambil_site(sesi, aktor, site_id)
    perangkat.site_id = site.id
    perangkat.branch_id = site.branch_id
    for port in sesi.execute(
        select(DevicePort).where(DevicePort.device_id == perangkat.id)
    ).scalars().all():
        port.branch_id = site.branch_id
    sesi.flush()
    return perangkat


def hapus_perangkat(sesi, aktor, device_id: int) -> int:
    """Menolak menghapus perangkat yang portnya masih dialokasikan."""
    perangkat = ambil_perangkat(sesi, aktor, device_id)
    terpakai = sesi.execute(
        select(func.count(DevicePort.id)).where(
            DevicePort.device_id == device_id,
            DevicePort.subscription_id.is_not(None),
        )
    ).scalar_one()
    if terpakai:
        raise MasihDipakai(
            "name",
            f"{terpakai} port perangkat ini masih dialokasikan ke langganan. "
            "Bebaskan dulu.",
        )

    sebelum = _potret(perangkat, KOLOM_PERANGKAT)
    sesi.delete(perangkat)
    sesi.flush()
    audit.record(sesi, "delete", "device", device_id, before=sebelum, aktor=aktor)
    return device_id


# --- Port -----------------------------------------------------------------


def daftar_port(sesi, user, device_id: int) -> list[DevicePort]:
    ambil_perangkat(sesi, user, device_id)
    return list(
        sesi.execute(
            select(DevicePort)
            .where(DevicePort.device_id == device_id)
            .order_by(DevicePort.id)
        ).scalars().all()
    )


def ambil_port(sesi, user, port_id: int) -> DevicePort:
    port = sesi.get(DevicePort, port_id)
    if port is None:
        raise TidakDitemukan("Port tidak ditemukan.")
    rbac.assert_branch_access(user, port.branch_id)
    return port


def tambah_port(sesi, aktor, device_id: int, data: dict) -> DevicePort:
    _pastikan_pilihan(data.get("kind"), JENIS_PORT, "kind", "Jenis port")
    _pastikan_pilihan(data.get("status"), STATUS_PORT, "status", "Status")

    perangkat = ambil_perangkat(sesi, aktor, device_id)
    port = DevicePort(
        **{
            k: data[k]
            for k in KOLOM_PORT
            if k in data and k not in ("device_id", "branch_id", "subscription_id")
        }
    )
    port.device_id = perangkat.id
    port.branch_id = perangkat.branch_id
    sesi.add(port)
    sesi.flush()
    audit.record(
        sesi, "create", "device_port", port.id,
        after=_potret(port, KOLOM_PORT), aktor=aktor,
    )
    return port


def ubah_port(sesi, aktor, port_id: int, data: dict) -> DevicePort:
    """Menyunting keterangan port. Alokasi **tidak** diubah lewat sini."""
    port = ambil_port(sesi, aktor, port_id)
    _pastikan_pilihan(data.get("kind"), JENIS_PORT, "kind", "Jenis port")
    _pastikan_pilihan(data.get("status"), STATUS_PORT, "status", "Status")

    if data.get("status") == "bebas" and port.subscription_id:
        raise PortSudahTerpakai(
            "status",
            "Port ini masih dialokasikan. Bebaskan alokasinya dulu, jangan "
            "menyetel statusnya langsung.",
        )
    if data.get("status") == "terpakai" and not port.subscription_id:
        raise PortSudahTerpakai(
            "status",
            "Status terpakai hanya boleh datang dari alokasi ke langganan.",
        )

    sebelum = _potret(port, KOLOM_PORT)
    for nama in ("name", "kind", "speed_mbps", "status", "note"):
        if nama in data:
            setattr(port, nama, data[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "device_port", port.id,
        before=sebelum, after=_potret(port, KOLOM_PORT), aktor=aktor,
    )
    return port


def alokasi_port(sesi, aktor, port_id: int, subscription_id: int) -> DevicePort:
    """Menautkan port ke langganan.

    Satu-satunya tempat `subscription_id` dan status alokasi berubah. Batasan
    unik di basis data adalah lapis pertahanan kedua; pemeriksaan di sini ada
    supaya pesannya bisa menyebut langganan mana yang sudah memakainya.
    """
    port = ambil_port(sesi, aktor, port_id)

    if port.status in STATUS_TIDAK_BOLEH_DIALOKASIKAN:
        raise PortTidakBisaDialokasikan(
            "status", f"Port berstatus '{port.status}' tidak bisa dialokasikan."
        )
    if port.subscription_id and port.subscription_id != subscription_id:
        raise PortSudahTerpakai(
            "subscription_id",
            f"Port ini sudah dialokasikan ke langganan #{port.subscription_id}.",
        )

    lain = sesi.execute(
        select(DevicePort).where(
            DevicePort.subscription_id == subscription_id,
            DevicePort.id != port.id,
        )
    ).scalars().first()
    if lain is not None:
        raise PortSudahTerpakai(
            "subscription_id",
            f"Langganan ini sudah memakai port {lain.name}. Bebaskan dulu.",
        )

    sebelum = _potret(port, KOLOM_PORT)
    port.subscription_id = subscription_id
    port.status = "terpakai"
    sesi.flush()
    audit.record(
        sesi, "update", "device_port", port.id,
        before=sebelum, after=_potret(port, KOLOM_PORT), aktor=aktor,
    )
    return port


def bebaskan_port(sesi, aktor, port_id: int) -> DevicePort:
    port = ambil_port(sesi, aktor, port_id)
    sebelum = _potret(port, KOLOM_PORT)
    port.subscription_id = None
    port.status = "bebas"
    sesi.flush()
    audit.record(
        sesi, "update", "device_port", port.id,
        before=sebelum, after=_potret(port, KOLOM_PORT), aktor=aktor,
    )
    return port


def hapus_port(sesi, aktor, port_id: int) -> int:
    port = ambil_port(sesi, aktor, port_id)
    if port.subscription_id:
        raise MasihDipakai(
            "name", "Port ini masih dialokasikan ke langganan. Bebaskan dulu."
        )
    sebelum = _potret(port, KOLOM_PORT)
    device_id = port.device_id
    sesi.delete(port)
    sesi.flush()
    audit.record(sesi, "delete", "device_port", port_id, before=sebelum, aktor=aktor)
    return device_id


def port_langganan(sesi, user, subscription_id: int) -> DevicePort | None:
    """Port yang dialokasikan ke satu langganan, kalau ada.

    Dipakai halaman Detail Layanan supaya teknisi tahu kabelnya menancap di
    mana tanpa menyisir seluruh perangkat.
    """
    query = select(DevicePort).where(DevicePort.subscription_id == subscription_id)
    return sesi.execute(rbac.scoped(query, user, DevicePort)).scalars().first()


# --- VLAN -----------------------------------------------------------------


def daftar_vlan(sesi, user, page: int = 1, per_page: int = 25, q: str | None = None):
    query = select(Vlan)
    if q:
        pola = f"%{q}%"
        query = query.where(
            or_(Vlan.name.ilike(pola), func.cast(Vlan.vlan_id, String).ilike(pola))
        )
    query = rbac.scoped(query, user, Vlan).order_by(Vlan.vlan_id)
    return paginate(sesi, query, page=page, per_page=per_page)


def ambil_vlan(sesi, user, vlan_row_id: int) -> Vlan:
    baris = sesi.get(Vlan, vlan_row_id)
    if baris is None:
        raise TidakDitemukan("VLAN tidak ditemukan.")
    rbac.assert_branch_access(user, baris.branch_id)
    return baris


def _pastikan_vlan(data: dict) -> None:
    _pastikan_pilihan(data.get("kind"), JENIS_VLAN, "kind", "Jenis VLAN")
    nomor = data.get("vlan_id")
    if nomor is not None and not (1 <= int(nomor) <= 4094):
        raise VlanDiLuarRentang("vlan_id", "Nomor VLAN harus antara 1 dan 4094.")


def tambah_vlan(sesi, aktor, data: dict) -> Vlan:
    _pastikan_vlan(data)
    rbac.assert_branch_access(aktor, data["branch_id"])
    baris = Vlan(**{k: data[k] for k in KOLOM_VLAN if k in data})
    sesi.add(baris)
    sesi.flush()
    audit.record(
        sesi, "create", "vlan", baris.id, after=_potret(baris, KOLOM_VLAN), aktor=aktor
    )
    return baris


def ubah_vlan(sesi, aktor, vlan_row_id: int, data: dict) -> Vlan:
    baris = ambil_vlan(sesi, aktor, vlan_row_id)
    if baris.is_auto:
        raise MasihDipakai(
            "vlan_id",
            "VLAN ini dikelola otomatis dari detail layanan dan tidak dapat diubah di Network.",
        )
    _pastikan_vlan(data)
    sebelum = _potret(baris, KOLOM_VLAN)
    for nama in KOLOM_VLAN:
        if nama in data:
            setattr(baris, nama, data[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "vlan", baris.id,
        before=sebelum, after=_potret(baris, KOLOM_VLAN), aktor=aktor,
    )
    return baris


def hapus_vlan(sesi, aktor, vlan_row_id: int) -> int:
    baris = ambil_vlan(sesi, aktor, vlan_row_id)
    if baris.is_auto:
        raise MasihDipakai(
            "vlan_id",
            "VLAN ini dikelola otomatis dari detail layanan. Hapus VLAN dari layanan terkait.",
        )
    sebelum = _potret(baris, KOLOM_VLAN)
    sesi.delete(baris)
    sesi.flush()
    audit.record(sesi, "delete", "vlan", vlan_row_id, before=sebelum, aktor=aktor)
    return vlan_row_id


# --- Blok IP --------------------------------------------------------------


def daftar_blok(sesi, user, page: int = 1, per_page: int = 25, q: str | None = None):
    query = select(IpBlock)
    if q:
        query = query.where(IpBlock.cidr.ilike(f"%{q}%"))
    query = rbac.scoped(query, user, IpBlock).order_by(IpBlock.cidr)
    return paginate(sesi, query, page=page, per_page=per_page)


def ambil_blok(sesi, user, blok_id: int) -> IpBlock:
    baris = sesi.get(IpBlock, blok_id)
    if baris is None:
        raise TidakDitemukan("Blok IP tidak ditemukan.")
    rbac.assert_branch_access(user, baris.branch_id)
    return baris


def _rapikan_cidr(nilai: str) -> str:
    """Memvalidasi dan menormalkan CIDR.

    `strict=False` menerima `103.10.10.5/29` dan mengubahnya jadi alamat
    jaringannya — orang menuliskan alamat perangkat, bukan alamat jaringan,
    dan menolaknya mentah-mentah cuma memindahkan pekerjaan ke pengguna.
    """
    try:
        return str(ipaddress.ip_network(str(nilai).strip(), strict=False))
    except ValueError as galat:
        raise CidrTidakSah(
            "cidr", "Blok IP harus berbentuk CIDR, contoh: 103.10.10.0/29."
        ) from galat


def tambah_blok(sesi, aktor, data: dict) -> IpBlock:
    _pastikan_pilihan(data.get("kind"), JENIS_BLOK_IP, "kind", "Jenis blok")
    rbac.assert_branch_access(aktor, data["branch_id"])

    bersih = dict(data)
    bersih["cidr"] = _rapikan_cidr(bersih["cidr"])
    baris = IpBlock(**{k: bersih[k] for k in KOLOM_BLOK if k in bersih})
    sesi.add(baris)
    sesi.flush()
    audit.record(
        sesi, "create", "ip_block", baris.id,
        after=_potret(baris, KOLOM_BLOK), aktor=aktor,
    )
    return baris


def ubah_blok(sesi, aktor, blok_id: int, data: dict) -> IpBlock:
    baris = ambil_blok(sesi, aktor, blok_id)
    _pastikan_pilihan(data.get("kind"), JENIS_BLOK_IP, "kind", "Jenis blok")

    bersih = dict(data)
    if bersih.get("cidr"):
        bersih["cidr"] = _rapikan_cidr(bersih["cidr"])

    sebelum = _potret(baris, KOLOM_BLOK)
    for nama in KOLOM_BLOK:
        if nama in bersih:
            setattr(baris, nama, bersih[nama])
    sesi.flush()
    audit.record(
        sesi, "update", "ip_block", baris.id,
        before=sebelum, after=_potret(baris, KOLOM_BLOK), aktor=aktor,
    )
    return baris


def hapus_blok(sesi, aktor, blok_id: int) -> int:
    baris = ambil_blok(sesi, aktor, blok_id)
    sebelum = _potret(baris, KOLOM_BLOK)
    sesi.delete(baris)
    sesi.flush()
    audit.record(sesi, "delete", "ip_block", blok_id, before=sebelum, aktor=aktor)
    return blok_id


# --- Ringkasan ------------------------------------------------------------


def langganan_tanpa_port(sesi, user, termasuk: int | None = None) -> list:
    """Langganan yang belum punya port, sebagai baris `(langganan, pelanggan)`.

    Menawarkan langganan yang sudah punya port berarti tombol yang selalu
    ditolak. `termasuk` menahan satu langganan tetap muncul — dipakai formulir
    alokasi ulang, supaya pilihan yang sedang terpasang tidak hilang dari
    daftarnya sendiri.
    """
    from app.modules.customers.models import Customer
    from app.modules.customers.subscriptions import Subscription

    terpakai = select(DevicePort.subscription_id).where(
        DevicePort.subscription_id.is_not(None)
    )
    if termasuk:
        terpakai = terpakai.where(DevicePort.subscription_id != termasuk)

    query = (
        select(Subscription, Customer)
        .join(Customer, Subscription.customer_id == Customer.id)
        .where(Subscription.id.notin_(terpakai))
        .order_by(Subscription.service_no)
    )
    return list(sesi.execute(rbac.scoped(query, user, Customer)).all())


def titik_peta(sesi, user) -> list[dict]:
    """Koordinat site dan pelanggan untuk peta sebaran.

    Baris tanpa koordinat dilewati, bukan diletakkan di titik nol — pelanggan
    yang muncul di tengah Samudra Atlantik lebih menyesatkan daripada
    pelanggan yang tidak muncul sama sekali.
    """
    from app.modules.customers.models import Customer

    titik = []

    query_site = rbac.scoped(
        select(Site).where(Site.lat.is_not(None), Site.lng.is_not(None)), user, Site
    )
    for site in sesi.execute(query_site).scalars().all():
        titik.append(
            {
                "jenis": "site",
                "nama": f"{site.code} — {site.name}",
                "lat": float(site.lat),
                "lng": float(site.lng),
                "id": site.id,
            }
        )

    query_pelanggan = rbac.scoped(
        select(Customer).where(
            Customer.install_lat.is_not(None), Customer.install_lng.is_not(None)
        ),
        user,
        Customer,
    )
    for pelanggan in sesi.execute(query_pelanggan).scalars().all():
        titik.append(
            {
                "jenis": "pelanggan",
                "nama": f"{pelanggan.cid} — {pelanggan.name}",
                "lat": float(pelanggan.install_lat),
                "lng": float(pelanggan.install_lng),
                "id": pelanggan.id,
            }
        )

    return titik


def ringkasan(sesi, user) -> dict:
    """Angka kartu di halaman Network."""

    def hitung(model, *kondisi):
        query = select(func.count(model.id))
        for syarat in kondisi:
            query = query.where(syarat)
        return sesi.execute(rbac.scoped(query, user, model)).scalar_one()

    terpakai = hitung(DevicePort, DevicePort.subscription_id.is_not(None))
    total_port = hitung(DevicePort)

    return {
        "site": hitung(Site),
        "perangkat": hitung(Device),
        "perangkat_bermasalah": hitung(Device, Device.status.in_(("rusak", "pensiun"))),
        "port": total_port,
        "port_terpakai": terpakai,
        "port_bebas": hitung(DevicePort, DevicePort.status == "bebas"),
        # Angka yang paling sering ditanya saat menerima pelanggan baru:
        # masih ada kapasitas atau tidak.
        "persen_terpakai": (
            round(terpakai * 100 / total_port, 1) if total_port else 0.0
        ),
        "vlan": hitung(Vlan),
        "blok_ip": hitung(IpBlock),
    }
