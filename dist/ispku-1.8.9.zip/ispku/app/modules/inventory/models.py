"""Inventaris jaringan: site/POP, perangkat, port, VLAN, dan blok IP (M4).

`branch_id` disalin ke perangkat dan port, tidak hanya hidup di site. Alasannya
sama dengan tiket: penyaringan cabang harus bisa dilakukan tanpa join berantai
di setiap query, dan port adalah tabel yang paling sering dibaca.

Konsekuensinya salinan itu harus dijaga — `service.pindah_site` adalah
satu-satunya tempat perangkat berpindah site, dan ia ikut memperbarui port.
"""

from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base
from app.core.models import TimestampMixin, enum_check

JENIS_SITE: tuple[str, ...] = ("pop", "datacenter", "tower", "kantor", "lainnya")

JENIS_PERANGKAT: tuple[str, ...] = (
    "router",
    "switch",
    "olt",
    "onu",
    "radio",
    "server",
    "lainnya",
)

# `pensiun` dipisahkan dari `rusak`: perangkat pensiun sengaja dikeluarkan dari
# layanan, yang rusak menunggu diperbaiki. Dua-duanya tidak boleh dipakai, tapi
# hanya satu yang perlu ditindaklanjuti.
STATUS_PERANGKAT: tuple[str, ...] = ("aktif", "cadangan", "rusak", "pensiun")

JENIS_PORT: tuple[str, ...] = ("access", "trunk", "uplink", "manajemen")

# Status port dihitung dari alokasinya, bukan disetel manual — lihat
# `service.alokasi_port`. `rusak` dan `dicadangkan` yang disetel manusia.
STATUS_PORT: tuple[str, ...] = ("bebas", "terpakai", "rusak", "dicadangkan")

JENIS_VLAN: tuple[str, ...] = ("pelanggan", "transit", "manajemen", "lainnya")

JENIS_BLOK_IP: tuple[str, ...] = ("publik", "privat")


class Site(Base, TimestampMixin):
    """Lokasi fisik: POP, data center, tower, atau kantor."""

    __tablename__ = "site"
    __table_args__ = (Index("ix_site_branch", "branch_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(20), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="pop")
    address: Mapped[str | None] = mapped_column(Text)
    # Presisi sama dengan koordinat instalasi pelanggan: Numeric, bukan Float.
    # Titik yang bergeser beberapa meter karena pembulatan biner adalah titik
    # yang salah di peta.
    lat: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    lng: Mapped[Decimal | None] = mapped_column(Numeric(10, 7))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    note: Mapped[str | None] = mapped_column(Text)


class Device(Base, TimestampMixin):
    __tablename__ = "device"
    __table_args__ = (
        Index("ix_device_site", "site_id"),
        Index("ix_device_branch", "branch_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("site.id"), nullable=False)
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="switch")
    brand: Mapped[str | None] = mapped_column(String(80))
    model: Mapped[str | None] = mapped_column(String(80))
    # Alamat manajemen disimpan apa adanya sebagai teks: sebagian perangkat
    # dikelola lewat nama host, dan memaksanya jadi INET menolak itu.
    mgmt_address: Mapped[str | None] = mapped_column(String(120))
    serial_number: Mapped[str | None] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="aktif")
    # Pemantauan keterjangkauan (`flask pantau-perangkat`). `monitor_status`
    # kosong berarti belum pernah diperiksa; "naik" atau "turun" sesudahnya.
    monitor_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=text("false")
    )
    monitor_status: Mapped[str | None] = mapped_column(String(10))
    monitor_fail_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default=text("0")
    )
    monitor_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    monitor_changed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    note: Mapped[str | None] = mapped_column(Text)


class DevicePort(Base, TimestampMixin):
    """Satu port fisik atau logis pada perangkat.

    Satu port hanya boleh dialokasikan ke satu langganan; itu ditegakkan basis
    data lewat `uq_port_langganan`, bukan hanya oleh pemeriksaan aplikasi yang
    bisa balapan antar-worker.
    """

    __tablename__ = "device_port"
    __table_args__ = (
        UniqueConstraint("device_id", "name", name="uq_port_per_perangkat"),
        UniqueConstraint("subscription_id", name="uq_port_langganan"),
        Index("ix_port_device", "device_id"),
        Index("ix_port_branch_status", "branch_id", "status"),
        enum_check("ck_device_port_status", "status", STATUS_PORT),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    device_id: Mapped[int] = mapped_column(
        ForeignKey("device.id", ondelete="CASCADE"), nullable=False
    )
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(60), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="access")
    speed_mbps: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="bebas"    )
    subscription_id: Mapped[int | None] = mapped_column(
        ForeignKey("subscription.id", ondelete="SET NULL")
    )
    note: Mapped[str | None] = mapped_column(Text)


class Vlan(Base, TimestampMixin):
    """Registry VLAN.

    Nomor VLAN unik **per site**, bukan global: dua POP yang berdiri sendiri
    boleh sama-sama memakai VLAN 100. VLAN tanpa site berlaku global dan
    nomornya tidak boleh bentrok dengan VLAN global lain.
    """

    __tablename__ = "vlan"
    __table_args__ = (
        UniqueConstraint("site_id", "vlan_id", name="uq_vlan_per_site"),
        Index("ix_vlan_branch", "branch_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    vlan_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"))
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="pelanggan")
    subscription_id: Mapped[int | None] = mapped_column(
        ForeignKey("subscription.id", ondelete="SET NULL")
    )
    is_auto: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    note: Mapped[str | None] = mapped_column(Text)


class IpBlock(Base, TimestampMixin):
    """Registry blok IP.

    `cidr` disimpan sebagai teks dan divalidasi `ipaddress` dari pustaka
    standar. Tipe INET Postgres lebih ketat, tetapi menguncinya berarti impor
    data lama yang sedikit berantakan gagal seluruhnya alih-alih masuk dengan
    catatan.
    """

    __tablename__ = "ip_block"
    __table_args__ = (
        UniqueConstraint("cidr", name="uq_blok_ip"),
        Index("ix_ip_block_branch", "branch_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cidr: Mapped[str] = mapped_column(String(60), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="publik")
    site_id: Mapped[int | None] = mapped_column(ForeignKey("site.id"))
    branch_id: Mapped[int] = mapped_column(ForeignKey("branch.id"), nullable=False)
    gateway: Mapped[str | None] = mapped_column(String(60))
    subscription_id: Mapped[int | None] = mapped_column(
        ForeignKey("subscription.id", ondelete="SET NULL")
    )
    note: Mapped[str | None] = mapped_column(Text)
