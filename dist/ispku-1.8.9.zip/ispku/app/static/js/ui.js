/* Antarmuka umum ISPKU: tema terang/gelap dan lonceng notifikasi.
 *
 * Menu lepas (akun, notifikasi) dibuka-tutup Alpine di base.html; berkas ini
 * hanya mengisi dan memperbarui isinya.
 */
(function () {
  "use strict";

  // --- Tema ---------------------------------------------------------------
  // Atributnya sudah dipasang skrip sebaris di <head> sebelum cat pertama;
  // di sini hanya tombolnya.
  document.addEventListener("click", (event) => {
    const tombol = event.target instanceof Element ? event.target.closest("[data-tema-toggle]") : null;
    if (!tombol) return;
    const akar = document.documentElement;
    const gelap = akar.getAttribute("data-theme") === "dark";
    const tema = gelap ? "light" : "dark";
    akar.setAttribute("data-theme", tema);
    try { localStorage.setItem("cusnet-tema", tema); } catch (e) { /* tetap berlaku sesi ini */ }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", tema === "dark" ? "#0b0f19" : "#ffffff");
  });

  // --- Jam di topbar -------------------------------------------------------
  // Dihitung peramban tetapi DIFORMAT di zona waktu aplikasi, jadi sama untuk
  // semua orang apa pun zona perangkatnya.
  (function () {
    const wadah = document.querySelector("[data-jam]");
    if (!wadah) return;
    const SINGKATAN = { "Asia/Jakarta": "WIB", "Asia/Makassar": "WITA", "Asia/Jayapura": "WIT", UTC: "UTC" };
    let zona = wadah.dataset.zona;
    let tanggal, jam;
    try {
      tanggal = new Intl.DateTimeFormat("id-ID", { timeZone: zona, weekday: "short", day: "2-digit", month: "short", year: "numeric" });
      jam = new Intl.DateTimeFormat("id-ID", { timeZone: zona, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
    } catch (e) {
      return; // zona tidak dikenal peramban: jam tidak ditampilkan
    }
    const elTanggal = wadah.querySelector("[data-jam-tanggal]");
    const elJam = wadah.querySelector("[data-jam-waktu]");
    const akhiran = SINGKATAN[zona] || zona.split("/").pop().replace(/_/g, " ");
    function detak() {
      const kini = new Date();
      elTanggal.textContent = tanggal.format(kini);
      elJam.textContent = jam.format(kini).replace(/\./g, ":") + " " + akhiran;
    }
    detak();
    window.setInterval(detak, 1000);
  })();

  // --- Keterangan (?) -----------------------------------------------------
  // Paragraf keterangan dipindah ke balik tombol tanda tanya. Yang dipindah:
  // keterangan sebuah isian (tepat di bawah isiannya) dan keterangan panjang
  // di bawah judul kartu. Kalimat pendek seperti "Belum ada data." dibiarkan.
  const BATAS_PENDEK = 60;
  let nomorBantuan = 0;

  function jangkarBantuan(p) {
    for (let s = p.previousElementSibling; s; s = s.previousElementSibling) {
      if (s.matches("label.form__label")) return s;
      if (s.matches(".panel__judul, h2, h3")) return s;
      if (s.matches(".panel__kepala, .db-panel__kepala")) return s.querySelector(".panel__judul, h2, h3");
      if (!s.matches(".form__isian, .isian-berawalan, .form__galat, .form__bantuan, input, select, textarea")) break;
    }
    return null;
  }

  function rapikanBantuan() {
    document.querySelectorAll("#konten-utama p.form__bantuan:not([hidden])").forEach((p) => {
      if (p.hasAttribute("data-bantuan-tetap")) return;
      const sebelum = p.previousElementSibling;
      const milikIsian = Boolean(sebelum && sebelum.matches(".form__isian, .isian-berawalan, input, select, textarea"));
      const panjang = p.textContent.trim().length > BATAS_PENDEK;
      if (!milikIsian && !panjang && !p.hasAttribute("data-bantuan-paksa")) return;
      const jangkar = jangkarBantuan(p);
      if (!jangkar) return;

      const id = "bantuan-" + (++nomorBantuan);
      const tombol = document.createElement("button");
      tombol.type = "button";
      tombol.className = "bantuan-tombol";
      tombol.textContent = "?";
      tombol.setAttribute("aria-label", "Keterangan");
      tombol.setAttribute("popovertarget", id);
      const pop = document.createElement("div");
      pop.id = id;
      pop.className = "bantuan-pop";
      pop.setAttribute("popover", "");
      pop.innerHTML = p.innerHTML;
      pop.addEventListener("toggle", (event) => {
        const buka = event.newState === "open";
        tombol.setAttribute("aria-expanded", buka ? "true" : "false");
        if (!buka) return;
        const kotak = tombol.getBoundingClientRect();
        const lebar = pop.offsetWidth, tinggi = pop.offsetHeight;
        const kiri = Math.max(8, Math.min(kotak.left - 10, window.innerWidth - lebar - 8));
        const bawah = kotak.bottom + 6;
        pop.style.left = kiri + "px";
        pop.style.top = (bawah + tinggi > window.innerHeight - 8 ? Math.max(8, kotak.top - tinggi - 6) : bawah) + "px";
      });
      jangkar.append(tombol);
      p.after(pop);
      p.hidden = true;
    });
  }

  if ("popover" in HTMLElement.prototype) {
    document.addEventListener("DOMContentLoaded", rapikanBantuan);
    document.addEventListener("cusnet:isi-berubah", rapikanBantuan);
    // Menggulir menutup keterangan yang terbuka: posisinya dihitung sekali.
    window.addEventListener("scroll", () => {
      document.querySelectorAll(".bantuan-pop:popover-open").forEach((pop) => pop.hidePopover());
    }, { passive: true });
  }

  // --- Pilihan berantai ----------------------------------------------------
  // <select data-anak="#id" data-anak-url="/…/0">: memilih nilainya mengisi
  // ulang <select> anak dari JSON [{id, teks}]. Angka 0 di ujung URL diganti
  // nilai yang dipilih.
  document.addEventListener("change", async (event) => {
    const induk = event.target instanceof Element ? event.target.closest("select[data-anak]") : null;
    if (!induk) return;
    const anak = document.querySelector(induk.dataset.anak);
    if (!anak) return;
    const kosong = anak.querySelector("option[value='0'], option[value='']");
    const awal = kosong ? kosong.outerHTML : '<option value="0">—</option>';
    const nilai = Number(induk.value);
    if (!nilai) { anak.innerHTML = awal; return; }
    anak.disabled = true;
    try {
      const response = await fetch(induk.dataset.anakUrl.replace(/0$/, String(nilai)), {
        credentials: "same-origin", headers: { Accept: "application/json" }
      });
      const daftar = response.ok ? await response.json() : [];
      anak.innerHTML = awal;
      daftar.forEach((satu) => {
        const pilihan = document.createElement("option");
        pilihan.value = satu.id;
        pilihan.textContent = satu.teks;
        anak.append(pilihan);
      });
      // Customer dengan satu layanan: langsung terpilih.
      if (daftar.length === 1) anak.value = String(daftar[0].id);
    } catch (galat) {
      console.warn("Daftar pilihan gagal dimuat:", galat);
    } finally {
      anak.disabled = false;
    }
  });

  // --- Notifikasi ---------------------------------------------------------
  const wadah = document.querySelector("[data-notifikasi]");
  if (!wadah) return;
  const isi = wadah.querySelector("[data-notifikasi-isi]");
  const lencana = wadah.querySelector("[data-notifikasi-jumlah]");
  const tombolDibaca = wadah.querySelector("[data-notifikasi-dibaca]");

  function tampilkanJumlah(jumlah) {
    if (!lencana) return;
    lencana.hidden = !jumlah;
    lencana.textContent = jumlah > 9 ? "9+" : String(jumlah || "");
    if (tombolDibaca) tombolDibaca.disabled = !jumlah;
  }

  async function muat() {
    try {
      const response = await fetch(wadah.dataset.url, {
        cache: "no-store", credentials: "same-origin", headers: { Accept: "application/json" }
      });
      if (!response.ok) return;
      const data = await response.json();
      isi.innerHTML = data.html;
      tampilkanJumlah(data.jumlah);
      if (window.lucide) window.lucide.createIcons();
    } catch (galat) {
      console.warn("Notifikasi gagal dimuat:", galat);
    }
  }

  if (tombolDibaca) {
    tombolDibaca.addEventListener("click", async () => {
      const data = new FormData();
      data.append("csrf_token", wadah.dataset.csrf);
      tombolDibaca.disabled = true;
      try {
        const response = await fetch(wadah.dataset.urlDibaca, {
          method: "POST", body: data, credentials: "same-origin"
        });
        if (response.ok) await muat();
      } catch (galat) {
        console.warn("Gagal menandai notifikasi:", galat);
      }
    });
  }

  muat();
  // Ikut diperbarui saat data berubah (live.js mengumumkannya) dan saat tab
  // kembali terlihat.
  document.addEventListener("cusnet:data-berubah", muat);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) muat(); });
})();

/* Pratinjau gangguan massal: berapa layanan yang lewat site/perangkat terpilih. */
(function () {
  function pasang() {
    document.querySelectorAll("[data-layanan-lewat]").forEach(function (kotak) {
      if (kotak.dataset.terpasang) return;
      kotak.dataset.terpasang = "1";
      var hasil = kotak.querySelector("[data-layanan-lewat-hasil]");
      var site = kotak.querySelector('select[name="site_id"]');
      var perangkat = kotak.querySelector('select[name="device_id"]');
      function hitung() {
        var s = site && Number(site.value), p = perangkat && Number(perangkat.value);
        if (!s && !p) { hasil.hidden = true; return; }
        var alamat = kotak.dataset.layananLewat + "?" + (p ? "device_id=" + p : "site_id=" + s);
        fetch(alamat, { credentials: "same-origin", headers: { Accept: "application/json" } })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (data) {
            if (!data) return;
            hasil.textContent = data.jumlah
              ? data.jumlah + " layanan akan dicatat sebagai terdampak."
              : "Belum ada layanan yang tercatat lewat " + (p ? "perangkat" : "site") + " ini.";
            hasil.hidden = false;
          })
          .catch(function () {});
      }
      [site, perangkat].forEach(function (pilih) { if (pilih) pilih.addEventListener("change", hitung); });
      hitung();
    });
  }
  document.addEventListener("DOMContentLoaded", pasang);
  document.addEventListener("cusnet:isi-berubah", pasang);
})();

/* Laporan SLA per customer: pilih customer, unduh PDF-nya. */
document.addEventListener("submit", function (peristiwa) {
  var form = peristiwa.target.closest && peristiwa.target.closest("[data-laporan-customer]");
  if (!form) return;
  peristiwa.preventDefault();
  var pilih = form.querySelector("select");
  if (!pilih.value) return;
  window.location.href = form.dataset.pola.replace("/0.pdf", "/" + pilih.value + ".pdf");
});
