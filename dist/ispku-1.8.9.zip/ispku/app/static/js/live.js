/* Pembaruan langsung ISPKU: simpan tanpa memuat ulang, dan perubahan dari
 * pengguna lain muncul sendiri.
 *
 * Dua hal dikerjakan di sini, keduanya tanpa `location.reload()`:
 *
 * 1. Formulir POST di dalam halaman dikirim lewat fetch. Server menjawab
 *    pengalihan sebagai JSON (lihat `_jawab_kirim_langsung` di app/__init__.py);
 *    bila tujuannya halaman yang sedang dibuka, isinya ditukar di tempat
 *    sehingga posisi gulir tidak berubah.
 * 2. Versi data diperiksa berkala. Bila berubah, halaman diambil di latar
 *    belakang dan hanya bagian yang berbeda yang ditukar.
 *
 * Penukaran dilakukan per simpul, bukan dengan mengganti seluruh isi: kolom
 * yang sedang diketik, formulir yang belum disimpan, <details> yang dibuka,
 * dan fokus kursor tetap seperti adanya.
 */
(function () {
  "use strict";

  const JEDA_AWAL = 3000;
  const JEDA_MAKS = 30000;
  const ATRIBUT_MILIK_PENGGUNA = new Set(["open", "aria-expanded", "data-live-dirty"]);

  function utama() {
    return document.getElementById("konten-utama");
  }

  function samaAlamat(a, b) {
    const x = new URL(a, location.href);
    const y = new URL(b, location.href);
    return x.origin === y.origin && x.pathname === y.pathname && x.search === y.search;
  }

  // --- Penukaran isi per simpul -------------------------------------------

  function kunci(simpul) {
    if (simpul.nodeType !== 1) return "#" + simpul.nodeType;
    return simpul.id ? simpul.nodeName + "#" + simpul.id : simpul.nodeName;
  }

  function ikonSama(lama, baru) {
    // lucide mengganti <i data-lucide="x"> dengan <svg data-lucide="x">.
    return (
      lama.nodeName.toLowerCase() === "svg" &&
      baru.nodeName === "I" &&
      lama.getAttribute("data-lucide") &&
      lama.getAttribute("data-lucide") === baru.getAttribute("data-lucide")
    );
  }

  function samakanAtribut(lama, baru, panelPengguna) {
    const jagaTersembunyi = lama.id && panelPengguna.has(lama.id);
    for (const atribut of Array.from(lama.attributes)) {
      if (ATRIBUT_MILIK_PENGGUNA.has(atribut.name)) continue;
      if (atribut.name === "hidden" && jagaTersembunyi) continue;
      if (!baru.hasAttribute(atribut.name)) lama.removeAttribute(atribut.name);
    }
    for (const atribut of Array.from(baru.attributes)) {
      if (ATRIBUT_MILIK_PENGGUNA.has(atribut.name)) continue;
      if (atribut.name === "hidden" && jagaTersembunyi) continue;
      if (lama.getAttribute(atribut.name) !== atribut.value) {
        lama.setAttribute(atribut.name, atribut.value);
      }
    }
  }

  function samakanNilai(lama, baru) {
    if (lama === document.activeElement) return;
    if (lama.nodeName === "INPUT") {
      if (lama.type === "file") return;
      if (lama.type === "checkbox" || lama.type === "radio") {
        lama.checked = baru.hasAttribute("checked");
      } else if (lama.value !== (baru.getAttribute("value") || "")) {
        lama.value = baru.getAttribute("value") || "";
      }
    } else if (lama.nodeName === "TEXTAREA") {
      if (lama.value !== baru.textContent) lama.value = baru.textContent;
    } else if (lama.nodeName === "SELECT") {
      const pilihan = baru.querySelector("option[selected]");
      const nilai = pilihan ? pilihan.value : (baru.options[0] || {}).value;
      if (nilai !== undefined && lama.value !== nilai) lama.value = nilai;
    }
  }

  function tukar(lama, baru, panelPengguna) {
    if (lama.nodeType !== baru.nodeType) {
      lama.replaceWith(document.importNode(baru, true));
      return;
    }
    if (lama.nodeType !== 1) {
      if (lama.nodeValue !== baru.nodeValue) lama.nodeValue = baru.nodeValue;
      return;
    }
    if (ikonSama(lama, baru)) return;
    if (lama.nodeName !== baru.nodeName) {
      lama.replaceWith(document.importNode(baru, true));
      return;
    }
    // Formulir yang sedang diisi dan komponen Alpine dibiarkan utuh: yang
    // pertama memuat ketikan yang belum disimpan, yang kedua memegang
    // keadaan yang tidak ada di HTML dari server.
    if (lama.matches('form[data-live-dirty="true"], [x-data]')) return;

    samakanAtribut(lama, baru, panelPengguna);
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(lama.nodeName)) {
      samakanNilai(lama, baru);
      if (lama.nodeName !== "SELECT") return;
    }

    const anakBaru = Array.from(baru.childNodes);
    let penunjuk = lama.firstChild;
    for (const calon of anakBaru) {
      let cocok = penunjuk;
      if (!cocok || kunci(cocok) !== kunci(calon)) {
        // Cari ke depan simpul ber-id sama; kalau tidak ada, sisipkan baru.
        cocok = null;
        if (calon.nodeType === 1 && calon.id) {
          for (let kandidat = penunjuk; kandidat; kandidat = kandidat.nextSibling) {
            if (kandidat.nodeType === 1 && kandidat.id === calon.id) {
              cocok = kandidat;
              break;
            }
          }
        }
        // Formulir dicari juga lewat `action`-nya. Skrip lain (tabel.js) boleh
        // membungkus tabel di sebelahnya sehingga urutan simpul bergeser;
        // tanpa ini formulirnya dianggap baru, dibuang, dan ketikan yang
        // sedang berjalan ikut hilang.
        if (!cocok && calon.nodeType === 1 && calon.nodeName === "FORM" && calon.getAttribute("action")) {
          for (let kandidat = penunjuk; kandidat; kandidat = kandidat.nextSibling) {
            if (kandidat.nodeName === "FORM" && kandidat.getAttribute("action") === calon.getAttribute("action")) {
              cocok = kandidat;
              break;
            }
          }
        }
        if (cocok) {
          lama.insertBefore(cocok, penunjuk);
        } else if (
          penunjuk && penunjuk.nodeType === 1 && calon.nodeType === 1 &&
          ikonSama(penunjuk, calon)
        ) {
          cocok = penunjuk;
        } else {
          lama.insertBefore(document.importNode(calon, true), penunjuk);
          continue;
        }
      }
      penunjuk = cocok.nextSibling;
      tukar(cocok, calon, panelPengguna);
    }
    while (penunjuk) {
      const berikut = penunjuk.nextSibling;
      penunjuk.remove();
      penunjuk = berikut;
    }
  }

  function terapkanHalaman(html) {
    const dokumen = new DOMParser().parseFromString(html, "text/html");
    const baru = dokumen.getElementById("konten-utama");
    const lama = utama();
    if (!baru || !lama) return false;

    // Panel yang dibuka-tutup pengguna (filter) tidak ikut ditutup lagi.
    const panelPengguna = new Set(
      Array.from(lama.querySelectorAll("[data-filter-toggle][aria-controls]"))
        .map((tombol) => tombol.getAttribute("aria-controls"))
    );
    tukar(lama, baru, panelPengguna);
    if (dokumen.title) document.title = dokumen.title;
    if (window.lucide) window.lucide.createIcons();
    if (window.htmx) window.htmx.process(lama);
    document.dispatchEvent(new CustomEvent("cusnet:isi-berubah"));
    return true;
  }

  let htmlTerakhir = null;

  // Pengguna sedang memilih baris atau mengisi dialog: pembaruan latar
  // belakang ditunda supaya pilihannya tidak hilang di tengah jalan.
  function sedangBekerja() {
    const fokus = document.activeElement;
    return Boolean(
      document.querySelector(".tabel__baris--dipilih, dialog[open], .alat__panel:not([hidden]), details.pemilih-kolom[open]") ||
      (fokus && fokus.closest && fokus.closest(".alat"))
    );
  }

  async function segarkan(paksa) {
    if (!paksa && sedangBekerja()) return;
    const response = await fetch(location.href, {
      cache: "no-store",
      credentials: "same-origin",
      headers: { "X-Live-Refresh": "1" }
    });
    if (response.status === 401 || (response.redirected && !samaAlamat(response.url, location.href))) {
      location.reload();
      return;
    }
    if (!response.ok) throw new Error("HTTP " + response.status);
    const html = await response.text();
    // Penanda versi berubah oleh tulisan apa pun di basis data, termasuk yang
    // tidak tampil di halaman ini. Kalau HTML-nya sama, tidak ada yang disentuh.
    const inti = html.replace(/name="cusnet-live-version" content="[^"]*"/, "");
    if (!paksa && inti === htmlTerakhir) return;
    htmlTerakhir = inti;
    terapkanHalaman(html);
  }

  // Dipakai tabel.js setelah aksi massal dan impor.
  window.cusnetSegarkan = () => segarkan(true);

  // --- Pemberitahuan ------------------------------------------------------

  function beriTahu(teks) {
    const kotak = document.getElementById("live-update-notice");
    if (!kotak) return;
    kotak.textContent = teks;
    kotak.hidden = false;
    window.clearTimeout(beriTahu.jam);
    beriTahu.jam = window.setTimeout(() => { kotak.hidden = true; }, 6000);
  }

  // --- Simpan tanpa memuat ulang ------------------------------------------

  function bolehDikirimLangsung(form) {
    if ((form.getAttribute("method") || "get").toLowerCase() !== "post") return false;
    if (form.dataset.live === "off" || form.target === "_blank") return false;
    if (form.closest("[hx-boost='true']") && !form.closest("[hx-boost='false']")) return false;
    return Boolean(utama() && utama().contains(form));
  }

  async function kirim(form, pemicu) {
    const data = pemicu ? new FormData(form, pemicu) : new FormData(form);
    const tombol = Array.from(form.querySelectorAll("button[type=submit], input[type=submit]"));
    tombol.forEach((satu) => { satu.disabled = true; });
    form.setAttribute("aria-busy", "true");
    try {
      const response = await fetch(form.action || location.href, {
        method: "POST",
        body: data,
        credentials: "same-origin",
        headers: { "X-Live-Submit": "1", Accept: "application/json, text/html" }
      });
      const jenis = response.headers.get("Content-Type") || "";
      if (jenis.includes("application/json")) {
        const jawaban = await response.json();
        if (jawaban && typeof jawaban.redirect === "string") {
          if (samaAlamat(jawaban.redirect, location.href)) {
            delete form.dataset.liveDirty;
            await segarkan(true);
          } else {
            pindah(new URL(jawaban.redirect, location.href), true);
          }
          return;
        }
      }
      if (response.status === 401) {
        location.reload();
        return;
      }
      const html = await response.text();
      if (response.ok || response.status === 400 || response.status === 422) {
        // Formulir dirender ulang beserta pesan galatnya.
        delete form.dataset.liveDirty;
        if (!terapkanHalaman(html)) location.reload();
        return;
      }
      beriTahu(
        response.status === 403
          ? "Anda tidak berhak melakukan perubahan ini."
          : response.status === 413
            ? "Berkas terlalu besar untuk diunggah."
            : "Gagal menyimpan (HTTP " + response.status + "). Coba lagi."
      );
    } catch (galat) {
      console.warn("Kirim langsung gagal:", galat);
      beriTahu("Tidak bisa menghubungi server. Periksa jaringan lalu coba lagi.");
    } finally {
      form.removeAttribute("aria-busy");
      tombol.forEach((satu) => { if (satu.isConnected) satu.disabled = false; });
    }
  }

  document.addEventListener("submit", (event) => {
    // `onsubmit="return confirm(...)"` yang dibatalkan sudah menandai
    // peristiwanya; yang seperti itu tidak dikirim.
    if (event.defaultPrevented) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || !bolehDikirimLangsung(form)) return;
    event.preventDefault();
    kirim(form, event.submitter);
  });

  // --- Pindah halaman tanpa muat ulang --------------------------------------
  // Klik menu atau tautan di dalam aplikasi mengambil halamannya lewat fetch,
  // lalu hanya isi (<main>) dan daftar menu yang diganti. Sidebar, topbar,
  // dan posisi gulir sidebar tidak tersentuh, jadi memilih menu paling bawah
  // tidak lagi melempar sidebar kembali ke atas.
  //
  // Isi diganti utuh, bukan ditukar per simpul: halaman tujuan adalah halaman
  // lain, dan mencocokkan simpulnya dengan halaman lama hanya menyisakan
  // potongan yang salah tempat.
  const BUKAN_HALAMAN = /\.(csv|pdf|zip|dump|png|jpe?g|svg|xlsx?|json)(\?|$)|\/(unduh|ekspor|cetak|berkas)(\/|\?|$)|\/keluar$/i;

  function bisaPindahDiTempat(url, unsur) {
    if (url.origin !== location.origin) return false;
    if (BUKAN_HALAMAN.test(url.pathname + url.search)) return false;
    if (unsur.target && unsur.target !== "_self") return false;
    if (unsur.hasAttribute("download") || unsur.dataset.live === "off") return false;
    if (unsur.closest("[hx-boost='true'], [hx-get], [data-live='off']")) return false;
    return true;
  }

  function pasangHalaman(html) {
    const dokumen = new DOMParser().parseFromString(html, "text/html");
    const baru = dokumen.getElementById("konten-utama");
    const lama = utama();
    const navBaru = dokumen.getElementById("navigasi-utama");
    const navLama = document.getElementById("navigasi-utama");
    if (!baru || !lama || !navBaru || !navLama) return false;

    lama.className = baru.className;
    lama.replaceChildren(...Array.from(baru.childNodes).map((n) => document.importNode(n, true)));
    navLama.replaceChildren(...Array.from(navBaru.childNodes).map((n) => document.importNode(n, true)));
    if (dokumen.title) document.title = dokumen.title;
    const metaBaru = dokumen.querySelector('meta[name="cusnet-live-version"]');
    const metaLama = document.querySelector('meta[name="cusnet-live-version"]');
    if (metaBaru && metaLama) metaLama.content = metaBaru.content;
    if (window.lucide) window.lucide.createIcons();
    if (window.htmx) window.htmx.process(lama);
    htmlTerakhir = null;
    document.dispatchEvent(new CustomEvent("cusnet:isi-berubah"));
    return true;
  }

  let pindahKe = 0;

  async function pindah(tujuan, catat) {
    const giliran = ++pindahKe;
    const isiUtama = utama();
    if (isiUtama) isiUtama.setAttribute("aria-busy", "true");
    try {
      const response = await fetch(tujuan.pathname + tujuan.search, {
        cache: "no-store", credentials: "same-origin", headers: { "X-Live-Nav": "1" }
      });
      // Klik berikutnya sudah mengambil alih; jawaban ini kedaluwarsa.
      if (giliran !== pindahKe) return;
      const jenis = response.headers.get("Content-Type") || "";
      if (!jenis.includes("text/html")) throw new Error("bukan halaman");
      const akhir = new URL(response.url);
      const html = await response.text();
      if (giliran !== pindahKe) return;
      if (akhir.pathname === "/masuk" || !pasangHalaman(html)) throw new Error("tidak bisa dipasang");
      const alamat = akhir.pathname + akhir.search + (akhir.pathname === tujuan.pathname ? tujuan.hash : "");
      if (catat) history.pushState({ live: true }, "", alamat);
      const jangkar = tujuan.hash ? document.getElementById(tujuan.hash.slice(1)) : null;
      if (jangkar) jangkar.scrollIntoView();
      else if (catat) window.scrollTo(0, 0);
      const laci = document.querySelector(".sidebar--buka");
      if (laci) document.querySelector(".tirai")?.click();
    } catch (galat) {
      // Apa pun yang tidak beres: pindah dengan cara biasa.
      location.assign(tujuan.href);
    } finally {
      if (isiUtama) isiUtama.removeAttribute("aria-busy");
    }
  }

  document.addEventListener("click", (event) => {
    if (event.defaultPrevented || event.button !== 0) return;
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const tautan = event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (!tautan || tautan.hasAttribute("data-live-link")) return;
    if (!tautan.closest("#navigasi-utama, #konten-utama, .lepas")) return;
    const mentah = tautan.getAttribute("href");
    if (!mentah || mentah.startsWith("#")) return;
    const tujuan = new URL(tautan.href, location.href);
    if (!bisaPindahDiTempat(tujuan, tautan)) return;
    // Jangkar di halaman yang sama: biarkan peramban menggulir sendiri.
    if (tujuan.pathname === location.pathname && tujuan.search === location.search && tujuan.hash) return;
    event.preventDefault();
    pindah(tujuan, true);
  });

  // Formulir GET (pencarian, filter) juga pindah di tempat.
  document.addEventListener("submit", (event) => {
    if (event.defaultPrevented) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if ((form.getAttribute("method") || "get").toLowerCase() !== "get") return;
    if (!utama() || !utama().contains(form)) return;
    const tujuan = new URL(form.action || location.href, location.href);
    if (!bisaPindahDiTempat(tujuan, form)) return;
    const data = new FormData(form, event.submitter || undefined);
    tujuan.search = new URLSearchParams(Array.from(data.entries()).filter(([, v]) => typeof v === "string")).toString();
    event.preventDefault();
    pindah(tujuan, true);
  });

  window.addEventListener("popstate", () => { pindah(new URL(location.href), false); });

  // --- Tautan di tempat ---------------------------------------------------
  // Tautan ber-`data-live-link` (pemilih rentang grafik, pil cakupan) hanya
  // mengganti sebagian isi halaman yang sama. Diambil lewat fetch dan ditukar
  // di tempat supaya posisi gulir tidak melompat ke atas.
  document.addEventListener("click", async (event) => {
    if (event.defaultPrevented || event.button !== 0) return;
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const tautan = event.target instanceof Element ? event.target.closest("a[data-live-link]") : null;
    if (!tautan || !utama() || !utama().contains(tautan)) return;
    const tujuan = new URL(tautan.href, location.href);
    if (tujuan.origin !== location.origin || tujuan.pathname !== location.pathname) return;
    event.preventDefault();
    try {
      const response = await fetch(tujuan.pathname + tujuan.search, {
        cache: "no-store",
        credentials: "same-origin",
        headers: { "X-Live-Refresh": "1" }
      });
      if (!response.ok) throw new Error("HTTP " + response.status);
      const html = await response.text();
      history.replaceState(null, "", tujuan.pathname + tujuan.search);
      htmlTerakhir = null;
      if (!terapkanHalaman(html)) location.assign(tujuan.href);
    } catch (galat) {
      location.assign(tujuan.href);
    }
  });

  // --- Perubahan dari pengguna lain ---------------------------------------

  function tandaiFormBerubah(event) {
    const form = event.target instanceof Element ? event.target.closest("form") : null;
    if (form && (form.getAttribute("method") || "").toLowerCase() === "post") {
      form.dataset.liveDirty = "true";
    }
  }
  document.addEventListener("input", tandaiFormBerubah);
  document.addEventListener("change", tandaiFormBerubah);

  document.addEventListener("DOMContentLoaded", () => {
    const meta = document.querySelector('meta[name="cusnet-live-version"]');
    if (!meta || !meta.content) return;

    let versi = meta.content;
    let jeda = JEDA_AWAL;

    async function periksa() {
      let berikut = jeda;
      try {
        if (document.hidden) {
          // Tab di latar belakang tidak perlu menarik halaman; dikejar saat
          // tab kembali terlihat.
          window.setTimeout(periksa, jeda);
          return;
        }
        const response = await fetch(meta.dataset.url, {
          cache: "no-store",
          credentials: "same-origin",
          headers: { Accept: "application/json" }
        });
        if (response.status === 401) {
          location.reload();
          return;
        }
        if (!response.ok) throw new Error("HTTP " + response.status);
        const data = await response.json();
        if (typeof data.version !== "string") throw new Error("Versi tidak sah.");
        jeda = JEDA_AWAL;
        berikut = jeda;
        if (data.version !== versi) {
          versi = data.version;
          await segarkan(false);
          document.dispatchEvent(new CustomEvent("cusnet:data-berubah"));
        }
      } catch (galat) {
        console.warn("Pemeriksaan pembaruan live gagal:", galat);
        jeda = Math.min(jeda * 2, JEDA_MAKS);
        berikut = jeda;
      }
      window.setTimeout(periksa, berikut);
    }

    window.setTimeout(periksa, jeda);
  });
})();
