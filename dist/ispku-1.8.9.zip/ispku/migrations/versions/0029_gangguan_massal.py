"""tiket gangguan massal: sumber di jaringan dan layanan terdampak

Revision ID: 0029
Revises: 0028
Create Date: 2026-10-08 19:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0029"
down_revision: Union[str, None] = "0028"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("ticket", sa.Column("site_id", sa.Integer(), nullable=True))
    op.add_column("ticket", sa.Column("device_id", sa.Integer(), nullable=True))
    op.create_foreign_key(
        "fk_ticket_site", "ticket", "site", ["site_id"], ["id"], ondelete="SET NULL"
    )
    op.create_foreign_key(
        "fk_ticket_device", "ticket", "device", ["device_id"], ["id"], ondelete="SET NULL"
    )
    op.create_table(
        "ticket_impact",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "ticket_id", sa.Integer(),
            sa.ForeignKey("ticket.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column(
            "subscription_id", sa.Integer(),
            sa.ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.UniqueConstraint("ticket_id", "subscription_id", name="uq_ticket_impact"),
    )
    op.create_index(
        "ix_ticket_impact_subscription", "ticket_impact", ["subscription_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_ticket_impact_subscription", table_name="ticket_impact")
    op.drop_table("ticket_impact")
    op.drop_constraint("fk_ticket_device", "ticket", type_="foreignkey")
    op.drop_constraint("fk_ticket_site", "ticket", type_="foreignkey")
    op.drop_column("ticket", "device_id")
    op.drop_column("ticket", "site_id")
