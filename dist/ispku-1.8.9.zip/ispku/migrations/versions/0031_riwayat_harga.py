"""riwayat perubahan harga dan paket langganan

Revision ID: 0031
Revises: 0030
Create Date: 2026-10-08 21:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0031"
down_revision: Union[str, None] = "0030"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "subscription_price_change",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "subscription_id", sa.Integer(),
            sa.ForeignKey("subscription.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("effective_date", sa.Date(), nullable=False),
        sa.Column("old_plan_id", sa.Integer(), sa.ForeignKey("service_plan.id"), nullable=True),
        sa.Column("new_plan_id", sa.Integer(), sa.ForeignKey("service_plan.id"), nullable=True),
        sa.Column("old_amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("new_amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("changed_by_user_id", sa.Integer(), sa.ForeignKey("app_user.id"), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True),
            server_default=sa.func.now(), nullable=False,
        ),
    )
    op.create_index(
        "ix_subscription_price_change_subscription_id",
        "subscription_price_change", ["subscription_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_subscription_price_change_subscription_id",
        table_name="subscription_price_change",
    )
    op.drop_table("subscription_price_change")
