"""cap kabar lewat SLA pada tiket

Revision ID: 0030
Revises: 0029
Create Date: 2026-10-08 20:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0030"
down_revision: Union[str, None] = "0029"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "ticket", sa.Column("sla_notified_at", sa.DateTime(timezone=True), nullable=True)
    )
    # Tiket yang sudah lewat tenggat sebelum fitur ini ada tidak dikabari
    # mundur: tanpa ini pemasangan lama mengirim satu email per tiket lama.
    op.execute(
        "UPDATE ticket SET sla_notified_at = now() "
        "WHERE resolve_due_at IS NOT NULL AND resolve_due_at < now()"
    )


def downgrade() -> None:
    op.drop_column("ticket", "sla_notified_at")
