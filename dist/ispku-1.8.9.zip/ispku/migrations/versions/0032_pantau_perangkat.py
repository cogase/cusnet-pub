"""pemantauan keterjangkauan perangkat

Revision ID: 0032
Revises: 0031
Create Date: 2026-10-08 22:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0032"
down_revision: Union[str, None] = "0031"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "device",
        sa.Column("monitor_enabled", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )
    op.add_column("device", sa.Column("monitor_status", sa.String(10), nullable=True))
    op.add_column(
        "device",
        sa.Column("monitor_fail_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
    )
    op.add_column(
        "device", sa.Column("monitor_checked_at", sa.DateTime(timezone=True), nullable=True)
    )
    op.add_column(
        "device", sa.Column("monitor_changed_at", sa.DateTime(timezone=True), nullable=True)
    )


def downgrade() -> None:
    for kolom in ("monitor_changed_at", "monitor_checked_at", "monitor_fail_count",
                  "monitor_status", "monitor_enabled"):
        op.drop_column("device", kolom)
