"""site di bawah layanan induk

Revision ID: 0028
Revises: 0027
Create Date: 2026-10-08 18:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0028"
down_revision: Union[str, None] = "0027"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Kosong berarti layanan biasa (atau induk). Terisi berarti site milik
    # layanan itu; ikut terhapus bersama induknya.
    op.add_column("subscription", sa.Column("parent_id", sa.Integer(), nullable=True))
    op.create_foreign_key(
        "fk_subscription_parent", "subscription", "subscription",
        ["parent_id"], ["id"], ondelete="CASCADE",
    )
    op.create_index("ix_subscription_parent_id", "subscription", ["parent_id"])


def downgrade() -> None:
    op.drop_index("ix_subscription_parent_id", table_name="subscription")
    op.drop_constraint("fk_subscription_parent", "subscription", type_="foreignkey")
    op.drop_column("subscription", "parent_id")
