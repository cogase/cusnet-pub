"""Merek aplikasi per ISP.

Terpisah dari `service.py` supaya jelas bahwa ini bukan pengaturan billing:
yang diatur di sini adalah nama, logo, dan warna **aplikasinya**, bukan kop
surat invoice.
"""

import re

from sqlalchemy import text

from app.core import audit
from app.core.errors import GalatDomain
from app.core.warna import AMBANG_TEKS_NORMAL, kontras, luminans
from app.modules.settings.models import AppBranding

ID_MEREK = 1

# Angkanya sembarang, yang penting tetap dan berbeda dari kunci pengaturan
# billing.
_KUNCI_MEREK = 918_273_646

KOLOM_MEREK = (
    "app_name",
    "app_name_suffix",
    "tagline",
    "accent_color",
    "sidebar_color",
    "login_headline",
    "login_body",
    "footer_text",
)

BAWAAN = {
    "app_name": "ISPKU",
    "app_name_suffix": "CRM",
    "tagline": "ISP Customer & Billing System",
    "accent_color": "#2563EB",
    "sidebar_color": "#0B1220",
}

# Di bawah luminans ini latar sidebar dianggap gelap dan tulisannya terang.
AMBANG_SIDEBAR_GELAP = 0.35


class MerekTidakSah(GalatDomain):
    """Nilai merek yang ditolak."""


def ambil_merek(sesi) -> AppBranding:
    """Baris merek satu-satunya, dibuat bila belum ada.

    Pola advisory lock-nya sama dengan `ambil_setting`: dua worker gunicorn
    yang sama-sama melihat tabel kosong akan sama-sama menyisipkan baris.
    """
    merek = sesi.get(AppBranding, ID_MEREK)
    if merek is not None:
        return merek

    sesi.execute(text("SELECT pg_advisory_xact_lock(:kunci)"), {"kunci": _KUNCI_MEREK})

    merek = sesi.get(AppBranding, ID_MEREK)
    if merek is None:
        merek = AppBranding(id=ID_MEREK, **BAWAAN)
        sesi.add(merek)
        sesi.flush()
    return merek


def periksa_warna(warna: str) -> None:
    """Menolak warna aksen yang tidak sah atau tidak terbaca.

    Teks putih dicetak di atas warna ini di tombol utama, lencana, dan tautan
    aktif. Rasio kontrasnya dihitung, bukan dinilai mata — orang yang memilih
    warnanya punya layar bagus dan ruangan terang, dan tidak akan melihat
    masalahnya.
    """
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", str(warna or "")):
        raise MerekTidakSah("accent_color", "Warna aksen harus berbentuk #RRGGBB.")

    rasio = kontras(warna, "#FFFFFF")
    if rasio < AMBANG_TEKS_NORMAL:
        raise MerekTidakSah(
            "accent_color",
            f"Kontras warna ini terhadap teks putih hanya {rasio:.2f}:1, "
            f"di bawah ambang {AMBANG_TEKS_NORMAL}:1. Tulisan di tombol utama "
            "akan sulit dibaca. Pilih warna yang lebih gelap.",
        )


def ubah_merek(sesi, aktor, data: dict, berkas: dict | None = None) -> AppBranding:
    """Menyimpan merek; entri `berkas` berisi StoredFile atau None."""
    merek = ambil_merek(sesi)

    nama = (data.get("app_name") or "").strip()
    if "app_name" in data and not nama:
        raise MerekTidakSah(
            "app_name",
            "Nama aplikasi wajib diisi. Sidebar tanpa nama adalah sidebar rusak.",
        )

    if data.get("accent_color") is not None:
        periksa_warna(data["accent_color"])
    if data.get("sidebar_color") is not None and not re.fullmatch(
        r"#[0-9A-Fa-f]{6}", str(data["sidebar_color"])
    ):
        raise MerekTidakSah("sidebar_color", "Warna sidebar harus berbentuk #RRGGBB.")

    sebelum = _potret(merek)
    for kolom in KOLOM_MEREK:
        if kolom not in data:
            continue
        nilai = data[kolom]
        if isinstance(nilai, str):
            nilai = nilai.strip() or None
        if kolom in ("app_name", "accent_color", "sidebar_color") and nilai is None:
            continue
        setattr(merek, kolom, nilai)

    for kolom, tersimpan in (berkas or {}).items():
        setattr(merek, kolom, tersimpan.path if tersimpan is not None else None)

    sesi.flush()
    audit.record(
        sesi, "update", "app_branding", merek.id,
        before=sebelum, after=_potret(merek), aktor=aktor,
    )
    return merek


def _potret(merek: AppBranding) -> dict:
    kolom = KOLOM_MEREK + ("logo_path", "favicon_path")
    return {nama: getattr(merek, nama) for nama in kolom}


def konteks(merek: AppBranding) -> dict:
    """Bentuk yang dipakai templat.

    Templat tidak boleh memanggil basis data sendiri, dan tidak boleh
    memutuskan nilai bawaan sendiri: satu nilai bawaan yang ditulis di dua
    templat akan berbeda begitu salah satunya diubah.
    """
    nama = merek.app_name or BAWAAN["app_name"]
    akhiran = (merek.app_name_suffix or "").strip()
    warna_sidebar = merek.sidebar_color or BAWAAN["sidebar_color"]
    return {
        "nama": nama,
        "akhiran": akhiran,
        "nama_penuh": f"{nama} {akhiran}".strip(),
        "tagline": merek.tagline or "",
        "warna": merek.accent_color or BAWAAN["accent_color"],
        "warna_sidebar": warna_sidebar,
        # Menentukan warna tulisan dan sorotan di sidebar.
        "sidebar_gelap": luminans(warna_sidebar) < AMBANG_SIDEBAR_GELAP,
        "punya_logo": bool(merek.logo_path),
        "punya_favicon": bool(merek.favicon_path),
        # Sengaja boleh `None`. Halaman masuk punya mockup, dan judul
        # bawaannya bergaya (tiga baris dengan satu kata dicetak miring).
        # Nilai bawaan berupa teks polos akan membuang gaya itu diam-diam;
        # templat yang memutuskan sendiri kapan memakai markup aslinya.
        "login_headline": merek.login_headline or None,
        "login_body": merek.login_body or None,
        "footer": merek.footer_text or f"{nama} {akhiran}".strip(),
    }


# --- Zona waktu ---------------------------------------------------------------

# Tiga zona Indonesia lebih dulu; sisanya menyusul menurut abjad.
ZONA_UTAMA = (
    ("Asia/Jakarta", "WIB — Asia/Jakarta (UTC+7)"),
    ("Asia/Makassar", "WITA — Asia/Makassar (UTC+8)"),
    ("Asia/Jayapura", "WIT — Asia/Jayapura (UTC+9)"),
    ("UTC", "UTC"),
)


def pilihan_zona() -> list[tuple[str, str]]:
    import zoneinfo

    utama = {nama for nama, _ in ZONA_UTAMA}
    lain = sorted(z for z in zoneinfo.available_timezones() if z not in utama and "/" in z)
    return list(ZONA_UTAMA) + [(z, z) for z in lain]


def zona_tersimpan(sesi) -> str | None:
    """Zona waktu pilihan pemasangan ini, atau `None` bila mengikuti .env."""
    merek = sesi.get(AppBranding, ID_MEREK)
    return (merek.timezone or None) if merek is not None else None


def ubah_zona(sesi, aktor, zona: str) -> str:
    import zoneinfo

    zona = (zona or "").strip()
    if zona not in zoneinfo.available_timezones():
        raise MerekTidakSah("zona", f"Zona waktu '{zona}' tidak dikenal.")
    merek = ambil_merek(sesi)
    sebelum = merek.timezone
    merek.timezone = zona
    sesi.flush()
    audit.record(
        sesi, "update", "app_branding", merek.id,
        before={"timezone": sebelum}, after={"timezone": zona}, aktor=aktor,
    )
    return zona


def pengaturan_kabar(sesi) -> dict:
    """Pengaturan pemantauan dan Telegram, untuk dibaca pekerjaan terjadwal."""
    merek = ambil_merek(sesi)
    return {
        "tiket_otomatis": bool(merek.monitor_auto_ticket),
        "telegram_token": merek.telegram_bot_token,
        "telegram_chat_id": merek.telegram_chat_id,
        "telegram_siap": bool(merek.telegram_bot_token and merek.telegram_chat_id),
    }


def ubah_kabar(sesi, aktor, data: dict) -> dict:
    """Menyimpan pilihan tiket otomatis dan bot Telegram.

    Token kosong berarti tidak diubah; "-" berarti dihapus. Audit log hanya
    mencatat BAHWA token berubah, tidak pernah isinya.
    """
    merek = ambil_merek(sesi)
    sebelum = {
        "monitor_auto_ticket": merek.monitor_auto_ticket,
        "telegram_chat_id": merek.telegram_chat_id,
        "telegram_token_terisi": bool(merek.telegram_bot_token),
    }
    merek.monitor_auto_ticket = bool(data.get("monitor_auto_ticket"))
    chat = (data.get("telegram_chat_id") or "").strip()
    if len(chat) > 60:
        raise MerekTidakSah("telegram_chat_id", "Chat ID paling panjang 60 karakter.")
    merek.telegram_chat_id = chat or None
    token = (data.get("telegram_bot_token") or "").strip()
    if token == "-":
        merek.telegram_bot_token = None
    elif token:
        if len(token) > 120 or ":" not in token:
            raise MerekTidakSah(
                "telegram_bot_token", "Token bot tidak sah. Bentuknya seperti 123456:ABC-DEF…"
            )
        merek.telegram_bot_token = token
    sesi.flush()
    audit.record(
        sesi, "update", "app_branding", merek.id, before=sebelum,
        after={
            "monitor_auto_ticket": merek.monitor_auto_ticket,
            "telegram_chat_id": merek.telegram_chat_id,
            "telegram_token_terisi": bool(merek.telegram_bot_token),
        },
        aktor=aktor,
    )
    return pengaturan_kabar(sesi)
