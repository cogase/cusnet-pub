"""Menarik data perangkat lewat SNMP v2c.

Hanya OID standar, jadi berlaku untuk hampir semua merek:

- MIB-II sistem: nama, deskripsi, uptime.
- IF-MIB: antarmuka (nama, tipe, status link, kecepatan, deskripsi) dan
  pencacah oktetnya, untuk grafik trafik.
- IP-MIB `ipAddrTable`: alamat IP tiap antarmuka. Jaringannya disambungkan
  ke Blok IP — yang belum terdaftar dibuatkan.
- Q-BRIDGE-MIB dan antarmuka bertipe VLAN: VLAN yang dikenal perangkat,
  didaftarkan ke registry VLAN site-nya.
- BGP4-MIB `bgpPeerTable`: sesi BGP dan keadaannya.

Log perangkat TIDAK ada di sini: SNMP tidak punya tabel log standar. Log
dikirim perangkat lewat syslog, dan itu butuh penerima tersendiri.

Port yang belum terdaftar dibuat; yang sudah ada diperbarui. Tidak ada port
yang dihapus, dan alokasi ke langganan tidak disentuh.
"""

import ipaddress
import logging
import re
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import delete, select

from app.core import audit, rbac, snmp
from app.core.errors import GalatDomain
from app.modules.inventory import pantau
from app.modules.inventory import service
from app.modules.inventory.models import (
    Device,
    DeviceBgpPeer,
    DeviceIp,
    DevicePort,
    IpBlock,
    PortTraffic,
    Vlan,
)

_log = logging.getLogger(__name__)

SYS_DESCR, SYS_UPTIME, SYS_NAME = "1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.3.0", "1.3.6.1.2.1.1.5.0"
IF_DESCR, IF_TYPE, IF_SPEED, IF_OPER = (
    "1.3.6.1.2.1.2.2.1.2", "1.3.6.1.2.1.2.2.1.3", "1.3.6.1.2.1.2.2.1.5", "1.3.6.1.2.1.2.2.1.8",
)
IF_IN, IF_OUT = "1.3.6.1.2.1.2.2.1.10", "1.3.6.1.2.1.2.2.1.16"
IF_NAME, IF_HC_IN, IF_HC_OUT, IF_HIGH_SPEED, IF_ALIAS = (
    "1.3.6.1.2.1.31.1.1.1.1", "1.3.6.1.2.1.31.1.1.1.6", "1.3.6.1.2.1.31.1.1.1.10",
    "1.3.6.1.2.1.31.1.1.1.15", "1.3.6.1.2.1.31.1.1.1.18",
)
IP_IFINDEX, IP_MASK = "1.3.6.1.2.1.4.20.1.2", "1.3.6.1.2.1.4.20.1.3"
VLAN_NAMA = "1.3.6.1.2.1.17.7.1.4.3.1.1"
BGP_STATE, BGP_AS, BGP_UPTIME = (
    "1.3.6.1.2.1.15.3.1.2", "1.3.6.1.2.1.15.3.1.9", "1.3.6.1.2.1.15.3.1.16",
)
KEADAAN_BGP = {1: "idle", 2: "connect", 3: "active", 4: "opensent", 5: "openconfirm", 6: "established"}

TIPE_LOOPBACK, TIPE_VLAN = 24, 135
# Antarmuka fisik: yang dijumlahkan untuk trafik agregat perangkat. VLAN,
# bridge, dan tunnel tidak ikut — trafiknya sudah terhitung di port fisiknya.
TIPE_FISIK = frozenset({6, 62, 69, 117})
BATAS_PORT = 2000
SIMPAN_HARI = 35
JEDA_MAKS = timedelta(hours=1)
_POLA_VLAN = re.compile(r"(?:vlan[\s._-]?|\.)(\d{1,4})$", re.I)


class SnmpGagal(GalatDomain):
    """Penarikan SNMP tidak bisa dijalankan atau perangkat tidak menjawab."""


def _klien_bawaan(host: str, community: str):
    return snmp.Klien(host, community)


def _angka(nilai) -> int | None:
    return nilai if isinstance(nilai, int) else None


def baca(klien) -> dict:
    """Seluruh data yang ditarik dari satu klien SNMP yang sudah terbuka."""
    sistem = klien.get([SYS_NAME, SYS_DESCR, SYS_UPTIME])
    nama = klien.walk(IF_NAME) or {}
    deskripsi = klien.walk(IF_DESCR)
    status = klien.walk(IF_OPER)
    tipe = klien.walk(IF_TYPE)
    cepat_tinggi = klien.walk(IF_HIGH_SPEED) or {}
    cepat = klien.walk(IF_SPEED) if not cepat_tinggi else {}
    alias = klien.walk(IF_ALIAS) or {}
    masuk = klien.walk(IF_HC_IN) or klien.walk(IF_IN)
    keluar = klien.walk(IF_HC_OUT) or klien.walk(IF_OUT)

    label: dict[str, str] = {}
    antarmuka = []
    for indeks in sorted(deskripsi, key=lambda teks: int(teks) if teks.isdigit() else 0):
        if not indeks.isdigit():
            continue
        satu = snmp.teks(nama.get(indeks)) or snmp.teks(deskripsi.get(indeks))
        if not satu:
            continue
        label[indeks] = satu[:60]
        if _angka(tipe.get(indeks)) == TIPE_LOOPBACK:
            continue
        mbps = _angka(cepat_tinggi.get(indeks))
        if mbps is None and _angka(cepat.get(indeks)) is not None:
            mbps = cepat[indeks] // 1_000_000
        antarmuka.append(
            {
                "indeks": int(indeks),
                "nama": satu[:60],
                "tipe": _angka(tipe.get(indeks)),
                "naik": _angka(status.get(indeks)) == 1,
                "mbps": mbps or None,
                "alias": snmp.teks(alias.get(indeks))[:120] or None,
                "masuk": _angka(masuk.get(indeks)),
                "keluar": _angka(keluar.get(indeks)),
            }
        )

    # Alamat IP: indeks barisnya adalah alamatnya sendiri.
    alamat = []
    topeng = klien.walk(IP_MASK)
    for ip, indeks in (klien.walk(IP_IFINDEX) or {}).items():
        try:
            jaringan = ipaddress.ip_interface(f"{ip}/{topeng.get(ip) or '255.255.255.255'}")
        except ValueError:
            continue
        if jaringan.ip.is_loopback or jaringan.ip.is_link_local or jaringan.ip.is_unspecified:
            continue
        alamat.append(
            {
                "alamat": str(jaringan.ip),
                "prefix": jaringan.network.prefixlen,
                "antarmuka": label.get(str(indeks)),
            }
        )

    vlan: dict[int, str] = {}
    for indeks, teks_nama in (klien.walk(VLAN_NAMA) or {}).items():
        if indeks.isdigit() and 1 <= int(indeks) <= 4094:
            vlan[int(indeks)] = snmp.teks(teks_nama)[:120] or f"VLAN {indeks}"
    for satu in antarmuka:
        cocok = _POLA_VLAN.search(satu["nama"]) if satu["tipe"] == TIPE_VLAN else None
        if cocok and 1 <= int(cocok.group(1)) <= 4094:
            vlan.setdefault(int(cocok.group(1)), satu["alias"] or satu["nama"])

    bgp = []
    asn = klien.walk(BGP_AS) or {}
    lama_naik = klien.walk(BGP_UPTIME) or {}
    for peer, keadaan in (klien.walk(BGP_STATE) or {}).items():
        bgp.append(
            {
                "peer": peer,
                "asn": _angka(asn.get(peer)),
                "keadaan": KEADAAN_BGP.get(_angka(keadaan), "tidak dikenal"),
                "detik": _angka(lama_naik.get(peer)),
            }
        )

    uptime = _angka(sistem.get(SYS_UPTIME))
    return {
        "sysname": snmp.teks(sistem.get(SYS_NAME))[:255] or None,
        "sysdescr": snmp.teks(sistem.get(SYS_DESCR)) or None,
        "uptime_detik": uptime // 100 if uptime is not None else None,
        "antarmuka": antarmuka[:BATAS_PORT],
        "alamat": alamat,
        "vlan": vlan,
        "bgp": bgp,
    }


def _laju(port: DevicePort, satu: dict, sekarang) -> tuple[int, int] | None:
    """Laju masuk/keluar (bps) sejak tarikan sebelumnya, atau `None`.

    `None` berarti belum ada pembanding, jedanya terlalu panjang untuk
    dirata-ratakan, atau pencacahnya mundur (perangkat menyala ulang).
    """
    if satu["masuk"] is None or satu["keluar"] is None:
        return None
    if port.last_counter_at is None or port.last_in_octets is None or port.last_out_octets is None:
        return None
    jeda = (sekarang - port.last_counter_at).total_seconds()
    if jeda < 10 or jeda > JEDA_MAKS.total_seconds():
        return None
    selisih_masuk = Decimal(satu["masuk"]) - port.last_in_octets
    selisih_keluar = Decimal(satu["keluar"]) - port.last_out_octets
    if selisih_masuk < 0 or selisih_keluar < 0:
        return None
    return int(selisih_masuk * 8 / Decimal(jeda)), int(selisih_keluar * 8 / Decimal(jeda))


def _terapkan_port(sesi, perangkat: Device, ada: list, data: dict, sekarang) -> dict:
    per_indeks = {p.snmp_index: p for p in ada if p.snmp_index is not None}
    per_nama = {p.name: p for p in ada}
    dibuat = diperbarui = sampel = 0
    terlihat: set[int] = set()
    for satu in data["antarmuka"]:
        port = per_indeks.get(satu["indeks"]) or per_nama.get(satu["nama"])
        if port is None:
            port = DevicePort(
                device_id=perangkat.id, branch_id=perangkat.branch_id,
                name=satu["nama"], kind="access", status="bebas",
            )
            sesi.add(port)
            per_nama[satu["nama"]] = port
            dibuat += 1
        elif port.id in terlihat:
            # Dua antarmuka bernama sama di perangkat: yang kedua dilewati,
            # karena nama port unik per perangkat.
            continue
        else:
            diperbarui += 1
        port.snmp_index = satu["indeks"]
        port.if_type = satu["tipe"]
        port.oper_status = "naik" if satu["naik"] else "turun"
        port.alias = satu["alias"]
        if satu["mbps"]:
            port.speed_mbps = satu["mbps"]
        sesi.flush()
        terlihat.add(port.id)

        laju = _laju(port, satu, sekarang)
        if laju is not None:
            sesi.add(PortTraffic(port_id=port.id, device_id=perangkat.id, at=sekarang,
                                 in_bps=laju[0], out_bps=laju[1]))
            sampel += 1
        if satu["masuk"] is not None and satu["keluar"] is not None:
            port.last_in_octets = Decimal(satu["masuk"])
            port.last_out_octets = Decimal(satu["keluar"])
            port.last_counter_at = sekarang

    # Port lama yang tidak lagi dilaporkan perangkat: status link-nya dikosongkan
    # supaya tidak menampilkan keadaan basi. Portnya sendiri tidak dihapus.
    for port in ada:
        if port.id not in terlihat and port.snmp_index is not None:
            port.oper_status = None
    sesi.flush()
    return {"dibuat": dibuat, "diperbarui": diperbarui, "sampel": sampel}


def _terapkan_alamat(sesi, perangkat: Device, alamat: list[dict]) -> int:
    """Menyimpan alamat IP perangkat dan menyambungkannya ke Blok IP."""
    blok = list(sesi.execute(select(IpBlock)).scalars())
    jaringan_blok = []
    for satu in blok:
        try:
            jaringan_blok.append((ipaddress.ip_network(satu.cidr, strict=False), satu))
        except ValueError:
            continue
    blok_baru = 0
    sesi.execute(delete(DeviceIp).where(DeviceIp.device_id == perangkat.id))
    for satu in alamat:
        ip = ipaddress.ip_address(satu["alamat"])
        cocok = sorted(
            (j for j in jaringan_blok if ip.version == j[0].version and ip in j[0]),
            key=lambda j: j[0].prefixlen, reverse=True,
        )
        terpilih = cocok[0][1] if cocok else None
        prefix = satu["prefix"]
        # Alamat tunggal (/32, /128) bukan jaringan: tidak dibuatkan blok.
        if terpilih is None and prefix < ip.max_prefixlen:
            jaringan = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
            terpilih = IpBlock(
                cidr=str(jaringan),
                kind="privat" if jaringan.is_private else "publik",
                site_id=perangkat.site_id, branch_id=perangkat.branch_id,
                note=f"Otomatis dari SNMP {perangkat.name}.",
            )
            sesi.add(terpilih)
            sesi.flush()
            jaringan_blok.append((jaringan, terpilih))
            blok_baru += 1
        sesi.add(
            DeviceIp(
                device_id=perangkat.id, address=str(ip), prefix_len=prefix,
                if_name=satu["antarmuka"], ip_block_id=terpilih.id if terpilih else None,
            )
        )
    sesi.flush()
    return blok_baru


def _terapkan_vlan(sesi, perangkat: Device, vlan: dict[int, str]) -> int:
    """Mendaftarkan VLAN perangkat ke registry VLAN site-nya; yang ada dibiarkan."""
    if not vlan:
        return 0
    ada = set(
        sesi.execute(
            select(Vlan.vlan_id).where(Vlan.site_id == perangkat.site_id)
        ).scalars()
    )
    baru = 0
    for nomor, nama in sorted(vlan.items()):
        if nomor in ada:
            continue
        sesi.add(
            Vlan(
                vlan_id=nomor, name=nama or f"VLAN {nomor}", site_id=perangkat.site_id,
                branch_id=perangkat.branch_id, kind="lainnya", is_auto=False,
                note=f"Otomatis dari SNMP {perangkat.name}.",
            )
        )
        baru += 1
    sesi.flush()
    return baru


def _terapkan_bgp(sesi, perangkat: Device, bgp: list[dict]) -> None:
    sesi.execute(delete(DeviceBgpPeer).where(DeviceBgpPeer.device_id == perangkat.id))
    for satu in bgp:
        sesi.add(
            DeviceBgpPeer(
                device_id=perangkat.id, remote_addr=satu["peer"][:45], remote_as=satu["asn"],
                state=satu["keadaan"], established_seconds=satu["detik"],
            )
        )
    sesi.flush()


def tarik(sesi, aktor, device_id: int, sekarang, klien_pabrik=None,
          catat_audit: bool = True) -> dict:
    klien_pabrik = klien_pabrik or _klien_bawaan
    perangkat = service.ambil_perangkat(sesi, aktor, device_id)
    host = pantau.host_dari(perangkat.mgmt_address)
    if not host:
        raise SnmpGagal("mgmt_address", "Isi Alamat Manajemen perangkat lebih dulu.")
    if not perangkat.snmp_community:
        raise SnmpGagal("snmp_community", "Isi Community SNMP di formulir perangkat lebih dulu.")

    try:
        with klien_pabrik(host, perangkat.snmp_community) as klien:
            data = baca(klien)
    except snmp.GalatSnmp as galat:
        raise SnmpGagal("snmp_community", str(galat)) from galat

    perangkat.snmp_sysname = data["sysname"]
    perangkat.snmp_sysdescr = data["sysdescr"]
    perangkat.snmp_uptime_seconds = data["uptime_detik"]
    perangkat.snmp_synced_at = sekarang
    perangkat.snmp_error = None

    ada = service.daftar_port(sesi, aktor, device_id)
    hasil = _terapkan_port(sesi, perangkat, ada, data, sekarang)
    hasil["antarmuka"] = len(data["antarmuka"])
    hasil["alamat"] = len(data["alamat"])
    hasil["blok_baru"] = _terapkan_alamat(sesi, perangkat, data["alamat"])
    hasil["vlan_baru"] = _terapkan_vlan(sesi, perangkat, data["vlan"])
    _terapkan_bgp(sesi, perangkat, data["bgp"])
    hasil["bgp"] = len(data["bgp"])

    # Tarikan berkala tidak dicatat tiap lima menit; yang dicatat hanya saat
    # ia menambah sesuatu ke inventaris.
    if catat_audit or hasil["dibuat"] or hasil["blok_baru"] or hasil["vlan_baru"]:
        audit.record(
            sesi, "update", "device", perangkat.id,
            after={"snmp_tarik": hasil, "snmp_sysname": perangkat.snmp_sysname}, aktor=aktor,
        )
    return hasil


def tarik_berkala(sesi, sekarang, klien_pabrik=None) -> dict:
    """Menarik semua perangkat yang dicentang "Tarik SNMP berkala".

    Satu perangkat yang gagal tidak menghentikan yang lain; galatnya disimpan
    di perangkatnya supaya tampil di halaman detail.
    """
    ringkas = {"perangkat": 0, "gagal": [], "sampel": 0}
    ids = sesi.execute(
        select(Device.id)
        .where(Device.snmp_poll.is_(True), Device.snmp_community.is_not(None))
        .order_by(Device.id)
    ).scalars().all()
    for device_id in ids:
        ringkas["perangkat"] += 1
        try:
            with sesi.begin_nested():
                hasil = tarik(sesi, rbac.SISTEM, device_id, sekarang,
                              klien_pabrik=klien_pabrik, catat_audit=False)
            ringkas["sampel"] += hasil["sampel"]
        except GalatDomain as galat:
            perangkat = sesi.get(Device, device_id)
            perangkat.snmp_error = str(galat)[:255]
            ringkas["gagal"].append(perangkat.name)
    sesi.execute(
        delete(PortTraffic).where(PortTraffic.at < sekarang - timedelta(days=SIMPAN_HARI))
    )
    sesi.flush()
    return ringkas
