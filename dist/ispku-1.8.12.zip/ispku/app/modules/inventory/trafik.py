"""Deret laju trafik dan grafiknya (gaya MRTG: masuk berisi, keluar bergaris)."""

from datetime import timedelta
from html import escape

from sqlalchemy import func, select

from app.modules.inventory.models import DevicePort, PortTraffic
from app.modules.inventory.snmp_tarik import TIPE_FISIK

RENTANG = {"24j": ("24 jam", timedelta(hours=24)), "7h": ("7 hari", timedelta(days=7)),
           "30h": ("30 hari", timedelta(days=30))}


def rentang_sah(kunci: str | None) -> str:
    return kunci if kunci in RENTANG else "24j"


def _waktu(kunci: str):
    # 24 jam memakai sampel apa adanya; rentang panjang dirata-ratakan per jam.
    return PortTraffic.at if kunci == "24j" else func.date_trunc("hour", PortTraffic.at)


def deret_port(sesi, port_id: int, sekarang, kunci: str = "24j") -> list[tuple]:
    kolom = _waktu(kunci)
    return [
        (saat, int(masuk), int(keluar))
        for saat, masuk, keluar in sesi.execute(
            select(kolom, func.avg(PortTraffic.in_bps), func.avg(PortTraffic.out_bps))
            .where(PortTraffic.port_id == port_id, PortTraffic.at >= sekarang - RENTANG[kunci][1])
            .group_by(kolom)
            .order_by(kolom)
        ).all()
    ]


def deret_perangkat(sesi, device_id: int, sekarang, kunci: str = "24j") -> list[tuple]:
    """Jumlah laju seluruh port FISIK perangkat per waktu sampel."""
    fisik = select(DevicePort.id).where(
        DevicePort.device_id == device_id, DevicePort.if_type.in_(TIPE_FISIK)
    )
    per_sampel = (
        select(
            PortTraffic.at.label("at"),
            func.sum(PortTraffic.in_bps).label("masuk"),
            func.sum(PortTraffic.out_bps).label("keluar"),
        )
        .where(
            PortTraffic.device_id == device_id,
            PortTraffic.port_id.in_(fisik),
            PortTraffic.at >= sekarang - RENTANG[kunci][1],
        )
        .group_by(PortTraffic.at)
        .subquery()
    )
    kolom = per_sampel.c.at if kunci == "24j" else func.date_trunc("hour", per_sampel.c.at)
    return [
        (saat, int(masuk), int(keluar))
        for saat, masuk, keluar in sesi.execute(
            select(kolom, func.avg(per_sampel.c.masuk), func.avg(per_sampel.c.keluar))
            .group_by(kolom)
            .order_by(kolom)
        ).all()
    ]


def laju_teks(bps: float) -> str:
    for batas, satuan in ((1e9, "Gbps"), (1e6, "Mbps"), (1e3, "kbps")):
        if bps >= batas:
            return f"{bps / batas:.2f} {satuan}".replace(".", ",")
    return f"{bps:.0f} bps"


def ringkas(deret: list[tuple]) -> dict | None:
    if not deret:
        return None
    masuk = [d[1] for d in deret]
    keluar = [d[2] for d in deret]
    return {
        "kini_masuk": laju_teks(masuk[-1]), "kini_keluar": laju_teks(keluar[-1]),
        "rata_masuk": laju_teks(sum(masuk) / len(masuk)),
        "rata_keluar": laju_teks(sum(keluar) / len(keluar)),
        "puncak_masuk": laju_teks(max(masuk)), "puncak_keluar": laju_teks(max(keluar)),
    }


def svg(deret: list[tuple], awal, akhir, lebar: int = 860, tinggi: int = 230) -> str:
    """Grafik trafik sebagai SVG. Sumbu waktu tetap `[awal, akhir]`.

    Sumbu waktunya tidak mengikuti data: celah saat perangkat tidak menjawab
    harus tampak sebagai celah, bukan dirapatkan.
    """
    kiri, kanan, atas, bawah = 82, 30, 12, 26
    w, h = lebar - kiri - kanan, tinggi - atas - bawah
    if not deret:
        return (
            f'<svg class="grafik-trafik" viewBox="0 0 {lebar} {tinggi}" role="img" '
            f'aria-label="Belum ada data trafik"><text x="{lebar / 2}" y="{tinggi / 2}" '
            'text-anchor="middle" class="grafik-trafik__kosong">Belum ada data trafik pada rentang ini</text></svg>'
        )
    total = max((akhir - awal).total_seconds(), 1)
    puncak = max(max(d[1], d[2]) for d in deret) or 1
    # Batas atas dibulatkan ke 1/2/5 × 10^n supaya garis skalanya enak dibaca.
    pangkat = 10 ** (len(str(int(puncak))) - 1)
    atas_skala = next(k * pangkat for k in (1, 2, 5, 10) if k * pangkat >= puncak)

    def x(saat):
        return kiri + w * min(max((saat - awal).total_seconds() / total, 0), 1)

    def y(nilai):
        return atas + h * (1 - nilai / atas_skala)

    # Sampel yang berjarak jauh diputus: garis tidak ditarik melewati celah data.
    jeda = [(b[0] - a[0]).total_seconds() for a, b in zip(deret, deret[1:])]
    batas_celah = (sorted(jeda)[len(jeda) // 2] * 3) if jeda else 0
    potong, kini = [], [deret[0]]
    for sebelum, satu in zip(deret, deret[1:]):
        if batas_celah and (satu[0] - sebelum[0]).total_seconds() > batas_celah:
            potong.append(kini)
            kini = []
        kini.append(satu)
    potong.append(kini)

    bagian = [f'<svg class="grafik-trafik" viewBox="0 0 {lebar} {tinggi}" role="img" '
              f'aria-label="Grafik trafik masuk dan keluar">']
    for langkah in range(5):
        nilai = atas_skala * langkah / 4
        yy = y(nilai)
        bagian.append(f'<line class="grafik-trafik__kisi" x1="{kiri}" x2="{lebar - kanan}" y1="{yy:.1f}" y2="{yy:.1f}"/>')
        bagian.append(f'<text class="grafik-trafik__label" x="{kiri - 6}" y="{yy + 3:.1f}" text-anchor="end">{escape(laju_teks(nilai))}</text>')
    for langkah in range(7):
        saat = awal + (akhir - awal) * langkah / 6
        teks = saat.strftime("%H:%M") if total <= 90000 else saat.strftime("%d %b")
        bagian.append(f'<text class="grafik-trafik__label" x="{x(saat):.1f}" y="{tinggi - 8}" text-anchor="middle">{teks}</text>')
    dasar = atas + h
    for ruas in potong:
        titik_masuk = " ".join(f"{x(d[0]):.1f},{y(d[1]):.1f}" for d in ruas)
        titik_keluar = " ".join(f"{x(d[0]):.1f},{y(d[2]):.1f}" for d in ruas)
        bagian.append(
            f'<polygon class="grafik-trafik__masuk" points="{x(ruas[0][0]):.1f},{dasar} {titik_masuk} {x(ruas[-1][0]):.1f},{dasar}"/>'
        )
        bagian.append(f'<polyline class="grafik-trafik__keluar" points="{titik_keluar}"/>')
        if len(ruas) == 1:
            bagian.append(f'<circle class="grafik-trafik__titik" cx="{x(ruas[0][0]):.1f}" cy="{y(ruas[0][2]):.1f}" r="2.5"/>')
    bagian.append("</svg>")
    return "".join(bagian)
