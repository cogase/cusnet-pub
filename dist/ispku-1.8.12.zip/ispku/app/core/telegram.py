"""Mengirim pesan ke Telegram lewat Bot API.

Hanya `sendMessage`, lewat pustaka standar. Tidak pernah melempar galat:
kabar yang gagal terkirim tidak boleh menggagalkan pekerjaan yang memicunya
(pemantauan perangkat, pembukaan tiket). Hasilnya dikembalikan sebagai
`(berhasil, keterangan)`.
"""

import json
import logging
import urllib.error
import urllib.request

_log = logging.getLogger(__name__)
ALAMAT = "https://api.telegram.org/bot{token}/sendMessage"


def _buka(permintaan, tenggat):
    return urllib.request.urlopen(permintaan, timeout=tenggat)  # noqa: S310 — alamat tetap


def kirim(token: str | None, chat_id: str | None, teks: str, tenggat: float = 6.0) -> tuple[bool, str]:
    token, chat_id = (token or "").strip(), (chat_id or "").strip()
    if not token or not chat_id:
        return False, "Token bot atau chat ID belum diisi."
    isi = json.dumps(
        {"chat_id": chat_id, "text": teks[:4000], "disable_web_page_preview": True}
    ).encode()
    permintaan = urllib.request.Request(
        ALAMAT.format(token=token), data=isi, headers={"Content-Type": "application/json"}
    )
    try:
        with _buka(permintaan, tenggat) as jawaban:
            hasil = json.loads(jawaban.read().decode() or "{}")
    except urllib.error.HTTPError as galat:
        try:
            rinci = json.loads(galat.read().decode()).get("description", "")
        except Exception:  # noqa: BLE001
            rinci = ""
        # Token tidak pernah ikut ke log maupun ke pesan galat.
        _log.warning("Telegram menolak pesan: HTTP %s %s", galat.code, rinci)
        return False, f"Telegram menolak (HTTP {galat.code}){': ' + rinci if rinci else ''}."
    except Exception as galat:  # noqa: BLE001 — jaringan, DNS, tenggat
        _log.warning("Telegram tidak terjangkau: %s", type(galat).__name__)
        return False, "Telegram tidak terjangkau dari server ini."
    if not hasil.get("ok"):
        return False, f"Telegram menolak: {hasil.get('description', 'tanpa keterangan')}."
    return True, "Terkirim."
