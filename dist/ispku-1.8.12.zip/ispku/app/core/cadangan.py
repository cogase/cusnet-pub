"""Cadangan dan pemulihan basis data.

Berkas cadangan memakai format custom `pg_dump -Fc`, bukan SQL polos, karena
pemulihan butuh `--clean --if-exists` per objek dan itu hanya ada di
`pg_restore`.

Versi `pg_dump`/`pg_restore` di image aplikasi harus sama dengan versi server
Postgres (lihat catatan di `Dockerfile`). Klien yang lebih tua menolak dump
dari server yang lebih baru, dan itu baru ketahuan saat pemulihan darurat.
"""

import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta

from app.core import waktu as waktu_aplikasi
from pathlib import Path
from urllib.parse import unquote, urlparse

from app.core.errors import GalatDomain, TidakDitemukan

POLA_NAMA = re.compile(r"^cusnet-\d{8}-\d{6}\.dump$")

# Batas waktu satu perintah pg_dump/pg_restore. Basis data ISP menengah masih
# jauh di bawah ini; batasnya ada supaya proses yang menggantung karena kunci
# tidak menahan worker gunicorn selamanya.
BATAS_DETIK = 1800


class GalatCadangan(GalatDomain):
    """Cadangan atau pemulihan gagal.

    Turunan `GalatDomain` supaya rute cukup menangkap satu kelas seperti modul
    lain; `.field` menunjuk kolom formulir yang paling dekat dengan pemicunya.
    """


@dataclass(frozen=True)
class BerkasCadangan:
    nama: str
    ukuran: int
    dibuat: datetime


def _koneksi(database_url: str) -> dict:
    """Pecah DATABASE_URL SQLAlchemy menjadi argumen dan env untuk klien pg.

    Sandi tidak pernah masuk ke baris perintah — daftar proses terbaca semua
    pengguna di host. Dikirim lewat `PGPASSWORD`.
    """
    terurai = urlparse(database_url)
    nama_db = unquote(terurai.path.lstrip("/"))
    if not nama_db:
        raise GalatCadangan("berkas", "DATABASE_URL tidak memuat nama basis data.")

    argumen = [
        "--host",
        terurai.hostname or "localhost",
        "--port",
        str(terurai.port or 5432),
        "--username",
        unquote(terurai.username or "postgres"),
        "--dbname",
        nama_db,
    ]
    env = dict(os.environ)
    if terurai.password:
        env["PGPASSWORD"] = unquote(terurai.password)
    return {"argumen": argumen, "env": env, "nama_db": nama_db, "urai": terurai}


def _jalankan(perintah: list[str], env: dict) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            perintah,
            env=env,
            capture_output=True,
            text=True,
            timeout=BATAS_DETIK,
        )
    except FileNotFoundError as galat:
        raise GalatCadangan(
            "berkas",
            f"Perintah {perintah[0]} tidak ada di dalam kontainer. "
            "Image aplikasi harus memasang postgresql-client versi yang sama "
            "dengan server.",
        ) from galat
    except subprocess.TimeoutExpired as galat:
        raise GalatCadangan(
            "berkas",
            f"{perintah[0]} melewati batas {BATAS_DETIK} detik dan dihentikan.",
        ) from galat


def _direktori(backup_dir: str) -> Path:
    folder = Path(backup_dir)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def nama_berkas(waktu: datetime) -> str:
    return f"cusnet-{waktu:%Y%m%d-%H%M%S}.dump"


def path_aman(backup_dir: str, nama: str) -> Path:
    """Path berkas cadangan bernama `nama`, atau galat.

    Nama dari pengguna tidak pernah digabung mentah ke `backup_dir`: satu
    `../../etc/passwd` sudah cukup untuk mengubah tombol Unduh menjadi
    pembaca berkas sembarang.
    """
    if not POLA_NAMA.match(nama or ""):
        raise TidakDitemukan("Berkas cadangan tidak dikenal.")
    berkas = _direktori(backup_dir) / nama
    if not berkas.is_file():
        raise TidakDitemukan("Berkas cadangan tidak ada.")
    return berkas


def daftar(backup_dir: str) -> list[BerkasCadangan]:
    """Cadangan yang ada, terbaru lebih dulu."""
    hasil = []
    for berkas in _direktori(backup_dir).iterdir():
        if not berkas.is_file() or not POLA_NAMA.match(berkas.name):
            continue
        info = berkas.stat()
        hasil.append(
            BerkasCadangan(
                nama=berkas.name,
                ukuran=info.st_size,
                # Zona aplikasi, bukan zona kontainer (yang hampir selalu UTC).
                dibuat=datetime.fromtimestamp(info.st_mtime, tz=waktu_aplikasi.sekarang().tzinfo),
            )
        )
    return sorted(hasil, key=lambda b: b.nama, reverse=True)


def buat(database_url: str, backup_dir: str, waktu: datetime, tujuan: str | None = None) -> Path:
    """Buat cadangan dan kembalikan path-nya."""
    koneksi = _koneksi(database_url)
    berkas = Path(tujuan) if tujuan else _direktori(backup_dir) / nama_berkas(waktu)
    berkas.parent.mkdir(parents=True, exist_ok=True)

    sementara = berkas.with_name(berkas.name + ".partial")
    hasil = _jalankan(
        ["pg_dump", "--format=custom", "--file", str(sementara), *koneksi["argumen"]],
        koneksi["env"],
    )
    if hasil.returncode != 0:
        sementara.unlink(missing_ok=True)
        raise GalatCadangan(
            "berkas", f"pg_dump gagal: {(hasil.stderr or '').strip()[:500]}"
        )

    # Ganti nama hanya setelah pg_dump sukses. Cadangan setengah jadi yang
    # sudah bernama benar adalah cadangan yang dipercaya padahal tidak utuh.
    sementara.replace(berkas)
    return berkas


# Batas ukuran berkas cadangan yang diunggah lewat peramban. Jauh di atas
# batas unggah umum aplikasi (8 MB) karena dump basis data memang besar.
BATAS_UNGGAH_BYTE = 1024 * 1024 * 1024
# Lima byte pertama setiap dump format custom `pg_dump -Fc`.
TANDA_DUMP = b"PGDMP"


def simpan_unggahan(backup_dir: str, berkas_unggah, waktu: datetime) -> Path:
    """Menyimpan dump yang diunggah ke `backup_dir` dan mengembalikan path-nya.

    Nama dari komputer pengunggah dibuang: berkas diberi nama baru menurut
    pola cadangan, sehingga tidak ada nama dari luar yang pernah menyentuh
    sistem berkas dan berkasnya langsung muncul di daftar cadangan.

    Isinya diperiksa dua kali sebelum dipercaya — tanda format di awal
    berkas, lalu `pg_restore --list` yang membaca daftar isinya tanpa
    menyentuh basis data. Berkas yang lolos keduanya baru diberi nama akhir.
    """
    folder = _direktori(backup_dir)
    tujuan = folder / nama_berkas(waktu)
    while tujuan.exists():
        waktu = waktu + timedelta(seconds=1)
        tujuan = folder / nama_berkas(waktu)

    sementara = tujuan.with_name(tujuan.name + ".partial")
    try:
        berkas_unggah.save(str(sementara))
        ukuran = sementara.stat().st_size
        if ukuran == 0:
            raise GalatCadangan("berkas", "Berkas yang diunggah kosong.")
        if ukuran > BATAS_UNGGAH_BYTE:
            raise GalatCadangan(
                "berkas",
                f"Berkas melebihi batas {BATAS_UNGGAH_BYTE // (1024 * 1024)} MB.",
            )
        with sementara.open("rb") as isi:
            if isi.read(len(TANDA_DUMP)) != TANDA_DUMP:
                raise GalatCadangan(
                    "berkas",
                    "Berkas ini bukan cadangan ISPKU. Unggah berkas .dump yang "
                    "diunduh dari halaman Sistem.",
                )
        hasil = _jalankan(["pg_restore", "--list", str(sementara)], dict(os.environ))
        if hasil.returncode != 0:
            raise GalatCadangan(
                "berkas",
                "Berkas cadangan rusak atau dibuat oleh versi PostgreSQL yang "
                f"lebih baru: {(hasil.stderr or '').strip()[:300]}",
            )
        sementara.replace(tujuan)
    finally:
        sementara.unlink(missing_ok=True)
    return tujuan


def hapus(backup_dir: str, nama: str) -> None:
    path_aman(backup_dir, nama).unlink()


def _putus_koneksi_lain(koneksi: dict) -> None:
    """Putuskan koneksi lain ke basis data yang akan dipulihkan.

    `pg_restore --clean` men-drop objek yang masih dipegang koneksi lain, dan
    menunggu koneksi itu melepas. Tanpa langkah ini pemulihan menggantung
    sampai batas waktu.
    """
    urai = koneksi["urai"]
    dsn_maintenance = [
        "--host",
        urai.hostname or "localhost",
        "--port",
        str(urai.port or 5432),
        "--username",
        unquote(urai.username or "postgres"),
        "--dbname",
        "postgres",
    ]
    sql = (
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        f"WHERE datname = '{koneksi['nama_db']}' AND pid <> pg_backend_pid()"
    )
    _jalankan(
        ["psql", "--quiet", "--no-psqlrc", "--command", sql, *dsn_maintenance],
        koneksi["env"],
    )


def _galat_fatal(stderr: str) -> list[str]:
    """Baris galat pg_restore yang benar-benar fatal.

    `--clean --if-exists` tetap mengeluh untuk objek yang memang belum ada di
    basis data tujuan. Peringatan semacam itu membuat kode keluar 1 tanpa
    berarti pemulihannya gagal.
    """
    dimaklumi = ("does not exist, skipping", "warning:", "peringatan:")
    baris_buruk = []
    for baris in (stderr or "").splitlines():
        bersih = baris.strip()
        if not bersih:
            continue
        if any(tanda in bersih.lower() for tanda in dimaklumi):
            continue
        baris_buruk.append(bersih)
    return baris_buruk


AKAR_MIGRASI = Path(__file__).resolve().parent.parent.parent


def versi_head() -> str:
    """Revisi migrasi terbaru menurut berkas di `migrations/versions/`.

    Dibaca dari nama berkas, bukan dengan memuat Alembic: fungsi ini dipanggil
    tepat sesudah pemulihan, saat basis datanya belum tentu bisa dibaca.
    """
    revisi = [
        b.name.split("_", 1)[0]
        for b in (AKAR_MIGRASI / "migrations" / "versions").glob("*.py")
        if b.name[0].isdigit()
    ]
    if not revisi:
        raise GalatCadangan("berkas", "Tidak ada berkas migrasi yang bisa dibaca.")
    return max(revisi)


def naikkan_skema(database_url: str) -> str:
    """Menjalankan `alembic upgrade head` pada `database_url`.

    Dipakai sesudah pemulihan. Mengembalikan revisi yang berlaku sesudahnya.
    """
    from alembic import command
    from alembic.config import Config as AlembicConfig

    sebelum = os.environ.get("DATABASE_URL")
    config = AlembicConfig(str(AKAR_MIGRASI / "alembic.ini"))
    config.set_main_option("script_location", str(AKAR_MIGRASI / "migrations"))
    os.environ["DATABASE_URL"] = database_url
    try:
        command.upgrade(config, "head")
    except Exception as galat:  # noqa: BLE001 — dibungkus jadi galat domain
        raise GalatCadangan(
            "berkas",
            "Basis data berhasil dipulihkan, tetapi migrasi setelahnya gagal: "
            f"{galat}. Jalankan `alembic upgrade head` secara manual sebelum "
            "memakai aplikasi.",
        ) from galat
    finally:
        if sebelum is None:
            os.environ.pop("DATABASE_URL", None)
        else:
            os.environ["DATABASE_URL"] = sebelum
    return versi_head()


def pulihkan(database_url: str, berkas: Path, engine=None) -> None:
    """Pulihkan basis data dari `berkas`, lalu jalankan migrasi ke head.

    Data yang ada sekarang dibuang.

    Migrasi di akhir bukan hiasan: `pg_restore --clean` mengembalikan seluruh
    isi dump termasuk tabel `alembic_version`, jadi cadangan yang dibuat
    sebelum sebuah migrasi mengembalikan skema **lama** ke bawah kode **baru**
    yang sedang berjalan. `docker-entrypoint.sh` memang menjalankan migrasi
    saat kontainer start, tapi pemulihan terjadi di kontainer yang sudah
    jalan — dan sampai restart berikutnya setiap halaman yang menyentuh kolom
    baru menjawab 500 tanpa ada yang memberi tahu kenapa.
    """
    from app.core.db import db_session

    koneksi = _koneksi(database_url)

    # Urutannya penting: lepas sesi permintaan ini, tutup pool, baru putuskan
    # koneksi sisa. Kalau tidak, pemulihan menunggu koneksinya sendiri.
    db_session.remove()
    if engine is not None:
        engine.dispose()
    _putus_koneksi_lain(koneksi)

    hasil = _jalankan(
        [
            "pg_restore",
            "--clean",
            "--if-exists",
            "--no-owner",
            "--no-privileges",
            "--single-transaction",
            *koneksi["argumen"],
            str(berkas),
        ],
        koneksi["env"],
    )
    if hasil.returncode != 0:
        buruk = _galat_fatal(hasil.stderr)
        if buruk:
            raise GalatCadangan(
                "berkas", f"pg_restore gagal: {' | '.join(buruk)[:500]}"
            )

    naikkan_skema(database_url)
