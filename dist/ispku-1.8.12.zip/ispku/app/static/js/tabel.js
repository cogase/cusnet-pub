/* Tabel standar ISPKU — tata letaknya mengikuti tabel Transit Pak.
 *
 * Setiap halaman daftar dirakit ulang menjadi susunan yang sama:
 *
 *   [ kartu bilah alat ]  cari · Saring (n) ............ Kolom · Ekspor · Impor
 *                         panel saringan (terbuka di bawah barisnya)
 *   Disaring: [cip ×] [cip ×]  Lepas semua
 *   [ kartu tabel ]       bilah aksi massal (saat ada baris dipilih)
 *                         tabel — kepala kecil huruf besar, kolom aksi lengket
 *                         kaki: Tampilkan [20] baris · 1–20 dari N ...... ‹ 1 2 ›
 *
 * Templat tidak perlu mengikuti susunan itu. Skrip ini memungut formulir
 * saringan GET, tautan ekspor, dan pemilih kolom yang ada di halaman, lalu
 * menaruhnya di tempat standarnya. Tabel yang ber-`data-entitas` dan barisnya
 * ber-`data-id` mendapat kotak centang, aksi massal, dan impor CSV.
 * Tabel yang tidak boleh disentuh diberi `data-tabel="polos"`.
 *
 * Aksi massal memanggil /massal/<entitas>/…; hak aksesnya ditentukan server.
 */
(function () {
  "use strict";

  const PILIHAN_BARIS = [20, 50, 100];
  const meta = new Map();

  const simpan = {
    baca(kunci, bawaan) {
      try { return JSON.parse(localStorage.getItem(kunci)) ?? bawaan; } catch (e) { return bawaan; }
    },
    tulis(kunci, nilai) {
      try { localStorage.setItem(kunci, JSON.stringify(nilai)); } catch (e) { /* tidak diingat */ }
    }
  };

  function buat(tag, kelas, isi) {
    const unsur = document.createElement(tag);
    if (kelas) unsur.className = kelas;
    if (isi !== undefined) unsur.innerHTML = isi;
    return unsur;
  }

  function ikon(nama) { return '<i data-lucide="' + nama + '"></i>'; }

  function kunciTabel(tabel, nomor) {
    return "cusnet-tabel:" + location.pathname + ":" + (tabel.dataset.entitas || tabel.id || nomor);
  }

  function csrf() {
    const wadah = document.querySelector("[data-csrf]");
    return wadah ? wadah.dataset.csrf : "";
  }

  function beriTahu(teks) {
    const kotak = document.getElementById("live-update-notice");
    if (!kotak) return;
    kotak.textContent = teks;
    kotak.hidden = false;
    window.clearTimeout(beriTahu.jam);
    beriTahu.jam = window.setTimeout(() => { kotak.hidden = true; }, 6000);
  }

  function segarkan() {
    if (window.cusnetSegarkan) return window.cusnetSegarkan();
    location.reload();
    return Promise.resolve();
  }

  // --- Lebar kolom ----------------------------------------------------------
  function pasangLebar(tabel, kunci) {
    const lebar = simpan.baca(kunci + ":lebar", {});
    const kepala = Array.from(tabel.tHead.rows[0].cells);
    const adaSimpanan = Object.keys(lebar).length > 0;
    if (adaSimpanan) tabel.classList.add("tabel--lebar-tetap");
    kepala.forEach((th, i) => {
      const nama = th.dataset.kolom || String(i);
      if (lebar[nama]) th.style.width = lebar[nama] + "px";
      if (th.classList.contains("tabel__pilih") || th.querySelector(".tabel__geser")) return;
      const pegangan = buat("span", "tabel__geser");
      pegangan.setAttribute("aria-hidden", "true");
      th.append(pegangan);
      pegangan.addEventListener("pointerdown", (awal) => {
        awal.preventDefault();
        awal.stopPropagation();
        // Bekukan lebar semua kolom dulu supaya kolom lain tidak ikut
        // meloncat saat tata letak berpindah ke lebar tetap.
        if (!tabel.classList.contains("tabel--lebar-tetap")) {
          kepala.forEach((k) => { k.style.width = k.offsetWidth + "px"; });
          tabel.classList.add("tabel--lebar-tetap");
        }
        const mulaiX = awal.clientX;
        const mulaiLebar = th.offsetWidth;
        pegangan.setPointerCapture(awal.pointerId);
        document.body.classList.add("sedang-menggeser");
        const gerak = (e) => { th.style.width = Math.max(56, mulaiLebar + e.clientX - mulaiX) + "px"; };
        const lepas = () => {
          pegangan.removeEventListener("pointermove", gerak);
          document.body.classList.remove("sedang-menggeser");
          const hasil = {};
          kepala.forEach((k, n) => { hasil[k.dataset.kolom || String(n)] = k.offsetWidth; });
          simpan.tulis(kunci + ":lebar", hasil);
        };
        pegangan.addEventListener("pointermove", gerak);
        pegangan.addEventListener("pointerup", lepas, { once: true });
        pegangan.addEventListener("pointercancel", lepas, { once: true });
      });
    });
  }

  // --- Kolom tampil/sembunyi --------------------------------------------------
  function terapkanKolom(tabel, sembunyi) {
    const kepala = Array.from(tabel.tHead.rows[0].cells);
    kepala.forEach((th, i) => {
      const hilang = sembunyi.includes(th.textContent.trim());
      const pilih = 'tr > :nth-child(' + (i + 1) + ')';
      tabel.querySelectorAll(pilih).forEach((sel) => {
        if (sel.colSpan > 1) return;
        sel.classList.toggle("tabel__sel--sembunyi", hilang);
      });
    });
  }

  function menuKolom(tabel, kunci) {
    const sembunyi = simpan.baca(kunci + ":sembunyi", []);
    terapkanKolom(tabel, sembunyi);
    const bungkus = buat("details", "pemilih-kolom tabel-alat__kolom");
    const ringkas = buat("summary", "tombol tombol--kecil", ikon("columns-3") + " Kolom");
    const lencana = buat("span", "alat__lencana-kolom");
    ringkas.append(lencana);
    bungkus.append(ringkas);
    const panel = buat("div", "pemilih-kolom__panel");
    panel.append(buat("div", "pemilih-kolom__judul", "Tampilkan kolom"));
    const kotakKotak = [];
    const tulisLencana = (kini) => {
      lencana.textContent = kini.length ? kini.length + " disembunyikan" : "";
      lencana.hidden = !kini.length;
    };
    Array.from(tabel.tHead.rows[0].cells).forEach((th) => {
      const judul = th.textContent.trim();
      if (!judul || th.classList.contains("tabel__pilih") || /^aksi$/i.test(judul)) return;
      const baris = buat("label", "pemilih-kolom__baris");
      const kotak = buat("input");
      kotak.type = "checkbox";
      kotak.checked = !sembunyi.includes(judul);
      kotak.addEventListener("change", () => {
        const kini = simpan.baca(kunci + ":sembunyi", []).filter((j) => j !== judul);
        if (!kotak.checked) kini.push(judul);
        simpan.tulis(kunci + ":sembunyi", kini);
        terapkanKolom(tabel, kini);
        tulisLencana(kini);
      });
      kotakKotak.push(kotak);
      baris.append(kotak, document.createTextNode(" " + judul));
      panel.append(baris);
    });
    const kaki = buat("div", "pemilih-kolom__kaki");
    const semua = buat("button", "tombol tombol--kecil tombol--hantu", "Tampilkan semua");
    semua.type = "button";
    semua.addEventListener("click", () => {
      simpan.tulis(kunci + ":sembunyi", []);
      kotakKotak.forEach((k) => { k.checked = true; });
      terapkanKolom(tabel, []);
      tulisLencana([]);
    });
    const tutup = buat("button", "tombol tombol--kecil tombol--hantu", "Tutup");
    tutup.type = "button";
    tutup.addEventListener("click", () => { bungkus.open = false; });
    kaki.append(semua, tutup);
    panel.append(kaki);
    bungkus.append(panel);
    tulisLencana(sembunyi);
    return bungkus;
  }

  // --- Ekspor CSV dari isi tabel ----------------------------------------------
  function eksporCsv(tabel) {
    const baris = [];
    const ambil = (sel) => '"' + sel.innerText.replace(/\s+/g, " ").trim().replace(/"/g, '""') + '"';
    tabel.querySelectorAll("tr").forEach((tr) => {
      const sel = Array.from(tr.cells).filter((s) =>
        !s.classList.contains("tabel__pilih") && !s.classList.contains("tabel__sel--sembunyi") &&
        !s.querySelector(".tabel__aksi") && !/^aksi$/i.test(s.textContent.trim()) && s.colSpan === 1);
      if (sel.length) baris.push(sel.map(ambil).join(","));
    });
    const berkas = new Blob(["﻿" + baris.join("\r\n")], { type: "text/csv;charset=utf-8" });
    const tautan = buat("a");
    tautan.href = URL.createObjectURL(berkas);
    tautan.download = (tabel.dataset.entitas || document.title.split(" — ")[0] || "tabel").toLowerCase().replace(/\s+/g, "-") + ".csv";
    tautan.dataset.live = "off";
    document.body.append(tautan);
    tautan.click();
    tautan.remove();
    window.setTimeout(() => URL.revokeObjectURL(tautan.href), 1000);
  }

  // --- Paginasi di peramban ---------------------------------------------------
  function paginasiLokal(tabel, kunci, wadah) {
    const baris = Array.from(tabel.tBodies[0].rows).filter((tr) => !tr.querySelector("td[colspan]"));
    if (baris.length <= PILIHAN_BARIS[0]) return;
    let per = simpan.baca(kunci + ":per", PILIHAN_BARIS[0]);
    let halaman = 1;
    const kaki = buat("div", "paginasi paginasi--lokal");
    const info = buat("span", "paginasi__info");
    const daftar = buat("div", "paginasi__daftar");
    const pilih = buat("select");
    pilih.setAttribute("aria-label", "Jumlah baris per halaman");
    PILIHAN_BARIS.forEach((n) => { const o = buat("option", "", n + " / halaman"); o.value = n; pilih.append(o); });
    pilih.value = PILIHAN_BARIS.includes(per) ? per : PILIHAN_BARIS[0];
    const formulir = buat("div", "paginasi__per-halaman");
    formulir.append(pilih);
    kaki.append(info, daftar, formulir);
    wadah.after(kaki);
    kaki.dataset.lokal = "1";

    function gambar() {
      per = Number(pilih.value);
      const akhir = Math.max(1, Math.ceil(baris.length / per));
      halaman = Math.min(halaman, akhir);
      baris.forEach((tr, i) => { tr.hidden = i < (halaman - 1) * per || i >= halaman * per; });
      info.textContent = "Menampilkan " + ((halaman - 1) * per + 1) + " - " + Math.min(halaman * per, baris.length) + " dari " + baris.length + " data";
      daftar.replaceChildren();
      const tombol = (teks, tujuan, mati, aktif) => {
        const t = buat("button", "paginasi__halaman" + (aktif ? " paginasi__halaman--aktif" : "") + (mati ? " paginasi__panah--mati" : ""), teks);
        t.type = "button";
        t.disabled = mati;
        t.addEventListener("click", () => { halaman = tujuan; gambar(); });
        daftar.append(t);
      };
      tombol("‹", halaman - 1, halaman === 1);
      for (let n = 1; n <= akhir; n++) {
        if (akhir > 7 && Math.abs(n - halaman) > 1 && n !== 1 && n !== akhir) {
          if (n === 2 || n === akhir - 1) daftar.append(buat("span", "paginasi__elipsis", "…"));
          continue;
        }
        tombol(String(n), n, false, n === halaman);
      }
      tombol("›", halaman + 1, halaman === akhir);
    }
    pilih.addEventListener("change", () => { simpan.tulis(kunci + ":per", Number(pilih.value)); halaman = 1; gambar(); });
    gambar();
  }

  // --- Aksi massal ------------------------------------------------------------
  async function ambilMeta(entitas) {
    if (meta.has(entitas)) return meta.get(entitas);
    const janji = fetch("/massal/" + entitas + "/meta", { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : null)).catch(() => null);
    meta.set(entitas, janji);
    return janji;
  }

  async function kirim(url, data) {
    data.append("csrf_token", csrf());
    const response = await fetch(url, { method: "POST", body: data, credentials: "same-origin", headers: { Accept: "application/json" } });
    let jawaban = null;
    try { jawaban = await response.json(); } catch (e) { /* bukan JSON */ }
    if (response.ok && jawaban && jawaban.ok) return jawaban;
    throw new Error((jawaban && jawaban.error) || (response.status === 403 ? "Anda tidak berhak melakukan ini." : "Gagal (HTTP " + response.status + ")."));
  }

  function dialog(judul, isiHtml) {
    const d = buat("dialog", "dialog");
    d.innerHTML =
      '<form method="dialog" class="dialog__isi" data-live="off">' +
      '<div class="dialog__kepala"><strong>' + judul + '</strong>' +
      '<button class="aksi-ikon" type="button" data-tutup aria-label="Tutup">' + ikon("x") + '</button></div>' +
      '<div class="dialog__badan">' + isiHtml + '</div>' +
      '<p class="form__galat" data-galat hidden></p>' +
      '<div class="dialog__aksi"><button class="tombol" type="button" data-tutup>Batal</button>' +
      '<button class="tombol tombol--utama" type="submit" data-kirim>Simpan</button></div></form>';
    document.body.append(d);
    d.addEventListener("close", () => d.remove());
    d.querySelectorAll("[data-tutup]").forEach((t) => t.addEventListener("click", () => d.close()));
    d.addEventListener("click", (e) => { if (e.target === d) d.close(); });
    if (window.lucide) window.lucide.createIcons();
    d.showModal();
    return d;
  }

  function jalankan(d, kerja) {
    const form = d.querySelector("form");
    const galat = d.querySelector("[data-galat]");
    const tombol = d.querySelector("[data-kirim]");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      galat.hidden = true;
      tombol.disabled = true;
      try {
        const jawaban = await kerja();
        d.close();
        beriTahu(jawaban.pesan || "Selesai.");
        await segarkan();
      } catch (e) {
        galat.textContent = e.message;
        galat.hidden = false;
      } finally {
        tombol.disabled = false;
      }
    });
  }

  function pasangPilih(tabel, info, bilah) {
    const entitas = tabel.dataset.entitas;
    const baris = Array.from(tabel.tBodies[0].rows).filter((tr) => tr.dataset.id);
    if (!baris.length) return;
    const kotakSemua = buat("input");
    kotakSemua.type = "checkbox";
    kotakSemua.setAttribute("aria-label", "Pilih semua baris");
    const th = buat("th", "tabel__pilih");
    th.append(kotakSemua);
    tabel.tHead.rows[0].prepend(th);
    Array.from(tabel.tBodies[0].rows).forEach((tr) => {
      if (!tr.dataset.id) {
        const sel = tr.querySelector("td[colspan]");
        if (sel) sel.colSpan += 1;
        return;
      }
      const td = buat("td", "tabel__pilih");
      const kotak = buat("input");
      kotak.type = "checkbox";
      kotak.value = tr.dataset.id;
      kotak.setAttribute("aria-label", "Pilih baris");
      td.append(kotak);
      td.addEventListener("click", (e) => e.stopPropagation());
      tr.prepend(td);
    });

    const terpilih = () => baris.filter((tr) => tr.querySelector(".tabel__pilih input").checked);
    const jumlah = buat("strong", "tabel-massal__jumlah");
    const kanan = buat("div", "tabel-massal__aksi");
    const tombolBatal = buat("button", "tabel-massal__batal", "Batalkan pilihan");
    const tombolUbah = buat("button", "tombol tombol--kecil");
    const tombolHapus = buat("button", "tombol tombol--kecil tombol--bahaya");
    [tombolUbah, tombolHapus, tombolBatal].forEach((t) => { t.type = "button"; });
    kanan.append(tombolBatal);
    if (info.medan && info.medan.length) kanan.append(tombolUbah);
    if (info.hapus) kanan.append(tombolHapus);
    bilah.append(jumlah, kanan);

    function perbarui() {
      const dipilih = terpilih();
      baris.forEach((tr) => tr.classList.toggle("tabel__baris--dipilih", tr.querySelector(".tabel__pilih input").checked));
      bilah.hidden = dipilih.length === 0;
      jumlah.textContent = dipilih.length + " baris dipilih";
      tombolUbah.innerHTML = ikon("pencil") + " Ubah massal (" + dipilih.length + ")";
      tombolHapus.innerHTML = ikon("trash-2") + " Hapus terpilih (" + dipilih.length + ")";
      if (window.lucide) window.lucide.createIcons();
      const tampak = baris.filter((tr) => !tr.hidden);
      kotakSemua.checked = tampak.length > 0 && tampak.every((tr) => tr.querySelector(".tabel__pilih input").checked);
      kotakSemua.indeterminate = !kotakSemua.checked && dipilih.length > 0;
    }
    tabel.addEventListener("change", (e) => { if (e.target.closest(".tabel__pilih")) perbarui(); });
    kotakSemua.addEventListener("change", () => {
      baris.filter((tr) => !tr.hidden).forEach((tr) => { tr.querySelector(".tabel__pilih input").checked = kotakSemua.checked; });
      perbarui();
    });
    tombolBatal.addEventListener("click", () => {
      baris.forEach((tr) => { tr.querySelector(".tabel__pilih input").checked = false; });
      perbarui();
    });

    const dataIds = () => {
      const data = new FormData();
      terpilih().forEach((tr) => data.append("id", tr.dataset.id));
      return data;
    };

    tombolHapus.addEventListener("click", () => {
      const n = terpilih().length;
      const d = dialog("Hapus " + n + " " + info.label + "?",
        "<p>Data yang dihapus tidak bisa dikembalikan, termasuk data turunannya. " +
        "Bila satu saja tidak boleh dihapus, tidak ada yang dihapus.</p>" +
        '<label class="form__label" for="konfirmasi-hapus">Ketik HAPUS untuk melanjutkan</label>' +
        '<input class="form__isian" id="konfirmasi-hapus" autocomplete="off" required pattern="HAPUS">');
      const tombol = d.querySelector("[data-kirim]");
      tombol.textContent = "Hapus " + n + " baris";
      tombol.classList.replace("tombol--utama", "tombol--bahaya");
      jalankan(d, () => {
        if (d.querySelector("#konfirmasi-hapus").value !== "HAPUS") throw new Error("Ketik HAPUS (huruf besar) untuk melanjutkan.");
        return kirim("/massal/" + entitas + "/hapus", dataIds());
      });
    });

    tombolUbah.addEventListener("click", () => {
      const n = terpilih().length;
      const pilihanMedan = info.medan.map((m, i) => '<option value="' + i + '">' + m.label + "</option>").join("");
      const d = dialog("Ubah " + n + " " + info.label,
        '<label class="form__label" for="massal-medan">Yang diubah</label>' +
        '<select class="form__isian" id="massal-medan">' + pilihanMedan + "</select>" +
        '<label class="form__label" for="massal-nilai">Menjadi</label>' +
        '<select class="form__isian" id="massal-nilai"></select>');
      const medan = d.querySelector("#massal-medan");
      const nilai = d.querySelector("#massal-nilai");
      const isi = () => {
        nilai.innerHTML = info.medan[Number(medan.value)].pilihan
          .map((p) => '<option value="' + p[0] + '">' + p[1] + "</option>").join("");
      };
      medan.addEventListener("change", isi);
      isi();
      d.querySelector("[data-kirim]").textContent = "Ubah " + n + " baris";
      jalankan(d, () => {
        const data = dataIds();
        data.append("medan", info.medan[Number(medan.value)].nama);
        data.append("nilai", nilai.value);
        return kirim("/massal/" + entitas + "/ubah", data);
      });
    });
  }

  function tombolImpor(entitas, info) {
    const tombol = buat("button", "tombol", ikon("upload") + " Impor");
    tombol.type = "button";
    tombol.addEventListener("click", () => {
      const wajib = info.kolom.filter((k) => k.wajib).map((k) => "<code>" + k.nama + "</code>").join(", ");
      const d = dialog("Impor " + info.label,
        "<p>Unggah berkas CSV. Kolom wajib: " + (wajib || "—") + ". " +
        'Mulai dari <a href="/massal/' + entitas + '/templat.csv" data-live="off" download>templat ini</a> supaya nama kolomnya persis.</p>' +
        '<label class="form__label" for="impor-berkas">Berkas CSV</label>' +
        '<input class="form__isian" id="impor-berkas" type="file" accept=".csv,text/csv" required>' +
        '<p class="form__bantuan" data-bantuan-tetap>Bila satu baris gagal, tidak ada yang tersimpan.</p>');
      d.querySelector("[data-kirim]").textContent = "Impor";
      jalankan(d, () => {
        const berkas = d.querySelector("#impor-berkas").files[0];
        if (!berkas) throw new Error("Pilih berkas CSV dulu.");
        const data = new FormData();
        data.append("berkas", berkas);
        return kirim("/massal/" + entitas + "/impor", data);
      });
    });
    return tombol;
  }

  // --- Bilah alat: cari, saring, cip ------------------------------------------
  const BUKAN_SARINGAN = new Set(["q", "page", "per_page", "tab"]);

  // Formulir GET utama halaman: yang paling banyak isiannya. Formulir GET
  // lain yang hanya berisi kotak cari adalah kembarannya dan dibuang.
  function formulirSaring(halaman, kartuTabel) {
    // Termasuk formulir di dalam kartu tabelnya sendiri (halaman Network
    // menaruh saringannya di sana); yang dikecualikan hanya paginasi.
    const calon = Array.from(halaman.querySelectorAll('form[method="get" i]')).filter((f) =>
      !f.closest(".paginasi, dialog") && !f.dataset.alat);
    if (!calon.length) return { utama: null, lain: [] };
    const bobot = (f) => f.querySelectorAll("input[name], select[name]").length;
    calon.sort((a, b) => bobot(b) - bobot(a));
    return { utama: calon[0], lain: calon.slice(1) };
  }

  function medanAktif(form) {
    const aktif = [];
    if (!form) return aktif;
    form.querySelectorAll("select[name], input[name]").forEach((medan) => {
      if (BUKAN_SARINGAN.has(medan.name) || medan.type === "hidden" || !medan.value) return;
      if ((medan.type === "checkbox" || medan.type === "radio") && !medan.checked) return;
      const label = form.querySelector('label[for="' + medan.id + '"]');
      const nilai = medan.tagName === "SELECT" ? medan.options[medan.selectedIndex].text.trim() : medan.value;
      aktif.push({ nama: medan.name, label: label ? label.textContent.trim() : medan.name, nilai });
    });
    return aktif;
  }

  function alamatTanpa(nama) {
    const alamat = new URL(location.href);
    if (nama) alamat.searchParams.delete(nama);
    else Array.from(alamat.searchParams.keys()).forEach((k) => { if (k !== "per_page" && k !== "tab") alamat.searchParams.delete(k); });
    alamat.searchParams.delete("page");
    return alamat.pathname + (alamat.search || "");
  }

  function kotakCari(form, tabel) {
    const bungkus = buat("div", "alat__cari");
    bungkus.innerHTML = ikon("search");
    let isian = form ? form.querySelector('input[name="q"]') : null;
    if (isian) {
      // Dipindah keluar dari formulirnya tetapi tetap terkait lewat `form=`,
      // jadi Enter mengirim formulir saringan yang sama.
      if (!form.id) form.id = "form-saring-" + (++hitung);
      isian.setAttribute("form", form.id);
      const labelLama = form.querySelector('label[for="' + isian.id + '"]');
      if (labelLama) labelLama.remove();
      isian.className = "alat__cari-isian";
      isian.type = "search";
      if (!isian.placeholder) isian.placeholder = "Cari…";
    } else {
      // Tabel tanpa pencarian server: saring baris yang sedang tampil.
      isian = buat("input", "alat__cari-isian");
      isian.type = "search";
      isian.placeholder = "Cari di tabel ini…";
      isian.setAttribute("aria-label", "Cari di tabel ini");
      isian.addEventListener("input", () => {
        const kata = isian.value.trim().toLowerCase();
        Array.from(tabel.tBodies[0].rows).forEach((tr) => {
          if (tr.querySelector("td[colspan]")) return;
          tr.classList.toggle("tabel__baris--tersaring", Boolean(kata) && !tr.textContent.toLowerCase().includes(kata));
        });
        tabel.dispatchEvent(new CustomEvent("cusnet:baris-berubah"));
      });
    }
    bungkus.append(isian);
    return bungkus;
  }

  let hitungMedan = 0;

  function panelSaring(form) {
    // Sisa formulir (tanpa kotak cari) menjadi panel saringan satu baris.
    const panel = buat("div", "alat__panel");
    panel.hidden = true;
    form.dataset.alat = "1";
    form.className = "alat__saring";
    // Kotak cari versi lama beserta pembungkusnya tidak dipakai lagi.
    form.querySelectorAll(".cari, .filter-panel__medan, .form-grid__medan").forEach((b) => {
      if (!b.querySelector("input[name], select[name], button, a")) b.remove();
    });
    const tombol = form.querySelector('button[type="submit"], button:not([type])');
    if (tombol) { tombol.className = "tombol tombol--utama tombol--kecil"; tombol.innerHTML = "Terapkan"; }

    // Semua halaman berakhir dengan susunan yang sama: tiap isian di dalam
    // medan berlabel kecil, tombol Terapkan di medan aksi paling akhir.
    // Isian telanjang (tanpa label) diberi label dari pilihan pertamanya —
    // "Semua Kategori" menjadi "Kategori".
    const labelDari = (isian) => {
      const pertama = isian.tagName === "SELECT" && isian.options.length ? isian.options[0].text.trim() : "";
      const teks = isian.getAttribute("aria-label") || pertama.replace(/^(Semua|Pilih)\s+/i, "") ||
        isian.getAttribute("placeholder") || isian.name;
      return teks.charAt(0).toUpperCase() + teks.slice(1);
    };
    Array.from(form.children).forEach((anak) => {
      if (!anak.matches("select, input:not([type=hidden])")) return;
      const medan = buat("div", "filter-panel__medan");
      if (!anak.id) anak.id = "saring-" + anak.name + "-" + (++hitungMedan);
      const label = buat("label", "form__label", labelDari(anak));
      label.htmlFor = anak.id;
      anak.classList.add("form__isian");
      anak.replaceWith(medan);
      medan.append(label, anak);
    });
    if (tombol && tombol.parentElement === form) {
      const aksi = buat("div", "filter-panel__medan filter-panel__medan--aksi");
      tombol.replaceWith(aksi);
      aksi.append(tombol);
    }
    const aksi = form.querySelector(".filter-panel__medan--aksi");
    if (aksi) form.append(aksi);
    panel.append(form);
    return panel;
  }

  function cipSaring(aktif) {
    if (!aktif.length) return null;
    const baris = buat("div", "alat__cip-baris");
    baris.append(buat("span", "alat__cip-label", "Disaring:"));
    aktif.forEach((satu) => {
      const cip = buat("span", "alat__cip");
      cip.append(document.createTextNode(satu.label + ": " + satu.nilai));
      const lepas = buat("a", "alat__cip-lepas", "×");
      lepas.href = alamatTanpa(satu.nama);
      lepas.setAttribute("aria-label", "Lepas saringan " + satu.label);
      cip.append(lepas);
      baris.append(cip);
    });
    if (aktif.length > 1) {
      const semua = buat("a", "alat__cip-semua", "Lepas semua");
      semua.href = alamatTanpa(null);
      baris.append(semua);
    }
    return baris;
  }

  // --- Merakit satu tabel -----------------------------------------------------
  let hitung = 0;

  function tabelUtama(halaman) {
    // Tabel daftar halaman: yang ber-entitas, atau yang sekartu dengan paginasi.
    const semua = Array.from(halaman.querySelectorAll("table.tabel"));
    return semua.find((t) => t.dataset.entitas) ||
      semua.find((t) => { const k = t.closest(".kartu"); return k && k.querySelector(".paginasi"); }) || null;
  }

  async function rakit(tabel, utama) {
    if (tabel.dataset.tabelSiap || tabel.dataset.tabel === "polos") return;
    if (!tabel.tHead || !tabel.tHead.rows.length || !tabel.tBodies.length) return;
    if (tabel.classList.contains("tabel--rapat") || tabel.closest(".tabel--rapat, dialog")) return;
    tabel.dataset.tabelSiap = "1";
    const kunci = kunciTabel(tabel, ++hitung);
    const halaman = document.getElementById("konten-utama") || document;
    const kartu = tabel.closest(".kartu, .db-panel") || tabel.parentElement;
    const bacaSaja = Boolean(tabel.closest(".isi--baca-saja"));
    // Kartu tanpa padding hanya untuk kartu yang isinya memang tabel. Kartu
    // campuran (rincian + tabel, seperti Detail Invoice) tetap berpadding.
    const hanyaTabel = () => Array.from(kartu.children).every((anak) =>
      anak.matches(".panel__kepala, .panel__judul, .form__bantuan, .tabel-bungkus, table, .paginasi, .tabel-massal, .bantuan-pop, [hidden]"));
    const tandaiKartu = () => kartu.classList.toggle("tabel-kartu", utama || hanyaTabel());

    // Pembungkus bergulir: kolom yang dilebarkan tidak melebarkan halaman.
    let bungkus = tabel.parentElement;
    if (!bungkus.classList.contains("tabel-bungkus")) {
      bungkus = buat("div", "tabel-bungkus");
      tabel.before(bungkus);
      bungkus.append(tabel);
    }
    const perbaruiBayang = () => {
      bungkus.toggleAttribute("data-ada-kanan", bungkus.scrollWidth - bungkus.clientWidth - bungkus.scrollLeft > 1);
    };
    bungkus.addEventListener("scroll", perbaruiBayang, { passive: true });
    if (window.ResizeObserver) new ResizeObserver(perbaruiBayang).observe(bungkus);

    // Kolom aksi lengket di kanan.
    const kepala = Array.from(tabel.tHead.rows[0].cells);
    const iAksi = kepala.findIndex((th) => /^aksi$/i.test(th.textContent.trim()));
    if (iAksi >= 0) {
      tabel.querySelectorAll("tr").forEach((tr) => {
        const sel = tr.cells[iAksi];
        if (sel && sel.colSpan === 1) sel.classList.add("tabel__aksi-lengket");
      });
    }
    // Keadaan kosong.
    tabel.querySelectorAll("tbody td[colspan]").forEach((sel) => {
      if (sel.closest("tr").dataset.id || sel.querySelector(".tabel-kosong")) return;
      const teks = sel.textContent.trim();
      sel.innerHTML = '<div class="tabel-kosong"><span class="tabel-kosong__ikon">' + ikon("inbox") + "</span><strong>" + teks + "</strong></div>";
    });

    const bilah = buat("div", "tabel-massal");
    bilah.hidden = true;
    bungkus.before(bilah);

    if (utama) {
      // ── Bilah alat standar ──
      const { utama: form, lain } = formulirSaring(halaman, kartu);
      const aktif = medanAktif(form);
      const alat = buat("div", "kartu alat");
      const baris = buat("div", "alat__baris");
      const kanan = buat("div", "alat__kanan");
      alat.append(baris);
      baris.append(kotakCari(form, tabel));

      // Pembungkus lama (bilah, <details> saringan) — dipungut isinya, lalu dibuang.
      const lama = new Set();
      const catatLama = (unsur) => {
        if (!unsur) return;
        const p = unsur.closest(".filter-lanjutan, .daftar-toolbar, .customer-toolbar, .billing-toolbar, .layanan-toolbar, .filter-baris");
        if (p && !p.matches("form")) lama.add(p.closest(".daftar-toolbar") || p);
      };
      [form, ...lain].forEach(catatLama);
      halaman.querySelectorAll(".daftar-toolbar, .filter-lanjutan").forEach((p) => { lama.add(p.closest(".daftar-toolbar") || p); });

      if (form) {
        const medanLain = Array.from(form.querySelectorAll("select[name], input[name]")).filter((m) => !BUKAN_SARINGAN.has(m.name) && m.type !== "hidden");
        const nSaring = aktif.filter((a) => a.nama !== "q").length;
        if (medanLain.length) {
          const tombol = buat("button", "tombol alat__saring-tombol" + (nSaring ? " alat__saring-tombol--aktif" : ""), ikon("filter") + " Saring");
          tombol.type = "button";
          tombol.setAttribute("aria-expanded", "false");
          if (nSaring) tombol.append(buat("span", "alat__hitung", String(nSaring)));
          const panel = panelSaring(form);
          tombol.addEventListener("click", () => {
            panel.hidden = !panel.hidden;
            tombol.setAttribute("aria-expanded", panel.hidden ? "false" : "true");
          });
          baris.append(tombol);
          alat.append(panel);
        } else {
          // Hanya kotak cari: formulirnya tetap ada tetapi tidak terlihat.
          form.dataset.alat = "1";
          form.hidden = true;
          alat.append(form);
        }
      }
      lain.forEach((f) => f.remove());

      // Tautan ekspor ikut pindah ke kanan. Pemilih kolom versi server
      // dibuang: ia butuh formulir POST-nya sendiri dan muat ulang halaman,
      // sedangkan pemilih standar di bawah bekerja seketika di semua tabel.
      const pungut = [];
      lama.forEach((p) => {
        p.querySelectorAll("details.pemilih-kolom").forEach((d) => {
          const formKolom = d.closest("form");
          (formKolom && !formKolom.querySelector("table") ? formKolom : d).remove();
        });
        p.querySelectorAll("a.tombol").forEach((a) => pungut.push(a));
      });
      let adaKolom = false, adaEkspor = false;
      pungut.forEach((unsur) => {
        if (unsur.matches("details")) {
          adaKolom = true;
          unsur.classList.add("tabel-alat__kolom");
          const ringkas = unsur.querySelector("summary");
          if (ringkas) ringkas.className = "tombol tombol--kecil";
        } else {
          unsur.className = "tombol tombol--kecil";
          if (/ekspor/i.test(unsur.textContent)) adaEkspor = true;
        }
        kanan.append(unsur);
      });
      lama.forEach((p) => p.remove());

      if (!adaKolom) kanan.prepend(menuKolom(tabel, kunci));
      if (!adaEkspor) {
        const tombol = buat("button", "tombol tombol--kecil", ikon("download") + " Ekspor");
        tombol.type = "button";
        tombol.addEventListener("click", () => eksporCsv(tabel));
        kanan.append(tombol);
      }
      const entitas = tabel.dataset.entitas;
      if (entitas && !bacaSaja) {
        const info = await ambilMeta(entitas);
        if (info && (info.hapus || (info.medan && info.medan.length))) pasangPilih(tabel, info, bilah);
        if (info && info.impor) { const t = tombolImpor(entitas, info); t.className = "tombol tombol--kecil"; kanan.append(t); }
      }
      if (tabel.dataset.imporUrl && !bacaSaja) {
        const tautan = buat("a", "tombol tombol--kecil", ikon("upload") + " Impor");
        tautan.href = tabel.dataset.imporUrl;
        kanan.append(tautan);
      }
      baris.append(kanan);
      kartu.before(alat);
      const cip = cipSaring(aktif);
      if (cip) kartu.before(cip);
    }

    tandaiKartu();
    pasangLebar(tabel, kunci);
    if (!kartu.querySelector(".paginasi")) paginasiLokal(tabel, kunci, bungkus);
    perbaruiBayang();
    if (window.lucide) window.lucide.createIcons();
  }

  function rakitSemua() {
    const halaman = document.getElementById("konten-utama");
    if (!halaman) return;
    const utama = tabelUtama(halaman);
    halaman.querySelectorAll("table.tabel").forEach((tabel) => { rakit(tabel, tabel === utama); });
    document.documentElement.classList.remove("tabel-menunggu");
  }

  document.addEventListener("DOMContentLoaded", rakitSemua);
  document.addEventListener("cusnet:isi-berubah", rakitSemua);
  document.addEventListener("htmx:afterSettle", rakitSemua);
  // Menu Kolom menutup saat diklik di luarnya.
  document.addEventListener("click", (event) => {
    document.querySelectorAll("details.tabel-alat__kolom[open]").forEach((d) => {
      if (!d.contains(event.target)) d.open = false;
    });
  });
})();
