"""pilihan tiket otomatis pemantauan dan bot Telegram

Revision ID: 0034
Revises: 0033
Create Date: 2026-10-09 03:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0034"
down_revision: Union[str, None] = "0033"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "app_branding",
        sa.Column("monitor_auto_ticket", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )
    op.add_column("app_branding", sa.Column("telegram_bot_token", sa.String(120), nullable=True))
    op.add_column("app_branding", sa.Column("telegram_chat_id", sa.String(60), nullable=True))


def downgrade() -> None:
    for kolom in ("telegram_chat_id", "telegram_bot_token", "monitor_auto_ticket"):
        op.drop_column("app_branding", kolom)
