"""audit_log.created_at: default yang membeku diganti now()

Migrasi 0001 menulis `server_default='now()'` sebagai TEKS. Postgres
mengubah teks 'now()' menjadi nilai waktu SAAT TABEL DIBUAT, lalu memakai
nilai tetap itu sebagai default selamanya. Akibatnya setiap entri audit log
bercap waktu pemasangan, bukan waktu kejadiannya.

Yang dikerjakan di sini:

1. Default diganti `now()` yang sungguhan, jadi entri baru benar.
2. Entri lama yang masih memuat nilai beku itu dipulihkan sebisanya:
   - entri `create` mengambil `created_at` baris yang dibuatnya — keduanya
     ditulis dalam transaksi yang sama, jadi nilainya memang identik;
   - entri lain (ubah, hapus, atau `create` yang barisnya sudah dihapus)
     mengambil waktu entri terpulihkan TERAKHIR SEBELUM dirinya menurut
     urutan id. Itu batas bawah, bukan waktu pasti: kejadiannya tidak lebih
     awal dari itu. Waktu pastinya tidak tersimpan di mana pun.

Revision ID: 0035
Revises: 0034
Create Date: 2026-10-09 04:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0035"
down_revision: Union[str, None] = "0034"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Nama entitas di audit log yang tidak sama dengan nama tabelnya.
TABEL_ENTITAS = {"user": "app_user"}


def upgrade() -> None:
    koneksi = op.get_bind()
    beku = koneksi.execute(
        sa.text(
            "SELECT pg_get_expr(d.adbin, d.adrelid) FROM pg_attrdef d "
            "JOIN pg_attribute a ON a.attrelid = d.adrelid AND a.attnum = d.adnum "
            "WHERE d.adrelid = 'audit_log'::regclass AND a.attname = 'created_at'"
        )
    ).scalar()
    op.alter_column("audit_log", "created_at", server_default=sa.text("now()"))
    if not beku or "now()" in beku or "::timestamp" not in beku:
        return  # Default sudah benar: tidak ada entri yang perlu dipulihkan.

    nilai_beku = koneksi.execute(sa.text(f"SELECT {beku}")).scalar()
    tabel = {
        nama
        for (nama,) in koneksi.execute(
            sa.text(
                "SELECT c.table_name FROM information_schema.columns c "
                "WHERE c.table_schema = current_schema() AND c.column_name = 'created_at' "
                "AND EXISTS (SELECT 1 FROM information_schema.columns i "
                "WHERE i.table_schema = c.table_schema AND i.table_name = c.table_name "
                "AND i.column_name = 'id')"
            )
        )
    }
    jenis = [
        baris[0]
        for baris in koneksi.execute(
            sa.text("SELECT DISTINCT entity_type FROM audit_log WHERE action = 'create'")
        )
    ]
    for entitas in jenis:
        nama = TABEL_ENTITAS.get(entitas, entitas)
        if nama not in tabel or nama == "audit_log":
            continue
        koneksi.execute(
            sa.text(
                f'UPDATE audit_log a SET created_at = t.created_at FROM "{nama}" t '
                "WHERE a.action = 'create' AND a.entity_type = :entitas "
                "AND a.entity_id = t.id AND a.created_at = :beku"
            ),
            {"entitas": entitas, "beku": nilai_beku},
        )
    # Sisanya: batas bawah dari entri terpulihkan terakhir sebelum dirinya.
    koneksi.execute(
        sa.text(
            "UPDATE audit_log a SET created_at = s.perkiraan FROM ("
            "  SELECT id, max(CASE WHEN created_at <> :beku THEN created_at END) "
            "         OVER (ORDER BY id ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS perkiraan "
            "  FROM audit_log"
            ") s WHERE a.id = s.id AND a.created_at = :beku AND s.perkiraan IS NOT NULL"
        ),
        {"beku": nilai_beku},
    )


def downgrade() -> None:
    # Default yang membeku tidak dipasang kembali, dan waktu yang sudah
    # dipulihkan tidak dikembalikan ke nilai yang salah.
    pass
