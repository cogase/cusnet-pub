"""SNMP lanjutan: trafik port, alamat IP, dan sesi BGP perangkat

Revision ID: 0036
Revises: 0035
Create Date: 2026-10-09 05:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0036"
down_revision: Union[str, None] = "0035"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _cap():
    return [
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    ]


def upgrade() -> None:
    op.add_column(
        "device", sa.Column("snmp_poll", sa.Boolean(), nullable=False, server_default=sa.text("false"))
    )
    op.add_column("device", sa.Column("snmp_error", sa.String(255), nullable=True))
    op.add_column("device_port", sa.Column("if_type", sa.Integer(), nullable=True))
    op.add_column("device_port", sa.Column("last_in_octets", sa.Numeric(20, 0), nullable=True))
    op.add_column("device_port", sa.Column("last_out_octets", sa.Numeric(20, 0), nullable=True))
    op.add_column(
        "device_port", sa.Column("last_counter_at", sa.DateTime(timezone=True), nullable=True)
    )
    op.create_table(
        "port_traffic",
        sa.Column("id", sa.BigInteger(), primary_key=True),
        sa.Column("port_id", sa.Integer(), sa.ForeignKey("device_port.id", ondelete="CASCADE"), nullable=False),
        sa.Column("device_id", sa.Integer(), sa.ForeignKey("device.id", ondelete="CASCADE"), nullable=False),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("in_bps", sa.BigInteger(), nullable=False),
        sa.Column("out_bps", sa.BigInteger(), nullable=False),
    )
    op.create_index("ix_port_traffic_port_at", "port_traffic", ["port_id", "at"])
    op.create_index("ix_port_traffic_device_at", "port_traffic", ["device_id", "at"])
    op.create_table(
        "device_ip",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("device_id", sa.Integer(), sa.ForeignKey("device.id", ondelete="CASCADE"), nullable=False),
        sa.Column("address", sa.String(45), nullable=False),
        sa.Column("prefix_len", sa.Integer(), nullable=True),
        sa.Column("if_name", sa.String(60), nullable=True),
        sa.Column("ip_block_id", sa.Integer(), sa.ForeignKey("ip_block.id", ondelete="SET NULL"), nullable=True),
        *_cap(),
        sa.UniqueConstraint("device_id", "address", name="uq_device_ip"),
    )
    op.create_index("ix_device_ip_device_id", "device_ip", ["device_id"])
    op.create_table(
        "device_bgp_peer",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("device_id", sa.Integer(), sa.ForeignKey("device.id", ondelete="CASCADE"), nullable=False),
        sa.Column("remote_addr", sa.String(45), nullable=False),
        sa.Column("remote_as", sa.BigInteger(), nullable=True),
        sa.Column("state", sa.String(20), nullable=False),
        sa.Column("established_seconds", sa.BigInteger(), nullable=True),
        *_cap(),
        sa.UniqueConstraint("device_id", "remote_addr", name="uq_device_bgp_peer"),
    )
    op.create_index("ix_device_bgp_peer_device_id", "device_bgp_peer", ["device_id"])


def downgrade() -> None:
    op.drop_table("device_bgp_peer")
    op.drop_table("device_ip")
    op.drop_table("port_traffic")
    for kolom in ("last_counter_at", "last_out_octets", "last_in_octets", "if_type"):
        op.drop_column("device_port", kolom)
    op.drop_column("device", "snmp_error")
    op.drop_column("device", "snmp_poll")
