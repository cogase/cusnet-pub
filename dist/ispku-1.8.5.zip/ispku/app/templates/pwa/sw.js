/* Service worker ISPKU CRM.
 *
 * ATURAN YANG TIDAK BOLEH DILANGGAR: halaman terautentikasi tidak pernah
 * disimpan. Halaman pelanggan, invoice, dan laporan memuat data yang hanya
 * boleh dilihat peran tertentu; menaruhnya di cache peramban berarti data itu
 * bertahan di perangkat setelah pengguna keluar, dan bisa dibaca siapa pun
 * yang memegang perangkat itu berikutnya.
 *
 * Yang disimpan hanya aset statis (CSS, font, JS pihak ketiga, ikon) dan satu
 * halaman luring yang tidak memuat data apa pun.
 *
 * Berkas ini dirender dari templat supaya nama cache ikut versi aplikasi —
 * pemasangan versi baru otomatis membuang aset versi lama.
 */

const VERSI = "{{ app_version }}";
const CACHE = "ispku-" + VERSI;
const LURING = "{{ url_for('pwa.luring') }}";

const ASET = [
  LURING,
  "{{ url_for('static', filename='css/tokens.css') }}",
  "{{ url_for('static', filename='css/app.css') }}?v={{ app_version }}",
  "{{ url_for('static', filename='css/login.css') }}",
  "{{ url_for('static', filename='css/standar.css') }}?v={{ app_version }}",
  "{{ url_for('static', filename='fonts/pakapps/inter-latin-wght-normal.woff2') }}",
  "{{ url_for('static', filename='fonts/pakapps/jetbrains-mono-latin-wght-normal.woff2') }}",
  "{{ url_for('static', filename='vendor/htmx.min.js') }}",
  "{{ url_for('static', filename='vendor/alpine.min.js') }}",
  "{{ url_for('static', filename='vendor/lucide.min.js') }}",
  "{{ url_for('static', filename='js/live.js') }}?v={{ app_version }}",
  "{{ url_for('static', filename='img/logo.svg') }}",
  "{{ url_for('static', filename='img/ikon-192.png') }}",
  "{{ url_for('static', filename='img/ikon-512.png') }}",
];

self.addEventListener("install", (peristiwa) => {
  peristiwa.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASET)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (peristiwa) => {
  peristiwa.waitUntil(
    caches.keys()
      .then((nama) => Promise.all(
        nama.filter((n) => n !== CACHE).map((n) => caches.delete(n))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (peristiwa) => {
  const permintaan = peristiwa.request;

  // POST, PUT, dan DELETE lewat tanpa disentuh — mencatat pembayaran atau
  // menerbitkan invoice tidak boleh punya jalur cache sama sekali.
  if (permintaan.method !== "GET") return;

  const url = new URL(permintaan.url);
  if (url.origin !== self.location.origin) return;

  // Permintaan halaman: jaringan dulu, dan bila jaringan gagal jatuh ke
  // halaman luring. Responsnya TIDAK PERNAH disimpan.
  if (permintaan.mode === "navigate") {
    peristiwa.respondWith(
      fetch(permintaan).catch(() => caches.match(LURING))
    );
    return;
  }

  // Aset statis: cache dulu. Yang belum ada diambil dari jaringan lalu
  // disimpan, supaya aset baru ikut terkumpul tanpa menaikkan versi.
  if (url.pathname.startsWith("/static/")) {
    peristiwa.respondWith(
      caches.match(permintaan).then((tersimpan) => {
        if (tersimpan) return tersimpan;
        return fetch(permintaan).then((respons) => {
          if (respons.ok) {
            const salinan = respons.clone();
            caches.open(CACHE).then((cache) => cache.put(permintaan, salinan));
          }
          return respons;
        });
      })
    );
    return;
  }

  // Sisanya — unduhan dokumen, bukti bayar, ekspor CSV — dibiarkan lewat
  // apa adanya. Semuanya berpenjaga cabang di sisi peladen.
});
